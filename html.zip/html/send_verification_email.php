<?php
// Admin email verification endpoint - uses PHPMailer via email_service.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Include email configuration and service (PHPMailer)
require_once 'email_config.php';
require_once 'email_service.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $code = $_POST['code'] ?? '';
    $action = $_POST['action'] ?? '';
    
    if ($action === 'send_verification' && $email && $code) {
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid email format'
            ]);
            exit;
        }
        
        // Validate admin email (security check)
        if ($email !== 'larsvgennip@gmail.com') {
            echo json_encode([
                'success' => false,
                'message' => 'Unauthorized email address'
            ]);
            exit;
        }
        
        // Validate code format (6 digits)
        if (!preg_match('/^[0-9]{6}$/', $code)) {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid verification code format'
            ]);
            exit;
        }
        
        try {
            $result = EmailService::sendVerificationCode($email, $code);
            
            if ($result) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Verification email sent successfully'
                ]);
                error_log("Admin verification code sent to: $email");
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to send verification email'
                ]);
                error_log("Failed to send admin verification code to: $email");
            }
        } catch (Exception $e) {
            error_log("Error in send_verification_email.php: " . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'Email service error: ' . $e->getMessage()
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid request parameters'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Only POST method allowed'
    ]);
}
?>
<?php
require_once 'access_control.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>OopsNowh</title>
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
    <link rel="shortcut icon" href="favicon.svg" type="image/svg+xml">
    <link rel="stylesheet" href="styles.css?v=53&nocache=1756044800000">
    <link rel="stylesheet" href="css/social.css?v=53&nocache=1756044800000">
    <style>
        .lobby-card.offline {
            opacity: 0.6;
            cursor: not-allowed;
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.1);
        }

        .lobby-card.offline:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.1);
            transform: none;
            box-shadow: none;
        }

        .lobby-card.offline .lobby-status {
            color: #ff6b6b;
        }

        .lobby-card.online .lobby-status {
            color: #51cf66;
        }

        .lobby-status {
            font-size: 12px;
            font-weight: bold;
            margin-top: 8px;
            text-align: center;
        }

        .server-status {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            background: rgba(0, 0, 0, 0.8);
            border-radius: 8px;
            padding: 8px 12px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .status-indicator {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            font-weight: 500;
        }

        .main-logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-circle {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: logoFloat 2s ease-in-out infinite;
        }

        .logo-circle svg {
            width: 100%;
            height: 100%;
        }

        @keyframes logoFloat {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-5px); }
        }

        .welcome-logo {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .welcome-logo svg {
            width: 100%;
            height: 100%;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #ffa500;
            animation: pulse 2s infinite;
        }

        .server-status.online .status-dot {
            background: #51cf66;
            animation: none;
        }

        .server-status.offline .status-dot {
            background: #ff6b6b;
            animation: none;
        }

        .server-status.online .status-text {
            color: #51cf66;
        }

        .server-status.offline .status-text {
            color: #ff6b6b;
        }

        .server-status .status-text {
            color: #ffa500;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        /* Responsive Design for Mobile Devices */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
                max-width: 100%;
            }

            .header {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }

            .main-logo {
                justify-content: center;
            }

            .logo-circle {
                width: 50px;
                height: 50px;
            }

            .user-welcome {
                text-align: center;
                order: -1;
            }

            .user-actions {
                justify-content: center;
                flex-wrap: wrap;
                gap: 10px;
            }

            .server-status {
                position: relative;
                top: auto;
                right: auto;
                margin: 10px auto;
                width: fit-content;
            }

            .main-content {
                flex-direction: column;
                gap: 20px;
            }

            .left-sidebar,
            .right-sidebar {
                width: 100%;
                order: 2;
            }

            .game-area {
                order: 1;
                width: 100%;
                min-height: 60vh;
            }

            .lobby-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .lobby-card {
                padding: 15px;
            }

            .panel {
                margin-bottom: 15px;
            }

            .wallet-actions {
                flex-direction: column;
                gap: 8px;
            }

            .wallet-buttons {
                flex-direction: column;
                gap: 10px;
            }

            .modal-content {
                width: 95%;
                max-width: 400px;
                margin: 20px auto;
                padding: 20px;
            }

            .auth-tabs {
                flex-direction: column;
                gap: 5px;
            }

            .auth-tab {
                padding: 12px;
            }

            .cashout-buttons {
                flex-direction: column;
                gap: 10px;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 5px;
            }

            .header {
                padding: 10px;
            }

            .logo-circle {
                width: 40px;
                height: 40px;
            }

            .user-actions button {
                padding: 8px 12px;
                font-size: 14px;
            }

            .lobby-card {
                padding: 12px;
            }

            .panel {
                padding: 12px;
            }

            .modal-content {
                width: 98%;
                margin: 10px auto;
                padding: 15px;
            }

            .balance-amount {
                font-size: 18px;
            }

            .wallet-title-section {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }

        /* Mobile Landscape Orientation */
        @media (max-width: 768px) and (orientation: landscape) {
            .main-content {
                flex-direction: row;
            }

            .left-sidebar,
            .right-sidebar {
                width: 250px;
                order: initial;
            }

            .game-area {
                flex: 1;
                order: initial;
                min-height: 50vh;
            }

            .header {
                flex-direction: row;
                padding: 10px 15px;
            }

            .user-welcome {
                order: initial;
                text-align: left;
            }
        }
    </style>
    <!-- Solana Web3.js Library -->
    <script src="https://unpkg.com/@solana/web3.js@latest/lib/index.iife.min.js"></script>
</head>
<body>

    
    <!-- Animated Grid Background -->
    <div class="grid-background"></div>
    
    <!-- Moving Players Background -->
    <div class="players-background">
        <!-- Left to Right Players -->
        <div class="moving-player player-1 small-player"></div>
        <div class="moving-player player-2 huge-player"></div>
        <div class="moving-player player-3 tiny-player"></div>
        
        <!-- Right to Left Players -->
        <div class="moving-player player-4 medium-player"></div>
        <div class="moving-player player-5 large-player"></div>
        <div class="moving-player player-6 tiny-player"></div>
        
        <!-- Top to Bottom Players -->
        <div class="moving-player player-7 medium-player"></div>
        <div class="moving-player player-8 small-player"></div>
        
        <!-- Bottom to Top Players -->
        <div class="moving-player player-9 small-player"></div>
        <div class="moving-player player-10 large-player"></div>
        
        <!-- Diagonal Players -->
        <div class="moving-player player-11 tiny-player"></div>
        <div class="moving-player player-12 huge-player"></div>
    </div>
    <!-- Login/Register Modal -->
    <div id="auth-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="auth-tabs">
                <button class="auth-tab active" data-tab="login">Login</button>
                <button class="auth-tab" data-tab="register">Register</button>
            </div>
            
            <!-- Login Form -->
            <div id="login-form" class="auth-form">
                <h2>Login to Your Account</h2>
                <div id="email-step">
                    <input type="email" id="login-email" placeholder="Email Address" required>
                    <button id="send-code-btn" class="auth-submit-btn">Send Verification Code</button>
                </div>
                <div id="verification-step" style="display: none;">
                    <p class="verification-text">We've sent a verification code to your email</p>
                    <input type="text" id="verification-code" placeholder="Enter 6-digit code" maxlength="6" required>
                    <button id="verify-code-btn" class="auth-submit-btn">Verify Code</button>
                    <button id="resend-code-btn" class="resend-btn">Resend Code</button>
                </div>
                <div id="username-step" style="display: none;">
                    <h3>Choose Your Username</h3>
                    <p class="welcome-new-user">Welcome! Let's set up your account.</p>
                    <input type="text" id="new-username" placeholder="Choose a username" required>
                    <button id="create-account-btn" class="auth-submit-btn">Create Account</button>
                </div>
            </div>
            
            <!-- Register Form -->
            <div id="register-form" class="auth-form" style="display: none;">
                <h2>Create New Account</h2>
                <input type="text" id="register-username" placeholder="Username" required>
                <input type="email" id="register-email" placeholder="Email" required>
                <input type="password" id="register-password" placeholder="Password" required>
                <input type="password" id="register-confirm" placeholder="Confirm Password" required>
                <button id="register-submit" class="auth-submit-btn">Register</button>
            </div>
        </div>
    </div>

    <!-- Wallet Modal -->
    <div id="wallet-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h2>Your Solana Wallet</h2>
            <div class="wallet-info">
                <div id="wallet-addresses">
                    <!-- Wallet addresses will be populated by JavaScript -->
                </div>
                
                <div class="deposit-history-section">
                    <h3>📊 Deposit History</h3>
                    <div id="deposit-history">
                        <!-- Deposit history will be populated by JavaScript -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Cashout Modal -->
    <div id="cashout-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h2>💸 Cash Out to External Wallet</h2>
            
            <!-- Prominent Available Balance Display -->
            <div class="available-balance-display">
                <div class="balance-label">Available Balance</div>
                <div class="balance-amount-large" id="available-sol-balance">0.000000 SOL</div>
            </div>
            
            <div class="cashout-form">
                <div class="wallet-info">
                    <div class="form-group">
                        <label for="cashout-sol-amount">Amount (SOL):</label>
                        <div class="input-with-popup">
                            <input type="number" id="cashout-sol-amount" min="0.000001" step="0.000001" placeholder="Enter SOL amount to cash out">
                            <div id="eur-conversion-popup" class="eur-popup" style="display: none;">
                                <div class="eur-popup-content">
                                    <div class="eur-amount">€0.00</div>
                                    <div class="eur-label">EUR equivalent</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="external-wallet-address">External Solana Wallet Address:</label>
                        <input type="text" id="external-wallet-address" placeholder="Enter your Solana wallet address">
                        <div class="wallet-info-text">⚠️ Make sure this is a valid Solana wallet address</div>
                    </div>
                    
                    <!-- Fee Notice -->
                    <div class="fee-notice">
                        <div class="fee-notice-text">
                            <strong>Transaction Fee:</strong> A fixed fee of €0.15 will be deducted from all cashouts.
                        </div>
                    </div>
                    
                    <div id="cashout-warning" class="warning-info" style="display: none;">
                        <div class="warning-text">
                            ⚠️ Transaction fees will be deducted from your balance
                        </div>
                    </div>
                    
                    <!-- Transaction Status Display -->
                    <div id="cashout-status" class="cashout-status" style="display: none;">
                        <div class="status-text" id="cashout-status-text">Preparing transaction...</div>
                    </div>
                    
                    <div class="cashout-buttons">
                        <button id="confirm-cashout-btn" class="confirm-btn">Confirm Cash Out</button>
                        <button id="cancel-cashout-btn" class="cancel-btn">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Header -->
        <header class="header">
            <div class="user-welcome">
                <div class="welcome-logo">
                    <svg width="24" height="24" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <!-- Outer ring with gradient -->
                        <defs>
                            <linearGradient id="logoGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#00ff88;stop-opacity:1" />
                                <stop offset="50%" style="stop-color:#00d4ff;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#ff6b6b;stop-opacity:1" />
                            </linearGradient>
                            <linearGradient id="textGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#ffffff;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#e0e0e0;stop-opacity:1" />
                            </linearGradient>
                        </defs>
                        
                        <!-- Background circle -->
                        <circle cx="40" cy="40" r="38" fill="rgba(0,0,0,0.3)" stroke="url(#logoGradient2)" stroke-width="2"/>
                        
                        <!-- Inner design elements -->
                        <circle cx="40" cy="40" r="30" fill="none" stroke="url(#logoGradient2)" stroke-width="1.5" opacity="0.6"/>
                        
                        <!-- Central "O" with modern styling -->
                        <circle cx="40" cy="40" r="18" fill="none" stroke="url(#logoGradient2)" stroke-width="3"/>
                        <circle cx="40" cy="40" r="12" fill="url(#logoGradient2)" opacity="0.2"/>
                        
                        <!-- Stylized "O" text -->
                        <text x="40" y="48" text-anchor="middle" fill="url(#textGradient2)" font-family="'Segoe UI', Arial, sans-serif" font-size="24" font-weight="bold">O</text>
                        
                        <!-- Decorative elements -->
                        <circle cx="25" cy="25" r="2" fill="url(#logoGradient2)" opacity="0.8"/>
                        <circle cx="55" cy="25" r="2" fill="url(#logoGradient2)" opacity="0.8"/>
                        <circle cx="25" cy="55" r="2" fill="url(#logoGradient2)" opacity="0.8"/>
                        <circle cx="55" cy="55" r="2" fill="url(#logoGradient2)" opacity="0.8"/>
                    </svg>
                </div>
                <span id="welcome-text" class="welcome-text">Welcome, oops!</span>
            </div>
            <div class="main-logo">
                <div class="logo-circle">
                    <svg width="60" height="60" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Outer ring with gradient -->
                    <defs>
                        <linearGradient id="logoGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:#00ff88;stop-opacity:1" />
                            <stop offset="50%" style="stop-color:#00d4ff;stop-opacity:1" />
                            <stop offset="100%" style="stop-color:#ff6b6b;stop-opacity:1" />
                        </linearGradient>
                        <linearGradient id="textGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style="stop-color:#ffffff;stop-opacity:1" />
                            <stop offset="100%" style="stop-color:#e0e0e0;stop-opacity:1" />
                        </linearGradient>
                    </defs>
                    
                    <!-- Background circle -->
                    <circle cx="40" cy="40" r="38" fill="rgba(0,0,0,0.3)" stroke="url(#logoGradient1)" stroke-width="2"/>
                    
                    <!-- Inner design elements -->
                    <circle cx="40" cy="40" r="30" fill="none" stroke="url(#logoGradient1)" stroke-width="1.5" opacity="0.6"/>
                    
                    <!-- Central "O" with modern styling -->
                    <circle cx="40" cy="40" r="18" fill="none" stroke="url(#logoGradient1)" stroke-width="3"/>
                    <circle cx="40" cy="40" r="12" fill="url(#logoGradient1)" opacity="0.2"/>
                    
                    <!-- Stylized "O" text -->
                    <text x="40" y="48" text-anchor="middle" fill="url(#textGradient1)" font-family="'Segoe UI', Arial, sans-serif" font-size="24" font-weight="bold">O</text>
                    
                    <!-- Decorative elements -->
                    <circle cx="25" cy="25" r="2" fill="url(#logoGradient1)" opacity="0.8"/>
                    <circle cx="55" cy="25" r="2" fill="url(#logoGradient1)" opacity="0.8"/>
                    <circle cx="25" cy="55" r="2" fill="url(#logoGradient1)" opacity="0.8"/>
                    <circle cx="55" cy="55" r="2" fill="url(#logoGradient1)" opacity="0.8"/>
                </svg>
                </div>
                <div class="logo-content">
                    <div class="logo-text">OOPS<span class="logo-highlight">NOWH</span></div>
                    <div class="logo-subtitle">SKILL-BASED BETTING</div>
                </div>
            </div>
            <div class="header-actions">
                <button onclick="window.open('https://discord.gg/H8NJHanBeS', '_blank')" class="header-btn discord-btn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                    </svg>
                    Join Discord!
                </button>
                <div id="logged-out-info">
                    <button id="login-btn" class="header-btn login-btn">Login</button>
                </div>
                <div id="logged-in-info" style="display: none;">
                    <button id="logout-btn" class="header-btn logout-btn">Logout</button>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Left Sidebar -->
            <div class="left-sidebar">
                <!-- Leaderboard Panel -->
                <div class="panel leaderboard-panel">
                    <div class="panel-header">
                        <span class="panel-icon">🏆</span>
                        <span class="panel-title">Leaderboard</span>
                        <span class="live-indicator">● Live</span>
                    </div>
                    <div class="leaderboard-list">
                        <div class="leaderboard-item">
                            <span class="rank">1.</span>
                            <span class="player-name">OopsLars</span>
                            <span class="amount">€10,20</span>
                        </div>
                        <div class="leaderboard-item">
                            <span class="rank">2.</span>
                            <span class="player-name">JonkoDuif</span>
                            <span class="amount">€7,90</span>
                        </div>
                        <div class="leaderboard-item">
                            <span class="rank">3.</span>
                            <span class="player-name">zTiqs</span>
                            <span class="amount">€6,05</span>
                        </div>
                    </div>
                    <button class="view-full-btn">View Full Leaderboard</button>
                </div>

                <!-- Social Panel -->
                <div class="panel social-panel">
                    <div class="panel-header">
                        <span class="panel-icon">👫</span>
                        <span class="panel-title">Social</span>
                        <button class="refresh-btn" title="Refresh Social Data">🔄</button>
                    </div>
                    <div class="social-content-mini">
                        <div class="friends-preview">
                            <div class="no-friends">
                                <div class="no-friends-icon">👤</div>
                                <p>No friends... add some!</p>
                            </div>
                            <div class="playing-count">0 playing</div>
                        </div>
                        <button class="view-full-social-btn" onclick="showSocialPopup()">View Full Social</button>
                    </div>
                </div>


            </div>

            <!-- Game Area -->
            <div class="game-area">
                <!-- Home Page -->
                <div id="home-page" class="home-page">
                    <!-- Name Input -->
                    <div class="name-input-section">
                        <div class="name-input-container">
                            <span class="help-icon">❓</span>
                            <input type="text" id="name-input" class="name-input" placeholder="Login to set your name" readonly>
                            <button class="external-link-btn">🔗</button>
                        </div>
                    </div>

                    <!-- Bet Selection -->
                    <div class="bet-selection">
                        <div class="custom-bet-input-container">
                            <label for="custom-bet-input" class="bet-input-label">Bet Amount (€)</label>
                            <input type="number" id="custom-bet-input" class="custom-bet-input" 
                                   min="0.25" step="0.01" value="0.25" placeholder="0.25">
                            <div class="bet-input-info">
                                <span class="min-bet-notice">Minimum: €0.25</span>
                                <span class="fee-notice">+ €0.10 fee</span>
                            </div>
                        </div>
                    </div>

                    <!-- Join Game Button -->
                    <button id="join-game-btn" class="join-game-btn">
                        <span class="play-icon">▶</span>
                        JOIN GAME
                    </button>

                    <!-- Lobby Selection Tab -->
                    <div class="lobby-tab-section">
                        <button class="lobby-tab-toggle" id="lobby-tab-toggle">
                            <span class="lobby-icon">🎮</span>
                            <span class="lobby-text">Join Lobby</span>
                            <span class="toggle-arrow">▼</span>
                        </button>
                        <div class="server-status-corner" id="server-status-corner">
                            <span class="status-dot offline"></span>
                            <span class="status-text">Offline</span>
                        </div>
                        
                        <!-- Collapsible Lobby Selection -->
                        <div class="lobby-selection-container" id="lobby-selection-container" style="display: none;">
                            <!-- Region Selection inside lobby container -->
                            <div class="lobby-region-selection">
                                <button class="region-btn active" data-region="US">🇺🇸 US</button>
                                <button class="region-btn" data-region="EU">🇪🇺 EU</button>
                            </div>
                            
                            <div class="lobby-grid-compact">
                                <!-- US Lobbies -->
                                <div class="lobby-card-compact" data-lobby-id="1" data-region="US">
                                    <div class="lobby-name">US Lobby 1</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                                <div class="lobby-card-compact" data-lobby-id="2" data-region="US">
                                    <div class="lobby-name">US Lobby 2</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                                <div class="lobby-card-compact" data-lobby-id="3" data-region="US">
                                    <div class="lobby-name">US Lobby 3</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                                <div class="lobby-card-compact" data-lobby-id="4" data-region="US">
                                    <div class="lobby-name">US Lobby 4</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                                
                                <!-- EU Lobbies -->
                                <div class="lobby-card-compact" data-lobby-id="5" data-region="EU">
                                    <div class="lobby-name">EU Lobby 1</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                                <div class="lobby-card-compact" data-lobby-id="6" data-region="EU">
                                    <div class="lobby-name">EU Lobby 2</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                                <div class="lobby-card-compact" data-lobby-id="7" data-region="EU">
                                    <div class="lobby-name">EU Lobby 3</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                                <div class="lobby-card-compact" data-lobby-id="8" data-region="EU">
                                    <div class="lobby-name">EU Lobby 4</div>
                                    <div class="lobby-stats-compact">
                                        <div class="lobby-players">0/50</div>
                                        <div class="lobby-status offline">● Offline</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Current Lobby Info -->
                    <div id="current-lobby-info" class="current-lobby-info" style="display: none;">
                        <!-- Lobby info will be populated by JavaScript -->
                    </div>

                    <!-- Game Stats -->
                    <div class="game-stats home-stats home-page-stats">
                        <div class="stat">
                            <div class="stat-number" id="players-online">0</div>
                            <div class="stat-label">Players in Game</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number" id="global-winnings">€0</div>
                            <div class="stat-label">Total Prize Pools</div>
                        </div>
                    </div>

                    <!-- Bottom Buttons -->
                    <div class="bottom-buttons">
                        <button class="daily-crate-btn">
                            <span class="crate-icon">📦</span>
                            Daily Crate
                        </button>
                        <button class="affiliate-btn">
                            <span class="affiliate-icon">👥</span>
                            Affiliate
                        </button>
                    </div>
                </div>

                <!-- Lobby Selection Page REMOVED - User should stay on home page when selecting lobby -->

                <!-- Lobby Page REMOVED - User should stay on home page when selecting lobby -->

                <!-- Game Container (Hidden initially) -->
                <div class="game-container" style="display: none;">
                    <canvas id="gameCanvas"></canvas>
                    
                    <!-- Game UI Overlay -->
                    <div class="game-ui">
                        <!-- Statistics Panel (Bottom Left) -->
                        <div class="stats-panel">
                            <div class="stats-header">
                                <span class="stats-icon">📊</span>
                                <span class="stats-title">Game Stats</span>
                            </div>
                            <div class="stats-content">
                                <div class="stat-item">
                                    <span class="stat-label">Bet Size:</span>
                                    <span class="stat-value" id="stat-bet-size">€0.00</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Ball Balance:</span>
                                    <span class="stat-value" id="stat-ball-balance">€0.00</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Ball Mass:</span>
                                    <span class="stat-value" id="stat-ball-mass">0</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Kills:</span>
                                    <span class="stat-value" id="stat-kills">0</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="game-controls">
                            <div class="cash-out-container">
                                <div class="cash-out-progress">
                                    <div class="cash-out-circle">
                                        <div class="cash-out-icon">💰</div>
                                        <div class="progress-ring">
                                            <svg class="progress-svg" width="60" height="60">
                                                <circle class="progress-bg" cx="30" cy="30" r="25" fill="none" stroke="#333" stroke-width="4"/>
                                                <circle class="progress-bar" cx="30" cy="30" r="25" fill="none" stroke="#ffd700" stroke-width="4" stroke-dasharray="157" stroke-dashoffset="157"/>
                                            </svg>
                                        </div>
                                    </div>
                                    <div class="cash-out-text">Hold Q to Cash Out</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="game-instructions">
                            <p>Move: Mouse | Split: Space | Eject: W | Cash Out: Hold Q</p>
                            <p class="cashout-warning">⚠️ You cannot leave manually - Cash out or play until eliminated!</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cashout Success Overlay -->
            <div id="cashout-success-overlay" class="cashout-success-overlay">
                <div class="cashout-success-content">
                    <div class="cashout-success-text">CASHED OUT</div>
                    <div class="cashout-amount" id="cashout-amount-display">€0.00</div>
                </div>
            </div>

            <!-- Elimination Overlay -->
            <div id="elimination-overlay" class="elimination-overlay">
                <div class="elimination-content">
                    <div class="elimination-text">ELIMINATED</div>
                    <div class="elimination-message" id="elimination-message-display">You lost all your balls!</div>
                </div>
            </div>

            <!-- Right Sidebar -->
            <div class="right-sidebar">
                <!-- Wallet Panel -->
                <div class="panel wallet-panel">
                    <div class="panel-header">
                        <div class="wallet-title-section">
                            <span class="panel-title">Wallet</span>
                            <div class="wallet-actions">
                                <button class="copy-address-btn">📋 Copy Address</button>
                                <button class="refresh-balance-btn">🔄 Refresh Balance</button>
                            </div>
                        </div>
                    </div>
                    <div class="wallet-balance">
                        <div class="balance-amount" id="balance-amount">0.000000 SOL</div>
                        <div class="balance-currency">Solana Wallet</div>
                    </div>
                    <div class="wallet-buttons">
                        <button class="add-funds-btn">Add Funds</button>
                        <button class="cash-out-btn">Cash Out</button>
                    </div>
                </div>

                <!-- Customize Panel -->
                <div class="panel customize-panel">
                    <div class="panel-header">
                        <span class="panel-icon">🎨</span>
                        <span class="panel-title">Customize</span>
                    </div>
                    <div class="skin-preview">
                        <div class="skin-blob"></div>
                    </div>
                    <button class="change-appearance-btn">Change Appearance</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Social System Container -->
    <div id="social-container"></div>

    <!-- Scripts - Direct JavaScript loading -->
    <script src="js/utils.js?v=52&nocache=1756037200000"></script>
<script src="js/auth.js?v=52&nocache=1756037200000"></script>
<script src="js/wallet.js?v=52&nocache=1756037200000"></script>
<script src="js/lobbyWallet.js?v=52&nocache=1756037200000"></script>
<script src="js/lobbySystem.js?v=52&nocache=1756037200000"></script>
<script src="js/ui.js?v=52&nocache=1756037200000"></script>
<script src="js/backgroundAnimation.js?v=52&nocache=1756037200000"></script>
<script src="js/multiplayer.js?v=52&nocache=1756037200000"></script>
<script src="js/game.js?v=54&nocache=1756037200000"></script>
<script src="js/gameManager.js?v=52&nocache=1756037200000"></script>
    
    <!-- Page refresh handling -->
    <script>
        // Handle page refresh/close - remove player from game and lobby
        function cleanupPlayerConnections() {
            console.log('🔄 Page refresh/close detected - cleaning up player...');
            
            try {
                // Leave current game if in one
                if (window.game && window.game.isActive) {
                    console.log('🎮 Leaving active game...');
                    if (window.game.multiplayer && window.game.multiplayer.disconnect) {
                        window.game.multiplayer.disconnect();
                    }
                    // Stop the game to prevent further updates
                    if (window.game.endGame) {
                        window.game.endGame();
                    }
                }
                
                // Leave current lobby if in one
                if (window.lobbySystem && window.lobbySystem.currentLobby) {
                    console.log('🚪 Leaving current lobby...');
                    window.lobbySystem.leaveLobby();
                }
                
                // Disconnect from lobby wallet server
                if (window.lobbyWalletManager && window.lobbyWalletManager.disconnect) {
                    console.log('💰 Disconnecting from lobby wallet server...');
                    window.lobbyWalletManager.disconnect();
                }
                
                // Additional cleanup for any remaining websocket connections
                if (window.gameManager && window.gameManager.cleanup) {
                    window.gameManager.cleanup();
                }
            } catch (error) {
                console.warn('⚠️ Error during cleanup:', error);
            }
        }
        
        // Handle beforeunload event (page refresh/close)
        window.addEventListener('beforeunload', cleanupPlayerConnections);
        
        // Handle pagehide event (mobile browsers, back button)
        window.addEventListener('pagehide', cleanupPlayerConnections);
        
        // Handle visibilitychange event (tab switching, minimizing)
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'hidden') {
                // Don't fully disconnect on visibility change, just pause
                console.log('👁️ Page hidden - pausing game updates...');
                if (window.game && window.game.pauseGame) {
                    window.game.pauseGame();
                }
            } else if (document.visibilityState === 'visible') {
                console.log('👁️ Page visible - resuming game updates...');
                if (window.game && window.game.resumeGame) {
                    window.game.resumeGame();
                }
            }
        });
        
        // Initialize Social System
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof SocialSystem !== 'undefined') {
                window.socialSystem = new SocialSystem();
                window.socialSystem.init();
            }
        });
    </script>
    <!-- Social Popup -->
    <?php include 'social_popup.html'; ?>

<script src="social.js?v=52&nocache=1756037200000"></script>
        <script src="social_popup.js?v=52&nocache=1756037200000"></script>
</body>
</html>
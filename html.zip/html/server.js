// WebSocket Server for Agar.io Multiplayer Game
const WebSocket = require('ws');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

// Import Solana Web3.js for blockchain operations
const solanaWeb3 = require('@solana/web3.js');

// Import wallet system for blockchain transfers
// const WalletSystem = require('./js/wallet.js'); // Commented out - client-side only
const EmailService = require('./js/emailService.js');

class GameServer {
    constructor(port = 8081, lobbyServerPort = 8082) {
        this.port = port;
        this.lobbyServerPort = lobbyServerPort;
        
        // Load site settings from file or use defaults
        this.loadSiteSettings();
        
        // Initialize wallet system for blockchain operations
        // this.walletSystem = new WalletSystem(); // Commented out - client-side only
        this.walletSystem = { isInitialized: false, connection: null }; // Simple server-side wallet system
        this.lobbyWallets = new Map(); // Store lobby wallet data
        
        // Initialize email service for admin verification
        this.emailService = new EmailService();
        
        // Clean up expired email codes every 5 minutes
        setInterval(() => {
            this.emailService.cleanupExpiredCodes();
        }, 5 * 60 * 1000);
        
        // Load lobby wallet data
        this.loadLobbyWallets();
        
        // ALWAYS use SSL in production - REQUIRED for security
        let server;
        const isProduction = true; // Force production mode
        
        try {
            // SSL certificates are REQUIRED
            const sslOptions = {
                key: fs.readFileSync('/etc/letsencrypt/live/oopsnowh.com/privkey.pem'),
                cert: fs.readFileSync('/etc/letsencrypt/live/oopsnowh.com/fullchain.pem')
            };
            
            // Create HTTPS server specifically for WebSocket on this port
            server = https.createServer(sslOptions);
            console.log(`🔒 Production mode: Using HTTPS/WSS server with SSL certificates on port ${port}`);
            this.isSSLEnabled = true;
        } catch (error) {
            console.error('❌ SSL certificates REQUIRED but not found:', error.message);
            console.error('❌ Server cannot start without SSL certificates');
            process.exit(1);
        }
        
        this.server = server;
        this.wss = new WebSocket.Server({ server: this.server });
        
        // Game state - organized by lobby ID instead of region/type
        this.gameLobbies = new Map(); // lobbyId -> { players: Map, food: [], gameState: {} }
        
        // Initialize all lobbies at startup
        this.initializeAllLobbies();
        
        // Connection to lobby server for coordination
        this.lobbyServerConnection = null;
        this.connectToLobbyServer();
        
        this.setupWebSocketServer();
        this.startGameLoop();
    }

    loadLobbyWallets() {
        try {
            const walletDataPath = './lobby_wallets_data.json';
            if (fs.existsSync(walletDataPath)) {
                const data = JSON.parse(fs.readFileSync(walletDataPath, 'utf8'));
                
                // Handle both old format (data.lobbyWallets array) and new format (direct object)
                if (data.lobbyWallets) {
                    // Old format: Convert array back to Map
                    data.lobbyWallets.forEach(([lobbyId, walletData]) => {
                        this.lobbyWallets.set(lobbyId, walletData);
                    });
                } else {
                    // New format: Direct object with lobby IDs as keys
                    Object.keys(data).forEach(lobbyIdStr => {
                        const lobbyId = parseInt(lobbyIdStr);
                        const walletData = data[lobbyIdStr];
                        this.lobbyWallets.set(lobbyId, walletData);
                        console.log(`🔑 Loaded lobby ${lobbyId} wallet: ${walletData.publicKey}`);
                    });
                }
                console.log(`💰 Loaded ${this.lobbyWallets.size} lobby wallets`);
            } else {
                console.log('📁 No lobby wallet data file found, starting fresh');
            }
        } catch (error) {
            console.error('❌ Error loading lobby wallets:', error);
        }
    }

    loadSiteSettings() {
        const settingsPath = path.join(__dirname, 'site_settings.json');
        const defaultSettings = {
            cashoutFee: 0.15, // Default cashout fee in EUR for wallet to external wallet transfers
            gameJoinFee: 0.10, // Default game join fee in SOL
            adminWallet: 'ADMIN_WALLET_ADDRESS_HERE', // Admin wallet address
            emergencyMode: false // Emergency mode flag
        };
        
        try {
            if (fs.existsSync(settingsPath)) {
                const settingsData = fs.readFileSync(settingsPath, 'utf8');
                this.siteSettings = JSON.parse(settingsData);
                console.log('✅ Site settings loaded from file:', this.siteSettings);
            } else {
                this.siteSettings = defaultSettings;
                console.log('📝 Using default site settings:', this.siteSettings);
            }
        } catch (error) {
            console.error('❌ Error loading site settings, using defaults:', error);
            this.siteSettings = defaultSettings;
        }
    }

    // Connect to lobby server for coordination
    connectToLobbyServer() {
        const protocol = this.isSSLEnabled ? 'wss' : 'ws';
        const lobbyServerUrl = `${protocol}://localhost:${this.lobbyServerPort}`;
        
        try {
            // Note: This would be for server-to-server communication if needed
            // For now, we'll rely on client-mediated communication
            console.log(`🔗 Game server ready to coordinate with lobby server at ${lobbyServerUrl}`);
        } catch (error) {
            console.error('❌ Failed to connect to lobby server:', error);
        }
    }

    // Initialize a game lobby when players join
    initializeGameLobby(lobbyId) {
        if (!this.gameLobbies.has(lobbyId)) {
            const gameLobby = {
                players: new Map(),
                food: [],
                viruses: [],
                gameState: {
                    lastUpdate: Date.now(),
                    isActive: true,
                    worldWidth: 7500,
                    worldHeight: 7500
                }
            };
            
            // Initialize viruses for this lobby
            this.initializeVirusesForLobby(gameLobby);
            
            this.gameLobbies.set(lobbyId, gameLobby);
            console.log(`🎮 Initialized game lobby ${lobbyId} with ${gameLobby.viruses.length} viruses`);
        }
        return this.gameLobbies.get(lobbyId);
    }
    
    initializeVirusesForLobby(gameLobby) {
        const maxViruses = 10;
        for (let i = 0; i < maxViruses; i++) {
            const radius = 35 + Math.random() * 15;
            const virus = {
                x: Math.random() * gameLobby.gameState.worldWidth,
                y: Math.random() * gameLobby.gameState.worldHeight,
                radius: radius,
                mass: Math.PI * radius * radius / 4,
                color: '#00FF00',
                spikes: 12,
                id: this.generateVirusId()
            };
            gameLobby.viruses.push(virus);
        }
    }
    
    generateVirusId() {
        return 'virus_' + Math.random().toString(36).substr(2, 9);
    }

    // Initialize all lobbies at startup (1-8: 1-4 US, 5-8 EU)
    initializeAllLobbies() {
        for (let i = 1; i <= 8; i++) {
            this.initializeGameLobby(i);
        }
        console.log('🎮 Initialized all 8 game lobbies (1-4: US, 5-8: EU)');
    }

    // Handle lobby server connection
    handleLobbyServerConnect(ws, message) {
        if (message.serverType === 'lobby') {
            ws.isLobbyServer = true;
            this.lobbyServerConnection = ws;
            console.log('🏢 Lobby server connected to game server');
        }
    }

    // Handle player joining game from lobby server
    handlePlayerJoinFromLobby(ws, message) {
        const { lobbyId, player } = message;
        console.log(`🎮 Lobby server notified: Player ${player.name} joining game in lobby ${lobbyId}`);
        
        // Initialize game lobby if needed
        const gameLobby = this.initializeGameLobby(lobbyId);
        
        // Store player info for when they connect directly
        if (!gameLobby.pendingPlayers) {
            gameLobby.pendingPlayers = new Map();
        }
        gameLobby.pendingPlayers.set(player.id, player);
    }

    // Handle player leaving game from lobby server
    handlePlayerLeaveFromLobby(ws, message) {
        const { lobbyId, playerId } = message;
        console.log(`🎮 Lobby server notified: Player ${playerId} leaving game in lobby ${lobbyId}`);
        
        const gameLobby = this.gameLobbies.get(lobbyId);
        if (gameLobby) {
            // Remove from pending players
            if (gameLobby.pendingPlayers) {
                gameLobby.pendingPlayers.delete(playerId);
            }
            
            // Remove from active players
            if (gameLobby.players.has(playerId)) {
                gameLobby.players.delete(playerId);
                
                // Broadcast player left to remaining players
                this.broadcastToGameLobby(lobbyId, {
                    type: 'player_left',
                    playerId: playerId
                });
            }
            
            // Don't clean up lobby immediately - preserve game state (mass drops, etc.)
            // Only clean up after extended period of inactivity
            if (gameLobby.players.size === 0 && (!gameLobby.pendingPlayers || gameLobby.pendingPlayers.size === 0)) {
                gameLobby.lastActivity = Date.now();
                console.log(`⏰ Game lobby ${lobbyId} is empty, marking for potential cleanup later`);
            }
        }
    }

    setupWebSocketServer() {
        this.wss.on('connection', (ws) => {
            console.log('New client connected');
            
            ws.playerId = this.generatePlayerId();
            ws.region = null;
            ws.lobby = null;
            ws.isLobbyServer = false;
            
            ws.on('message', (message) => {
                try {
                    const data = JSON.parse(message);
                    this.handleMessage(ws, data);
                } catch (error) {
                    console.error('Error parsing message:', error);
                }
            });
            
            ws.on('close', (code, reason) => {
            console.log(`Client disconnected - Code: ${code}, Reason: ${reason}`);
            this.removePlayerFromGameLobby(ws);
        });
        
        // Handle unexpected disconnections
        ws.on('error', (error) => {
            console.error(`WebSocket error: ${error.message}`);
            this.removePlayerFromGameLobby(ws);
        });
        
        // Add heartbeat to detect dead connections
        ws.isAlive = true;
        ws.on('pong', () => {
            ws.isAlive = true;
        });
        });
    }

    handleMessage(ws, message) {
        switch (message.type) {
            case 'lobby_server_connect':
                this.handleLobbyServerConnect(ws, message);
                break;
            case 'player_join_game':
                this.handlePlayerJoinFromLobby(ws, message);
                break;
            case 'player_leave_game':
                this.handlePlayerLeaveFromLobby(ws, message);
                break;
            case 'player_leave':
                this.handlePlayerLeave(ws, message);
                break;
            case 'join_game':
                this.handleJoinGame(ws, message);
                break;
            case 'player_update':
                this.handlePlayerUpdate(ws, message);
                break;
            case 'player_split':
                this.handlePlayerSplit(ws, message);
                break;
            case 'mass_feed':
                this.handleMassFeed(ws, message);
                break;
            case 'playerCashout':
                    this.handlePlayerCashout(ws, message);
                    break;
                case 'cashoutResult':
                    this.handleCashoutResult(ws, message);
                    break;
            case 'player_kill':
                this.handlePlayerKill(ws, message);
                break;
            case 'player_eaten':
                this.handlePlayerEaten(ws, message);
                break;
            case 'player_eliminated':
                this.handlePlayerEliminated(ws, message);
                break;
            case 'lobby_reset':
                this.handleLobbyReset(ws, message);
                break;
            case 'clear_all_players':
                this.clearAllPlayers();
                ws.send(JSON.stringify({
                    type: 'clear_all_players_response',
                    success: true,
                    message: 'All players cleared from all lobbies'
                }));
                break;
            // Admin functionality
            case 'admin_authenticate':
                this.handleAdminAuthenticate(ws, message);
                break;
            case 'request_email_verification':
                this.handleRequestEmailVerification(ws, message);
                break;
            case 'verify_email_code':
                this.handleVerifyEmailCode(ws, message);
                break;
            case 'search_user':
                this.handleSearchUser(ws, message);
                break;
            case 'timeout_user':
                this.handleTimeoutUser(ws, message);
                break;
            case 'ban_user':
                this.handleBanUser(ws, message);
                break;
            case 'unban_user':
                this.handleUnbanUser(ws, message);
                break;
            case 'update_site_settings':
                    this.handleUpdateSiteSettings(ws, message);
                    break;
                
                case 'get_site_settings':
                    this.handleGetSiteSettings(ws, message);
                    break;
            case 'emergency_stop_all':
                this.handleEmergencyStopAll(ws, message);
                break;
            case 'emergency_cashout_all':
                this.handleEmergencyCashoutAll(ws, message);
                break;
            case 'transfer_lobby_funds_to_admin':
                this.handleTransferLobbyFundsToAdmin(ws, message);
                break;
            case 'check_lobby_status':
                this.handleCheckLobbyStatus(ws, message);
                break;
            case 'view_lobby_wallet':
                this.handleViewLobbyWallet(ws, message);
                break;
            case 'stop_lobby':
                this.handleStopLobby(ws, message);
                break;
            case 'blockchain_transfer':
                this.handleBlockchainTransfer(ws, message);
                break;
            default:
                console.log('Unknown message type:', message.type);
        }
    }

    // Handle player leaving (disconnect/refresh)
    handlePlayerLeave(ws, message) {
        console.log(`🚪 Player ${message.playerId} leaving game (${message.reason || 'unknown reason'})`);
        
        // Remove player from their current lobby
        this.removePlayerFromGameLobby(ws);
        
        // Close the connection
        if (ws.readyState === WebSocket.OPEN) {
            ws.close();
        }
    }

    handleJoinGame(ws, message) {
        const { lobbyId, player } = message;
        
        console.log(`🔍 DEBUG: Received join_game request with lobbyId: ${lobbyId} (type: ${typeof lobbyId})`);
        console.log(`🔍 DEBUG: Full message:`, JSON.stringify(message, null, 2));
        
        // Validate lobbyId
        if (!lobbyId || typeof lobbyId !== 'number') {
            console.log(`❌ Invalid lobbyId: ${lobbyId}`);
            ws.send(JSON.stringify({ type: 'error', error: 'Invalid lobby ID' }));
            return;
        }
        
        // Initialize game lobby if it doesn't exist
        const gameLobby = this.initializeGameLobby(lobbyId);
        
        // Remove player from previous lobby if any
        this.removePlayerFromGameLobby(ws);
        
        // Set player connection properties
        ws.playerId = this.generatePlayerId();
        ws.lobbyId = lobbyId;
        
        // Calculate spawn size based on bet amount using consistent function
        const betAmount = player.betAmount || 0.10;
        const spawnSize = this.calculateSizeFromMoney(betAmount);
        
        // Create player object with Agar.io mechanics
        const gamePlayer = {
            id: ws.playerId,
            name: player.name,
            color: player.color || this.generateRandomColor(),
            balls: [{
                id: this.generateBallId(),
                x: Math.random() * 7500, // Spawn randomly across entire map
                y: Math.random() * 7500,
                size: spawnSize,
                money: betAmount,
                vx: 0,
                vy: 0,
                mergeTime: 0 // Time until this ball can merge
            }],
            totalMoney: betAmount,
            kills: 0,
            startTime: Date.now(),
            lastUpdate: Date.now(),
            ws: ws
        };
        
        // Add player to game lobby
        gameLobby.players.set(ws.playerId, gamePlayer);
        
        console.log(`✅ Player ${player.name} joined game in lobby ${lobbyId} with bet €${betAmount} (${gameLobby.players.size} players)`);
        
        // Send game state to new player
        ws.send(JSON.stringify({
            type: 'gameState',
            data: {
                players: this.getPlayersForClient(gameLobby),
                massDrops: gameLobby.massDrops || [],
                food: gameLobby.food || [],
                viruses: gameLobby.viruses || [],
                gameArea: { width: 7500, height: 7500 }
            },
            playerId: ws.playerId,
            lobbyId: lobbyId
        }));
        
        // Notify other players in the same lobby
        this.broadcastToGameLobby(lobbyId, {
            type: 'player_joined',
            data: {
                playerId: ws.playerId,
                name: player.name,
                color: gamePlayer.color,
                balls: gamePlayer.balls
            }
        }, ws.playerId);
    }

    handlePlayerUpdate(ws, message) {
        if (!ws.lobbyId || !ws.playerId) {
            return;
        }
        
        const gameLobby = this.gameLobbies.get(ws.lobbyId);
        if (!gameLobby) return;
        
        const player = gameLobby.players.get(ws.playerId);
        
        if (player && message.data && message.data.balls) {
            // Update player position and validate movement
            const updatedBalls = message.data.balls.map(ball => {
                // Validate ball position within game area
                const x = Math.max(ball.size, Math.min(5000 - ball.size, ball.x));
                const y = Math.max(ball.size, Math.min(5000 - ball.size, ball.y));
                
                return {
                    ...ball,
                    x: x,
                    y: y,
                    lastUpdate: Date.now()
                };
            });
            
            player.balls = updatedBalls;
            player.totalMoney = message.data.totalMoney || player.totalMoney;
            player.lastUpdate = Date.now();
            
            // Check for collisions with other players
            this.checkPlayerCollisions(ws.lobbyId, ws.playerId);
            
            // Check for mass drop pickups
            this.checkMassDropPickups(player, gameLobby);
            
            // Broadcast update to other players in the same lobby
            this.broadcastToGameLobby(ws.lobbyId, {
                type: 'player_update',
                data: {
                    playerId: ws.playerId,
                    balls: player.balls,
                    totalMoney: player.totalMoney
                }
            }, ws.playerId);
        }
    }

    handlePlayerSplit(ws, message) {
        if (!ws.lobbyId || !ws.playerId) return;
        
        const gameLobby = this.gameLobbies.get(ws.lobbyId);
        if (!gameLobby) return;
        
        const player = gameLobby.players.get(ws.playerId);
        
        if (player && message.data && message.data.balls) {
            // Validate split - ensure no ball goes below 0.05 money
            const validBalls = message.data.balls.filter(ball => ball.money >= 0.05);
            
            if (validBalls.length > 0 && validBalls.length <= 16) {
                // Update player balls with split result
                player.balls = validBalls.map(ball => ({
                    ...ball,
                    mergeTime: Date.now() + 15000, // 15 seconds before can merge
                    lastUpdate: Date.now()
                }));
                
                // Recalculate total money
                player.totalMoney = player.balls.reduce((sum, ball) => sum + ball.money, 0);
                
                // Broadcast split to other players
                this.broadcastToGameLobby(ws.lobbyId, {
                    type: 'player_split',
                    data: {
                        playerId: ws.playerId,
                        balls: player.balls
                    }
                }, ws.playerId);
                
                console.log(`🔄 Player ${player.name} split into ${player.balls.length} balls`);
            }
        }
    }

    handleMassFeed(ws, message) {
        if (!ws.lobbyId || !ws.playerId) return;
        
        const gameLobby = this.gameLobbies.get(ws.lobbyId);
        if (!gameLobby) return;
        
        const player = gameLobby.players.get(ws.playerId);
        
        if (player && message.data && message.data.massDrop && message.data.fromBall) {
            // Validate that the player has enough money to feed
            const fromBall = player.balls.find(ball => ball.id === message.data.fromBall.id);
            
            if (fromBall && fromBall.money >= 0.06) { // Need at least 0.06 to feed 0.01 and stay above 0.05
                // Deduct money from the ball
                fromBall.money -= 0.01; // Standard agar.io feed amount
                fromBall.size = this.calculateSizeFromMoney(fromBall.money);
                
                // Add mass drop to game lobby
                if (!gameLobby.massDrops) {
                    gameLobby.massDrops = [];
                }
                
                const massDrop = {
                    ...message.data.massDrop,
                    id: this.generateMassDropId(),
                    playerId: ws.playerId,
                    createdAt: Date.now()
                };
                
                gameLobby.massDrops.push(massDrop);
                
                // Update player total money
                player.totalMoney = player.balls.reduce((sum, ball) => sum + ball.money, 0);
                
                // Broadcast mass feed to all players
                this.broadcastToGameLobby(ws.lobbyId, {
                    type: 'massFeed',
                    data: {
                        playerId: ws.playerId,
                        massDrop: massDrop,
                        fromBall: fromBall
                    }
                });
                
                console.log(`🍽️ Player ${player.name} fed mass: €0.01`); // Standard agar.io feed amount
            }
        }
    }

    handlePlayerCashout(ws, message) {
        if (!ws.lobbyId || !ws.playerId) {
            ws.send(JSON.stringify({
                type: 'cashoutComplete',
                data: {
                    success: false,
                    error: 'Not in a lobby'
                }
            }));
            return;
        }
        
        const gameLobby = this.gameLobbies.get(ws.lobbyId);
        if (!gameLobby) {
            ws.send(JSON.stringify({
                type: 'cashoutComplete',
                data: {
                    success: false,
                    error: 'Lobby not found'
                }
            }));
            return;
        }
        
        const player = gameLobby.players.get(ws.playerId);
        
        if (player && message.data) {
            const { amount, kills, playtime } = message.data;
            
            console.log(`💰 Player ${player.name} cashed out €${amount} (${kills} kills, ${playtime}s playtime)`);
            
            // Process real Solana blockchain transaction through lobby wallet system
            this.processRealCashout(ws, player, amount, kills, playtime);
            return; // Exit early as processRealCashout handles the response
            
            // Broadcast to other players in lobby
            this.broadcastToGameLobby(ws.lobbyId, {
                type: 'playerCashedOut',
                data: {
                    playerId: ws.playerId,
                    playerName: player.name,
                    amount: amount
                }
            }, ws.playerId);
            
            // Remove player from lobby
            this.removePlayerFromGameLobby(ws);
        } else {
            ws.send(JSON.stringify({
                type: 'cashoutComplete',
                data: {
                    success: false,
                    error: 'Player not found in lobby'
                }
            }));
        }
    }

    handlePlayerKill(ws, message) {
        if (!ws.lobbyId || !ws.playerId) return;
        
        const { victimId, moneyGained } = message;
        const gameLobby = this.gameLobbies.get(ws.lobbyId);
        
        if (gameLobby) {
            // Update killer's total money
            const killer = gameLobby.players.get(ws.playerId);
            if (killer && moneyGained) {
                killer.totalMoney += moneyGained;
                console.log(`💰 Player ${killer.name} gained €${moneyGained}, total: €${killer.totalMoney}`);
            }
        }
        
        // Broadcast kill event to all players in lobby
        this.broadcastToGameLobby(ws.lobbyId, {
            type: 'player_killed',
            killerId: ws.playerId,
            victimId: victimId,
            moneyGained: moneyGained
        });
    }
    
    // Handle player being eaten
    handlePlayerEaten(ws, message) {
        if (!ws.lobbyId || !ws.playerId) return;
        
        const { victimId, killerId, ballId, moneyLost } = message;
        const gameLobby = this.gameLobbies.get(ws.lobbyId);
        
        if (gameLobby) {
            // Update victim's total money
            const victim = gameLobby.players.get(victimId);
            if (victim && moneyLost) {
                victim.totalMoney = Math.max(0, victim.totalMoney - moneyLost);
                console.log(`💸 Player ${victim.name} lost €${moneyLost}, total: €${victim.totalMoney}`);
            }
        }
        
        // Broadcast eaten event to all players in lobby
        this.broadcastToGameLobby(ws.lobbyId, {
            type: 'player_ball_eaten',
            victimId: victimId,
            killerId: killerId,
            ballId: ballId,
            moneyLost: moneyLost
        });
    }
    
    // Handle player elimination
    handlePlayerEliminated(ws, message) {
        if (!ws.lobbyId || !ws.playerId) return;
        
        const { playerId, eliminatedBy } = message;
        
        console.log(`💀 Player ${playerId} eliminated by ${eliminatedBy} in lobby ${ws.lobbyId}`);
        
        // Remove player from lobby
        this.removePlayerFromGameLobby(ws);
        
        // Broadcast elimination to all players in lobby
        this.broadcastToGameLobby(ws.lobbyId, {
            type: 'player_eliminated',
            playerId: playerId,
            eliminatedBy: eliminatedBy
        });
        
        // Notify lobby server about elimination
        if (this.lobbyServerConnection) {
            this.lobbyServerConnection.send(JSON.stringify({
                type: 'player_eliminated',
                lobbyId: ws.lobbyId,
                playerId: playerId,
                eliminatedBy: eliminatedBy
            }));
        }
    }

    // Admin function to clear all players from a lobby (for bugged players)
    handleLobbyReset(ws, message) {
        const { lobbyId, adminKey } = message;
        
        // Simple admin key check (in production, use proper authentication)
        if (adminKey !== 'KJ2N1Mm!-0!') {
            ws.send(JSON.stringify({ type: 'error', message: 'Unauthorized' }));
            return;
        }
        
        console.log(`🧹 Admin reset requested for lobby ${lobbyId}`);
        
        const gameLobby = this.gameLobbies.get(lobbyId);
        if (gameLobby) {
            // Disconnect all players in the lobby
            gameLobby.players.forEach((player, playerId) => {
                if (player.ws && player.ws.readyState === WebSocket.OPEN) {
                    player.ws.send(JSON.stringify({
                        type: 'lobby_reset',
                        message: 'Lobby has been reset by admin. Please rejoin.'
                    }));
                    player.ws.close(1000, 'Lobby reset');
                }
            });
            
            // Clear all players and reset lobby state
            gameLobby.players.clear();
            gameLobby.food = [];
            gameLobby.gameState = {
                lastUpdate: Date.now(),
                isActive: true
            };
            
            console.log(`✅ Lobby ${lobbyId} has been reset - all players cleared`);
            
            // Notify admin of successful reset
            ws.send(JSON.stringify({
                type: 'lobby_reset_success',
                lobbyId: lobbyId,
                message: `Lobby ${lobbyId} has been successfully reset`
            }));
        } else {
            ws.send(JSON.stringify({
                type: 'error',
                message: `Lobby ${lobbyId} not found`
            }));
        }
    }

    // Clear all players from all lobbies (admin function)
    clearAllPlayers() {
        console.log('🧹 Clearing all players from all lobbies...');
        
        this.gameLobbies.forEach((gameLobby, lobbyId) => {
            const playerCount = gameLobby.players.size;
            if (playerCount > 0) {
                console.log(`🧹 Clearing ${playerCount} players from lobby ${lobbyId}`);
                
                // Notify all players they're being removed
                this.broadcastToGameLobby(lobbyId, {
                    type: 'force_disconnect',
                    reason: 'Server cleanup - removing all players'
                });
                
                // Clear all players
                gameLobby.players.clear();
            }
        });
        
        console.log('✅ All players cleared from all lobbies');
    }

    removePlayerFromGameLobby(ws) {
        if (ws.lobbyId && this.gameLobbies.has(ws.lobbyId)) {
            const gameLobby = this.gameLobbies.get(ws.lobbyId);
            const player = gameLobby.players.get(ws.playerId);
            
            if (player) {
                gameLobby.players.delete(ws.playerId);
                
                // Notify other players
                this.broadcastToGameLobby(ws.lobbyId, {
                    type: 'player_left',
                    playerId: ws.playerId
                }, ws.playerId);
                
                console.log(`Player ${player.name} left lobby ${ws.lobbyId}`);
                
                // Clean up empty lobbies
                if (gameLobby.players.size === 0) {
                    this.gameLobbies.delete(ws.lobbyId);
                    console.log(`🗑️ Cleaned up empty lobby ${ws.lobbyId}`);
                }
            }
        }
        
        ws.lobbyId = null;
    }

    broadcastToGameLobby(lobbyId, message, excludePlayerId = null) {
        const gameLobby = this.gameLobbies.get(lobbyId);
        if (!gameLobby) return;
        
        const messageStr = JSON.stringify(message);
        
        gameLobby.players.forEach((player, playerId) => {
            if (playerId !== excludePlayerId && player.ws.readyState === WebSocket.OPEN) {
                player.ws.send(messageStr);
            }
        });
    }

    sanitizePlayer(player) {
        return {
            id: player.id,
            name: player.name,
            color: player.color,
            balls: player.balls,
            totalMoney: player.totalMoney
        };
    }

    generatePlayerId() {
        return 'player_' + Math.random().toString(36).substr(2, 9);
    }

    generateBallId() {
        return 'ball_' + Math.random().toString(36).substr(2, 9);
    }
    
    // Map lobby ID to region/lobby combination


    startGameLoop() {
        setInterval(() => {
            // Update food and check collisions in all active game lobbies
            this.gameLobbies.forEach((gameLobby, lobbyId) => {
                this.updateGameLobbyFood(gameLobby, lobbyId);
                this.checkCollisions(gameLobby);
            });
        }, 1000 / 60); // Update 60 times per second for smooth gameplay
        
        // Heartbeat to detect dead connections
        setInterval(() => {
            this.wss.clients.forEach((ws) => {
                if (!ws.isAlive) {
                    console.log('🔍 Terminating dead connection');
                    this.removePlayerFromGameLobby(ws);
                    return ws.terminate();
                }
                ws.isAlive = false;
                ws.ping();
            });
        }, 30000); // Check every 30 seconds
        
        // Cleanup old empty lobbies and mass drops
        setInterval(() => {
            this.cleanupOldLobbiesAndMassDrops();
        }, 60000); // Check every minute
    }

    updateGameLobbyFood(gameLobby, lobbyId) {
        // Spawn food if needed - Agar.io style pellets with clustered distribution
        const targetFoodCount = 2000; // Increased for better gameplay
        
        while (gameLobby.food.length < targetFoodCount) {
            const foodTypeRand = Math.random();
            let radius;
            
            // Create properly sized Agar.io style food pellets with better size variety
            if (foodTypeRand < 0.75) {
                // Small food pellets (75% of food) - base size
                radius = 4; // Slightly bigger base size for better visibility
            } else if (foodTypeRand < 0.92) {
                // Medium food (17% of food) - noticeably bigger
                radius = 6; // Medium size
            } else if (foodTypeRand < 0.99) {
                // Large food (7% of food) - bigger
                radius = 8; // Large size
            } else {
                // Extra large food (1% of food) - biggest
                radius = 10; // Extra large size
            }
            
            // Use clustered spawning with random seeds
            let x, y;
            if (Math.random() < 0.6) {
                // 60% chance for clustered spawning
                const clusterCenterX = Math.random() * 7500;
                const clusterCenterY = Math.random() * 7500;
                const clusterRadius = 200 + Math.random() * 300; // Cluster radius 200-500
                const angle = Math.random() * Math.PI * 2;
                const distance = Math.random() * clusterRadius;
                
                x = Math.max(50, Math.min(7450, clusterCenterX + Math.cos(angle) * distance));
                y = Math.max(50, Math.min(7450, clusterCenterY + Math.sin(angle) * distance));
            } else {
                // 40% chance for random spawning
                x = 50 + Math.random() * 7400;
                y = 50 + Math.random() * 7400;
            }
            
            gameLobby.food.push({
                id: 'food_' + Math.random().toString(36).substr(2, 9),
                x: x,
                y: y,
                radius: radius,
                value: radius * 0.5, // Value based on size for growth
                color: this.getRandomFoodColor()
            });
        }
        
        // Update viruses
        this.updateGameLobbyViruses(gameLobby, lobbyId);
        
        // Broadcast food updates regularly to ensure visibility
        this.broadcastToGameLobby(lobbyId, {
            type: 'food_update',
            food: gameLobby.food
        });
    }

    initializeLobbyViruses(lobbyId) {
        const gameLobby = this.gameLobbies.get(lobbyId);
        if (!gameLobby) return;
        
        // Initialize 15 viruses per lobby
        for (let i = 0; i < 15; i++) {
            const radius = 35 + Math.random() * 15;
            gameLobby.viruses.push({
                id: 'virus_' + Math.random().toString(36).substr(2, 9),
                x: Math.random() * 7500,
                y: Math.random() * 7500,
                radius: radius,
                mass: Math.PI * radius * radius / 4,
                color: '#00FF00',
                spikes: 12
            });
        }
        
        console.log(`🦠 Initialized ${gameLobby.viruses.length} viruses for lobby ${lobbyId}`);
    }
    
    updateGameLobbyViruses(gameLobby, lobbyId) {
        // Check virus feeding (food makes viruses grow)
        gameLobby.food.forEach((food, foodIndex) => {
            gameLobby.viruses.forEach((virus, virusIndex) => {
                const dx = food.x - virus.x;
                const dy = food.y - virus.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < virus.radius + food.radius) {
                    // Food feeds the virus
                    virus.mass += food.value * 10 || 5; // Convert food value to mass
                    virus.radius = Math.sqrt(virus.mass / Math.PI) * 2;
                    
                    // Remove the food
                    gameLobby.food.splice(foodIndex, 1);
                    
                    // Check if virus should split
                    if (virus.mass >= 150) {
                        this.splitVirus(gameLobby, virusIndex, lobbyId);
                    }
                }
            });
        });
        
        // Maintain virus count
        while (gameLobby.viruses.length < 15) {
            const radius = 35 + Math.random() * 15;
            gameLobby.viruses.push({
                id: 'virus_' + Math.random().toString(36).substr(2, 9),
                x: Math.random() * 8000,
                y: Math.random() * 8000,
                radius: radius,
                mass: Math.PI * radius * radius / 4,
                color: '#00FF00',
                spikes: 12
            });
        }
        
        // Broadcast virus updates occasionally
        if (Math.random() < 0.02) { // 2% chance each update
            this.broadcastToGameLobby(lobbyId, {
                type: 'virus_update',
                viruses: gameLobby.viruses
            });
        }
    }
    
    splitVirus(gameLobby, virusIndex, lobbyId) {
        const virus = gameLobby.viruses[virusIndex];
        
        // Remove original virus
        gameLobby.viruses.splice(virusIndex, 1);
        
        // Create two new viruses
        const newMass = virus.mass / 2;
        const newRadius = Math.sqrt(newMass / Math.PI) * 2;
        
        for (let i = 0; i < 2; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = virus.radius + 20;
            
            const newVirus = {
                id: 'virus_' + Math.random().toString(36).substr(2, 9),
                x: Math.max(newRadius, Math.min(8000 - newRadius, virus.x + Math.cos(angle) * distance)),
                y: Math.max(newRadius, Math.min(8000 - newRadius, virus.y + Math.sin(angle) * distance)),
                radius: newRadius,
                mass: newMass,
                color: '#00FF00',
                spikes: 12
            };
            
            gameLobby.viruses.push(newVirus);
        }
        
        // Broadcast virus split
        this.broadcastToGameLobby(lobbyId, {
            type: 'virus_split',
            viruses: gameLobby.viruses
        });
    }

    getRandomFoodColor() {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    // Admin Authentication
    async handleAdminAuthenticate(ws, message) {
        const { adminKey } = message;
        
        // Simple admin key check (in production, use proper authentication)
        if (adminKey === 'KJ2N1Mm!-0!') {
            ws.isAdminKeyVerified = true;
            console.log('🔐 Admin key verified, requesting email verification');
            
            // Automatically request email verification
            await this.handleRequestEmailVerification(ws, message);
        } else {
            ws.send(JSON.stringify({ type: 'admin_auth_failed' }));
            console.log('❌ Failed admin authentication attempt');
        }
    }

    // Email Verification for Admin Access
    async handleRequestEmailVerification(ws, message) {
        try {
            const adminEmail = 'larsvgennip@gmail.com';
            
            // Generate 6-digit verification code
            const code = Math.floor(100000 + Math.random() * 900000).toString();
            
            // Store code with expiration (5 minutes)
            this.emailService.storeCode(adminEmail, code);
            
            // Send email via PHP service
            const result = await this.sendEmailViaPHP(adminEmail, code);
            
            if (result.success) {
                ws.send(JSON.stringify({
                    type: 'email_verification_required',
                    success: true,
                    message: 'Verification code sent to admin email'
                }));
                console.log('📧 Email verification code sent to admin');
            } else {
                ws.send(JSON.stringify({
                    type: 'email_code_sent',
                    success: false,
                    message: result.message
                }));
                console.log('❌ Failed to send email verification:', result.message);
            }
        } catch (error) {
            console.error('Error sending email verification:', error);
            ws.send(JSON.stringify({
                type: 'email_code_sent',
                success: false,
                message: 'Failed to send verification email'
            }));
        }
    }

    handleVerifyEmailCode(ws, message) {
        const { code } = message;
        const adminEmail = 'larsvgennip@gmail.com';
        
        // Check if admin key was verified first
        if (!ws.isAdminKeyVerified) {
            ws.send(JSON.stringify({
                type: 'email_verification_failed',
                success: false,
                message: 'Admin key verification required first'
            }));
            return;
        }
        
        const result = this.emailService.verifyCode(adminEmail, code);
        
        if (result.success) {
            ws.isEmailVerified = true;
            ws.isAdmin = true; // Grant full admin access
            ws.send(JSON.stringify({
                type: 'email_verification_success',
                success: true,
                message: 'Email verification successful'
            }));
            console.log('✅ Admin email verification successful - full access granted');
        } else {
            ws.send(JSON.stringify({
                type: 'email_verification_failed',
                success: false,
                message: result.message
            }));
            console.log('❌ Admin email verification failed:', result.message);
        }
    }
    
    async sendEmailViaPHP(email, code) {
        try {
            const https = require('https');
            const querystring = require('querystring');
            
            const postData = querystring.stringify({
                'email': email,
                'code': code,
                'action': 'send_verification'
            });
            
            const options = {
                hostname: '149.12.246.143',
                port: 443,
                path: '/send_verification_email.php',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Content-Length': Buffer.byteLength(postData)
                },
                rejectUnauthorized: false // Accept self-signed certificates
            };
            
            return new Promise((resolve, reject) => {
                const req = https.request(options, (res) => {
                    let data = '';
                    
                    res.on('data', (chunk) => {
                        data += chunk;
                    });
                    
                    res.on('end', () => {
                        try {
                            const result = JSON.parse(data);
                            resolve(result);
                        } catch (e) {
                            resolve({ success: true }); // Assume success if no JSON response
                        }
                    });
                });
                
                req.on('error', (e) => {
                    console.error('Email service error:', e);
                    resolve({ success: false, message: 'Email service unavailable' });
                });
                
                req.write(postData);
                req.end();
            });
        } catch (error) {
            console.error('Error calling PHP email service:', error);
            return { success: false, message: 'Email service error' };
        }
    }

    // User Management Functions
    handleSearchUser(ws, message) {
        // Authentication removed - direct access allowed

        const { searchTerm } = message;
        console.log(`🔍 Admin searching for user: ${searchTerm}`);
        
        // Search for real user data across all lobbies
        let foundUser = null;
        
        // Search through all active players in all lobbies
        for (const [lobbyId, gameLobby] of this.gameLobbies) {
            for (const [playerId, player] of gameLobby.players) {
                if (player.name && (player.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                    player.email && player.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    player.walletAddress && player.walletAddress.includes(searchTerm))) {
                    foundUser = {
                        id: playerId,
                        username: player.name || 'Unknown',
                        email: player.email || 'Not provided',
                        walletAddress: player.walletAddress || 'Not connected',
                        solBalance: player.solBalance || '0',
                        eurBalance: player.eurBalance || '0',
                        status: player.status || 'active',
                        createdAt: player.joinedAt || new Date().toISOString().split('T')[0],
                        lastLogin: new Date().toISOString().split('T')[0],
                        totalGames: player.gamesPlayed || '0',
                        bestScore: player.bestScore || player.score || '0',
                        totalPlaytime: player.totalPlaytime || '0',
                        currentLobby: lobbyId,
                        isOnline: true
                    };
                    break;
                }
            }
            if (foundUser) break;
        }
        
        if (!foundUser) {
            ws.send(JSON.stringify({ 
                type: 'error', 
                message: `User '${searchTerm}' not found in any active lobby` 
            }));
            return;
        }
        
        ws.send(JSON.stringify({ 
            type: 'user_search_result', 
            user: foundUser 
        }));
    }

    handleTimeoutUser(ws, message) {
        // Authentication removed - direct access allowed

        const { userId, username, duration } = message;
        console.log(`⏰ Admin timing out user ${username} for ${duration}ms`);
        
        // In production, update user status in database
        ws.send(JSON.stringify({ 
            type: 'user_action_success', 
            message: `User ${username} has been timed out for 24 hours` 
        }));
    }

    handleBanUser(ws, message) {
        // Authentication removed - direct access allowed

        const { userId, username } = message;
        console.log(`🚫 Admin banning user ${username}`);
        
        // In production, update user status in database
        ws.send(JSON.stringify({ 
            type: 'user_action_success', 
            message: `User ${username} has been permanently banned` 
        }));
    }

    handleUnbanUser(ws, message) {
        // Authentication removed - direct access allowed

        const { userId, username } = message;
        console.log(`✅ Admin unbanning user ${username}`);
        
        // In production, update user status in database
        ws.send(JSON.stringify({ 
            type: 'user_action_success', 
            message: `User ${username} has been unbanned` 
        }));
    }

    // Site Settings
    handleUpdateSiteSettings(ws, message) {
        // Authentication removed - direct access allowed

        const { settings } = message;
        console.log('💾 Admin updating site settings:', settings);
        
        // Validate settings
        const validatedSettings = {};
        
        if (settings.cashoutFee !== undefined) {
            const fee = parseFloat(settings.cashoutFee);
            if (fee >= 0 && fee <= 1) {
                validatedSettings.cashoutFee = fee;
            }
        }
        
        if (settings.gameJoinFee !== undefined) {
            const fee = parseFloat(settings.gameJoinFee);
            if (fee >= 0 && fee <= 1) {
                validatedSettings.gameJoinFee = fee;
            }
        }
        
        if (settings.adminWallet && typeof settings.adminWallet === 'string') {
            validatedSettings.adminWallet = settings.adminWallet;
        }
        
        if (settings.emergencyMode !== undefined) {
            validatedSettings.emergencyMode = Boolean(settings.emergencyMode);
        }
        
        // Update settings
        this.siteSettings = {
            ...this.siteSettings,
            ...validatedSettings
        };
        
        // Save to persistent storage
        try {
            const settingsPath = path.join(__dirname, 'site_settings.json');
            fs.writeFileSync(settingsPath, JSON.stringify(this.siteSettings, null, 2));
            console.log('✅ Site settings updated and saved:', this.siteSettings);
        } catch (error) {
            console.error('❌ Error saving site settings:', error);
        }
        
        ws.send(JSON.stringify({ 
            type: 'settings_updated',
            settings: this.siteSettings
        }));
    }

    handleGetSiteSettings(ws, message) {
        // Authentication removed - direct access allowed

        console.log('📋 Admin requesting current site settings');
        
        ws.send(JSON.stringify({ 
            type: 'settings_updated',
            settings: this.siteSettings
        }));
    }

    // Emergency Functions
    handleEmergencyStopAll(ws, message) {
        // Authentication removed - direct access allowed

        console.log('🛑 EMERGENCY: Admin stopping all lobbies');
        
        let totalPlayersDisconnected = 0;
        
        // Stop all lobbies and disconnect all players
        this.gameLobbies.forEach((gameLobby, lobbyId) => {
            gameLobby.players.forEach((player, playerId) => {
                if (player.ws && player.ws.readyState === WebSocket.OPEN) {
                    player.ws.send(JSON.stringify({
                        type: 'emergency_stop',
                        message: 'Emergency maintenance - all games stopped by admin'
                    }));
                    player.ws.close(1000, 'Emergency stop');
                    totalPlayersDisconnected++;
                }
            });
            
            // Clear lobby
            gameLobby.players.clear();
            gameLobby.food = [];
            gameLobby.gameState.isActive = false;
        });
        
        ws.send(JSON.stringify({ 
            type: 'emergency_complete',
            message: `All lobbies stopped, ${totalPlayersDisconnected} players disconnected`,
            details: `Emergency stop completed at ${new Date().toISOString()}`
        }));
    }

    handleEmergencyCashoutAll(ws, message) {
        // Authentication removed - direct access allowed

        console.log('💸 EMERGENCY: Admin cashing out all players');
        
        let totalPlayersCashedOut = 0;
        let totalAmountCashedOut = 0;
        
        // Cashout all players from all lobbies
        this.gameLobbies.forEach((gameLobby, lobbyId) => {
            gameLobby.players.forEach((player, playerId) => {
                if (player.ws && player.ws.readyState === WebSocket.OPEN) {
                    // Calculate cashout amount based on player score/mass
                    const cashoutAmount = Math.max(0.1, (player.mass || 100) / 1000);
                    totalAmountCashedOut += cashoutAmount;
                    
                    player.ws.send(JSON.stringify({
                        type: 'emergency_cashout',
                        amount: cashoutAmount,
                        message: 'Emergency cashout initiated by admin'
                    }));
                    
                    totalPlayersCashedOut++;
                }
            });
        });
        
        ws.send(JSON.stringify({ 
            type: 'emergency_complete',
            message: `${totalPlayersCashedOut} players cashed out, total: ${totalAmountCashedOut.toFixed(3)} SOL`,
            details: `Emergency cashout completed at ${new Date().toISOString()}`
        }));
    }

    async handleTransferLobbyFundsToAdmin(ws, message) {
        // Authentication removed - direct access allowed

        const { adminWallet } = message;
        console.log(`🏦 EMERGENCY: Admin transferring all lobby funds to ${adminWallet}`);
        
        try {
            // Initialize wallet system if not already done
            // if (!this.walletSystem.isInitialized) {
            //     this.walletSystem.connection = new solanaWeb3.Connection(
            //         'https://api.mainnet-beta.solana.com',
            //         'confirmed'
            //     );
            //     this.walletSystem.isInitialized = true;
            //     console.log('✅ Wallet system initialized for server operations');
            // }
            
            let totalTransferred = 0;
            const transferResults = [];
            
            // Transfer funds from each lobby wallet
            for (const [lobbyId, lobbyData] of this.lobbyWallets) {
                if (!lobbyData.privateKey) {
                    console.log(`⚠️ Skipping lobby ${lobbyId} - no private key`);
                    continue;
                }
                
                try {
                    // Get current balance of lobby wallet
                    const secretKey = new Uint8Array(lobbyData.privateKey);
                    const fromKeypair = solanaWeb3.Keypair.fromSecretKey(secretKey);
                    const balance = await this.walletSystem.connection.getBalance(fromKeypair.publicKey);
                    const balanceSOL = balance / solanaWeb3.LAMPORTS_PER_SOL;
                    
                    console.log(`💰 Lobby ${lobbyId} balance: ${balanceSOL.toFixed(6)} SOL`);
                    
                    // Only transfer if there's a meaningful amount (more than network fees)
                    const networkFeeSOL = 0.000005;
                    const senderRentExemption = 0.00089088;
                    const minTransferAmount = networkFeeSOL + senderRentExemption + 0.001; // Minimum 0.001 SOL to transfer
                    
                    if (balanceSOL > minTransferAmount) {
                        // Calculate transfer amount (leave rent exemption in wallet)
                        const transferAmount = balanceSOL - senderRentExemption - networkFeeSOL;
                        
                        console.log(`📤 Transferring ${transferAmount.toFixed(6)} SOL from lobby ${lobbyId}`);
                        
                        const transferResult = await this.performBlockchainTransfer(
                            lobbyData.privateKey,
                            adminWallet,
                            transferAmount,
                            `Emergency transfer from Lobby ${lobbyId} to Admin`
                        );
                        
                        if (transferResult.success) {
                            totalTransferred += transferAmount;
                            transferResults.push({
                                lobbyId: lobbyId,
                                amount: transferAmount,
                                signature: transferResult.signature,
                                success: true
                            });
                            
                            // Update lobby wallet balance
                            if (lobbyData.gamePool) {
                                lobbyData.gamePool = 0;
                            }
                            
                            console.log(`✅ Lobby ${lobbyId} transfer successful: ${transferResult.signature}`);
                        } else {
                            transferResults.push({
                                lobbyId: lobbyId,
                                amount: 0,
                                error: transferResult.error,
                                success: false
                            });
                            console.error(`❌ Lobby ${lobbyId} transfer failed: ${transferResult.error}`);
                        }
                    } else {
                        console.log(`⚠️ Lobby ${lobbyId} balance too low to transfer (${balanceSOL.toFixed(6)} SOL)`);
                        transferResults.push({
                            lobbyId: lobbyId,
                            amount: 0,
                            message: 'Balance too low',
                            success: true
                        });
                    }
                    
                } catch (error) {
                    console.error(`❌ Error processing lobby ${lobbyId}:`, error);
                    transferResults.push({
                        lobbyId: lobbyId,
                        amount: 0,
                        error: error.message,
                        success: false
                    });
                }
            }
            
            console.log(`🏦 Total transferred to admin: ${totalTransferred.toFixed(6)} SOL`);
            
            ws.send(JSON.stringify({ 
                type: 'emergency_complete',
                message: `${totalTransferred.toFixed(6)} SOL transferred from ${transferResults.filter(r => r.success && r.amount > 0).length} lobby wallets to admin wallet`,
                details: `Fund transfer completed at ${new Date().toISOString()}`,
                totalTransferred: totalTransferred.toFixed(6),
                transferResults: transferResults
            }));
            
        } catch (error) {
            console.error('❌ Emergency lobby funds transfer failed:', error);
            ws.send(JSON.stringify({ 
                type: 'error', 
                message: `Emergency transfer failed: ${error.message}`
            }));
        }
    }

    // Lobby Management
    handleCheckLobbyStatus(ws, message) {
        // Authentication removed - direct access allowed

        const { lobbyId } = message;
        const gameLobby = this.gameLobbies.get(lobbyId);
        
        if (!gameLobby) {
            ws.send(JSON.stringify({ type: 'error', message: `Lobby ${lobbyId} not found` }));
            return;
        }
        
        const status = {
            players: gameLobby.players.size,
            balance: (Math.random() * 5).toFixed(3), // Mock balance
            state: gameLobby.gameState.isActive ? 'active' : 'inactive',
            lastUpdate: new Date(gameLobby.gameState.lastUpdate).toISOString()
        };
        
        ws.send(JSON.stringify({ type: 'lobby_status', status }));
    }

    async handleViewLobbyWallet(ws, message) {
        // Authentication removed - direct access allowed

        const { lobbyId } = message;
        const lobbyWallet = this.lobbyWallets.get(parseInt(lobbyId));
        
        if (!lobbyWallet) {
            ws.send(JSON.stringify({ 
                type: 'error', 
                message: `Lobby ${lobbyId} wallet not found` 
            }));
            return;
        }
        
        try {
            // Get real balance from Solana blockchain
            let balance = '0';
            let transactionCount = 'Unknown';
            
            // if (this.walletSystem && this.walletSystem.connection) {
            //     try {
            //         const publicKey = new solanaWeb3.PublicKey(lobbyWallet.publicKey);
            //         const balanceInfo = await this.walletSystem.connection.getBalance(publicKey);
            //         balance = (balanceInfo / solanaWeb3.LAMPORTS_PER_SOL).toFixed(6);
            //         
            //         // Get transaction count
            //         const signatures = await this.walletSystem.connection.getSignaturesForAddress(publicKey, { limit: 1000 });
            //         transactionCount = signatures.length;
            //     } catch (blockchainError) {
            //         console.log('⚠️ Could not fetch live blockchain data:', blockchainError.message);
            //         balance = 'Unable to fetch';
            //     }
            // }
            
            const walletInfo = {
                address: lobbyWallet.publicKey,
                balance: balance,
                transactions: transactionCount,
                name: lobbyWallet.name || `Lobby ${lobbyId}`,
                region: lobbyWallet.region || 'Unknown'
            };
            
            ws.send(JSON.stringify({ 
                type: 'user_action_success', 
                message: `${walletInfo.name} (${walletInfo.region}) | Address: ${walletInfo.address} | Balance: ${walletInfo.balance} SOL | Transactions: ${walletInfo.transactions}` 
            }));
        } catch (error) {
            console.error('❌ Error fetching lobby wallet info:', error);
            ws.send(JSON.stringify({ 
                type: 'error', 
                message: `Error fetching wallet info for Lobby ${lobbyId}: ${error.message}` 
            }));
        }
    }

    handleStopLobby(ws, message) {
        // Authentication removed - direct access allowed

        const { lobbyId } = message;
        const gameLobby = this.gameLobbies.get(lobbyId);
        
        if (!gameLobby) {
            ws.send(JSON.stringify({ type: 'error', message: `Lobby ${lobbyId} not found` }));
            return;
        }
        
        console.log(`🛑 Admin stopping Lobby ${lobbyId}`);
        
        // Disconnect all players in the lobby
        let playersDisconnected = 0;
        gameLobby.players.forEach((player, playerId) => {
            if (player.ws && player.ws.readyState === WebSocket.OPEN) {
                player.ws.send(JSON.stringify({
                    type: 'lobby_stopped',
                    message: 'Lobby has been stopped by admin'
                }));
                player.ws.close(1000, 'Lobby stopped by admin');
                playersDisconnected++;
            }
        });
        
        // Clear lobby
        gameLobby.players.clear();
        gameLobby.food = [];
        gameLobby.gameState.isActive = false;
        
        ws.send(JSON.stringify({ 
            type: 'user_action_success', 
            message: `Lobby ${lobbyId} stopped, ${playersDisconnected} players disconnected` 
        }));
    }

    // Blockchain Operations
    async handleBlockchainTransfer(ws, message) {
        // Authentication removed - direct access allowed
        const { fromWallet, toAddress, amount, reason } = message;
        console.log(`🔗 Blockchain transfer: ${amount} SOL from ${fromWallet} to ${toAddress} (${reason})`);
        
        try {
            // Initialize wallet system if not already done
            if (!this.walletSystem.isInitialized) {
                // Create a mock connection for server-side operations
                this.walletSystem.connection = new solanaWeb3.Connection(
                    'https://api.mainnet-beta.solana.com',
                    'confirmed'
                );
                this.walletSystem.isInitialized = true;
                console.log('✅ Wallet system initialized for server operations');
            }
            
            // Find the lobby wallet data
            let lobbyWalletData = null;
            let lobbyId = null;
            
            // Extract lobby ID from wallet name - support multiple formats:
            // "Lobby 1 Wallet" -> 1, "lobby1" -> 1, "Lobby 5" -> 5, "lobby5" -> 5
            let lobbyMatch = fromWallet.match(/Lobby (\d+)/);
            if (!lobbyMatch) {
                lobbyMatch = fromWallet.match(/lobby(\d+)/);
            }
            
            if (lobbyMatch) {
                lobbyId = parseInt(lobbyMatch[1]);
                lobbyWalletData = this.lobbyWallets.get(lobbyId);
                console.log(`🔍 Searching for lobby ${lobbyId} wallet data from input: ${fromWallet}`);
            }
            
            if (!lobbyWalletData || !lobbyWalletData.privateKey) {
                throw new Error(`Lobby wallet data not found for ${fromWallet}`);
            }
            
            console.log(`💰 Found lobby ${lobbyId} wallet data`);
            console.log(`📤 From: ${lobbyWalletData.publicKey}`);
            console.log(`📥 To: ${toAddress}`);
            console.log(`💵 Amount: ${amount} SOL`);
            
            // Perform the actual blockchain transfer
            const transferResult = await this.performBlockchainTransfer(
                lobbyWalletData.privateKey,
                toAddress,
                amount,
                reason
            );
            
            if (transferResult.success) {
                console.log(`✅ Blockchain transfer successful! Signature: ${transferResult.signature}`);
                
                // Update lobby wallet balance (subtract transferred amount)
                if (lobbyWalletData.gamePool) {
                    lobbyWalletData.gamePool = Math.max(0, lobbyWalletData.gamePool - amount);
                }
                
                ws.send(JSON.stringify({ 
                    type: 'blockchain_transfer_success',
                    signature: transferResult.signature,
                    amount: amount,
                    from: fromWallet,
                    to: toAddress,
                    message: `Successfully transferred ${amount} SOL from ${fromWallet} to external wallet`
                }));
            } else {
                throw new Error(transferResult.error);
            }
            
        } catch (error) {
            console.error('❌ Blockchain transfer failed:', error);
            ws.send(JSON.stringify({ 
                type: 'error', 
                message: `Transfer failed: ${error.message}`
            }));
        }
    }
    
    async performBlockchainTransfer(privateKeyArray, toAddress, solAmount, reason) {
        try {
            // Convert private key array to Uint8Array
            const secretKey = new Uint8Array(privateKeyArray);
            const fromKeypair = solanaWeb3.Keypair.fromSecretKey(secretKey);
            
            console.log(`🚀 Starting blockchain transfer:`);
            console.log(`   From: ${fromKeypair.publicKey.toString()}`);
            console.log(`   To: ${toAddress}`);
            console.log(`   Amount: ${solAmount} SOL`);
            console.log(`   Reason: ${reason}`);
            
            // Get sender balance
            const senderBalance = await this.walletSystem.connection.getBalance(fromKeypair.publicKey);
            const senderBalanceSOL = senderBalance / solanaWeb3.LAMPORTS_PER_SOL;
            
            console.log(`💰 Sender balance: ${senderBalanceSOL.toFixed(6)} SOL`);
            
            // Calculate required amount (transfer + network fee + rent exemption)
            const networkFeeSOL = 0.000005;
            const senderRentExemption = 0.00089088;
            const totalRequiredSOL = solAmount + networkFeeSOL + senderRentExemption;
            
            if (senderBalanceSOL < totalRequiredSOL) {
                const shortfall = totalRequiredSOL - senderBalanceSOL;
                throw new Error(`Insufficient funds. Need ${totalRequiredSOL.toFixed(6)} SOL total. Have ${senderBalanceSOL.toFixed(6)} SOL. Missing: ${shortfall.toFixed(6)} SOL.`);
            }
            
            // Convert SOL to lamports
            const lamports = Math.floor(solAmount * solanaWeb3.LAMPORTS_PER_SOL);
            
            // Create transaction
            const toPublicKey = new solanaWeb3.PublicKey(toAddress);
            const transaction = new solanaWeb3.Transaction();
            
            transaction.add(
                solanaWeb3.SystemProgram.transfer({
                    fromPubkey: fromKeypair.publicKey,
                    toPubkey: toPublicKey,
                    lamports: lamports
                })
            );
            
            console.log(`📝 Transaction created with ${lamports} lamports`);
            
            // Send transaction
            const signature = await solanaWeb3.sendAndConfirmTransaction(
                this.walletSystem.connection,
                transaction,
                [fromKeypair],
                {
                    commitment: 'confirmed',
                    preflightCommitment: 'confirmed'
                }
            );
            
            console.log(`✅ Transfer successful! Signature: ${signature}`);
            
            return {
                success: true,
                signature: signature,
                amount: solAmount,
                from: fromKeypair.publicKey.toString(),
                to: toAddress
            };
            
        } catch (error) {
            console.error('❌ Blockchain transfer error:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Utility methods for Agar.io mechanics
    calculateSizeFromMoney(money) {
        // Base size of 40, grows with money - reduced by 50% for proper agar.io size
        return (40 + Math.sqrt(money * 1000)) * 0.5; // Reduced base size and multiplier for 50% smaller
    }
    
    generateMassDropId() {
        return 'mass_' + Math.random().toString(36).substr(2, 9);
    }
    
    generateTransactionId() {
        return 'tx_' + Math.random().toString(36).substr(2, 16);
    }
    
    async processRealCashout(ws, player, amount, kills, playtime) {
        try {
            console.log(`🔗 Processing real Solana cashout for ${player.name}: €${amount}`);
            
            // Send cashout request to client to handle blockchain transaction
            ws.send(JSON.stringify({
                type: 'initiateCashout',
                data: {
                    lobbyId: ws.lobbyId,
                    playerId: ws.playerId,
                    amount: amount,
                    kills: kills,
                    playtime: playtime
                }
            }));
            
            console.log(`📡 Sent cashout initiation to client for blockchain processing`);
            
        } catch (error) {
            console.error('❌ Failed to initiate cashout:', error);
            
            // Send error response to player
            ws.send(JSON.stringify({
                type: 'cashoutComplete',
                data: {
                    success: false,
                    error: 'Failed to initiate cashout: ' + error.message
                }
            }));
        }
    }
    
    handleCashoutResult(ws, message) {
        if (!ws.lobbyId || !ws.playerId) {
            console.error('❌ Cashout result received but player not in lobby');
            return;
        }
        
        const gameLobby = this.gameLobbies.get(ws.lobbyId);
        if (!gameLobby) {
            console.error('❌ Cashout result received but lobby not found');
            return;
        }
        
        const player = gameLobby.players.get(ws.playerId);
        if (!player) {
            console.error('❌ Cashout result received but player not found');
            return;
        }
        
        const { success, amount, transactionSignature, error } = message.data;
        
        if (success) {
            console.log(`✅ Blockchain cashout successful for ${player.name}: €${amount}, signature: ${transactionSignature}`);
            
            // Send final success response to player
            ws.send(JSON.stringify({
                type: 'cashoutComplete',
                data: {
                    success: true,
                    amount: amount,
                    transactionSignature: transactionSignature,
                    blockchainTransaction: true,
                    message: `Successfully cashed out €${amount} via Solana blockchain`
                }
            }));
            
            // Broadcast to other players in lobby
            this.broadcastToGameLobby(ws.lobbyId, {
                type: 'playerCashedOut',
                data: {
                    playerId: ws.playerId,
                    playerName: player.name,
                    amount: amount
                }
            }, ws.playerId);
            
            // Remove player from lobby
            this.removePlayerFromGameLobby(ws);
            
        } else {
            console.error(`❌ Blockchain cashout failed for ${player.name}: ${error}`);
            
            // Send error response to player
            ws.send(JSON.stringify({
                type: 'cashoutComplete',
                data: {
                    success: false,
                    error: `Blockchain transaction failed: ${error}`
                }
            }));
        }
    }
    
    checkCollisions(gameLobby) {
        const players = Array.from(gameLobby.players.values());
        
        for (let i = 0; i < players.length; i++) {
            const player1 = players[i];
            
            for (let j = i + 1; j < players.length; j++) {
                const player2 = players[j];
                
                // Check collisions between all balls of both players
                for (const ball1 of player1.balls) {
                    for (const ball2 of player2.balls) {
                        this.checkBallCollision(ball1, ball2, player1, player2, gameLobby);
                    }
                }
            }
            
            // Check mass drop pickups
            if (gameLobby.massDrops) {
                this.checkMassDropPickups(player1, gameLobby);
            }
            
            // Check food pickups
            this.checkFoodPickups(player1, gameLobby);
        }
    }
    
    checkBallCollision(ball1, ball2, player1, player2, gameLobby) {
        const dx = ball1.x - ball2.x;
        const dy = ball1.y - ball2.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        const radius1 = ball1.size / 2;
        const radius2 = ball2.size / 2;
        
        // Check if balls are touching or overlapping
        if (distance < radius1 + radius2) {
            // Determine which ball is bigger
            let biggerBall, smallerBall, biggerPlayer, smallerPlayer;
            
            if (ball1.size > ball2.size) {
                biggerBall = ball1;
                smallerBall = ball2;
                biggerPlayer = player1;
                smallerPlayer = player2;
            } else {
                biggerBall = ball2;
                smallerBall = ball1;
                biggerPlayer = player2;
                smallerPlayer = player1;
            }
            
            // Calculate overlap percentage
            const overlapDistance = (biggerBall.size / 2 + smallerBall.size / 2) - distance;
            const overlapPercentage = overlapDistance / (smallerBall.size / 2);
            
            // Check if bigger ball can eat smaller ball (85% overlap or direct contact)
            if (overlapPercentage >= 0.85 || distance <= 1) {
                // Bigger ball eats smaller ball
                this.eatBall(biggerBall, smallerBall, biggerPlayer, smallerPlayer, gameLobby);
            }
        }
    }
    
    eatBall(eaterBall, victimBall, eaterPlayer, victimPlayer, gameLobby) {
        // Transfer money and size
        eaterBall.money += victimBall.money;
        eaterBall.size = this.calculateSizeFromMoney(eaterBall.money);
        
        // Remove victim ball from victim player
        victimPlayer.balls = victimPlayer.balls.filter(ball => ball.id !== victimBall.id);
        
        // Update player total money
        eaterPlayer.totalMoney = eaterPlayer.balls.reduce((sum, ball) => sum + ball.money, 0);
        victimPlayer.totalMoney = victimPlayer.balls.reduce((sum, ball) => sum + ball.money, 0);
        
        // Increment kills for eater
        eaterPlayer.kills = (eaterPlayer.kills || 0) + 1;
        
        console.log(`🍽️ ${eaterPlayer.name} ate ${victimPlayer.name}'s ball (€${victimBall.money.toFixed(2)})`);
        
        // Broadcast ball eaten event
        this.broadcastToGameLobby(gameLobby.id, {
            type: 'ballEaten',
            data: {
                eaterPlayerId: eaterPlayer.id,
                victimPlayerId: victimPlayer.id,
                eaterBall: eaterBall,
                victimBallId: victimBall.id
            }
        });
        
        // Check if victim player is eliminated (no balls left)
        if (victimPlayer.balls.length === 0) {
            this.eliminatePlayer(victimPlayer, gameLobby);
        }
    }
    
    eliminatePlayer(player, gameLobby) {
        console.log(`💀 Player ${player.name} eliminated`);
        
        // Find player's WebSocket connection
        const playerWs = Array.from(this.wss.clients).find(ws => 
            ws.playerId === player.id && ws.lobbyId === gameLobby.id
        );
        
        if (playerWs) {
            // Send elimination message to player
            playerWs.send(JSON.stringify({
                type: 'playerEliminated',
                data: {
                    kills: player.kills || 0,
                    playtime: Math.floor((Date.now() - player.startTime) / 1000)
                }
            }));
        }
        
        // Broadcast elimination to other players
        this.broadcastToGameLobby(gameLobby.id, {
            type: 'playerEliminated',
            data: {
                playerId: player.id,
                playerName: player.name
            }
        }, player.id);
        
        // Remove player from lobby
        if (playerWs) {
            this.removePlayerFromGameLobby(playerWs);
        }
    }
    
    checkMassDropPickups(player, gameLobby) {
        if (!gameLobby.massDrops) return;
        
        for (const ball of player.balls) {
            for (let i = gameLobby.massDrops.length - 1; i >= 0; i--) {
                const massDrop = gameLobby.massDrops[i];
                
                // Allow players to eat their own mass drops (like Agar.io)
                // if (massDrop.playerId === player.id) continue;
                
                const dx = ball.x - massDrop.x;
                const dy = ball.y - massDrop.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                // Check if ball can pick up mass drop
                if (distance < ball.size / 2 + massDrop.size / 2) {
                    // Add money to ball
                    ball.money += massDrop.money;
                    ball.size = this.calculateSizeFromMoney(ball.money);
                    
                    // Update player total money
                    player.totalMoney = player.balls.reduce((sum, ball) => sum + ball.money, 0);
                    
                    // Remove mass drop
                    gameLobby.massDrops.splice(i, 1);
                    
                    // Broadcast mass pickup
                    this.broadcastToGameLobby(gameLobby.id, {
                        type: 'massPickup',
                        data: {
                            playerId: player.id,
                            ballId: ball.id,
                            massDropId: massDrop.id
                        }
                    });
                    
                    console.log(`🔄 ${player.name} picked up mass: €${massDrop.money.toFixed(2)}`);
                    break;
                }
            }
        }
    }
    
    checkFoodPickups(player, gameLobby) {
        if (!gameLobby.food) return;
        
        for (const ball of player.balls) {
            for (let i = gameLobby.food.length - 1; i >= 0; i--) {
                const food = gameLobby.food[i];
                
                const dx = ball.x - food.x;
                const dy = ball.y - food.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                // Check if ball can eat food (ball radius + food radius)
                if (distance < ball.size / 2 + food.radius) {
                    // Food gives only size growth, no money
                    const sizeGrowth = food.radius * 0.5; // Growth based on food size
                    ball.size += sizeGrowth;
                    
                    // Update player total money
                    player.totalMoney = player.balls.reduce((sum, ball) => sum + ball.money, 0);
                    
                    // Remove food
                    gameLobby.food.splice(i, 1);
                    
                    // Broadcast food eaten
                    this.broadcastToGameLobby(gameLobby.id, {
                        type: 'food_eaten',
                        foodId: food.id,
                        playerId: player.id,
                        ballId: ball.id
                    });
                    
                    break;
                }
            }
        }
    }

    cleanupOldLobbiesAndMassDrops() {
        const now = Date.now();
        const LOBBY_CLEANUP_TIME = 10 * 60 * 1000; // 10 minutes
        const MASS_DROP_CLEANUP_TIME = 5 * 60 * 1000; // 5 minutes
        
        // Cleanup old empty lobbies
        this.gameLobbies.forEach((gameLobby, lobbyId) => {
            if (gameLobby.players.size === 0 && 
                (!gameLobby.pendingPlayers || gameLobby.pendingPlayers.size === 0) &&
                gameLobby.lastActivity && 
                (now - gameLobby.lastActivity) > LOBBY_CLEANUP_TIME) {
                
                this.gameLobbies.delete(lobbyId);
                console.log(`🧹 Cleaned up old empty game lobby ${lobbyId}`);
            }
            
            // Cleanup old mass drops in active lobbies
            if (gameLobby.massDrops) {
                const initialCount = gameLobby.massDrops.length;
                gameLobby.massDrops = gameLobby.massDrops.filter(massDrop => {
                    return (now - massDrop.createdAt) < MASS_DROP_CLEANUP_TIME;
                });
                
                const removedCount = initialCount - gameLobby.massDrops.length;
                if (removedCount > 0) {
                    console.log(`🧹 Cleaned up ${removedCount} old mass drops in lobby ${lobbyId}`);
                }
            }
        });
    }

    start() {
        this.server.listen(this.port, () => {
            console.log(`🎮 Game server running on port ${this.port}`);
            console.log(`🔗 Ready to accept game connections`);
            console.log(`📡 Protocol: ${this.isSSLEnabled ? 'WSS (Secure)' : 'WS (Standard)'}`);            
            
            // Initialize all lobbies and start the game loop
            this.initializeAllLobbies();
            this.startGameLoop();
            console.log('🎮 Game loop started - food and viruses will now spawn');
        });
    }
}

// Start the server
const gameServer = new GameServer(8081);
gameServer.start();
// Social Popup JavaScript - Real Database Version
console.log('=== NEW SOCIAL POPUP LOADED ===');

let currentUser = null;
let currentUserId = null;

// API Base URL - gebruik altijd de live server
const API_BASE = 'https://oopsnowh.com/api';

// Get current user from AuthSystem
function getCurrentUser() {
    console.log('Getting current user...');
    
    // Try AuthSystem first
    if (window.authSystem && window.authSystem.getCurrentUser()) {
        const user = window.authSystem.getCurrentUser();
        console.log('AuthSystem user:', user);
        if (user && (user.username || user.email)) {
            currentUser = user.username || user.email;
            return currentUser;
        }
    }
    
    // Fallback sources
    const fallbackSources = [
        localStorage.getItem('currentUser'),
        localStorage.getItem('username'),
        localStorage.getItem('userEmail'),
        'TestUser' // Final fallback
    ];
    
    for (const source of fallbackSources) {
        if (source) {
            console.log('Using fallback user:', source);
            currentUser = source;
            return currentUser;
        }
    }
    
    console.log('Using final fallback: TestUser');
    currentUser = 'TestUser';
    return currentUser;
}

// Get user ID from username
async function getUserId(username) {
    try {
        const response = await fetch(`${API_BASE}/test_profile.php?username=${encodeURIComponent(username)}`);
        const data = await response.json();
        
        if (data.success && data.user && data.user.id) {
            return data.user.id;
        }
        return null;
    } catch (error) {
        console.error('Error getting user ID:', error);
        return null;
    }
}

// Show social popup
async function showSocialPopup() {
    console.log('=== SHOWING NEW SOCIAL POPUP ===');
    const popup = document.getElementById('socialPopup');
    
    if (popup) {
        popup.style.display = 'flex';
        
        // Get current user and initialize
        currentUser = getCurrentUser();
        currentUserId = await getUserId(currentUser);
        
        console.log('Current user:', currentUser);
        console.log('Current user ID:', currentUserId);
        
        // Load initial data
        await loadProfileData();
        await loadFriends();
        await loadLeaderboard();
    } else {
        console.error('socialPopup element not found!');
    }
}

// Close social popup
function closeSocialPopup() {
    const popup = document.getElementById('socialPopup');
    if (popup) {
        popup.style.display = 'none';
    }
}

// Switch between tabs
function switchTab(tabName) {
    // Hide all tab panels
    const panels = document.querySelectorAll('.tab-panel');
    panels.forEach(panel => {
        panel.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab panel
    const targetPanel = document.getElementById(tabName + '-tab');
    if (targetPanel) {
        targetPanel.classList.add('active');
    }
    
    // Add active class to clicked button
    event.target.classList.add('active');
    
    // Load data for specific tabs if needed
    if (tabName === 'profile') {
        loadProfileData();
    } else if (tabName === 'friends') {
        loadFriends();
    } else if (tabName === 'leaderboard') {
        loadLeaderboard();
    }
}

// Load profile data
async function loadProfileData() {
    console.log('Loading profile data for:', currentUser);
    const container = document.getElementById('profileStats');
    
    if (!container) return;
    
    container.innerHTML = '<div class="loading">Loading profile data...</div>';
    
    try {
        const response = await fetch(`${API_BASE}/get_profile_stats.php?username=${encodeURIComponent(currentUser)}`);
        const data = await response.json();
        
        console.log('Profile API response:', data);
        
        if (data.success && data.user) {
            const user = data.user;
            const stats = data.stats || {};
            
            container.innerHTML = `
                <div class="stat-card">
                    <div class="stat-value">${user.balance || '0.00'}</div>
                    <div class="stat-label">Balance ($)</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${user.total_winnings || '0.00'}</div>
                    <div class="stat-label">Total Winnings ($)</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${user.games_played || '0'}</div>
                    <div class="stat-label">Games Played</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.total_kills || '0'}</div>
                    <div class="stat-label">Total Kills</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.total_wins || '0'}</div>
                    <div class="stat-label">Total Wins</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">${stats.total_losses || '0'}</div>
                    <div class="stat-label">Total Losses</div>
                </div>
            `;
        } else {
            container.innerHTML = '<div class="error">Failed to load profile data: ' + (data.error || 'Unknown error') + '</div>';
        }
    } catch (error) {
        console.error('Error loading profile:', error);
        container.innerHTML = '<div class="error">Error loading profile data. Please try again.</div>';
    }
}

// Load friends list
async function loadFriends() {
    console.log('Loading friends for user ID:', currentUserId);
    const container = document.getElementById('friendsList');
    
    if (!container) {
        return;
    }
    
    container.innerHTML = '<div class="loading">Loading friends...</div>';
    
    try {
        // If we don't have currentUserId, try to get it first
        if (!currentUserId) {
            currentUserId = await getUserId(currentUser);
        }
        
        // If still no user ID, use username as fallback
        const userParam = currentUserId || currentUser;
        const response = await fetch(`${API_BASE}/get_friends.php?user_id=${userParam}`);
        const data = await response.json();
        
        console.log('Friends API response:', data);
        
        if (data.success) {
            if (data.friends && data.friends.length > 0) {
                container.innerHTML = data.friends.map(friend => `
                    <div class="friend-item">
                        <div class="friend-info">
                            <div class="friend-avatar">
                                ${friend.username ? friend.username.charAt(0).toUpperCase() : '?'}
                            </div>
                            <div class="friend-details">
                                <h4>${friend.username || 'Unknown'}</h4>
                                <p>Balance: $${friend.balance || '0.00'} | Games: ${friend.games_played || '0'}</p>
                            </div>
                        </div>
                        <div class="friend-actions">
                            <button class="action-btn" onclick="viewProfile('${friend.username}')">
                                View Profile
                            </button>
                        </div>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<div class="no-data">No friends found. Use the Search tab to find and add friends!</div>';
            }
        } else {
            container.innerHTML = '<div class="error">Failed to load friends: ' + (data.error || 'Unknown error') + '</div>';
        }
    } catch (error) {
        console.error('Error loading friends:', error);
        container.innerHTML = '<div class="error">Error loading friends. Please try again.</div>';
    }
}

// Load leaderboard
async function loadLeaderboard() {
    console.log('Loading leaderboard...');
    const container = document.getElementById('leaderboardList');
    
    if (!container) return;
    
    container.innerHTML = '<div class="loading">Loading leaderboard...</div>';
    
    try {
        // Use the existing leaderboard endpoint
        const response = await fetch('https://oopsnowh.com/api/get_leaderboard.php');
        const data = await response.json();
        
        console.log('Leaderboard API response:', data);
        
        if (data.success && data.leaderboard && data.leaderboard.length > 0) {
            container.innerHTML = data.leaderboard.map((player, index) => {
                const rank = index + 1;
                let rankClass = '';
                if (rank === 1) rankClass = 'gold';
                else if (rank === 2) rankClass = 'silver';
                else if (rank === 3) rankClass = 'bronze';
                
                return `
                    <div class="leaderboard-item">
                        <div class="rank ${rankClass}">${rank}.</div>
                        <div class="player-info">
                            <div class="player-name">${player.username || 'Unknown'}</div>
                            <div class="player-stats">Balance: €${(player.balance || 0).toFixed(2)} | Earnings: €${(player.total_winnings || 0).toFixed(2)} | Games: ${player.games_played || 0}</div>
                        </div>
                    </div>
                `;
            }).join('');
        } else {
            container.innerHTML = '<div class="no-data">No leaderboard data available</div>';
        }
    } catch (error) {
        console.error('Error loading leaderboard:', error);
        container.innerHTML = '<div class="error">Error loading leaderboard. Please try again.</div>';
    }
}

// Search users
let searchTimeout;
async function searchUsers() {
    const searchInput = document.getElementById('searchInput');
    const resultsContainer = document.getElementById('searchResults');
    
    if (!searchInput || !resultsContainer) return;
    
    const query = searchInput.value.trim();
    
    // Clear previous timeout
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }
    
    if (query.length < 2) {
        resultsContainer.innerHTML = '<div class="no-data">Enter at least 2 characters to search</div>';
        return;
    }
    
    // Debounce search
    searchTimeout = setTimeout(async () => {
        resultsContainer.innerHTML = '<div class="loading">Searching...</div>';
        
        try {
            const response = await fetch(`${API_BASE}/search_users.php?query=${encodeURIComponent(query)}`);
            const data = await response.json();
            
            console.log('Search API response:', data);
            
            if (data.success && data.users && data.users.length > 0) {
                resultsContainer.innerHTML = data.users.map(user => `
                    <div class="friend-item">
                        <div class="friend-info">
                            <div class="friend-avatar">
                                ${user.username ? user.username.charAt(0).toUpperCase() : '?'}
                            </div>
                            <div class="friend-details">
                                <h4>${user.username || 'Unknown'}</h4>
                                <p>Balance: $${user.balance || '0.00'} | Games: ${user.games_played || '0'}</p>
                            </div>
                        </div>
                        <div class="friend-actions">
                            <button class="action-btn" onclick="viewProfile('${user.username}')">
                                View Profile
                            </button>
                            <button class="action-btn" onclick="addFriend('${user.username}')">
                                Add Friend
                            </button>
                        </div>
                    </div>
                `).join('');
            } else {
                resultsContainer.innerHTML = '<div class="no-data">No users found matching "' + query + '"</div>';
            }
        } catch (error) {
            console.error('Error searching users:', error);
            resultsContainer.innerHTML = '<div class="error">Error searching users. Please try again.</div>';
        }
    }, 500);
}

// View profile function
function viewProfile(username) {
    console.log('Viewing profile for:', username);
    // Switch to profile tab and load that user's data
    // For now, just show an alert
    alert('Profile view for ' + username + ' - Feature coming soon!');
}

// Add friend function
function addFriend(username) {
    console.log('Adding friend:', username);
    // Implement friend request functionality
    alert('Friend request sent to ' + username + ' - Feature coming soon!');
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Social popup DOM loaded');
});

// Export functions for global access
window.showSocialPopup = showSocialPopup;
window.closeSocialPopup = closeSocialPopup;
window.switchTab = switchTab;
window.searchUsers = searchUsers;
window.viewProfile = viewProfile;
window.addFriend = addFriend;

console.log('Social popup JavaScript loaded successfully');
<?php
require_once 'config_hostinger.php';

$db = Database::getInstance();
echo 'Database connected: ' . ($db->isConnected() ? 'YES' : 'NO') . "\n";
echo 'Using database: ' . ($db->useDatabase() ? 'YES' : 'NO') . "\n";

if ($db->isConnected()) {
    echo 'Database connection successful!\n';
} else {
    echo 'Database connection failed - using JSON fallback\n';
}
?>
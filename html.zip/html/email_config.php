<?php
// Email Configuration
// To enable real email sending, update these settings with your SMTP provider

// Hostinger SMTP Configuration
// Using Hostinger's SMTP server with no-reply@oopsnowh.com
// Configure these settings in your Hostinger control panel

define('SMTP_HOST', 'smtp.hostinger.com');
define('SMTP_PORT', 465);
define('SMTP_USERNAME', 'no-reply@oopsnowh.com'); // Your Hostinger email address
define('SMTP_PASSWORD', 'KJ2N10!_91n2kX'); // Your Hostinger email password
define('SMTP_FROM_EMAIL', 'no-reply@oopsnowh.com'); // Your Hostinger email address
define('SMTP_FROM_NAME', 'OopsNowh Game');

// Alternative: SendGrid Configuration
// define('SMTP_HOST', 'smtp.sendgrid.net');
// define('SMTP_PORT', 587);
// define('SMTP_USERNAME', 'apikey');
// define('SMTP_PASSWORD', 'your-sendgrid-api-key');
// define('SMTP_FROM_EMAIL', 'noreply@yourdomain.com');
// define('SMTP_FROM_NAME', 'Agario Game');

// Alternative: Mailgun Configuration
// define('SMTP_HOST', 'smtp.mailgun.org');
// define('SMTP_PORT', 587);
// define('SMTP_USERNAME', 'your-mailgun-username');
// define('SMTP_PASSWORD', 'your-mailgun-password');
// define('SMTP_FROM_EMAIL', 'noreply@yourdomain.com');
// define('SMTP_FROM_NAME', 'Agario Game');
?>
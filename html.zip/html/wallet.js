// Direct access prevention
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
    throw new Error('Direct file access denied');
}

// Wallet System - Handles Solana crypto deposits and balance management
class WalletSystem {
    constructor() {
        this.connection = null;
        this.deposits = {};
        this.userWallets = new Map(); // Initialize as Map
        this.pendingDeposits = new Map(); // Initialize as Map
        this.monitoringIntervals = new Map(); // Store monitoring intervals for each user
        this.isInitialized = false; // Track initialization status
        
        // Solana configuration - using reliable free RPC endpoints
        this.solanaConfig = {
            rpcEndpoint: 'https://solana-api.projectserum.com', // Free, reliable mainnet RPC
            devnetEndpoint: 'https://api.devnet.solana.com',
            useDevnet: false, // Set to true for testing with devnet
            lamportsPerSol: 1000000000,
            solToEuroRate: 157.12, // Default fallback rate - will be auto-updated with real price
            eurToSolRate: 1/157.12, // 1 EUR = ~0.0064 SOL (inverse of solToEuroRate)
            lastPriceUpdate: 0, // Force fresh price fetch on first use
            priceUpdateInterval: 300000 // Update price every 5 minutes
        }
        
        // Initialize the wallet system
        this.init();
    }

    // Enhanced transaction confirmation with retry logic
    async confirmTransactionWithRetry(signature, timeoutMs = 60000) {
        const startTime = Date.now();
        const pollInterval = 2000; // Poll every 2 seconds
        
        console.log(`🔍 Confirming transaction ${signature} using polling method (WebSocket disabled)`);
        
        while ((Date.now() - startTime) < timeoutMs) {
            try {
                console.log(`Checking transaction status...`);
                
                // Use getSignatureStatus instead of confirmTransaction to avoid WebSocket issues
                const status = await this.connection.getSignatureStatus(signature);
                
                if (status && status.value) {
                    if (status.value.confirmationStatus === 'confirmed' || status.value.confirmationStatus === 'finalized') {
                        console.log('✅ Transaction confirmed successfully');
                        return { success: true, result: status.value };
                    }
                    
                    if (status.value.err) {
                        console.error('❌ Transaction failed:', status.value.err);
                        return { 
                            success: false, 
                            error: `Transaction failed: ${JSON.stringify(status.value.err)}` 
                        };
                    }
                    
                    // Transaction is still processing
                    console.log(`⏳ Transaction status: ${status.value.confirmationStatus || 'processing'}`);
                } else {
                    console.log('⏳ Transaction not yet visible on blockchain');
                }
                
                // Wait before next poll
                await new Promise(resolve => setTimeout(resolve, pollInterval));
                
            } catch (error) {
                console.log(`Status check failed:`, error.message);
                
                // Wait before retrying
                await new Promise(resolve => setTimeout(resolve, pollInterval));
            }
        }
        
        // Final timeout check
        try {
            console.log('Final check: Querying transaction status...');
            const status = await this.connection.getSignatureStatus(signature);
            
            if (status && status.value) {
                if (status.value.confirmationStatus === 'confirmed' || status.value.confirmationStatus === 'finalized') {
                    console.log('✅ Transaction confirmed on final check');
                    return { success: true, result: status.value };
                }
                
                if (status.value.err) {
                    console.error('❌ Transaction failed on final check:', status.value.err);
                    return { 
                        success: false, 
                        error: `Transaction failed: ${JSON.stringify(status.value.err)}` 
                    };
                }
            }
        } catch (statusError) {
            console.error('Failed to check transaction status:', statusError);
        }
        
        return {
            success: false,
            error: `Transaction confirmation timeout after ${timeoutMs/1000} seconds. Check signature ${signature} on Solana Explorer.`
        };
    }

    // Initialize wallet system
    async init() {
        console.log('🚀 Initializing Wallet System...');
        
        // Load saved data
        this.loadDeposits();
        this.loadUserWallets();
        this.loadPendingDeposits();
        
        // Initialize Solana connection
        await this.initSolanaConnection();
        
        // Mark as initialized
        this.isInitialized = true;
        
        console.log('✅ Wallet System initialized');
    }

    // Load deposits from localStorage
    loadDeposits() {
        const savedDeposits = localStorage.getItem('agarDeposits');
        if (savedDeposits) {
            try {
                this.deposits = JSON.parse(savedDeposits);
            } catch (e) {
                console.error('Failed to load deposits:', e);
                this.deposits = {};
            }
        }
    }

    // Load user wallets from localStorage
    loadUserWallets() {
        const savedWallets = localStorage.getItem('agarUserWallets');
        if (savedWallets) {
            try {
                const walletsData = JSON.parse(savedWallets);
                this.userWallets = new Map(Object.entries(walletsData));
            } catch (e) {
                console.error('Failed to load user wallets:', e);
                this.userWallets = new Map();
            }
        } else {
            // Initialize as empty Map if no saved data
            this.userWallets = new Map();
        }
    }

    // Load pending deposits from localStorage
    loadPendingDeposits() {
        const savedPending = localStorage.getItem('agarPendingDeposits');
        if (savedPending) {
            try {
                const data = JSON.parse(savedPending);
                this.pendingDeposits = new Map(Object.entries(data));
            } catch (e) {
                console.error('Failed to load pending deposits:', e);
                this.pendingDeposits = new Map();
            }
        } else {
            // Initialize as empty Map if no saved data
            this.pendingDeposits = new Map();
        }
    }

    // Initialize Solana connection with multiple reliable endpoints
    async initSolanaConnection() {
        console.log('🔗 Initializing REAL Solana blockchain connection...');
        
        // Use verified free Solana mainnet RPC endpoints
        const rpcEndpoints = [
            'https://solana-rpc.publicnode.com',
            'https://solana.drpc.org',
            'https://endpoints.omniatech.io/v1/sol/mainnet/public',
            'https://solana.api.onfinality.io/public',
            'https://public.rpc.solanavibestation.com',
            'https://api.mainnet-beta.solana.com'
        ];

        try {
            // Load Solana Web3.js library
            if (!window.solanaWeb3) {
                console.log('📦 Loading Solana Web3.js library...');
                await this.loadSolanaWeb3();
                console.log('✅ Solana Web3.js loaded');
            }

            // Try each RPC endpoint until one works
            for (const endpoint of rpcEndpoints) {
                try {
                    console.log(`🔍 Trying RPC endpoint: ${endpoint}`);
                    
                    // Create connection with CORS-friendly configuration
                    const connection = new window.solanaWeb3.Connection(endpoint, {
                        commitment: 'confirmed',
                        wsEndpoint: undefined,  // Disable websocket to avoid CORS issues
                        httpHeaders: {
                            'Content-Type': 'application/json',
                        }
                    });
                    
                    // Test the connection with a longer timeout for real blockchain
                    const timeoutPromise = new Promise((_, reject) => 
                        setTimeout(() => reject(new Error('Connection timeout')), 12000)
                    );
                    
                    const versionPromise = connection.getVersion();
                    const version = await Promise.race([versionPromise, timeoutPromise]);
                    
                    console.log(`✅ Connected to REAL Solana blockchain via: ${endpoint}`, version);
                    
                    this.connection = connection;
                    this.isConnected = true;
                    return true;
                    
                } catch (error) {
                    console.log(`❌ Failed to connect to ${endpoint}: ${error.message}`);
                    continue;
                }
            }

            // If all endpoints fail, throw an error instead of using mock
            throw new Error('❌ CRITICAL: Cannot connect to Solana blockchain. All RPC endpoints failed. Please check your internet connection and try again.');

        } catch (error) {
            console.error('💥 Failed to initialize Solana connection:', error);
            throw error; // Require real blockchain connection only
        }
    }




    // Load Solana Web3.js library dynamically
    async loadSolanaWeb3() {
        return new Promise((resolve, reject) => {
            if (window.solanaWeb3) {
                resolve();
                return;
            }

            const script = document.createElement('script');
            script.src = 'https://unpkg.com/@solana/web3.js@latest/lib/index.iife.min.js';
            script.onload = () => {
                console.log('Solana Web3.js loaded');
                resolve();
            };
            script.onerror = () => reject(new Error('Failed to load Solana Web3.js'));
            document.head.appendChild(script);
        });
    }

    // Generate or retrieve unique Solana wallet for user
    async generateUserWallet(username) {
        // Check if user already has a wallet
        if (this.userWallets.has(username)) {
            const walletData = this.userWallets.get(username);
            return {
                publicKey: walletData.publicKey,
                address: walletData.address
            };
        }

        try {
            // Generate deterministic Solana keypair based on username
            if (!window.solanaWeb3) {
                await this.loadSolanaWeb3();
            }

            // Generate deterministic seed from username
            const seed = await this.generateSeedFromUsername(username);
            const keypair = window.solanaWeb3.Keypair.fromSeed(seed);
            const publicKey = keypair.publicKey.toString();
            
            // Store wallet data (including private key for cashout functionality)
            const walletData = {
                publicKey: publicKey,
                address: publicKey, // In Solana, public key is the address
                privateKey: Array.from(keypair.secretKey), // Store private key as array for cashout
                createdAt: new Date().toISOString(),
                username: username // Store username for verification
            };
            
            this.userWallets.set(username, walletData);
            this.saveUserWallets();
            
            // Note: Automatic wallet monitoring disabled to prevent unwanted transaction processing
            // Users can manually check for deposits using the "Check for Deposits Now" button
            
            console.log(`Generated unique Solana wallet for ${username}: ${publicKey}`);
            
            return {
                publicKey: publicKey,
                address: publicKey
            };
            
        } catch (error) {
            console.error('Failed to generate user wallet:', error);
            throw new Error('Failed to generate wallet address');
        }
    }

    // Generate deterministic seed from username
    async generateSeedFromUsername(username) {
        // Create a deterministic seed from username with better entropy
        // This ensures the same user always gets the same wallet address
        const userString = `solana_wallet_${username}_${window.location.hostname}_v2`;
        
        // Use crypto.subtle for better hashing if available, fallback to simple hash
        if (window.crypto && window.crypto.subtle) {
            return await this.createCryptoSeed(userString);
        } else {
            // Fallback to enhanced deterministic mixing
            const encoder = new TextEncoder();
            const data = encoder.encode(userString);
            return this.createSeed32Enhanced(data);
        }
    }

    // Create cryptographic seed using Web Crypto API
    async createCryptoSeed(userString) {
        try {
            const encoder = new TextEncoder();
            const data = encoder.encode(userString);
            
            // Use SHA-256 to create a proper hash
            const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
            return new Uint8Array(hashBuffer);
        } catch (error) {
            console.warn('Crypto API failed, using fallback seed generation');
            const encoder = new TextEncoder();
            const data = encoder.encode(userString);
            return this.createSeed32Enhanced(data);
        }
    }

    // Enhanced 32-byte seed creation with better entropy
    createSeed32Enhanced(data) {
        const seed = new Uint8Array(32);
        
        // Use multiple passes with different mixing functions for better entropy
        for (let pass = 0; pass < 3; pass++) {
            for (let i = 0; i < 32; i++) {
                const dataIndex = (i + pass * 11) % data.length;
                const mixValue = data[dataIndex];
                
                // Enhanced mixing with multiple operations
                seed[i] ^= mixValue;
                seed[i] ^= (i * 17 + pass * 23) & 0xFF;
                seed[i] ^= ((mixValue << 3) | (mixValue >> 5)) & 0xFF;
                seed[i] = (seed[i] + (i * 7) + (pass * 13)) & 0xFF;
            }
        }
        
        return seed;
    }

    // Create 32-byte seed from input data (legacy fallback)
    createSeed32(data) {
        // Enhanced version of the old function
        return this.createSeed32Enhanced(data);
    }

    // Start monitoring wallet for incoming transactions
    async startWalletMonitoring(username, publicKey) {
        if (!this.connection) {
            console.warn('No Solana connection available, skipping wallet monitoring');
            return;
        }

        try {
            // Clear existing monitoring for this user
            if (this.monitoringIntervals.has(username)) {
                clearInterval(this.monitoringIntervals.get(username));
            }

            let lastSignature = null;
            
            // Get initial transaction signature to avoid processing old transactions
            try {
                const signatures = await this.connection.getSignaturesForAddress(
                    new window.solanaWeb3.PublicKey(publicKey),
                    { limit: 1 }
                );
                if (signatures.length > 0) {
                    lastSignature = signatures[0].signature;
                }
            } catch (error) {
                console.log('No previous transactions found for wallet:', publicKey);
            }

            // Monitor for new transactions every 30 seconds <mcreference link="https://solana.com/docs/rpc" index="1">1</mcreference>
            const monitoringInterval = setInterval(async () => {
                try {
                    await this.checkForNewDeposits(username, publicKey, lastSignature);
                } catch (error) {
                    console.error('Error checking for deposits:', error);
                }
            }, 30000);

            this.monitoringIntervals.set(username, monitoringInterval);
            console.log(`Started monitoring wallet ${publicKey} for user ${username}`);
            
        } catch (error) {
            console.error('Failed to start wallet monitoring:', error);
        }
    }

    // Check for new deposits to user's wallet
    async checkForNewDeposits(username, publicKey, lastKnownSignature) {
        if (!this.connection) {
            console.error('No Solana connection available for deposit check');
            return;
        }

        console.log(`🔍 Checking deposits for ${username} at address ${publicKey}`);

        try {
            // Get recent transactions for the wallet
            console.log('📡 Fetching transaction signatures...');
            const signatures = await this.connection.getSignaturesForAddress(
                new window.solanaWeb3.PublicKey(publicKey),
                { limit: 10 }
            );

            console.log(`📋 Found ${signatures.length} transaction signatures`);
            
            if (signatures.length === 0) {
                console.log('❌ No transactions found for this address');
                return;
            }

            // Process new transactions
            for (const sigInfo of signatures) {
                console.log(`🔍 Processing transaction: ${sigInfo.signature}`);
                
                // Skip if we've already processed this transaction
                if (lastKnownSignature && sigInfo.signature === lastKnownSignature) {
                    console.log('⏭️ Already processed this transaction, stopping');
                    break;
                }

                // Skip failed transactions
                if (sigInfo.err) {
                    console.log('❌ Transaction failed, skipping:', sigInfo.err);
                    continue;
                }

                console.log('📄 Fetching transaction details...');
                // Get transaction details
                const transaction = await this.connection.getTransaction(sigInfo.signature, {
                    maxSupportedTransactionVersion: 0
                });

                if (transaction && transaction.meta) {
                    console.log('✅ Transaction details retrieved, processing...');
                    await this.processTransaction(username, publicKey, transaction, sigInfo);
                } else {
                    console.log('❌ Failed to get transaction details');
                }
            }

            // Update last known signature
            if (signatures.length > 0) {
                lastKnownSignature = signatures[0].signature;
                console.log(`📝 Updated last known signature: ${lastKnownSignature}`);
            }

        } catch (error) {
            console.error('💥 Error checking for new deposits:', error);
            console.error('Error details:', error.message);
        }
    }

    // Process a transaction to check if it's a deposit
    async processTransaction(username, publicKey, transaction, sigInfo) {
        console.log(`🔄 Processing transaction for ${username}: ${sigInfo.signature}`);
        
        try {
            const meta = transaction.meta;
            const message = transaction.transaction?.message;
            
            // Validate transaction structure
            if (!meta || !message) {
                console.log('❌ Invalid transaction structure - missing meta or message');
                return;
            }
            
            console.log('📊 Transaction meta:', {
                fee: meta.fee,
                preBalances: meta.preBalances,
                postBalances: meta.postBalances,
                accountKeys: message.accountKeys?.length || 0
            });

            // Find the account index for our wallet
            let accountIndex = -1;
            if (message.accountKeys && message.accountKeys.length > 0) {
                for (let i = 0; i < message.accountKeys.length; i++) {
                    if (message.accountKeys[i].toString() === publicKey) {
                        accountIndex = i;
                        break;
                    }
                }
            }

            console.log(`🎯 Found wallet at account index: ${accountIndex}`);

            if (accountIndex === -1) {
                console.log('❌ Wallet not found in transaction accounts');
                return;
            }

            // Check if balance increased (deposit)
            const preBalance = meta.preBalances[accountIndex];
            const postBalance = meta.postBalances[accountIndex];
            const balanceChange = postBalance - preBalance;

            console.log(`💰 Balance change: ${preBalance} → ${postBalance} (${balanceChange} lamports)`);

            if (balanceChange > 0) {
                console.log('✅ Deposit detected!');
                
                // Convert lamports to SOL
                const solAmount = balanceChange / 1000000000; // 1 SOL = 1 billion lamports
                console.log(`💎 Deposit amount: ${solAmount} SOL`);

                // Calculate 3% fee for site owner
                const feePercentage = 0.03; // 3%
                const feeAmount = solAmount * feePercentage;
                const netAmount = solAmount - feeAmount;
                
                console.log(`💸 Fee (3%): ${feeAmount.toFixed(6)} SOL`);
                console.log(`💰 Net amount for user: ${netAmount.toFixed(6)} SOL`);

                // Get current SOL price in EUR from real API
                const solPriceEur = await this.getRealSolPrice();
                const eurAmount = netAmount * solPriceEur; // Use net amount for user balance
                const feeEurAmount = feeAmount * solPriceEur;

                console.log(`💶 EUR equivalent (net): €${eurAmount.toFixed(2)}`);
                console.log(`💶 Fee in EUR: €${feeEurAmount.toFixed(2)}`);

                // Send fee to site owner's wallet
                try {
                    await this.sendFeeToOwner(feeAmount, 'deposit_fee', sigInfo.signature);
                } catch (feeError) {
                    console.error('⚠️ Failed to send fee to owner:', feeError);
                    // Continue with deposit processing even if fee transfer fails
                }

                // Create deposit record with proper structure (using net amount)
                const deposit = {
                    id: sigInfo.signature,
                    username: username,
                    crypto: 'SOL',
                    amount: netAmount, // Net amount after fee
                    originalAmount: solAmount, // Original deposit amount
                    feeAmount: feeAmount, // Fee amount
                    euroValue: eurAmount, // Net EUR value
                    timestamp: new Date(sigInfo.blockTime * 1000).toISOString(),
                    signature: sigInfo.signature,
                    status: 'confirmed',
                    blockTime: sigInfo.blockTime
                };

                console.log('💾 Saving deposit:', deposit);

                // Save deposit to the deposits object and localStorage
                this.deposits[deposit.id] = deposit;
                this.saveDeposits();
                
                // Also save to user-specific deposit data
                const userDeposits = this.getUserDeposits(username);
                userDeposits.push(deposit);
                this.saveDepositData(username, userDeposits);

                // Update user balance (with net amount)
                console.log('🔄 Updating user balance...');
                if (window.authSystem) {
                    const currentBalance = window.authSystem.getUserBalance(username) || 0;
                    const newBalance = currentBalance + eurAmount;
                    window.authSystem.updateUserBalance(username, newBalance);
                    console.log(`💰 Balance updated: €${currentBalance} → €${newBalance}`);
                }

                // Show deposit notification (with net amount)
                console.log('🔔 Showing deposit notification...');
                this.showDepositNotification(netAmount, eurAmount);

                // Update UI immediately after saving deposit
                console.log('🖥️ Updating wallet UI...');
                await this.updateWalletUI();
            } else {
                console.log('📤 Transaction was outgoing or no balance change');
            }

        } catch (error) {
            console.error('💥 Error processing transaction:', error);
            console.error('Error details:', error.message);
        }
    }

    // Transfer SOL between users (for game winnings/losses)
    async transferSolBetweenUsers(fromUsername, toUsername, solAmount, reason = 'Game transfer') {
        try {
            if (!fromUsername || !toUsername || solAmount <= 0) {
                throw new Error('Invalid transfer parameters');
            }

            // Get both users' wallets
            const fromWallet = this.userWallets.get(fromUsername);
            const toWallet = this.userWallets.get(toUsername);

            if (!fromWallet || !toWallet) {
                throw new Error('One or both user wallets not found');
            }

            // Check if sender has sufficient balance
            const fromBalance = await this.getUserBalance(fromUsername);
            if (fromBalance < solAmount) {
                throw new Error(`Insufficient balance. Required: ${solAmount} SOL, Available: ${fromBalance} SOL`);
            }

            // Create transaction record
            const transactionId = 'game_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            const timestamp = new Date().toISOString();

            // Record the transfer (debit from sender)
            const debitTransaction = {
                id: transactionId + '_debit',
                username: fromUsername,
                type: 'game_loss',
                crypto: 'SOL',
                amount: -solAmount,
                euroValue: -(solAmount * this.solanaConfig.solToEuroRate),
                toAddress: toWallet.publicKey,
                fromAddress: fromWallet.publicKey,
                timestamp: timestamp,
                status: 'confirmed',
                reason: reason,
                gameTransaction: true
            };

            // Record the transfer (credit to receiver)
            const creditTransaction = {
                id: transactionId + '_credit',
                username: toUsername,
                type: 'game_win',
                crypto: 'SOL',
                amount: solAmount,
                euroValue: solAmount * this.solanaConfig.solToEuroRate,
                fromAddress: fromWallet.publicKey,
                toAddress: toWallet.publicKey,
                timestamp: timestamp,
                status: 'confirmed',
                reason: reason,
                gameTransaction: true
            };

            // Save both transactions
            this.deposits[debitTransaction.id] = debitTransaction;
            this.deposits[creditTransaction.id] = creditTransaction;
            this.saveDeposits();

            // Update user balances in auth system
            if (window.authSystem) {
                // Update sender's balance
                const senderUser = window.authSystem.getCurrentUser();
                if (senderUser && senderUser.username === fromUsername) {
                    const newBalance = senderUser.balance - (solAmount * this.solanaConfig.solToEuroRate);
                    window.authSystem.updateBalance(newBalance);
                }

                // If receiver is current user, update their balance too
                if (senderUser && senderUser.username === toUsername) {
                    const newBalance = senderUser.balance + (solAmount * this.solanaConfig.solToEuroRate);
                    window.authSystem.updateBalance(newBalance);
                }
            }

            console.log(`Transferred ${solAmount} SOL from ${fromUsername} to ${toUsername}`);
            
            // Show notification for the transfer
            await this.showGameTransferNotification(fromUsername, toUsername, solAmount, reason);

            return {
                success: true,
                transactionId: transactionId,
                debitTransaction: debitTransaction,
                creditTransaction: creditTransaction
            };

        } catch (error) {
            console.error('Failed to transfer SOL between users:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Transfer SOL from one keypair to another address
    async transferSol(fromKeypair, toAddress, solAmount, reason = 'SOL transfer', isGameBet = false, isCashout = false) {
        console.log('🔄 DEBUG: transferSol called with:', {
            fromKeypair: fromKeypair ? 'present' : 'missing',
            toAddress,
            solAmount,
            reason,
            isGameBet,
            isCashout
        });
        
        try {
            if (!fromKeypair || !toAddress || solAmount <= 0) {
                throw new Error('Invalid transfer parameters');
            }

            if (!this.connection) {
                throw new Error('Solana connection not available');
            }

            // Check sender's balance before attempting transfer
            const senderBalance = await this.connection.getBalance(fromKeypair.publicKey);
            const senderBalanceSOL = senderBalance / this.solanaConfig.lamportsPerSol;
            
            // Calculate minimum balance requirements
            const networkFeeSOL = 0.000005; // Standard transaction fee
            let totalRequiredSOL;
            let actualTransferAmount;
            
            if (isGameBet) {
                // For game bets: NEVER include rent exemption - lobby must already exist
                actualTransferAmount = solAmount;
                totalRequiredSOL = solAmount + networkFeeSOL; // Only bet amount + network fee, NO RENT EXEMPTION
                console.log(`🎮 Game bet: User pays ${solAmount.toFixed(6)} SOL total (bet + €0.10 fee) - NO RENT EXEMPTION`);
                console.log(`🔍 DEBUG: isGameBet=true, solAmount=${solAmount.toFixed(6)}, actualTransfer=${actualTransferAmount.toFixed(6)}, totalRequiredSOL=${totalRequiredSOL.toFixed(6)}`);
            } else if (isCashout) {
                // For cashouts: Player receives the full cashout amount
                const senderRentExemption = 0.00089088; // Minimum SOL that must remain in sender's account
                actualTransferAmount = solAmount;
                totalRequiredSOL = solAmount + networkFeeSOL + senderRentExemption;
                console.log(`💰 Cashout: Player receives ${solAmount.toFixed(6)} SOL`);
                console.log(`🔍 DEBUG: isCashout=true, solAmount=${solAmount.toFixed(6)}, actualTransfer=${actualTransferAmount.toFixed(6)}, totalRequiredSOL=${totalRequiredSOL.toFixed(6)}`);
            } else {
                // For regular transfers, add network fee and rent exemption
                const rentExemptionSOL = 0.00203928; // Rent exemption for creating new account
                const senderRentExemption = 0.00089088; // Minimum SOL that must remain in sender's account
                actualTransferAmount = solAmount;
                totalRequiredSOL = solAmount + networkFeeSOL + rentExemptionSOL + senderRentExemption;
                console.log(`🔍 DEBUG: isGameBet=false, solAmount=${solAmount.toFixed(6)}, networkFee=${networkFeeSOL.toFixed(6)}, rentExemption=${rentExemptionSOL.toFixed(6)}, senderRentExemption=${senderRentExemption.toFixed(6)}, totalRequiredSOL=${totalRequiredSOL.toFixed(6)}`);
            }
            
            console.log(`💰 Transfer validation:`);
            console.log(`   Sender balance: ${senderBalanceSOL.toFixed(6)} SOL`);
            console.log(`   Transfer amount: ${solAmount.toFixed(6)} SOL`);
            if (isGameBet) {
                console.log(`   0.10 EUR fee already included - covers network costs`);
            } else if (isCashout) {
                console.log(`   Network fee: ${networkFeeSOL.toFixed(6)} SOL`);
                console.log(`   Player receives full amount`);
            } else {
                const rentExemptionSOL = 0.00203928;
                console.log(`   Network fee: ${networkFeeSOL.toFixed(6)} SOL`);
                console.log(`   Rent exemption: ${rentExemptionSOL.toFixed(6)} SOL`);
            }
            console.log(`   Total required: ${totalRequiredSOL.toFixed(6)} SOL`);
            console.log(`   Transfer type: ${isGameBet ? 'Game bet (0.10 EUR fee covers network costs)' : isCashout ? 'Cashout' : 'Regular transfer'}`);
            
            // Add small tolerance for floating point precision issues
            const tolerance = 0.000001; // 1 microSOL tolerance
            if (senderBalanceSOL < (totalRequiredSOL - tolerance)) {
                const shortfall = totalRequiredSOL - senderBalanceSOL;
                if (isGameBet) {
                    throw new Error(`Insufficient SOL balance. You have ${senderBalanceSOL.toFixed(6)} SOL but need ${totalRequiredSOL.toFixed(6)} SOL total (bet + €0.10 fee covers all costs). Missing: ${shortfall.toFixed(6)} SOL. Please deposit more SOL and try again.`);
                } else if (isCashout) {
                    throw new Error(`Lobby wallet insufficient funds for cashout. Need ${totalRequiredSOL.toFixed(6)} SOL total (${solAmount.toFixed(6)} SOL cashout + ${networkFeeSOL.toFixed(6)} SOL fee). Lobby has ${senderBalanceSOL.toFixed(6)} SOL. Missing: ${shortfall.toFixed(6)} SOL.`);
                } else {
                    const rentExemptionSOL = 0.00203928;
                    throw new Error(`Insufficient funds. Need ${totalRequiredSOL.toFixed(6)} SOL total (${solAmount.toFixed(6)} SOL transfer + ${networkFeeSOL.toFixed(6)} SOL fee + ${rentExemptionSOL.toFixed(6)} SOL rent). You have ${senderBalanceSOL.toFixed(6)} SOL. Missing: ${shortfall.toFixed(6)} SOL.`);
                }
            }

            // Convert SOL to lamports - use actualTransferAmount for the transaction
            const lamports = Math.floor(actualTransferAmount * this.solanaConfig.lamportsPerSol);
            
            if (isGameBet) {
                console.log(`🎮 Game bet: Transferring ${actualTransferAmount.toFixed(6)} SOL (${solAmount.toFixed(6)} SOL total - fees kept in sender account)`);
            } else if (isCashout) {
                console.log(`💰 Cashout: Transferring ${actualTransferAmount.toFixed(6)} SOL to player (lobby covers all fees from €0.10 fee)`);
            }

            // Validate toAddress before creating PublicKey
            console.log(`🔍 Attempting to transfer to address: "${toAddress}"`);
            
            if (!toAddress || typeof toAddress !== 'string') {
                throw new Error(`Invalid toAddress: ${toAddress}`);
            }
            
            // Check if address looks like a valid base58 string
            const base58Regex = /^[1-9A-HJ-NP-Za-km-z]+$/;
            if (!base58Regex.test(toAddress)) {
                throw new Error(`Invalid base58 address: "${toAddress}"`);
            }
            
            // Create recipient public key
            const recipientPubkey = new window.solanaWeb3.PublicKey(toAddress);
            
            // For non-game bets, check if recipient account exists for rent exemption
            let recipientExists = false;
            if (!isGameBet) {
                const recipientAccountInfo = await this.connection.getAccountInfo(recipientPubkey);
                recipientExists = recipientAccountInfo !== null;
                console.log(`🔍 Recipient account ${toAddress} exists: ${recipientExists}`);
            }
            
            let transaction;
            
            // For game bets: NEVER include rent exemption - always use exact lamports
            if (isGameBet) {
                console.log(`🎮 Game bet: Creating transaction with exact ${lamports} lamports - NO RENT EXEMPTION`);
                transaction = new window.solanaWeb3.Transaction().add(
                    window.solanaWeb3.SystemProgram.transfer({
                        fromPubkey: fromKeypair.publicKey,
                        toPubkey: recipientPubkey,
                        lamports: lamports
                    })
                );
            } else if (!recipientExists) {
                // For non-game transfers to non-existent accounts, include rent exemption
                const rentExemptionLamports = 2039280; // 0.00203928 SOL in lamports
                const totalLamports = lamports + rentExemptionLamports;
                
                console.log(`⚠️ Non-game transfer to non-existent account - adding rent exemption: ${rentExemptionLamports} lamports`);
                console.log(`💰 Total transfer: ${totalLamports} lamports (${lamports} + ${rentExemptionLamports} rent)`);
                
                transaction = new window.solanaWeb3.Transaction().add(
                    window.solanaWeb3.SystemProgram.transfer({
                        fromPubkey: fromKeypair.publicKey,
                        toPubkey: recipientPubkey,
                        lamports: totalLamports
                    })
                );
            } else {
                // Create normal transaction for existing accounts
                transaction = new window.solanaWeb3.Transaction().add(
                    window.solanaWeb3.SystemProgram.transfer({
                        fromPubkey: fromKeypair.publicKey,
                        toPubkey: recipientPubkey,
                        lamports: lamports
                    })
                );
            }

            // Get recent blockhash
            const { blockhash } = await this.connection.getLatestBlockhash();
            transaction.recentBlockhash = blockhash;
            transaction.feePayer = fromKeypair.publicKey;

            // Sign and send transaction
            transaction.sign(fromKeypair);
            const signature = await this.connection.sendRawTransaction(transaction.serialize());

            // Wait for confirmation with custom timeout and retry logic
            console.log(`Transaction sent with signature: ${signature}`);
            console.log('Waiting for confirmation...');
            
            const confirmationResult = await this.confirmTransactionWithRetry(signature, 60000); // 60 second timeout
            
            if (!confirmationResult.success) {
                throw new Error(`SOL transfer failed: ${confirmationResult.error}`);
            }

            console.log(`Successfully transferred ${solAmount} SOL. Signature: ${signature}`);

            return {
                success: true,
                signature: signature,
                amount: solAmount,
                reason: reason
            };

        } catch (error) {
            console.error('Failed to transfer SOL:', error);
            
            // Provide more specific error messages
            let errorMessage = error.message;
            if (error.message.includes('insufficient funds') || error.message.includes('account (0) with insufficient funds')) {
                if (isGameBet) {
                    errorMessage = `Insufficient SOL balance. You need ${solAmount.toFixed(6)} SOL total (bet + 0.10 EUR fee already included covers all network costs). Please deposit more SOL and try again.`;
                } else {
                    errorMessage = 'Insufficient SOL balance. Your wallet needs more SOL to cover the transfer amount, network fees, and minimum account balance (rent exemption). Please deposit more SOL and try again.';
                }
            }
            
            return {
                success: false,
                error: errorMessage
            };
        }
    }

    // Show game transfer notification
    async showGameTransferNotification(fromUsername, toUsername, amount, reason) {
        const currentUser = window.authSystem?.getCurrentUser();
        if (!currentUser) return;

        let message = '';
        let type = 'info';

        // Get current SOL price for EUR conversion
        const eurRate = await this.getRealSolPrice();
        const eurValue = amount * eurRate;

        if (currentUser.username === fromUsername) {
            message = `You lost ${amount.toFixed(6)} SOL (€${eurValue.toFixed(2)}) to ${toUsername}`;
            type = 'warning';
        } else if (currentUser.username === toUsername) {
            message = `You won ${amount.toFixed(6)} SOL (€${eurValue.toFixed(2)}) from ${fromUsername}!`;
            type = 'success';
        } else {
            return; // Not involved in this transfer
        }

        const notification = document.createElement('div');
        notification.className = `game-transfer-notification ${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            background: ${type === 'success' ? '#4CAF50' : type === 'warning' ? '#FF9800' : '#2196F3'};
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            z-index: 10000;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            max-width: 300px;
        `;
        notification.innerHTML = `
            <div style="font-size: 14px; margin-bottom: 5px;">${type === 'success' ? '🎉' : '💸'} Game Result</div>
            <div style="font-size: 16px;">${message}</div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    // Validate Solana address format
    isValidSolanaAddress(address) {
        try {
            if (!address || typeof address !== 'string') return false;
            
            // Solana addresses are base58 encoded and typically 32-44 characters
            if (address.length < 32 || address.length > 44) return false;
            
            // Check if it's a valid base58 string (basic check)
            const base58Regex = /^[1-9A-HJ-NP-Za-km-z]+$/;
            if (!base58Regex.test(address)) return false;
            
            // If Solana Web3 is available, use it for validation
            if (window.solanaWeb3) {
                try {
                    new window.solanaWeb3.PublicKey(address);
                    return true;
                } catch (e) {
                    return false;
                }
            }
            
            return true; // Basic validation passed
        } catch (error) {
            return false;
        }
    }

    // Get user's SOL balance based on actual blockchain balance
    async getUserSolBalance(username) {
        console.log(`🔍 Getting REAL SOL balance for ${username} from blockchain`);
        
        if (!this.connection) {
            console.warn('⚠️ No Solana connection available, attempting to connect to blockchain...');
            
            // Try to initialize connection to real blockchain
            await this.initSolanaConnection();
            
            if (!this.connection) {
                throw new Error('❌ Cannot connect to Solana blockchain. Please check your internet connection.');
            }
        }

        // Ensure we have a real blockchain connection
        if (!this.isConnected) {
            throw new Error('❌ Not connected to Solana blockchain. Please refresh and try again.');
        }

        try {
            const walletData = this.userWallets.get(username);
            if (!walletData) {
                console.log(`❌ No wallet found for user: ${username}`);
                return 0;
            }

            console.log(`🔗 Getting balance from REAL Solana blockchain`);
            
            // Get actual balance from Solana blockchain
            const publicKey = new window.solanaWeb3.PublicKey(walletData.publicKey);
            const balance = await this.connection.getBalance(publicKey);
            const solBalance = balance / this.solanaConfig.lamportsPerSol;
            
            console.log(`💰 Real blockchain balance for ${username}: ${solBalance.toFixed(6)} SOL (${balance} lamports)`);
            return solBalance;
        } catch (error) {
            console.error('💥 Error getting user SOL balance from blockchain:', error);
            
            // If there's a network error, try to reconnect and retry once
            if (error.message.includes('network') || error.message.includes('connection') || error.message.includes('timeout')) {
                console.log('🔄 Network error detected, retrying with fresh blockchain connection...');
                try {
                    await this.initSolanaConnection();
                    
                    const walletData = this.userWallets.get(username);
                    if (walletData && this.connection && this.isConnected) {
                        const publicKey = new window.solanaWeb3.PublicKey(walletData.publicKey);
                        const balance = await this.connection.getBalance(publicKey);
                        const solBalance = balance / this.solanaConfig.lamportsPerSol;
                        console.log(`💰 Retry successful - real balance: ${solBalance.toFixed(6)} SOL`);
                        return solBalance;
                    }
                } catch (retryError) {
                    console.error('💥 Retry also failed:', retryError);
                }
            }
            
            throw error; // Don't return 0, throw the error so UI can handle it properly
        }
    }

    // Get user's balance (legacy method name for compatibility)
    async getUserBalance(username) {
        return await this.getUserSolBalance(username);
    }

    // Deduct SOL balance from user's wallet (for game payments)
    async deductUserSolBalance(username, solAmount) {
        try {
            console.log(`💸 Deducting ${solAmount.toFixed(6)} SOL from ${username}'s wallet`);
            
            // Check if user has sufficient balance
            const currentBalance = await this.getUserSolBalance(username);
            if (currentBalance < solAmount) {
                console.error(`❌ Insufficient balance: ${currentBalance.toFixed(6)} SOL < ${solAmount.toFixed(6)} SOL`);
                return false;
            }
            
            // Create a debit transaction record
            const transactionId = 'game_payment_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            const timestamp = new Date().toISOString();
            const solPrice = await this.getRealSolPrice();
            
            const debitTransaction = {
                id: transactionId,
                username: username,
                type: 'game_payment',
                crypto: 'SOL',
                amount: -solAmount,
                euroValue: -(solAmount * solPrice),
                timestamp: timestamp,
                status: 'confirmed',
                reason: 'Game bet payment',
                gameTransaction: true
            };
            
            // Save the transaction
            this.deposits[transactionId] = debitTransaction;
            this.saveDeposits();
            
            console.log(`✅ Successfully deducted ${solAmount.toFixed(6)} SOL from ${username}`);
            return true;
            
        } catch (error) {
            console.error('❌ Error deducting SOL balance:', error);
            return false;
        }
    }
    
    // Add SOL balance to user's wallet (for refunds)
    async addUserSolBalance(username, solAmount) {
        try {
            console.log(`💰 Adding ${solAmount.toFixed(6)} SOL to ${username}'s wallet`);
            
            // Create a credit transaction record
            const transactionId = 'game_refund_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            const timestamp = new Date().toISOString();
            const solPrice = await this.getRealSolPrice();
            
            const creditTransaction = {
                id: transactionId,
                username: username,
                type: 'game_refund',
                crypto: 'SOL',
                amount: solAmount,
                euroValue: solAmount * solPrice,
                timestamp: timestamp,
                status: 'confirmed',
                reason: 'Game payment refund',
                gameTransaction: true
            };
            
            // Save the transaction
            this.deposits[transactionId] = creditTransaction;
            this.saveDeposits();
            
            console.log(`✅ Successfully added ${solAmount.toFixed(6)} SOL to ${username}`);
            return true;
            
        } catch (error) {
            console.error('❌ Error adding SOL balance:', error);
            return false;
        }
    }

    // Get user's Solana wallet address
    async getUserWalletAddress(username) {
        if (!username) return null;
        
        // Check if wallet already exists in memory
        if (this.userWallets.has(username)) {
            return this.userWallets.get(username).publicKey;
        }
        
        // Try to load from localStorage
        const savedWallets = this.loadUserWalletData();
        if (savedWallets[username]) {
            this.userWallets.set(username, savedWallets[username]);
            return savedWallets[username].publicKey;
        }
        
        // Generate deterministic wallet if it doesn't exist
        try {
            const wallet = await this.generateUserWallet(username);
            return wallet ? wallet.publicKey : null;
        } catch (error) {
            console.error('Error getting user wallet address:', error);
            return null;
        }
    }

    // Get user's keypair for SOL transfers
    getUserKeypair(userId) {
        // In this system, userId is the username
        const userWallet = this.userWallets.get(userId);
        if (!userWallet || !userWallet.privateKey) {
            return null;
        }
        
        try {
            // Create keypair from stored private key
            const keypair = window.solanaWeb3.Keypair.fromSecretKey(
                new Uint8Array(userWallet.privateKey)
            );
            return keypair;
        } catch (error) {
            console.error('Error creating keypair for user:', userId, error);
            return null;
        }
    }

    // Confirm deposit and add to user balance
    confirmDeposit(depositId) {
        const deposit = this.pendingDeposits.get(depositId);
        if (!deposit) return;

        deposit.status = 'confirmed';
        this.deposits[depositId] = deposit;
        this.pendingDeposits.delete(depositId);

        // Add to user balance
        if (window.authSystem && window.authSystem.isLoggedIn) {
            const currentUser = window.authSystem.getCurrentUser();
            if (currentUser && currentUser.username === deposit.username) {
                const newBalance = currentUser.balance + deposit.euroValue;
                window.authSystem.updateBalance(newBalance);
                
                // Show notification
                this.showDepositNotification(deposit);
            }
        }

        this.saveDeposits();
        this.savePendingDeposits();
    }

    // Show deposit confirmation notification
    showDepositNotification(deposit) {
        const notification = document.createElement('div');
        notification.className = 'deposit-notification';
        notification.innerHTML = `
            <div class="notification-content">
                <h3>✅ Deposit Confirmed!</h3>
                <p>${deposit.amount} ${deposit.crypto} (€${deposit.euroValue.toFixed(2)}) has been added to your balance.</p>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    // Get user's deposit history
    getUserDeposits(username) {
        console.log(`📋 Getting deposits for user: ${username}`);
        const userDeposits = [];
        
        // Add confirmed deposits
        for (const depositId in this.deposits) {
            const deposit = this.deposits[depositId];
            if (deposit.username === username) {
                console.log(`✅ Found confirmed deposit: ${depositId}`, deposit);
                userDeposits.push(deposit);
            }
        }
        
        // Add pending deposits
        for (const [depositId, deposit] of this.pendingDeposits) {
            if (deposit.username === username) {
                console.log(`⏳ Found pending deposit: ${depositId}`, deposit);
                userDeposits.push(deposit);
            }
        }
        
        console.log(`📊 Total deposits found for ${username}: ${userDeposits.length}`);
        return userDeposits.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    }

    // Update wallet UI with real-time blockchain balance
    async updateWalletUI() {
        console.log('🔄 updateWalletUI called');
        
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            console.log('❌ No auth system or user not logged in');
            return;
        }

        const user = window.authSystem.getCurrentUser();
        console.log('👤 Current user:', user?.username);
        
        const deposits = this.getUserDeposits(user.username);
        console.log('💰 User deposits:', deposits.length);

        try {
            // Get real SOL price first
            const realSolPrice = await this.getRealSolPrice();
            console.log('💰 Real SOL price:', realSolPrice, 'EUR');
            
            // Get or generate user's Solana wallet
            const walletAddress = await this.getUserWalletAddress(user.username);
            console.log('🏦 Wallet address:', walletAddress);
            
            // Note: Automatic deposit checking removed to prevent unwanted transactions on page refresh
            // Users can manually check for deposits using the "Check for Deposits Now" button
            
            const currentBalance = await this.getUserSolBalance(user.username);
            console.log('💎 Current SOL balance:', currentBalance);

            // Update wallet address display
            const addressContainer = document.getElementById('wallet-addresses');
            console.log('📍 Address container found:', !!addressContainer);
            
            if (addressContainer && walletAddress) {
                console.log('✅ Updating address container with wallet info');
                addressContainer.innerHTML = `
                    <div class="crypto-address">
                        <div class="crypto-header">
                            <span class="crypto-name">Solana (SOL)</span>
                            <span class="crypto-rate">€${realSolPrice.toLocaleString()}</span>
                        </div>
                        <div class="current-balance">
                            <span class="balance-label">Real-time Balance:</span>
                            <span class="balance-amount">${currentBalance.toFixed(6)} SOL (€${(currentBalance * realSolPrice).toFixed(2)})</span>
                        </div>
                        <div class="address-container">
                            <input type="text" value="${walletAddress}" readonly class="address-input">
                            <button onclick="copyAddress('${walletAddress}')" class="copy-btn">📋</button>
                        </div>
                        <div class="wallet-info">
                            <p><strong>How to deposit:</strong></p>
                            <ol>
                                <li>Copy the address above</li>
                                <li>Open your Solana wallet (Phantom, Solflare, etc.)</li>
                                <li>Send SOL to this address</li>
                                <li>Your balance will update automatically!</li>
                            </ol>
                            <p><small>⚡ Balance updates in real-time from the Solana blockchain</small></p>
                            <button onclick="window.walletSystem.forceDepositCheck('${user.username}', '${walletAddress}')" 
                                    style="margin-top: 10px; padding: 8px 16px; background: #2196F3; color: white; border: none; border-radius: 4px; cursor: pointer;">
                                🔄 Check for Deposits Now
                            </button>
                        </div>
                    </div>
                `;
            } else {
                console.log('❌ Address container not found or no wallet address');
            }

            // Update deposit history
            const historyContainer = document.getElementById('deposit-history');
            console.log('📋 History container found:', !!historyContainer);
            console.log('📊 Deposits to display:', deposits);
            
            if (historyContainer) {
                historyContainer.innerHTML = '';
                
                if (deposits.length === 0) {
                    console.log('📭 No deposits found, showing empty message');
                    historyContainer.innerHTML = '<p class="no-deposits">No deposits yet. Send SOL to your address above to get started!</p>';
                } else {
                    console.log(`📋 Displaying ${deposits.length} deposits`);
                    deposits.forEach((deposit, index) => {
                        console.log(`📄 Creating deposit item ${index + 1}:`, deposit);
                        const depositDiv = document.createElement('div');
                        depositDiv.className = `deposit-item ${deposit.status}`;
                        depositDiv.innerHTML = `
                            <div class="deposit-info">
                                <span class="deposit-amount">${deposit.amount.toFixed(6)} ${deposit.crypto}</span>
                                <span class="deposit-euro">€${deposit.euroValue.toFixed(2)}</span>
                            </div>
                            <div class="deposit-status">
                                <span class="status-badge ${deposit.status}">${deposit.status.toUpperCase()}</span>
                                ${deposit.signature ? 
                                    `<a href="https://solscan.io/tx/${deposit.signature}" target="_blank" class="tx-link">View on Solscan</a>` : 
                                    ''}
                            </div>
                            <div class="deposit-time">${new Date(deposit.timestamp).toLocaleString()}</div>
                        `;
                        historyContainer.appendChild(depositDiv);
                    });
                }
            } else {
                console.error('❌ deposit-history container not found in DOM');
            }

        } catch (error) {
            console.error('💥 Error updating wallet UI:', error);
            
            // Show error message
            const addressContainer = document.getElementById('wallet-addresses');
            if (addressContainer) {
                addressContainer.innerHTML = `
                    <div class="wallet-error">
                        <p>⚠️ Unable to load wallet. Please refresh the page and try again.</p>
                        <p>If the problem persists, check your internet connection.</p>
                    </div>
                `;
            }
        }
    }

    // Save deposits to localStorage
    saveDeposits() {
        localStorage.setItem('agarDeposits', JSON.stringify(this.deposits));
    }

    // Save pending deposits to localStorage
    savePendingDeposits() {
        const dataToSave = Object.fromEntries(this.pendingDeposits);
        localStorage.setItem('agarPendingDeposits', JSON.stringify(dataToSave));
    }

    // Save deposit data to localStorage
    saveDepositData(username, deposits) {
        const key = `wallet_deposits_${username}`;
        localStorage.setItem(key, JSON.stringify(deposits));
    }

    // Save user wallet data to localStorage
    saveUserWalletData() {
        const walletData = Object.fromEntries(this.userWallets);
        localStorage.setItem('solana_user_wallets', JSON.stringify(walletData));
    }

    // Save user wallets (alias for compatibility)
    saveUserWallets() {
        this.saveUserWalletData();
    }

    async forceDepositCheck(username, walletAddress) {
        console.log(`🔄 Force checking deposits for ${username} at ${walletAddress}`);
        
        // Remove any existing notification first
        const existingNotification = document.getElementById('deposit-check-notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // Check if we have a real blockchain connection
        if (!this.connection) {
            console.error('❌ No Solana connection available');
            
            // Try to reinitialize connection
            console.log('🔄 Attempting to reinitialize Solana connection...');
            await this.initSolanaConnection();
            
            if (!this.connection) {
                throw new Error('❌ Unable to connect to Solana blockchain. Please check your internet connection and try again.');
            }
        }

        let notification = null;
        try {
            // Show loading notification
            notification = document.createElement('div');
            notification.id = 'deposit-check-notification';
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #2196F3;
                color: white;
                padding: 12px 20px;
                border-radius: 8px;
                z-index: 10000;
                font-weight: bold;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            `;
            
            notification.textContent = '🔄 Checking blockchain for deposits...';
            
            document.body.appendChild(notification);

            // Check for deposits
            await this.checkForNewDeposits(username, walletAddress, null);
            
            // Update the notification
            notification.style.background = '#4CAF50';
            notification.textContent = '✅ Blockchain check complete!';
            
            // Refresh the wallet UI
            await this.updateWalletUI();
            
            setTimeout(() => {
                if (notification && notification.parentNode) {
                    notification.remove();
                }
            }, 3000);
            
        } catch (error) {
            console.error('💥 Error during force deposit check:', error);
            
            // Ensure we have a notification to update
            if (!notification) {
                notification = document.createElement('div');
                notification.id = 'deposit-check-notification';
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: #f44336;
                    color: white;
                    padding: 12px 20px;
                    border-radius: 8px;
                    z-index: 10000;
                    font-weight: bold;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                `;
                document.body.appendChild(notification);
            } else {
                notification.style.background = '#f44336';
            }
            
            notification.textContent = '❌ Error checking deposits: ' + error.message;
            setTimeout(() => {
                if (notification && notification.parentNode) {
                    notification.remove();
                }
            }, 5000);
            
            // Re-throw the error so the calling function knows it failed
            throw error;
        }
    }

    // Cashout SOL from user's game wallet to external wallet
    async cashoutToExternalWallet(username, solAmount, externalWalletAddress, statusCallback = null) {
        console.log(`💸 Processing cashout: ${username} wants to withdraw ${solAmount} SOL to ${externalWalletAddress}`);
        
        try {
            // Update status
            if (statusCallback) statusCallback('Validating cashout parameters...');
            
            // Validate inputs
            if (!username || !solAmount || !externalWalletAddress) {
                throw new Error('Missing required cashout parameters');
            }
            
            if (solAmount <= 0) {
                throw new Error('Cashout amount must be greater than 0');
            }
            
            // Validate external wallet address
            if (!this.isValidSolanaAddress(externalWalletAddress)) {
                throw new Error('Invalid Solana wallet address');
            }
            
            // Check if user is logged in
            if (!window.authSystem || !window.authSystem.isLoggedIn) {
                throw new Error('User must be logged in to cashout');
            }
            
            const currentUser = window.authSystem.getCurrentUser();
            if (currentUser.username !== username) {
                throw new Error('User can only cashout from their own account');
            }
            
            // Get user's game wallet
            const userWallet = this.userWallets.get(username);
            if (!userWallet) {
                throw new Error('User wallet not found. Please contact support.');
            }
            
            // Check actual SOL balance in the game wallet
            const gameWalletBalance = await this.getUserSolBalance(username);
            
            // Get current SOL price in EUR for fee calculation
            const solPriceEur = await this.getRealSolPrice();
            
            // Calculate 0.15 EUR equivalent fee in SOL
            const FEE_EUR = 0.15;
            const feeAmountSOL = FEE_EUR / solPriceEur;
            
            // Calculate what user actually receives (requested amount minus fee)
            const userReceivesSOL = solAmount - feeAmountSOL;
            
            console.log(`💰 Wallet balance: ${gameWalletBalance.toFixed(6)} SOL`);
            console.log(`💸 Requested cashout: ${solAmount.toFixed(6)} SOL (€${(solAmount * solPriceEur).toFixed(2)})`);
            console.log(`💳 Cashout fee: ${feeAmountSOL.toFixed(6)} SOL (€${FEE_EUR})`);
            console.log(`💎 User receives: ${userReceivesSOL.toFixed(6)} SOL (€${(userReceivesSOL * solPriceEur).toFixed(2)})`);
            
            // Validate that user receives a positive amount
            if (userReceivesSOL <= 0) {
                throw new Error(`Cashout amount too small. Minimum required: ${(feeAmountSOL + 0.000001).toFixed(6)} SOL to cover the €${FEE_EUR} fee`);
            }
            
            // Calculate total SOL needed for the cashout operation
            // We need: requested amount + network fees
            // Note: The fee is deducted from the requested amount, not added to it
            const networkFeePerTransaction = 0.000005;
            const minimumAccountBalance = 0.00089088; // Solana rent exemption (must remain in account)
            const totalNetworkFees = networkFeePerTransaction * 2; // Fee transaction + user transaction
            const totalRequiredSOL = solAmount + totalNetworkFees;
            
            // Check if user has enough SOL for the cashout operation (keeping minimum balance)
            const remainingAfterCashout = gameWalletBalance - totalRequiredSOL;
            if (gameWalletBalance < totalRequiredSOL || remainingAfterCashout < minimumAccountBalance) {
                const actualRequired = totalRequiredSOL + (remainingAfterCashout < minimumAccountBalance ? minimumAccountBalance - remainingAfterCashout : 0);
                const shortfall = actualRequired - gameWalletBalance;
                throw new Error(`Cashout error: Insufficient funds. Need ${actualRequired.toFixed(6)} SOL total (${solAmount.toFixed(6)} SOL transfer + ${totalNetworkFees.toFixed(6)} SOL fees + ${minimumAccountBalance.toFixed(6)} SOL must remain). You have ${gameWalletBalance.toFixed(6)} SOL. Missing: ${shortfall.toFixed(6)} SOL.`);
            }
            
            // Update status
            if (statusCallback) statusCallback('Processing cashout fee...');
            
            // Send cashout fee to site owner first
            let feeTransactionSuccess = false;
            try {
                await this.sendFeeToOwner(feeAmountSOL, 'cashout_fee', `cashout_${Date.now()}`);
                console.log(`✅ Cashout fee of ${feeAmountSOL.toFixed(6)} SOL (€${FEE_EUR}) sent to site owner`);
                feeTransactionSuccess = true;
            } catch (feeError) {
                console.error('⚠️ Failed to send cashout fee to owner:', feeError);
                
                // Check if it's a timeout error (transaction might have succeeded)
                if (feeError.message.includes('Transaction was not confirmed') || feeError.message.includes('timeout')) {
                    console.log('⚠️ Fee transaction timed out but may have succeeded. Continuing with cashout...');
                    feeTransactionSuccess = 'timeout'; // Mark as timeout, not failure
                } else {
                    // For other errors, still continue but log the issue
                    console.log('⚠️ Fee transaction failed, but continuing with cashout to user...');
                    feeTransactionSuccess = false;
                }
            }
            
            // User receives the amount minus the fee
            const lamports = Math.floor(userReceivesSOL * this.solanaConfig.lamportsPerSol);
            
            console.log(`💱 User receives: ${userReceivesSOL.toFixed(6)} SOL (${lamports} lamports) after €${FEE_EUR} fee`);
            
            // Create cashout record
            const cashoutId = `cashout_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            const cashout = {
                id: cashoutId,
                username: username,
                requestedAmount: solAmount, // What user requested
                solAmount: userReceivesSOL, // What user actually receives
                feeAmount: feeAmountSOL, // Fee in SOL
                feeEUR: FEE_EUR, // Fee in EUR
                feeTransactionStatus: feeTransactionSuccess, // Track fee transaction status
                lamports: lamports,
                fromAddress: userWallet.publicKey,
                toAddress: externalWalletAddress,
                status: 'pending',
                timestamp: new Date().toISOString(),
                blockTime: Math.floor(Date.now() / 1000),
                type: 'cashout'
            };
            
            // Update status
            if (statusCallback) statusCallback('Creating and sending transaction to your wallet...');
            
            // Create and send actual Solana transaction (sending userReceivesSOL amount)
            try {
                const signature = await this.createAndSendSolanaTransaction(username, externalWalletAddress, lamports);
                
                // Update status
                if (statusCallback) statusCallback('Transaction confirmed! Processing completion...');
                
                cashout.signature = signature;
                cashout.status = 'completed';
                
                console.log(`✅ Real Solana transaction sent! Signature: ${signature}`);
                
            } catch (transactionError) {
                console.log('⚠️ Transaction error occurred, performing final verification...');
                
                // Extract signature from error message if available
                let signature = null;
                const signatureMatch = transactionError.message.match(/signature ([A-Za-z0-9]{87,88})/);
                if (signatureMatch) {
                    signature = signatureMatch[1];
                }
                
                // If we have a signature, do a final check to see if transaction actually succeeded
                if (signature) {
                    try {
                        console.log(`🔍 Checking final status for signature: ${signature}`);
                        const status = await this.connection.getSignatureStatus(signature);
                        
                        if (status && status.value && 
                            (status.value.confirmationStatus === 'confirmed' || status.value.confirmationStatus === 'finalized')) {
                            console.log('✅ Transaction actually succeeded despite timeout error!');
                            cashout.signature = signature;
                            cashout.status = 'completed';
                            
                            // Save successful cashout record
                            this.saveCashout(cashout);
                            
                            // Show success notification
                            this.showCashoutNotification(cashout);
                            
                            // Update wallet UI to reflect new balance
                            await this.updateWalletUI();
                            
                            console.log('💡 Cashout completed successfully!');
                            return; // Exit successfully
                        }
                    } catch (statusError) {
                        console.log('Could not verify transaction status:', statusError.message);
                    }
                }
                
                // If we get here, the transaction genuinely failed or we couldn't verify it
                console.error('💥 Transaction failed:', transactionError);
                cashout.status = 'failed';
                cashout.error = transactionError.message;
                
                // Save failed cashout record
                this.saveCashout(cashout);
                
                throw new Error(`Transaction failed: ${transactionError.message}`);
            }
            
            // Save successful cashout record
            this.saveCashout(cashout);
            
            // Show success notification
            this.showCashoutNotification(cashout);
            
            // Update wallet UI to reflect new balance
            await this.updateWalletUI();
            
            console.log(`✅ Cashout completed: ${userReceivesSOL.toFixed(6)} SOL sent to ${externalWalletAddress} (€${FEE_EUR} fee ${feeTransactionSuccess === true ? 'successfully processed' : feeTransactionSuccess === 'timeout' ? 'may have been processed (timed out)' : 'failed to process'})`);
            
            let successMessage = `Successfully withdrew ${userReceivesSOL.toFixed(6)} SOL to your wallet`;
            if (feeTransactionSuccess === 'timeout') {
                successMessage += ` (€${FEE_EUR} fee transaction timed out but may have succeeded)`;
            } else if (feeTransactionSuccess === false) {
                successMessage += ` (€${FEE_EUR} fee transaction failed - please contact support)`;
            } else {
                successMessage += ` (€${FEE_EUR} fee deducted from your ${solAmount.toFixed(6)} SOL request)`;
            }
            
            return {
                success: true,
                cashout: cashout,
                message: successMessage,
                signature: signature,
                feeStatus: feeTransactionSuccess
            };
            
        } catch (error) {
            console.error('💥 Cashout failed:', error);
            
            // Show error notification
            this.showCashoutErrorNotification(error.message);
            
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    // Create and send actual Solana transaction
    async createAndSendSolanaTransaction(username, toAddress, lamports) {
        if (!this.connection) {
            throw new Error('No Solana connection available');
        }
        
        if (!window.solanaWeb3) {
            throw new Error('Solana Web3 library not loaded');
        }
        
        // Get user's wallet keypair (this requires the private key)
        const userWallet = this.userWallets.get(username);
        if (!userWallet || !userWallet.privateKey) {
            throw new Error('User wallet not found or missing private key');
        }
        
        try {
            // Create keypair from stored private key
            const fromKeypair = window.solanaWeb3.Keypair.fromSecretKey(
                new Uint8Array(userWallet.privateKey)
            );
            const toPublicKey = new window.solanaWeb3.PublicKey(toAddress);
            
            console.log(`🔐 Creating transaction from ${fromKeypair.publicKey.toString()} to ${toAddress}`);
            
            // Create transfer instruction
            const transferInstruction = window.solanaWeb3.SystemProgram.transfer({
                fromPubkey: fromKeypair.publicKey,
                toPubkey: toPublicKey,
                lamports: lamports
            });
            
            // Get recent blockhash
            const { blockhash } = await this.connection.getLatestBlockhash();
            
            // Create transaction
            const transaction = new window.solanaWeb3.Transaction({
                recentBlockhash: blockhash,
                feePayer: fromKeypair.publicKey
            }).add(transferInstruction);
            
            // Sign transaction
            transaction.sign(fromKeypair);
            
            console.log('📡 Sending transaction to Solana network...');
            
            // Send transaction
            const signature = await this.connection.sendRawTransaction(transaction.serialize(), {
                skipPreflight: false,
                preflightCommitment: 'confirmed'
            });
            
            console.log(`✅ Transaction sent! Signature: ${signature}`);
            
            // Wait for confirmation with retry logic
            console.log('⏳ Waiting for transaction confirmation...');
            const confirmationResult = await this.confirmTransactionWithRetry(signature, 90000); // 90 second timeout
            
            if (!confirmationResult.success) {
                throw new Error(`Transaction failed: ${confirmationResult.error || 'Unknown error'}`);
            }
            
            console.log('✅ Transaction confirmed!');
            return signature;
            
        } catch (error) {
            console.error('💥 Error creating/sending transaction:', error);
            
            // Handle specific Solana errors
            if (error.message.includes('insufficient funds')) {
                throw new Error('Insufficient SOL for transaction and fees');
            } else if (error.message.includes('blockhash not found')) {
                throw new Error('Network error: Please try again');
            } else if (error.message.includes('invalid')) {
                throw new Error('Invalid wallet address or transaction data');
            }
            
            throw error;
        }
    }
    
    // Validate Solana wallet address
    isValidSolanaAddress(address) {
        try {
            // Basic validation - Solana addresses are base58 encoded and 32 bytes (44 characters)
            if (!address || typeof address !== 'string') {
                return false;
            }
            
            // Check length (Solana addresses are typically 32-44 characters)
            if (address.length < 32 || address.length > 44) {
                return false;
            }
            
            // Check if it contains only valid base58 characters
            const base58Regex = /^[1-9A-HJ-NP-Za-km-z]+$/;
            if (!base58Regex.test(address)) {
                return false;
            }
            
            // If Solana Web3 is available, use it for more thorough validation
            if (window.solanaWeb3) {
                try {
                    new window.solanaWeb3.PublicKey(address);
                    return true;
                } catch (e) {
                    return false;
                }
            }
            
            return true;
        } catch (error) {
            console.error('Error validating Solana address:', error);
            return false;
        }
    }
    
    // Save cashout record
    saveCashout(cashout) {
        // Load existing cashouts
        const existingCashouts = this.loadCashouts();
        existingCashouts[cashout.id] = cashout;
        
        // Save to localStorage
        localStorage.setItem('agario_cashouts', JSON.stringify(existingCashouts));
        
        // Also save to user-specific cashout history
        const userCashouts = this.getUserCashouts(cashout.username);
        userCashouts.push(cashout);
        this.saveUserCashouts(cashout.username, userCashouts);
    }
    
    // Load all cashouts
    loadCashouts() {
        const data = localStorage.getItem('agario_cashouts');
        return data ? JSON.parse(data) : {};
    }
    
    // Get user's cashout history
    getUserCashouts(username) {
        const key = `cashouts_${username}`;
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : [];
    }
    
    // Save user's cashout history
    saveUserCashouts(username, cashouts) {
        const key = `cashouts_${username}`;
        localStorage.setItem(key, JSON.stringify(cashouts));
    }
    
    // Show cashout success notification
    showCashoutNotification(cashout) {
        const notification = document.createElement('div');
        notification.className = 'cashout-notification success';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4CAF50;
            color: white;
            padding: 16px 24px;
            border-radius: 8px;
            z-index: 10000;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            max-width: 400px;
        `;
        
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 20px;">✅</span>
                <div>
                    <div style="font-size: 16px; margin-bottom: 4px;">Cashout Successful!</div>
                    <div style="font-size: 14px; opacity: 0.9;">
                        €${(cashout.amount || 0).toFixed(2)} (${(cashout.solAmount || 0).toFixed(6)} SOL)<br>
                        Sent to: ${(cashout.toAddress || '').substring(0, 8)}...${(cashout.toAddress || '').substring(-8)}
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 8000);
    }
    
    // Show cashout error notification
    showCashoutErrorNotification(errorMessage) {
        const notification = document.createElement('div');
        notification.className = 'cashout-notification error';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #f44336;
            color: white;
            padding: 16px 24px;
            border-radius: 8px;
            z-index: 10000;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            max-width: 400px;
        `;
        
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 20px;">❌</span>
                <div>
                    <div style="font-size: 16px; margin-bottom: 4px;">Cashout Failed</div>
                    <div style="font-size: 14px; opacity: 0.9;">${errorMessage}</div>
                </div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 10000);
     }
     
     // Load user wallet data from localStorage
     loadUserWalletData() {
         const data = localStorage.getItem('solana_user_wallets');
         return data ? JSON.parse(data) : {};
     }

     // Get user wallet data
     getUserWallet(user) {
         if (!user || !user.username) {
             return null;
         }
         
         // First check in-memory wallets
         if (this.userWallets.has(user.username)) {
             return this.userWallets.get(user.username);
         }
         
         // Then check localStorage
         const savedWallets = this.loadUserWalletData();
         if (savedWallets[user.username]) {
             return savedWallets[user.username];
         }
         
         // Also check the old storage format
         const oldWallets = localStorage.getItem('agarUserWallets');
         if (oldWallets) {
             try {
                 const walletsData = JSON.parse(oldWallets);
                 if (walletsData[user.username]) {
                     return walletsData[user.username];
                 }
             } catch (e) {
                 console.error('Failed to load old wallet data:', e);
             }
         }
         
         return null;
     }

     // Transfer SOL from system wallet to user's external wallet (for cashouts)
    async transferFromSystemToUser(username, userExternalWallet, solAmount) {
        try {
            console.log(`💸 Transferring ${solAmount.toFixed(6)} SOL from system to user ${username} at ${userExternalWallet}`);
            
            // For now, we'll use the user's internal wallet as the source
            // In a production system, you would have a funded system wallet
            const userWallet = this.userWallets.get(username);
            if (!userWallet || !userWallet.privateKey) {
                throw new Error('User wallet not found or missing private key');
            }

            // Check if user has sufficient balance in their internal wallet
            const userBalance = await this.getUserSolBalance(username);
            if (userBalance < solAmount) {
                throw new Error(`Insufficient balance. Required: ${solAmount.toFixed(6)} SOL, Available: ${userBalance.toFixed(6)} SOL`);
            }

            // Use the existing connection
            if (!this.connection || !this.isConnected) {
                console.log('🔗 Re-establishing Solana connection for cashout transfer...');
                await this.initSolanaConnection();
            }
            
            const connection = this.connection;

            // Create keypair from user's internal wallet private key
            const fromKeypair = window.solanaWeb3.Keypair.fromSecretKey(
                new Uint8Array(userWallet.privateKey)
            );

            // Create destination public key (user's external wallet)
            const toPublicKey = new window.solanaWeb3.PublicKey(userExternalWallet);

            // Convert SOL to lamports
            const lamports = Math.floor(solAmount * this.solanaConfig.lamportsPerSol);

            // Create transaction
            const transaction = new window.solanaWeb3.Transaction().add(
                window.solanaWeb3.SystemProgram.transfer({
                    fromPubkey: fromKeypair.publicKey,
                    toPubkey: toPublicKey,
                    lamports: lamports,
                })
            );

            // Get recent blockhash
            const { blockhash } = await connection.getLatestBlockhash();
            transaction.recentBlockhash = blockhash;
            transaction.feePayer = fromKeypair.publicKey;

            // Sign and send transaction
            transaction.sign(fromKeypair);
            const signature = await connection.sendRawTransaction(transaction.serialize());

            console.log(`✅ Cashout transaction sent: ${signature}`);

            // Wait for confirmation
            const confirmationResult = await this.confirmTransactionWithRetry(signature, 90000);
            if (!confirmationResult.success) {
                throw new Error(`Cashout transaction failed: ${confirmationResult.error || 'Unknown error'}`);
            }
            console.log(`✅ Cashout transaction confirmed: ${signature}`);

            // Record the cashout transaction
            const cashoutRecord = {
                id: signature,
                username: username,
                type: 'cashout',
                amount: -solAmount, // Negative because it's leaving the internal wallet
                euroValue: -(solAmount * this.solanaConfig.solToEuroRate),
                fromAddress: userWallet.publicKey,
                toAddress: userExternalWallet,
                timestamp: new Date().toISOString(),
                status: 'confirmed',
                signature: signature
            };

            // Save the transaction record
            this.deposits[cashoutRecord.id] = cashoutRecord;
            this.saveDeposits();

            return {
                success: true,
                signature: signature,
                amount: solAmount,
                message: `Successfully transferred ${solAmount.toFixed(6)} SOL to your external wallet`
            };

        } catch (error) {
            console.error('❌ Failed to transfer SOL from system to user:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Send fee to site owner's wallet
    async sendFeeToOwner(feeAmount, feeType, originalTransactionId) {
        const SITE_OWNER_WALLET = "F44t5GTZaJTRAF699bkiNbjZ15fTXsnAG17W8SewaxMa";
        
        console.log(`💸 Sending ${feeType} fee: ${feeAmount.toFixed(6)} SOL to site owner`);
        
        try {
            // Get the current user's wallet
            const currentUser = window.authSystem?.getCurrentUser();
            if (!currentUser) {
                throw new Error('No authenticated user found');
            }

            const userWallet = this.getUserWallet(currentUser);
            if (!userWallet || !userWallet.privateKey) {
                throw new Error('User wallet not found or missing private key');
            }

            // Use the existing connection instead of creating a new one
            if (!this.connection || !this.isConnected) {
                console.log('🔗 Re-establishing Solana connection for fee transfer...');
                await this.initSolanaConnection();
            }
            
            const connection = this.connection;

            // Create keypair from private key
            const fromKeypair = solanaWeb3.Keypair.fromSecretKey(
                new Uint8Array(userWallet.privateKey)
            );

            // Create destination public key
            const toPublicKey = new solanaWeb3.PublicKey(SITE_OWNER_WALLET);

            // Convert SOL to lamports
            const lamports = Math.floor(feeAmount * 1000000000);

            // Create transaction
            const transaction = new solanaWeb3.Transaction().add(
                solanaWeb3.SystemProgram.transfer({
                    fromPubkey: fromKeypair.publicKey,
                    toPubkey: toPublicKey,
                    lamports: lamports,
                })
            );

            // Get recent blockhash
            const { blockhash } = await connection.getLatestBlockhash();
            transaction.recentBlockhash = blockhash;
            transaction.feePayer = fromKeypair.publicKey;

            // Sign and send transaction
            transaction.sign(fromKeypair);
            const signature = await connection.sendRawTransaction(transaction.serialize());

            console.log(`✅ Fee transaction sent: ${signature}`);

            // Wait for confirmation with retry logic
            const confirmationResult = await this.confirmTransactionWithRetry(signature, 90000);
            if (!confirmationResult.success) {
                throw new Error(`Fee transaction failed: ${confirmationResult.error || 'Unknown error'}`);
            }
            console.log(`✅ Fee transaction confirmed: ${signature}`);

            // Log the fee transaction for record keeping
            const feeRecord = {
                id: signature,
                type: feeType,
                amount: feeAmount,
                recipient: SITE_OWNER_WALLET,
                originalTransaction: originalTransactionId,
                timestamp: new Date().toISOString(),
                status: 'confirmed'
            };

            // Save fee record to localStorage
            const feeRecords = JSON.parse(localStorage.getItem('feeRecords') || '[]');
            feeRecords.push(feeRecord);
            localStorage.setItem('feeRecords', JSON.stringify(feeRecords));

            return signature;

        } catch (error) {
            console.error('❌ Failed to send fee to owner:', error);
            throw error;
        }
    }

    // Get real SOL price from CoinGecko API
     async getRealSolPrice() {
         try {
             const now = Date.now();
             
             // Check if we have a recent price (within 5 minutes)
             if (now - this.solanaConfig.lastPriceUpdate < this.solanaConfig.priceUpdateInterval) {
                 console.log('💰 Using cached SOL price:', this.solanaConfig.solToEuroRate);
                 return this.solanaConfig.solToEuroRate;
             }

             console.log('🔄 Fetching real SOL price from CoinGecko...');
            
            const proxyUrl = 'php/api_proxy.php?url=' + encodeURIComponent('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=eur');
            const response = await fetch(proxyUrl, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                }
            });

             if (!response.ok) {
                 throw new Error(`HTTP error! status: ${response.status}`);
             }

             const data = await response.json();
             
             if (data.solana && data.solana.eur) {
                 const realPrice = data.solana.eur;
                 this.solanaConfig.solToEuroRate = realPrice;
                 this.solanaConfig.eurToSolRate = 1 / realPrice; // Update inverse rate
                 this.solanaConfig.lastPriceUpdate = now;
                 
                 console.log('✅ Updated SOL price:', realPrice, 'EUR');
                 return realPrice;
             } else {
                 throw new Error('Invalid price data received');
             }

         } catch (error) {
             console.error('❌ Failed to fetch real SOL price:', error);
             console.log('⚠️ Using last known price:', this.solanaConfig.solToEuroRate);
             return this.solanaConfig.solToEuroRate;
         }
     }
}

// Global functions for UI interaction
window.copyAddress = function(address) {
    navigator.clipboard.writeText(address).then(() => {
        // Show copy notification
        const notification = document.createElement('div');
        notification.className = 'copy-notification';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4CAF50;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 10000;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        notification.textContent = 'Address copied to clipboard!';
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy address:', err);
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = address;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        alert('Address copied to clipboard!');
    });
};

// Export for use in other modules
window.WalletSystem = WalletSystem;
<?php
/**
 * Secure Configuration Loader
 * Loads configuration from environment variables or .env file
 * Replaces hardcoded credentials with secure environment-based config
 */

class SecureConfig {
    private static $config = [];
    private static $loaded = false;
    
    public static function load() {
        if (self::$loaded) {
            return;
        }
        
        // Load .env file if it exists
        self::loadEnvFile();
        
        // Set default configuration
        self::$config = [
            'database' => [
                'host' => self::getEnv('DB_HOST', 'localhost'),
                'name' => self::getEnv('DB_NAME', ''),
                'username' => self::getEnv('DB_USERNAME', ''),
                'password' => self::getEnv('DB_PASSWORD', ''),
                'charset' => 'utf8mb4'
            ],
            'email' => [
                'host' => self::getEnv('SMTP_HOST', 'smtp.hostinger.com'),
                'port' => (int)self::getEnv('SMTP_PORT', 587),
                'username' => self::getEnv('SMTP_USERNAME', ''),
                'password' => self::getEnv('SMTP_PASSWORD', ''),
                'from_email' => self::getEnv('SMTP_FROM_EMAIL', ''),
                'from_name' => self::getEnv('SMTP_FROM_NAME', 'OOPSNOWH')
            ],
            'security' => [
                'session_secret' => self::getEnv('SESSION_SECRET', self::generateRandomKey()),
                'encryption_key' => self::getEnv('ENCRYPTION_KEY', self::generateRandomKey())
            ],
            'app' => [
                'env' => self::getEnv('APP_ENV', 'production'),
                'debug' => filter_var(self::getEnv('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN),
                'url' => self::getEnv('APP_URL', '')
            ],
            'solana' => [
                'rpc_endpoint' => self::getEnv('SOLANA_RPC_ENDPOINT', 'https://solana-api.projectserum.com'),
                'use_devnet' => filter_var(self::getEnv('SOLANA_USE_DEVNET', 'false'), FILTER_VALIDATE_BOOLEAN)
            ]
        ];
        
        self::$loaded = true;
        
        // Validate critical configuration
        self::validateConfig();
    }
    
    private static function loadEnvFile() {
        $envFile = __DIR__ . '/.env';
        if (file_exists($envFile)) {
            $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                if (strpos($line, '#') === 0) continue; // Skip comments
                if (strpos($line, '=') !== false) {
                    list($key, $value) = explode('=', $line, 2);
                    $key = trim($key);
                    $value = trim($value, '"\' ');
                    if (!array_key_exists($key, $_ENV)) {
                        $_ENV[$key] = $value;
                    }
                }
            }
        }
    }
    
    private static function getEnv($key, $default = null) {
        return $_ENV[$key] ?? getenv($key) ?: $default;
    }
    
    private static function generateRandomKey($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
    
    private static function validateConfig() {
        $required = [
            'database.name' => 'Database name is required',
            'database.username' => 'Database username is required',
            'database.password' => 'Database password is required',
            'email.username' => 'SMTP username is required',
            'email.password' => 'SMTP password is required'
        ];
        
        foreach ($required as $key => $message) {
            $value = self::get($key);
            if (empty($value)) {
                error_log("Configuration Error: $message");
                if (self::get('app.env') === 'production') {
                    throw new Exception("Configuration Error: Missing required configuration");
                }
            }
        }
    }
    
    public static function get($key, $default = null) {
        if (!self::$loaded) {
            self::load();
        }
        
        $keys = explode('.', $key);
        $value = self::$config;
        
        foreach ($keys as $k) {
            if (!isset($value[$k])) {
                return $default;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
    
    public static function getDatabase() {
        return self::get('database');
    }
    
    public static function getEmail() {
        return self::get('email');
    }
    
    public static function getSecurity() {
        return self::get('security');
    }
    
    public static function getApp() {
        return self::get('app');
    }
    
    public static function getSolana() {
        return self::get('solana');
    }
    
    public static function isDebug() {
        return self::get('app.debug', false);
    }
    
    public static function isProduction() {
        return self::get('app.env') === 'production';
    }
}

// Initialize configuration
SecureConfig::load();

// Legacy compatibility functions
function getDbConfig() {
    return SecureConfig::getDatabase();
}

function getEmailConfig() {
    return SecureConfig::getEmail();
}

function isDebugMode() {
    return SecureConfig::isDebug();
}
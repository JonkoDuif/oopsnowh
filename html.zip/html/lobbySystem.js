// Prevent direct loading from a /js/ path if that's how you're serving static files
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
  throw new Error('Direct file access denied');
}

/**
 * Lobby System
 * - Manages multiple lobbies
 * - Connects to Lobby WebSocket via nginx proxy path /ws-lobby/{lobbyId}
 * - Works with flat deployment (no /php subfolder required on disk)
 */

class LobbySystem {
  constructor() {
    this.currentLobby = 1;                    // default to lobby 1 (US TRYHARD)
    this.availableLobbies = new Map();        // lobbyId -> lobby meta/state
    this.lobbyConnections = new Map();        // lobbyId -> WebSocket
    this.serverOnline = false;                // Start as offline until confirmed
    this.gameServerOnline = false;            // Game server status
    this.connectionCheckInterval = null;      // Interval for checking connectivity
    this.statusCheckInProgress = false;       // Prevent multiple simultaneous checks
    this.hasPerformedInitialCheck = false;    // Track if initial check has been performed
    
    this.initializeLobbies();
    
    // Perform initial server check immediately
    this.performInitialServerCheck();
    this.startServerMonitoring();
  }

  initializeLobbies() {
    const lobbyConfig = [
      // US (1-4)
      { id: 1, name: 'US Lobby 1', region: 'US', type: 'TRYHARD' },
      { id: 2, name: 'US Lobby 2', region: 'US', type: 'CRAZY' },
      { id: 3, name: 'US Lobby 3', region: 'US', type: 'OPEN' },
      { id: 4, name: 'US Lobby 4', region: 'US', type: 'OPEN' },
      // EU (5-8)
      { id: 5, name: 'EU Lobby 1', region: 'EU', type: 'TRYHARD' },
      { id: 6, name: 'EU Lobby 2', region: 'EU', type: 'CRAZY' },
      { id: 7, name: 'EU Lobby 3', region: 'EU', type: 'OPEN' },
      { id: 8, name: 'EU Lobby 4', region: 'EU', type: 'OPEN' },
    ];

    lobbyConfig.forEach(cfg => {
      this.availableLobbies.set(cfg.id, {
        id: cfg.id,
        name: cfg.name,
        region: cfg.region,
        type: cfg.type,
        players: new Map(),
        maxPlayers: 50,
        gameActive: false,
        walletAddress: null,
      });
    });

    console.log('?? Initialized 8 game lobbies (4 per region)');
  }

  getUserRegion() {
    const user = window.authSystem?.getCurrentUser?.();
    if (user?.region) return user.region;

    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
      const euHints = ['Europe/', 'Africa/Cairo', 'Africa/Johannesburg', 'Asia/Istanbul', 'Asia/Dubai', 'Asia/Kuwait', 'Asia/Riyadh'];
      return euHints.some(h => tz.includes(h)) ? 'EU' : 'US';
    } catch { return 'US'; }
  }

  async joinLobby(lobbyId, playerData = {}) {
    // Prevent lobby joining if servers are offline or being checked
    if (!this.serverOnline || !this.gameServerOnline || this.statusCheckInProgress) {
      const reason = this.statusCheckInProgress ? 'being checked' : 
                    (!this.serverOnline ? 'lobby servers offline' : 'game servers offline');
      console.warn(`🚫 Cannot join lobby ${lobbyId}: Servers are ${reason}`);
      
      if (window.gameManager?.uiManager) {
        window.gameManager.uiManager.showNotification(
          this.statusCheckInProgress ? 'Please wait, checking server status...' : 'Servers are offline. Cannot join lobby.', 
          'warning'
        );
      }
      
      return { success: false, error: this.statusCheckInProgress ? 'Server status check in progress' : 'Servers are offline' };
    }
    
    try {
      if (this.currentLobby) await this.leaveLobby();

      const lobby = this.availableLobbies.get(lobbyId);
      if (!lobby) throw new Error(`Lobby ${lobbyId} does not exist`);
      if (lobby.players.size >= lobby.maxPlayers) throw new Error(`Lobby ${lobbyId} is full`);

      const user = window.authSystem?.getCurrentUser?.() || {};
      const playerId = user.id ?? playerData.id ?? ('p_' + Math.random().toString(36).slice(2));
      lobby.players.set(playerId, { ...playerData, id: playerId, joinedAt: Date.now() });
      this.currentLobby = lobbyId;

      // populate wallet info if available
      const walletInfo = window.lobbyWalletManager?.getLobbyWallet?.(lobbyId);
      lobby.walletAddress = walletInfo?.publicKey || null;

      await this.connectToLobbyServer(lobbyId);

      // Also notify the lobby wallet manager
      if (window.lobbyWalletManager) {
        window.lobbyWalletManager.joinLobby(lobbyId, {
          id: playerId,
          username: user.username || user.email || 'anonymous',
          balance: user.balance || 0
        });
      }

      console.log(`?? Joined Lobby ${lobbyId}. Players: ${lobby.players.size}/${lobby.maxPlayers}`);
      this.updateLobbyUI(lobby);

      return {
        success: true,
        lobby: {
          id: lobbyId,
          name: lobby.name,
          players: lobby.players.size,
          maxPlayers: lobby.maxPlayers,
          walletAddress: lobby.walletAddress,
        },
      };
    } catch (err) {
      console.error(`? Failed to join lobby ${lobbyId}:`, err);
      return { success: false, error: err.message };
    }
  }

  async leaveLobby() {
    if (!this.currentLobby) return;
    const lobbyId = this.currentLobby;

    const lobby = this.availableLobbies.get(lobbyId);
    if (lobby) {
      const user = window.authSystem?.getCurrentUser?.();
      if (user?.id) {
        lobby.players.delete(user.id);
        
        // Send leave message to server before disconnecting
        const ws = this.lobbyConnections.get(lobbyId);
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'leave_lobby',
            lobbyId: lobbyId,
            player: {
              id: user.id,
              username: user.username || user.email || 'anonymous'
            }
          }));
        }
      }
      console.log(`🚪 Left Lobby ${lobbyId}`);
    }

    window.lobbyWalletManager?.leaveLobby?.();

    this.disconnectFromLobbyServer(lobbyId);
    this.currentLobby = null;
    this.updateLobbyUI(null);
    
    // Refresh lobby cards to update player counts
    if (window.gameManager?.uiManager) {
      window.gameManager.uiManager.updateLobbyCards();
    }
  }

  async connectToLobbyServer(lobbyId) {
    try {
      // Only disconnect from other lobby connections, not the current one
      this.lobbyConnections.forEach((ws, id) => {
        if (id !== lobbyId) {
          try {
            if (ws && ws.readyState === WebSocket.OPEN) ws.close();
          } catch {}
          this.lobbyConnections.delete(id);
        }
      });
      
      // If already connected to this lobby, don't reconnect
      if (this.lobbyConnections.has(lobbyId)) {
        const existingWs = this.lobbyConnections.get(lobbyId);
        if (existingWs && existingWs.readyState === WebSocket.OPEN) {
          console.log(`Already connected to Lobby ${lobbyId}`);
          return Promise.resolve();
        }
      }

      // Always use NGINX proxy for lobby connections
      const wsUrl = `wss://${location.host}/ws-lobby/${encodeURIComponent(String(lobbyId))}`;
      console.log('🔒 Using NGINX proxy for lobby connection');

      console.log('🔌 Connecting to lobby server:', wsUrl);
      
      // Return a Promise that resolves when the connection is established
      return new Promise((resolve, reject) => {
        const ws = new WebSocket(wsUrl);
        
        // Set a timeout for connection
        const connectionTimeout = setTimeout(() => {
          ws.close();
          reject(new Error('WebSocket connection timeout'));
        }, 10000); // 10 second timeout

        ws.onopen = () => {
          console.log(`?? Connected to Lobby ${lobbyId} server`);
          clearTimeout(connectionTimeout);
          this.serverOnline = true;
          this.updateServerStatus('online');
          
          const user = window.authSystem?.getCurrentUser?.() || {};
          ws.send(JSON.stringify({
            type: 'join_lobby',
            lobbyId,
            player: {
              id: user.id ?? ('p_' + Math.random().toString(36).slice(2)),
              username: user.username || user.email || 'anonymous',
              balance: user.balance ?? 0,
              region: this.getUserRegion(),
            },
          }));
          
          // Store the WebSocket connection
          this.lobbyConnections.set(lobbyId, ws);
          
          // Resolve the Promise
          resolve();
        };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleLobbyMessage(lobbyId, msg);
        } catch (e) {
          console.error('? Lobby message parse error:', e);
        }
      };

        ws.onclose = () => {
          console.log(`🔌 Disconnected from Lobby ${lobbyId} server`);
          this.lobbyConnections.delete(lobbyId);
          
          // Don't immediately set server offline - instead trigger a connectivity check
          // This prevents false offline status when user leaves a lobby
          if (this.lobbyConnections.size === 0) {
            console.log('🔍 No active lobby connections, scheduling server connectivity check');
            // Delay the check slightly to avoid immediate status changes
            setTimeout(() => {
              this.checkServerConnectivity();
            }, 1000);
          }
        };

        ws.onerror = (err) => {
          console.error(`❌ Lobby ${lobbyId} WebSocket error:`, err);
          clearTimeout(connectionTimeout);
          
          // Don't immediately set server offline - instead trigger a connectivity check
          if (this.lobbyConnections.size === 0) {
            console.log('🔍 WebSocket error with no active connections, scheduling server connectivity check');
            setTimeout(() => {
              this.checkServerConnectivity();
            }, 1000);
          }
          
          // Reject the Promise
          reject(new Error(`WebSocket connection failed: ${err.message || 'Unknown error'}`));
        };
      });
    } catch (err) {
      console.error(`? Failed to connect to Lobby ${lobbyId} server:`, err);
      this.serverOnline = false;
      this.updateServerStatus('offline');
      return Promise.reject(err);
    }
  }

  disconnectFromLobbyServer(lobbyId) {
    const ws = this.lobbyConnections.get(lobbyId);
    try {
      if (ws && ws.readyState === WebSocket.OPEN) ws.close();
    } catch {}
    this.lobbyConnections.delete(lobbyId);
  }

  handleLobbyMessage(lobbyId, message) {
    switch (message.type) {
      case 'player_joined':
      case 'player_left':
        this.updateLobbyPlayerList(lobbyId, message.players || []);
        break;
      case 'game_started':
        if (lobbyId === this.currentLobby) window.gameManager?.startLobbyGame?.(message.gameData);
        break;
      case 'player_update':
        if (lobbyId === this.currentLobby) window.game?.multiplayer?.handlePlayerUpdate?.(message);
        break;
      case 'player_eliminated':
        if (lobbyId === this.currentLobby) {
          window.lobbyWalletManager?.handlePlayerElimination?.(lobbyId, message.playerId, message.playerMoney);
        }
        break;
      default:
        console.log(`?? Lobby ${lobbyId} message:`, message);
    }
  }

  updateLobbyPlayerList(lobbyId, players) {
    const lobby = this.availableLobbies.get(lobbyId);
    if (!lobby) return;
    lobby.players.clear();
    players.forEach(p => lobby.players.set(p.id, p));
    if (lobbyId === this.currentLobby) this.updateLobbyUI(lobby);
  }

  updateLobbyUI(lobby) {
    const el = document.getElementById('current-lobby-info');
    if (!el) return;
    if (lobby) {
      // Get wallet address from lobby wallet manager
      const walletInfo = window.lobbyWalletManager?.getLobbyStats?.(this.currentLobby);
      const walletAddress = walletInfo?.publicKey;
      const walletShort = walletAddress ? (walletAddress.slice(0, 8) + '…') : 'Loading…';
      el.innerHTML = `
        <div class="lobby-info">
          <h3>${lobby.name}</h3>
          <p>Players: ${lobby.players.size}/${lobby.maxPlayers}</p>
          <p>Wallet: ${walletShort}</p>
        </div>
      `;
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
    }
  }

  sendToLobby(message) {
    if (!this.currentLobby) return console.warn('?? No current lobby to send message to');
    const ws = this.lobbyConnections.get(this.currentLobby);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ ...message, lobbyId: this.currentLobby, timestamp: Date.now() }));
    }
  }

  getCurrentLobby() {
    if (!this.currentLobby) return null;
    const lobby = this.availableLobbies.get(this.currentLobby);
    const walletInfo = window.lobbyWalletManager?.getLobbyStats?.(this.currentLobby);
    return {
      id: this.currentLobby,
      name: lobby?.name,
      players: Array.from(lobby?.players?.values() || []),
      walletInfo,
    };
  }

  getAvailableLobbies() {
    const out = [];
    this.availableLobbies.forEach((lobby, id) => {
      const walletInfo = window.lobbyWalletManager?.getLobbyStats?.(id);
      out.push({
        id,
        name: lobby.name,
        type: lobby.type,
        region: lobby.region,
        players: lobby.players.size,
        maxPlayers: lobby.maxPlayers,
        gameActive: lobby.gameActive,
        walletAddress: walletInfo?.publicKey,
      });
    });
    return out;
  }

  // Join game method for ready button functionality
  async joinGame(playerData) {
    console.log('🎮 joinGame called with playerData:', playerData);
    
    if (!this.currentLobby) {
      throw new Error('Not in a lobby');
    }
    
    const lobby = this.availableLobbies.get(this.currentLobby);
    if (!lobby) {
      throw new Error('Current lobby not found');
    }
    
    // Send join game message to lobby server
    const ws = this.lobbyConnections.get(this.currentLobby);
    if (ws && ws.readyState === WebSocket.OPEN) {
      const message = {
        type: 'join_game',
        lobbyId: this.currentLobby,
        player: playerData,
        timestamp: Date.now()
      };
      
      console.log('📤 Sending join_game message:', message);
      ws.send(JSON.stringify(message));
      
      return {
        success: true,
        message: 'Game join request sent'
      };
    } else {
      throw new Error('No connection to lobby server');
    }
  }

  // Server monitoring methods
  async performInitialServerCheck() {
    // Disable lobby interactions until status is confirmed
    this.updateServerStatus('checking');
    await this.checkServerConnectivity();
  }
  
  // Method to trigger initial server check when UI is ready
  triggerInitialServerCheck() {
    if (!this.hasPerformedInitialCheck) {
      this.hasPerformedInitialCheck = true;
      this.performInitialServerCheck();
    }
  }

  startServerMonitoring() {
    this.connectionCheckInterval = setInterval(() => {
      this.checkServerConnectivity();
    }, 30000); // Check every 30 seconds
  }

  async checkServerConnectivity() {
    // Prevent multiple simultaneous checks
    if (this.statusCheckInProgress) {
      return;
    }
    
    this.statusCheckInProgress = true;
    
    try {
      // Check if we have any active lobby connections
      const hasActiveConnections = this.lobbyConnections.size > 0;
      
      if (hasActiveConnections) {
        // If we have active connections, both servers are definitely online
        this.serverOnline = true;
        this.gameServerOnline = true;
        this.updateServerStatus('online');
        return;
      }
      
      // Only test connectivity if we don't have active connections
      // Test lobby server connectivity - always use nginx proxy
      const lobbyWsUrl = `wss://${location.host}/ws-lobby/status-check`;
      
      try {
        await this.testWebSocketConnection(lobbyWsUrl);
        this.serverOnline = true;
      } catch (error) {
        this.serverOnline = false;
      }
      
      // Test game server connectivity - always use nginx proxy
      const gameWsUrl = `wss://${location.host}/ws-game`;
      
      try {
        await this.testWebSocketConnection(gameWsUrl);
        this.gameServerOnline = true;
      } catch (error) {
        this.gameServerOnline = false;
      }
      
      // Update UI based on both server statuses
      const bothOnline = this.serverOnline && this.gameServerOnline;
      this.updateServerStatus(bothOnline ? 'online' : 'offline');
      
    } catch (error) {
      console.error('Server connectivity check failed:', error);
      this.serverOnline = false;
      this.gameServerOnline = false;
      this.updateServerStatus('offline');
    } finally {
      this.statusCheckInProgress = false;
    }
  }
  
  // Helper method to test WebSocket connections
  testWebSocketConnection(wsUrl) {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(wsUrl);
      const timeout = setTimeout(() => {
        ws.close();
        reject(new Error('Connection timeout'));
      }, 3000);
      
      ws.onopen = () => {
        clearTimeout(timeout);
        ws.close();
        resolve(true);
      };
      
      ws.onerror = () => {
        clearTimeout(timeout);
        reject(new Error('Connection failed'));
      };
      
      ws.onclose = (event) => {
        clearTimeout(timeout);
        // If close code is 1000 (normal) or 1006 (abnormal but connected), server is reachable
        if (event.code === 1000 || event.code === 1006) {
          resolve(true);
        } else {
          reject(new Error('Connection rejected'));
        }
      };
    });
  }

  updateServerStatus(status) {
    const statusEl = document.getElementById('server-status');
    if (statusEl) {
      if (status === 'checking') {
        statusEl.textContent = '🔄 Checking...';
        statusEl.className = 'server-status checking';
      } else {
        statusEl.textContent = status === 'online' ? '🟢 Online' : '🔴 Offline';
        statusEl.className = `server-status ${status}`;
      }
    }
    
    // Update lobby cards if UI manager exists
    if (window.gameManager?.uiManager) {
      window.gameManager.uiManager.updateLobbyCards();
      window.gameManager.uiManager.updateJoinGameButtonState();
    }
    
    // Update UI status indicator
    if (window.uiManager) {
      window.uiManager.updateServerStatusCorner(status);
    }
    
    console.log(`🌐 Server status: ${status}`);
  }

  getServerStatus() {
    return {
      online: this.serverOnline,
      lastCheck: Date.now()
    };
  }
}

window.lobbySystem = new LobbySystem();
console.log('?? Lobby System initialized');

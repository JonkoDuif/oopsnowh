<?php
require_once 'config_hostinger.php';

// Test SQLite database connection
$db = Database::getInstance();

echo "Database connected: " . ($db->isConnected() ? 'YES' : 'NO') . "\n";

if ($db->isConnected()) {
    echo "Database type: SQLite\n";
    
    // Initialize tables
    $result = $db->initializeTables();
    echo "Tables initialized: " . ($result ? 'YES' : 'NO') . "\n";
    
    // Test verification code storage
    try {
        $testResult = storeVerificationCode('test@example.com', '123456');
        echo "Test verification code stored: " . ($testResult ? 'YES' : 'NO') . "\n";
        
        // Test verification
        $verifyResult = verifyCode('test@example.com', '123456');
        echo "Test verification code verified: " . ($verifyResult ? 'YES' : 'NO') . "\n";
        
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
    }
} else {
    echo "Database connection failed\n";
}
?>
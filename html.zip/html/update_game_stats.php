<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../database_improved.php';

try {
    $db = Database::getInstance();
    
    if (!$db->isConnected()) {
        throw new Exception('Database connection failed');
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    $userId = $input['user_id'] ?? null;
    $gameId = $input['game_id'] ?? null;
    $kills = (int)($input['kills'] ?? 0);
    $deaths = (int)($input['deaths'] ?? 0);
    $score = (int)($input['score'] ?? 0);
    $gameDuration = (int)($input['game_duration'] ?? 0); // in seconds
    $betAmount = (float)($input['bet_amount'] ?? 0);
    $winnings = (float)($input['winnings'] ?? 0);
    $position = (int)($input['position'] ?? 0); // 1 = winner, 2 = second, etc.
    $isWin = $position === 1;
    
    if (!$userId || !$gameId) {
        throw new Exception('User ID and Game ID are required');
    }
    
    $conn = $db->getConnection();
    $conn->beginTransaction();
    
    try {
        // Insert game stats record
        $stmt = $conn->prepare("
            INSERT INTO game_stats 
            (user_id, game_id, kills, deaths, score, game_duration, bet_amount, winnings, position) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$userId, $gameId, $kills, $deaths, $score, $gameDuration, $betAmount, $winnings, $position]);
        
        // Update or create user_stats
        $stmt = $conn->prepare("
            INSERT INTO user_stats (user_id, total_earnings, total_kills, total_wins, total_losses, total_games, avg_game_time)
            VALUES (?, ?, ?, ?, ?, 1, ?)
            ON DUPLICATE KEY UPDATE
                total_earnings = total_earnings + VALUES(total_earnings),
                total_kills = total_kills + VALUES(total_kills),
                total_wins = total_wins + VALUES(total_wins),
                total_losses = total_losses + VALUES(total_losses),
                total_games = total_games + 1,
                avg_game_time = ((avg_game_time * (total_games - 1)) + VALUES(avg_game_time)) / total_games,
                updated_at = NOW()
        ");
        
        $earnings = $winnings - $betAmount; // Net earnings (can be negative)
        $wins = $isWin ? 1 : 0;
        $losses = $isWin ? 0 : 1;
        
        $stmt->execute([$userId, $earnings, $kills, $wins, $losses, $gameDuration]);
        
        // Update user balance if there are winnings
        if ($winnings > 0) {
            $stmt = $conn->prepare("UPDATE users SET balance = balance + ?, total_winnings = total_winnings + ? WHERE id = ?");
            $stmt->execute([$winnings, $winnings, $userId]);
        }
        
        // Deduct bet amount from balance
        if ($betAmount > 0) {
            $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt->execute([$betAmount, $userId]);
        }
        
        $conn->commit();
        
        // Get updated user stats
        $stmt = $conn->prepare("
            SELECT 
                us.*,
                u.balance,
                u.total_winnings,
                CASE WHEN us.total_games > 0 THEN ROUND(us.total_kills / us.total_games, 2) ELSE 0 END as avg_kills_per_game,
                CASE WHEN us.total_games > 0 THEN ROUND((us.total_wins / us.total_games) * 100, 2) ELSE 0 END as win_percentage
            FROM user_stats us
            JOIN users u ON us.user_id = u.id
            WHERE us.user_id = ?
        ");
        $stmt->execute([$userId]);
        $updatedStats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'message' => 'Game stats updated successfully',
            'stats' => $updatedStats,
            'game_result' => [
                'kills' => $kills,
                'deaths' => $deaths,
                'score' => $score,
                'position' => $position,
                'winnings' => $winnings,
                'net_earnings' => $earnings
            ]
        ]);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log('Update game stats error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
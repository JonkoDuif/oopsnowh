<?php
require_once 'database.php';
require_once 'security.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

class SocialAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = $_GET['action'] ?? '';
        
        try {
            switch ($path) {
                case 'search_users':
                    return $this->searchUsers();
                case 'send_friend_request':
                    return $this->sendFriendRequest();
                case 'respond_friend_request':
                    return $this->respondFriendRequest();
                case 'get_friends':
                    return $this->getFriends();
                case 'get_friend_requests':
                    return $this->getFriendRequests();
                case 'get_leaderboard':
                    return $this->getLeaderboard();
                case 'get_user_stats':
                    return $this->getUserStats();
                case 'get_online_status':
                    return $this->getOnlineStatus();
                case 'send_money':
                    return $this->sendMoney();
                case 'block_user':
                    return $this->blockUser();
                case 'unblock_user':
                    return $this->unblockUser();
                case 'get_blocked_users':
                    return $this->getBlockedUsers();
                case 'remove_friend':
                    return $this->removeFriend();
                default:
                    throw new Exception('Invalid action');
            }
        } catch (Exception $e) {
            return $this->errorResponse($e->getMessage());
        }
    }
    
    private function searchUsers() {
        $query = $_GET['query'] ?? '';
        $currentUserId = $this->getCurrentUserId();
        
        if (strlen($query) < 2) {
            return $this->errorResponse('Query must be at least 2 characters');
        }
        
        $stmt = $this->db->prepare("
            SELECT u.id, u.username, u.last_login,
                   CASE WHEN s.user_id IS NOT NULL THEN 1 ELSE 0 END as is_online,
                   CASE WHEN f.friend_id IS NOT NULL THEN 1 ELSE 0 END as is_friend,
                   CASE WHEN fr.id IS NOT NULL THEN fr.status ELSE NULL END as friend_request_status,
                   CASE WHEN fr.sender_id = ? THEN 'sent' 
                        WHEN fr.receiver_id = ? THEN 'received' 
                        ELSE NULL END as request_direction
            FROM users u
            LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
            LEFT JOIN friendships f ON (f.user_id = ? AND f.friend_id = u.id)
            LEFT JOIN friend_requests fr ON ((fr.sender_id = ? AND fr.receiver_id = u.id) OR (fr.sender_id = u.id AND fr.receiver_id = ?))
            WHERE u.username LIKE ? AND u.id != ?
            ORDER BY is_online DESC, u.username ASC
            LIMIT 20
        ");
        
        $searchTerm = '%' . $query . '%';
        $stmt->execute([$currentUserId, $currentUserId, $currentUserId, $currentUserId, $currentUserId, $searchTerm, $currentUserId]);
        
        return $this->successResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    private function sendFriendRequest() {
        $data = json_decode(file_get_contents('php://input'), true);
        $receiverId = $data['receiver_id'] ?? null;
        $senderId = $this->getCurrentUserId();
        
        if (!$receiverId) {
            return $this->errorResponse('Receiver ID is required');
        }
        
        // Check if already friends
        $stmt = $this->db->prepare("SELECT id FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
        $stmt->execute([$senderId, $receiverId, $receiverId, $senderId]);
        if ($stmt->fetch()) {
            return $this->errorResponse('Already friends');
        }
        
        // Check if request already exists
        $stmt = $this->db->prepare("SELECT id, status FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
        $stmt->execute([$senderId, $receiverId, $receiverId, $senderId]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            return $this->errorResponse('Friend request already exists');
        }
        
        // Send friend request
        $stmt = $this->db->prepare("INSERT INTO friend_requests (sender_id, receiver_id) VALUES (?, ?)");
        $stmt->execute([$senderId, $receiverId]);
        
        return $this->successResponse(['message' => 'Friend request sent']);
    }
    
    private function respondFriendRequest() {
        $data = json_decode(file_get_contents('php://input'), true);
        $requestId = $data['request_id'] ?? null;
        $response = $data['response'] ?? null; // 'accepted' or 'declined'
        $currentUserId = $this->getCurrentUserId();
        
        if (!$requestId || !in_array($response, ['accepted', 'declined'])) {
            return $this->errorResponse('Invalid request');
        }
        
        // Get the friend request
        $stmt = $this->db->prepare("SELECT sender_id, receiver_id FROM friend_requests WHERE id = ? AND receiver_id = ? AND status = 'pending'");
        $stmt->execute([$requestId, $currentUserId]);
        $request = $stmt->fetch();
        
        if (!$request) {
            return $this->errorResponse('Friend request not found');
        }
        
        // Update request status
        $stmt = $this->db->prepare("UPDATE friend_requests SET status = ? WHERE id = ?");
        $stmt->execute([$response, $requestId]);
        
        // If accepted, create friendship
        if ($response === 'accepted') {
            $stmt = $this->db->prepare("INSERT INTO friendships (user_id, friend_id) VALUES (?, ?), (?, ?)");
            $stmt->execute([$request['sender_id'], $request['receiver_id'], $request['receiver_id'], $request['sender_id']]);
        }
        
        return $this->successResponse(['message' => 'Friend request ' . $response]);
    }
    
    private function getFriends() {
        $currentUserId = $this->getCurrentUserId();
        $filter = $_GET['filter'] ?? 'all'; // all, online, offline
        
        $whereClause = '';
        if ($filter === 'online') {
            $whereClause = 'AND s.user_id IS NOT NULL';
        } elseif ($filter === 'offline') {
            $whereClause = 'AND s.user_id IS NULL';
        }
        
        $stmt = $this->db->prepare("
            SELECT u.id, u.username, u.last_login,
                   CASE WHEN s.user_id IS NOT NULL THEN 1 ELSE 0 END as is_online,
                   us.total_earnings, us.total_kills, us.total_games
            FROM friendships f
            JOIN users u ON f.friend_id = u.id
            LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
            LEFT JOIN user_stats us ON u.id = us.user_id
            WHERE f.user_id = ? $whereClause
            ORDER BY is_online DESC, u.username ASC
        ");
        
        $stmt->execute([$currentUserId]);
        return $this->successResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    private function getFriendRequests() {
        $currentUserId = $this->getCurrentUserId();
        $type = $_GET['type'] ?? 'received'; // received, sent
        
        if ($type === 'received') {
            $stmt = $this->db->prepare("
                SELECT fr.id, fr.sender_id, u.username, fr.created_at
                FROM friend_requests fr
                JOIN users u ON fr.sender_id = u.id
                WHERE fr.receiver_id = ? AND fr.status = 'pending'
                ORDER BY fr.created_at DESC
            ");
            $stmt->execute([$currentUserId]);
        } else {
            $stmt = $this->db->prepare("
                SELECT fr.id, fr.receiver_id, u.username, fr.status, fr.created_at
                FROM friend_requests fr
                JOIN users u ON fr.receiver_id = u.id
                WHERE fr.sender_id = ?
                ORDER BY fr.created_at DESC
            ");
            $stmt->execute([$currentUserId]);
        }
        
        return $this->successResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    private function getLeaderboard() {
        $currentUserId = $this->getCurrentUserId();
        $type = $_GET['type'] ?? 'friends'; // friends, global
        $limit = $_GET['limit'] ?? 10;
        
        if ($type === 'friends') {
            $stmt = $this->db->prepare("
                SELECT u.id, u.username, us.total_earnings, us.total_kills, us.total_games,
                       CASE WHEN s.user_id IS NOT NULL THEN 1 ELSE 0 END as is_online
                FROM friendships f
                JOIN users u ON f.friend_id = u.id
                LEFT JOIN user_stats us ON u.id = us.user_id
                LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
                WHERE f.user_id = ?
                ORDER BY us.total_earnings DESC
                LIMIT ?
            ");
            $stmt->execute([$currentUserId, $limit]);
        } else {
            $stmt = $this->db->prepare("
                SELECT u.id, u.username, us.total_earnings, us.total_kills, us.total_games,
                       CASE WHEN s.user_id IS NOT NULL THEN 1 ELSE 0 END as is_online
                FROM users u
                LEFT JOIN user_stats us ON u.id = us.user_id
                LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
                ORDER BY us.total_earnings DESC
                LIMIT ?
            ");
            $stmt->execute([$limit]);
        }
        
        return $this->successResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    private function getUserStats() {
        $userId = $_GET['user_id'] ?? $this->getCurrentUserId();
        
        $stmt = $this->db->prepare("
            SELECT u.username, u.created_at as joined_date,
                   us.total_earnings, us.total_kills, us.total_wins, us.total_losses, us.total_games,
                   CASE WHEN us.total_games > 0 THEN ROUND(us.total_kills / us.total_games, 2) ELSE 0 END as avg_kills_per_game,
                   CASE WHEN us.total_games > 0 THEN ROUND((us.total_wins / us.total_games) * 100, 2) ELSE 0 END as win_rate
            FROM users u
            LEFT JOIN user_stats us ON u.id = us.user_id
            WHERE u.id = ?
        ");
        
        $stmt->execute([$userId]);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$stats) {
            return $this->errorResponse('User not found');
        }
        
        return $this->successResponse($stats);
    }
    
    private function getOnlineStatus() {
        $userIds = $_GET['user_ids'] ?? '';
        $userIdArray = explode(',', $userIds);
        
        if (empty($userIdArray)) {
            return $this->errorResponse('No user IDs provided');
        }
        
        $placeholders = str_repeat('?,', count($userIdArray) - 1) . '?';
        $stmt = $this->db->prepare("
            SELECT u.id, 
                   CASE WHEN s.user_id IS NOT NULL THEN 1 ELSE 0 END as is_online
            FROM users u
            LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
            WHERE u.id IN ($placeholders)
        ");
        
        $stmt->execute($userIdArray);
        return $this->successResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    private function sendMoney() {
        $data = json_decode(file_get_contents('php://input'), true);
        $receiverId = $data['receiver_id'] ?? null;
        $amount = $data['amount'] ?? null;
        $senderId = $this->getCurrentUserId();
        
        if (!$receiverId || !$amount || $amount <= 0) {
            return $this->errorResponse('Invalid transfer data');
        }
        
        // Check if users are friends
        $stmt = $this->db->prepare("SELECT id FROM friendships WHERE user_id = ? AND friend_id = ?");
        $stmt->execute([$senderId, $receiverId]);
        if (!$stmt->fetch()) {
            return $this->errorResponse('You can only send money to friends');
        }
        
        // Check sender balance
        $stmt = $this->db->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$senderId]);
        $senderBalance = $stmt->fetchColumn();
        
        if ($senderBalance < $amount) {
            return $this->errorResponse('Insufficient balance');
        }
        
        // Perform transfer
        $this->db->beginTransaction();
        
        try {
            // Deduct from sender
            $stmt = $this->db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt->execute([$amount, $senderId]);
            
            // Add to receiver
            $stmt = $this->db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
            $stmt->execute([$amount, $receiverId]);
            
            // Record transaction
            $stmt = $this->db->prepare("INSERT INTO wallet_transactions (sender_id, receiver_id, amount, fee) VALUES (?, ?, ?, 0)");
            $stmt->execute([$senderId, $receiverId, $amount]);
            
            $this->db->commit();
            return $this->successResponse(['message' => 'Money sent successfully']);
        } catch (Exception $e) {
            $this->db->rollback();
            return $this->errorResponse('Transfer failed');
        }
    }
    
    private function blockUser() {
        $data = json_decode(file_get_contents('php://input'), true);
        $blockedUserId = $data['user_id'] ?? null;
        $currentUserId = $this->getCurrentUserId();
        
        if (!$blockedUserId) {
            return $this->errorResponse('User ID is required');
        }
        
        // Remove friendship if exists
        $stmt = $this->db->prepare("DELETE FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
        $stmt->execute([$currentUserId, $blockedUserId, $blockedUserId, $currentUserId]);
        
        // Remove friend requests
        $stmt = $this->db->prepare("DELETE FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
        $stmt->execute([$currentUserId, $blockedUserId, $blockedUserId, $currentUserId]);
        
        // Add to blocked users (we'll create this table)
        $stmt = $this->db->prepare("INSERT IGNORE INTO blocked_users (user_id, blocked_user_id) VALUES (?, ?)");
        $stmt->execute([$currentUserId, $blockedUserId]);
        
        return $this->successResponse(['message' => 'User blocked']);
    }
    
    private function unblockUser() {
        $data = json_decode(file_get_contents('php://input'), true);
        $blockedUserId = $data['user_id'] ?? null;
        $currentUserId = $this->getCurrentUserId();
        
        if (!$blockedUserId) {
            return $this->errorResponse('User ID is required');
        }
        
        $stmt = $this->db->prepare("DELETE FROM blocked_users WHERE user_id = ? AND blocked_user_id = ?");
        $stmt->execute([$currentUserId, $blockedUserId]);
        
        return $this->successResponse(['message' => 'User unblocked']);
    }
    
    private function getBlockedUsers() {
        $currentUserId = $this->getCurrentUserId();
        
        $stmt = $this->db->prepare("
            SELECT u.id, u.username, bu.created_at as blocked_at
            FROM blocked_users bu
            JOIN users u ON bu.blocked_user_id = u.id
            WHERE bu.user_id = ?
            ORDER BY bu.created_at DESC
        ");
        
        $stmt->execute([$currentUserId]);
        return $this->successResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    private function removeFriend() {
        $data = json_decode(file_get_contents('php://input'), true);
        $friendId = $data['friend_id'] ?? null;
        $currentUserId = $this->getCurrentUserId();
        
        if (!$friendId) {
            return $this->errorResponse('Friend ID is required');
        }
        
        $stmt = $this->db->prepare("DELETE FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
        $stmt->execute([$currentUserId, $friendId, $friendId, $currentUserId]);
        
        return $this->successResponse(['message' => 'Friend removed']);
    }
    
    private function getCurrentUserId() {
        // Get user ID from session or token
        session_start();
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('Not authenticated');
        }
        return $_SESSION['user_id'];
    }
    
    private function successResponse($data) {
        return json_encode(['success' => true, 'data' => $data]);
    }
    
    private function errorResponse($message) {
        return json_encode(['success' => false, 'error' => $message]);
    }
}

// Handle the request
$api = new SocialAPI();
echo $api->handleRequest();
?>
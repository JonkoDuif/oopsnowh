const WebSocket = require('ws');

// Connect to the game server and clear all players
const ws = new WebSocket('wss://localhost:8081', {
    rejectUnauthorized: false // Allow self-signed certificates
});

ws.on('open', () => {
    console.log('Connected to game server');
    
    // Send clear all players command
    ws.send(JSON.stringify({
        type: 'clear_all_players'
    }));
    
    console.log('Sent clear all players command');
    
    // Close connection after a short delay
    setTimeout(() => {
        ws.close();
        console.log('Disconnected from server');
        process.exit(0);
    }, 1000);
});

ws.on('message', (data) => {
    const message = JSON.parse(data.toString());
    console.log('Server response:', message);
});

ws.on('error', (error) => {
    console.error('WebSocket error:', error);
    process.exit(1);
});

ws.on('close', () => {
    console.log('Connection closed');
});
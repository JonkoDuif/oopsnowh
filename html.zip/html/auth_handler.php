<?php
require_once 'config_hostinger.php';
require_once 'email_service.php';

class AuthHandler {
    
    public static function handleRequest() {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'send_verification':
                return self::sendVerificationCode($input);
            case 'verify_code':
                return self::verifyCode($input);
            case 'create_account':
                return self::createAccount($input);
            case 'check_session':
                return self::checkSession($input);
            case 'update_wallet_address':
                return self::updateWalletAddress($input);
            case 'logout':
                return self::logout($input);
            default:
                return self::errorResponse('Invalid action');
        }
    }
    
    private static function sendVerificationCode($input) {
        $email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
        
        if (!$email) {
            return self::errorResponse('Invalid email address');
        }
        
        // Generate verification code
        $code = generateCode();
        $timestamp = time();
        
        // Store verification code in database
        storeVerificationCode($email, $code);
        
        // For development: Try to send email, but don't fail if it doesn't work
        try {
            $emailSent = EmailService::sendVerificationCode($email, $code);
        } catch (Exception $e) {
            error_log("Email service error: " . $e->getMessage());
            $emailSent = false;
        }
        
        if ($emailSent) {
            return self::successResponse([
                'message' => 'Verification code sent successfully'
            ]);
        } else {
            // Development mode: Return the code in the response for testing
            error_log("Development mode: Verification code for $email is: $code");
            return self::successResponse([
                'message' => 'Email service unavailable. Development mode: Check console for verification code.',
                'dev_code' => $code // Include code for development
            ]);
        }
    }
    
    private static function verifyCode($input) {
        $email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
        $code = $input['code'] ?? '';
        
        if (!$email || !$code) {
            return self::errorResponse('Email and code are required');
        }
        
        // Verify code using database function
        $verificationResult = verifyCode($email, $code);
        
        if (!$verificationResult) {
            return self::errorResponse('Invalid or expired verification code');
        }
        
        // Check if user exists
        $userData = getUserByEmail($email);
        
        if ($userData) {
            // User exists, log them in
            $sessionToken = self::createSession($userData);
            
            // Clean up verification code
            cleanupVerificationCode($email);
            
            return self::successResponse([
                'user_exists' => true,
                'user' => [
                    'id' => $userData['id'],
                    'username' => $userData['username'],
                    'email' => $userData['email'],
                    'balance' => $userData['balance'],
                    'wallet_address' => $userData['wallet_address']
                ],
                'session_token' => $sessionToken
            ]);
        } else {
            // User doesn't exist, need to create account
            return self::successResponse([
                'message' => 'Email verified. Please create your account.',
                'new_user' => true,
                'email' => $email
            ]);
        }
    }
    
    private static function createAccount($input) {
        $email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
        $username = trim($input['username'] ?? '');
        
        if (!$email || !$username) {
            return self::errorResponse('Email and username are required');
        }
        
        if (strlen($username) < 3 || strlen($username) > 20) {
            return self::errorResponse('Username must be between 3 and 20 characters');
        }
        
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            return self::errorResponse('Username can only contain letters, numbers, and underscores');
        }
        
        // Check if user already exists
        if (getUserByEmail($email)) {
            return self::errorResponse('Email is already registered');
        }
        
        // Create new user using database function
        $userData = createUser($username, $email);
        
        if (!$userData) {
            return self::errorResponse('Failed to create user account');
        }
        
        // Create session
        $sessionToken = self::createSession($userData);
        
        // Clean up verification code
        cleanupVerificationCode($email);
        
        return self::successResponse([
            'message' => 'Account created successfully',
            'user' => [
                'id' => $userData['id'],
                'username' => $userData['username'],
                'email' => $userData['email'],
                'balance' => $userData['balance'],
                'wallet_address' => $userData['wallet_address']
            ],
            'session_token' => $sessionToken
        ]);
    }
    
    private static function createSession($userData) {
        return createSession($userData['id']);
    }
    
    private static function checkSession($input) {
        $sessionToken = $input['session_token'] ?? '';
        
        if (!$sessionToken) {
            return self::errorResponse('Session token required');
        }
        
        // Validate session using database function
        $userId = validateSession($sessionToken);
        
        if (!$userId) {
            return self::errorResponse('Invalid or expired session');
        }
        
        // Get current user data
        $userData = getUserById($userId);
        
        if (!$userData) {
            return self::errorResponse('User not found');
        }
        
        return self::successResponse([
            'valid' => true,
            'user' => [
                'id' => $userData['id'],
                'username' => $userData['username'],
                'email' => $userData['email'],
                'balance' => $userData['balance'],
                'wallet_address' => $userData['wallet_address']
            ]
        ]);
    }
    
    private static function updateWalletAddress($input) {
        $sessionToken = $input['session_token'] ?? '';
        $walletAddress = $input['wallet_address'] ?? '';
        
        if (!$sessionToken || !$walletAddress) {
            return self::errorResponse('Session token and wallet address are required');
        }
        
        // Validate session using database function
        $userId = validateSession($sessionToken);
        
        if (!$userId) {
            return self::errorResponse('Invalid or expired session');
        }
        
        // Update user's wallet address using database function
        $userData = getUserById($userId);
        if (!$userData) {
            return self::errorResponse('User not found');
        }
        
        $updated = updateUser($userData['id'], ['wallet_address' => $walletAddress]);
        
        if (!$updated) {
            return self::errorResponse('Failed to update wallet address');
        }
        
        return self::successResponse([
            'message' => 'Wallet address updated successfully',
            'wallet_address' => $walletAddress
        ]);
    }

    private static function logout($input) {
        $sessionToken = $input['session_token'] ?? '';
        
        if ($sessionToken) {
            deleteSession($sessionToken);
        }
        
        return self::successResponse(['message' => 'Logged out successfully']);
    }
    
    private static function successResponse($data) {
        http_response_code(200);
        echo json_encode(['success' => true, 'data' => $data]);
        exit;
    }
    
    private static function errorResponse($message) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $message]);
        exit;
    }
}

// Handle the request
AuthHandler::handleRequest();
?>
<?php
// Hybrid User Management Functions
// Automatically uses database when available, falls back to JSON

// Database class already included via config_hostinger.php

// User management functions - Database only (no JSON fallback)
function createUser($username, $email, $password = null, $walletAddress = null) {
    $db = Database::getInstance();
    if ($db->isConnected()) {
        return createUserDatabase($username, $email, $password, $walletAddress);
    } else {
        return createUserJSON($username, $email, $password, $walletAddress);
    }
}

function createUserDatabase($username, $email, $password = null, $walletAddress = null) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    if ($conn === null) {
        // Fallback to JSON when database is not available
        return createUserJSON($username, $email, $password, $walletAddress);
    }
    
    try {
        $hashedPassword = $password ? password_hash($password, PASSWORD_DEFAULT) : null;
        
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password_hash, wallet_address) 
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->execute([$username, $email, $hashedPassword, $walletAddress]);
        
        $userId = $conn->lastInsertId();
        error_log("User created in database: $username (ID: $userId)");
        
        return [
            "success" => true,
            "user_id" => $userId,
            "message" => "User created successfully in database"
        ];
        
    } catch (PDOException $e) {
        error_log("Database user creation failed: " . $e->getMessage());
        
        // Fallback to JSON on database error
        return createUserJSON($username, $email, $password, $walletAddress);
    }
}

function createUserJSON($username, $email, $password = null, $walletAddress = null) {
    $users = loadJsonFile(USERS_FILE);
    
    // Check if user already exists
    foreach ($users as $user) {
        if ($user['email'] === $email || $user['username'] === $username) {
            return [
                "success" => false,
                "error" => "User already exists"
            ];
        }
    }
    
    $hashedPassword = $password ? password_hash($password, PASSWORD_DEFAULT) : null;
    $userId = count($users) + 1;
    
    $newUser = [
        'id' => $userId,
        'username' => $username,
        'email' => $email,
        'password_hash' => $hashedPassword,
        'wallet_address' => $walletAddress,
        'balance' => 0.00,
        'total_winnings' => 0.00,
        'games_played' => 0,
        'is_verified' => true,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s'),
        'last_login' => null
    ];
    
    $users[] = $newUser;
    
    if (saveJsonFile(USERS_FILE, $users)) {
        error_log("User created in JSON: $username (ID: $userId)");
        return [
            "success" => true,
            "user_id" => $userId,
            "message" => "User created successfully in JSON"
        ];
    } else {
        return [
            "success" => false,
            "error" => "Failed to save user to JSON file"
        ];
    }
}

// createUserJSON function removed - Database only implementation

function getUserByEmail($email) {
    $db = Database::getInstance();
    return getUserByEmailDatabase($email);
}

// Alias function for compatibility
function getUser($email) {
    return getUserByEmail($email);
}

function getUserById($id) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    if ($conn === null) {
        // Fallback to JSON when database is not available
        return getUserByIdJSON($id);
    }
    
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Database query failed: " . $e->getMessage());
        // Fallback to JSON on database error
        return getUserByIdJSON($id);
    }
}

function getUserByIdJSON($id) {
    $users = loadJsonFile(USERS_FILE);
    foreach ($users as $user) {
        if (isset($user['id']) && $user['id'] == $id) {
            return $user;
        }
    }
    return false;
}

function updateUser($id, $data) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    try {
        $fields = [];
        $values = [];
        
        foreach ($data as $key => $value) {
            $fields[] = "$key = ?";
            $values[] = $value;
        }
        
        $values[] = $id;
        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        return $stmt->execute($values);
    } catch (PDOException $e) {
        error_log("Database update failed: " . $e->getMessage());
        return false;
    }
}

function getUserByEmailDatabase($email) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    if ($conn === null) {
        // Fallback to JSON when database is not available
        return getUserByEmailJSON($email);
    }
    
    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Database query failed: " . $e->getMessage());
        // Fallback to JSON on database error
        return getUserByEmailJSON($email);
    }
}

function getUserByEmailJSON($email) {
    $users = loadJsonFile(USERS_FILE);
    foreach ($users as $user) {
        if ($user['email'] === $email) {
            return $user;
        }
    }
    return false;
}

// JSON utility functions are already defined in config_hostinger.php
?>
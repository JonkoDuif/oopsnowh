#!/bin/bash

# Start All Servers Script
# This script starts all required servers on the correct ports

echo "Starting all servers..."

# Change to the correct directory
cd /var/www/html/

# Kill any existing processes on the required ports
echo "Cleaning up existing processes..."
killall -9 node 2>/dev/null || true
killall -9 php 2>/dev/null || true

# Wait a moment for processes to clean up
sleep 2

# Start PHP server on port 8000
echo "Starting PHP server on port 8000..."
nohup php -S 0.0.0.0:8000 > php-server.log 2>&1 &
PHP_PID=$!
echo "PHP server started with PID: $PHP_PID"

# Start main server (server.js) on port 8081
echo "Starting main server on port 8081..."
nohup node server.js > server.log 2>&1 &
SERVER_PID=$!
echo "Main server started with PID: $SERVER_PID"

# Start lobby server on port 8082
echo "Starting lobby server on port 8082..."
nohup node lobbyServer.js > lobby-server.log 2>&1 &
LOBBY_PID=$!
echo "Lobby server started with PID: $LOBBY_PID"

# Start wallet server on port 8083
echo "Starting wallet server on port 8083..."
nohup node lobbyWalletServer.js > lobby-wallet-server.log 2>&1 &
WALLET_PID=$!
echo "Wallet server started with PID: $WALLET_PID"

# Start game manager on port 8084
echo "Starting game manager on port 8084..."
nohup node gameManager.js > game-server.log 2>&1 &
GAME_PID=$!
echo "Game manager started with PID: $GAME_PID"

# Wait a moment for servers to initialize
sleep 3

# Check if all servers are running
echo "\nChecking server status..."
echo "Checking port 8000 (PHP):" && ss -tlnp | grep :8000 || echo "PHP server not responding"
echo "Checking port 8081 (Main):" && ss -tlnp | grep :8081 || echo "Main server not responding"
echo "Checking port 8082 (Lobby):" && ss -tlnp | grep :8082 || echo "Lobby server not responding"
echo "Checking port 8083 (Wallet):" && ss -tlnp | grep :8083 || echo "Wallet server not responding"
echo "Checking port 8084 (Game):" && ss -tlnp | grep :8084 || echo "Game server not responding"

echo "\nAll servers started!"
echo "Process IDs:"
echo "PHP: $PHP_PID"
echo "Main: $SERVER_PID"
echo "Lobby: $LOBBY_PID"
echo "Wallet: $WALLET_PID"
echo "Game: $GAME_PID"

echo "\nTo stop all servers, run: kill $PHP_PID $SERVER_PID $LOBBY_PID $WALLET_PID $GAME_PID"
echo "Or use: pkill -f 'php -S' && pkill -f 'node'"
<?php
// Hostinger Production Configuration
require_once 'database_improved.php';
require_once 'user_management_hybrid.php';
require_once 'email_config.php';

// JSON file fallback configuration
define('USERS_FILE', __DIR__ . '/data/users.json');
define('VERIFICATION_CODES_FILE', __DIR__ . '/data/verification_codes.json');
define('SESSIONS_FILE', __DIR__ . '/data/sessions.json');

// Security settings
define('CODE_EXPIRY_MINUTES', 10);
define('SESSION_EXPIRY_HOURS', 24);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME_MINUTES', 15);

// CORS headers - Restrict to your domain in production
header('Access-Control-Allow-Origin: https://oopsnowh.com'); // Updated for production domain
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// JSON file utility functions for fallback
function initializeDataFiles() {
    $files = [
        USERS_FILE => [],
        VERIFICATION_CODES_FILE => [],
        SESSIONS_FILE => []
    ];
    
    foreach ($files as $file => $defaultContent) {
        if (!file_exists($file)) {
            $dir = dirname($file);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            file_put_contents($file, json_encode($defaultContent, JSON_PRETTY_PRINT));
        }
    }
}

function loadJsonFile($filename) {
    if (!file_exists($filename)) {
        initializeDataFiles();
    }
    $content = file_get_contents($filename);
    return json_decode($content, true) ?: [];
}

function saveJsonFile($filename, $data) {
    $dir = dirname($filename);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT));
}

function generateCode($length = 6) {
    return str_pad(random_int(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

// Initialize data files
initializeDataFiles();

// Note: User management functions (getUser, getUserById, createUser, updateUser) 
// are now handled by user_management_hybrid.php

// Utility functions for auth_handler_hostinger.php
function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function storeVerificationCode($email, $code) {
    $dbInstance = Database::getInstance();
    
    // Force database connection - throw error if not connected
    if (!$dbInstance->isConnected()) {
        throw new Exception('Database connection required for verification codes');
    }
    
    $db = $dbInstance->getConnection();
    
    // Delete any existing codes for this email
    $stmt = $db->prepare('DELETE FROM verification_codes WHERE email = ?');
    $stmt->execute([$email]);
    
    // Store new code
    $expiresAt = date('Y-m-d H:i:s', time() + (CODE_EXPIRY_MINUTES * 60));
    $stmt = $db->prepare('INSERT INTO verification_codes (email, code, expires_at) VALUES (?, ?, ?)');
    return $stmt->execute([$email, $code, $expiresAt]);
}

function verifyCode($email, $code) {
    $dbInstance = Database::getInstance();
    
    // Force database connection - throw error if not connected
    if (!$dbInstance->isConnected()) {
        throw new Exception('Database connection required for verification codes');
    }
    
    $db = $dbInstance->getConnection();
    $currentTime = date('Y-m-d H:i:s');
    $stmt = $db->prepare('SELECT * FROM verification_codes WHERE email = ? AND code = ? AND expires_at > ? AND used = FALSE');
    $stmt->execute([$email, $code, $currentTime]);
    $result = $stmt->fetch();
    
    if ($result) {
        // Mark code as used
        $stmt = $db->prepare('UPDATE verification_codes SET used = TRUE WHERE id = ?');
        $stmt->execute([$result['id']]);
        return true;
    }
    return false;
}

// Rate limiting function removed

function createSession($userId) {
    $dbInstance = Database::getInstance();
    if ($dbInstance->isConnected()) {
        $db = $dbInstance->getConnection();
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', time() + (SESSION_EXPIRY_HOURS * 3600));
        
        $stmt = $db->prepare('INSERT INTO sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)');
        if ($stmt->execute([$userId, $token, $expiresAt])) {
            return $token;
        }
        return false;
    } else {
        // Fallback to JSON files
        $sessions = loadJsonFile(SESSIONS_FILE);
        $token = generateToken();
        $sessions[$token] = [
            'user_id' => $userId,
            'expires_at' => time() + (SESSION_EXPIRY_HOURS * 3600)
        ];
        if (saveJsonFile(SESSIONS_FILE, $sessions)) {
            return $token;
        }
        return false;
    }
}

function validateSession($token) {
    $dbInstance = Database::getInstance();
    if ($dbInstance->isConnected()) {
        $db = $dbInstance->getConnection();
        $currentTime = date('Y-m-d H:i:s');
        $stmt = $db->prepare('SELECT u.* FROM users u JOIN sessions s ON u.id = s.user_id WHERE s.session_token = ? AND s.expires_at > ?');
        $stmt->execute([$token, $currentTime]);
        return $stmt->fetch();
    } else {
        // Fallback to JSON files
        $sessions = loadJsonFile(SESSIONS_FILE);
        
        if (!isset($sessions[$token])) {
            return false;
        }
        
        $session = $sessions[$token];
        
        // Check if session has expired
        if (time() > $session['expires_at']) {
            unset($sessions[$token]);
            saveJsonFile(SESSIONS_FILE, $sessions);
            return false;
        }
        
        // Get user data
        $users = loadJsonFile(USERS_FILE);
        foreach ($users as $user) {
            if (isset($user['id']) && $user['id'] == $session['user_id']) {
                return $user;
            }
        }
        
        return false;
     }
 }

function deleteSession($token) {
    $dbInstance = Database::getInstance();
    if ($dbInstance->isConnected()) {
        $db = $dbInstance->getConnection();
        $stmt = $db->prepare('DELETE FROM sessions WHERE session_token = ?');
        return $stmt->execute([$token]);
    } else {
        // Fallback to JSON files
        $sessions = loadJsonFile(SESSIONS_FILE);
        if (isset($sessions[$token])) {
            unset($sessions[$token]);
            return saveJsonFile(SESSIONS_FILE, $sessions);
        }
        return false;
    }
}

function validateUsername($username) {
    return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
}

// Rate limiting functions removed

// Clean up expired data periodically
if (rand(1, 100) <= 5) { // 5% chance
    cleanupExpiredSessions();
}

// Cleanup function that works with both database and JSON
function cleanupExpiredSessions() {
    $dbInstance = Database::getInstance();
    if ($dbInstance->isConnected()) {
        try {
            $db = $dbInstance->getConnection();
            $db->exec('DELETE FROM sessions WHERE expires_at < NOW()');
            $db->exec('DELETE FROM verification_codes WHERE expires_at < NOW()');
        } catch (PDOException $e) {
            error_log('Session cleanup error: ' . $e->getMessage());
        }
    } else {
        // Cleanup JSON files
        $sessions = loadJsonFile(SESSIONS_FILE);
        $now = time();
        $sessions = array_filter($sessions, function($session) use ($now) {
            return $session['expires_at'] > $now;
        });
        saveJsonFile(SESSIONS_FILE, $sessions);
        
        $codes = loadJsonFile(VERIFICATION_CODES_FILE);
        $codes = array_filter($codes, function($code) use ($now) {
            return ($now - $code['timestamp']) < (CODE_EXPIRY_MINUTES * 60);
        });
        saveJsonFile(VERIFICATION_CODES_FILE, $codes);
    }
}
?>
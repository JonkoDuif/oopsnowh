<?php
require_once 'config.php';

/**
 * Verify user authentication from session token
 * @return array|false User data if authenticated, false otherwise
 */
function verifyAuth() {
    // Check for session token in various places
    $token = null;
    
    // Check Authorization header
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        $authHeader = $headers['Authorization'];
        if (preg_match('/Bearer\s+(\S+)/', $authHeader, $matches)) {
            $token = $matches[1];
        }
    }
    
    // Check POST data
    if (!$token && isset($_POST['session_token'])) {
        $token = $_POST['session_token'];
    }
    
    // Check GET data
    if (!$token && isset($_GET['session_token'])) {
        $token = $_GET['session_token'];
    }
    
    // Check cookies
    if (!$token && isset($_COOKIE['session_token'])) {
        $token = $_COOKIE['session_token'];
    }
    
    // Check session
    if (!$token && isset($_SESSION['session_token'])) {
        $token = $_SESSION['session_token'];
    }
    
    if (!$token) {
        return false;
    }
    
    // Validate the session token
    return validateSession($token);
}

/**
 * Get current authenticated user
 * @return array|null User data if authenticated, null otherwise
 */
function getCurrentUser() {
    return verifyAuth();
}
/**
 * Lobby Wallet Server - Centralized lobby wallet management for production
 * Handles lobby wallets, player connections, and multiplayer synchronization
 */

const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

class LobbyWalletServer {
    constructor() {
        this.port = 8082;
        this.server = null;
        this.wss = null;
        this.clients = new Map(); // Map of client ID to WebSocket connection
        this.lobbyWallets = new Map(); // Centralized lobby wallets
        this.lobbyPlayers = new Map(); // Map of lobby ID to Set of player IDs
        this.playerLobbies = new Map(); // Map of player ID to lobby ID
        this.dataFile = path.join(__dirname, 'lobby_wallets_data.json');
        
        this.initializeLobbyWallets();
        this.loadLobbyWallets();
        this.startServer();
        
        // Auto-save every 30 seconds
        setInterval(() => {
            this.saveLobbyWallets();
        }, 30000);
    }

    // Initialize default lobby wallets
    initializeLobbyWallets() {
        // Create 8 lobbies (1-4: US, 5-8: EU)
        for (let i = 1; i <= 8; i++) {
            if (!this.lobbyWallets.has(i)) {
                const region = i <= 4 ? 'US' : 'EU';
                const lobbyNumber = i <= 4 ? i : i - 4;
                
                this.lobbyWallets.set(i, {
                    lobbyId: i,
                    name: `${region} Lobby ${lobbyNumber}`,
                    region: region,
                    publicKey: this.generateLobbyWalletAddress(i),
                    privateKey: this.generateLobbyPrivateKey(i),
                    balance: 0,
                    gamePool: 0,
                    houseFeeReserve: 0,
                    totalBets: 0,
                    activePlayers: new Set(),
                    pendingBets: new Set(),
                    pendingCashouts: new Set(),
                    createdAt: new Date().toISOString()
                });
            }
            
            if (!this.lobbyPlayers.has(i)) {
                this.lobbyPlayers.set(i, new Set());
            }
        }
        console.log('🏦 Initialized 8 lobby wallets');
    }

    // Generate deterministic wallet address for lobby
    generateLobbyWalletAddress(lobbyId) {
        // In production, this would use proper Solana keypair generation
        // Generate a more realistic looking address that doesn't all start with "LobbyWallet"
        const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz123456789';
        let address = '';
        
        // Use lobby ID as seed for deterministic generation
        let seed = lobbyId * 12345;
        for (let i = 0; i < 44; i++) {
            seed = (seed * 9301 + 49297) % 233280;
            address += chars[seed % chars.length];
        }
        
        return address;
    }

    // Generate deterministic private key for lobby
    generateLobbyPrivateKey(lobbyId) {
        // In production, this would use proper Solana keypair generation
        const key = [];
        for (let i = 0; i < 64; i++) {
            key.push((lobbyId * 7 + i * 3) % 256);
        }
        return key;
    }

    // Load lobby wallets from file
    loadLobbyWallets() {
        try {
            if (fs.existsSync(this.dataFile)) {
                const fileContent = fs.readFileSync(this.dataFile, 'utf8').trim();
                if (fileContent === '') {
                    console.log('[LOBBY] Empty data file, initializing with default data');
                    this.initializeDefaultData();
                    return;
                }
                const data = JSON.parse(fileContent);
                
                Object.entries(data).forEach(([lobbyId, walletData]) => {
                    const id = parseInt(lobbyId);
                    this.lobbyWallets.set(id, {
                        ...walletData,
                        activePlayers: new Set(walletData.activePlayers || []),
                        pendingBets: new Set(walletData.pendingBets || []),
                        pendingCashouts: new Set(walletData.pendingCashouts || [])
                    });
                });
                
                console.log('✅ Loaded lobby wallets from file');
            } else {
                console.log('[LOBBY] Data file does not exist, creating with default data');
                this.initializeDefaultData();
            }
        } catch (error) {
            console.error('❌ Failed to load lobby wallets:', error);
            console.log('[LOBBY] Initializing with default data due to error');
            this.initializeDefaultData();
        }
    }

    // Initialize default data when file is empty or corrupted
    initializeDefaultData() {
        const defaultData = {
            "1": {
                "lobbyId": 1,
                "publicKey": "Sample1PublicKey123...",
                "balance": 0,
                "usdBalance": 0,
                "lastActivity": Date.now(),
                "lastDrained": Date.now()
            },
            "2": {
                "lobbyId": 2,
                "publicKey": "Sample2PublicKey456...",
                "balance": 0,
                "usdBalance": 0,
                "lastActivity": Date.now(),
                "lastDrained": Date.now()
            },
            "3": {
                "lobbyId": 3,
                "publicKey": "Sample3PublicKey789...",
                "balance": 0,
                "usdBalance": 0,
                "lastActivity": Date.now(),
                "lastDrained": Date.now()
            }
        };
        
        // Write default data to file
        fs.writeFileSync(this.dataFile, JSON.stringify(defaultData, null, 4));
        
        // Load the default data into memory
        Object.entries(defaultData).forEach(([lobbyId, walletData]) => {
            const id = parseInt(lobbyId);
            this.lobbyWallets.set(id, {
                ...walletData,
                activePlayers: new Set(),
                pendingBets: new Set(),
                pendingCashouts: new Set()
            });
        });
        
        console.log('✅ Initialized default lobby wallet data');
    }

    // Save lobby wallets to file
    saveLobbyWallets() {
        try {
            const data = {};
            this.lobbyWallets.forEach((wallet, lobbyId) => {
                data[lobbyId] = {
                    ...wallet,
                    activePlayers: Array.from(wallet.activePlayers),
                    pendingBets: Array.from(wallet.pendingBets),
                    pendingCashouts: Array.from(wallet.pendingCashouts)
                };
            });
            
            fs.writeFileSync(this.dataFile, JSON.stringify(data, null, 2));
            console.log('💾 Saved lobby wallets to file');
        } catch (error) {
            console.error('❌ Failed to save lobby wallets:', error);
        }
    }

    // Start WebSocket server
    startServer() {
        this.server = http.createServer((req, res) => {
            // Handle HTTP requests for status checks
            if (req.method === 'GET' && req.url === '/status') {
                res.writeHead(200, {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                });
                res.end(JSON.stringify({
                    status: 'running',
                    port: this.port,
                    lobbies: this.lobbyWallets.size,
                    connectedClients: this.clients.size,
                    uptime: process.uptime(),
                    timestamp: new Date().toISOString()
                }));
                return;
            }
            
            // Default response for other requests
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('Lobby Wallet Server - WebSocket only');
        });
        
        this.wss = new WebSocket.Server({ server: this.server });

        this.wss.on('connection', (ws) => {
            const clientId = this.generateClientId();
            ws.clientId = clientId;
            this.clients.set(clientId, ws);
            
            console.log(`🔌 Client ${clientId} connected`);

            ws.on('message', (message) => {
                try {
                    const data = JSON.parse(message);
                    this.handleMessage(ws, data);
                } catch (error) {
                    console.error('❌ Error parsing message:', error);
                }
            });

            ws.on('close', () => {
                console.log(`🔌 Client ${clientId} disconnected`);
                this.handleClientDisconnect(clientId);
            });

            // Send initial lobby data
            this.sendLobbyData(ws);
        });

        this.server.listen(this.port, () => {
            console.log(`🚀 Lobby Wallet Server running on port ${this.port}`);
        });
    }

    // Generate unique client ID
    generateClientId() {
        return 'client_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Handle client messages
    handleMessage(ws, data) {
        switch (data.type) {
            case 'join_lobby':
                this.handleJoinLobby(ws, data);
                break;
            case 'leave_lobby':
                this.handleLeaveLobby(ws, data);
                break;
            case 'add_player_bet':
                this.handleAddPlayerBet(ws, data);
                break;
            case 'cashout_player':
                this.handleCashoutPlayer(ws, data);
                break;
            case 'get_lobby_stats':
                this.handleGetLobbyStats(ws, data);
                break;
            case 'player_update':
                this.handlePlayerUpdate(ws, data);
                break;
            case 'player_ready':
                this.handlePlayerReady(ws, data);
                break;
            default:
                console.log('❓ Unknown message type:', data.type);
        }
    }

    // Handle client disconnect
    handleClientDisconnect(clientId) {
        // Remove client from all lobbies
        const playerId = clientId; // Using clientId as playerId for simplicity
        const lobbyId = this.playerLobbies.get(playerId);
        
        if (lobbyId) {
            this.lobbyPlayers.get(lobbyId)?.delete(playerId);
            this.playerLobbies.delete(playerId);
            
            // Broadcast player left to other clients in the lobby
            this.broadcastToLobby(lobbyId, {
                type: 'player_left',
                lobbyId: lobbyId,
                playerId: playerId,
                players: Array.from(this.lobbyPlayers.get(lobbyId) || [])
            });
        }
        
        this.clients.delete(clientId);
    }

    // Handle join lobby
    handleJoinLobby(ws, data) {
        const { lobbyId, playerId, playerData } = data;
        
        // Remove player from previous lobby if any
        const previousLobby = this.playerLobbies.get(playerId);
        if (previousLobby) {
            this.lobbyPlayers.get(previousLobby)?.delete(playerId);
        }
        
        // Add player to new lobby
        this.lobbyPlayers.get(lobbyId)?.add(playerId);
        this.playerLobbies.set(playerId, lobbyId);
        ws.currentLobby = lobbyId;
        ws.playerId = playerId;
        
        console.log(`👤 Player ${playerId} joined Lobby ${lobbyId}`);
        
        // Send confirmation to player
        ws.send(JSON.stringify({
            type: 'lobby_joined',
            lobbyId: lobbyId,
            success: true
        }));
        
        // Broadcast to all players in lobby
        this.broadcastToLobby(lobbyId, {
            type: 'player_joined',
            lobbyId: lobbyId,
            playerId: playerId,
            playerData: playerData,
            players: Array.from(this.lobbyPlayers.get(lobbyId) || [])
        });
    }

    // Handle leave lobby
    handleLeaveLobby(ws, data) {
        const { lobbyId, playerId } = data;
        
        this.lobbyPlayers.get(lobbyId)?.delete(playerId);
        this.playerLobbies.delete(playerId);
        ws.currentLobby = null;
        ws.playerId = null;
        
        console.log(`👤 Player ${playerId} left Lobby ${lobbyId}`);
        
        // Broadcast to remaining players
        this.broadcastToLobby(lobbyId, {
            type: 'player_left',
            lobbyId: lobbyId,
            playerId: playerId,
            players: Array.from(this.lobbyPlayers.get(lobbyId) || [])
        });
    }

    // Handle add player bet
    handleAddPlayerBet(ws, data) {
        const { lobbyId, playerId, betAmount } = data;
        const wallet = this.lobbyWallets.get(lobbyId);
        
        if (!wallet) {
            ws.send(JSON.stringify({
                type: 'bet_error',
                error: 'Lobby wallet not found'
            }));
            return;
        }
        
        try {
            // Add bet to lobby wallet
            const feeAmount = 0.10; // €0.10 fee
            const totalAmount = betAmount + feeAmount;
            
            wallet.gamePool += betAmount;
            wallet.houseFeeReserve += feeAmount;
            wallet.totalBets += totalAmount;
            wallet.activePlayers.add(playerId);
            
            console.log(`💰 Added bet: €${betAmount} + €${feeAmount} fee to Lobby ${lobbyId}`);
            
            // Save changes
            this.saveLobbyWallets();
            
            // Send confirmation
            ws.send(JSON.stringify({
                type: 'bet_success',
                lobbyId: lobbyId,
                betAmount: betAmount,
                feeAmount: feeAmount,
                totalAmount: totalAmount,
                newGamePool: wallet.gamePool
            }));
            
            // Broadcast updated lobby stats to all players
            this.broadcastLobbyStats(lobbyId);
            
        } catch (error) {
            console.error('❌ Failed to add player bet:', error);
            ws.send(JSON.stringify({
                type: 'bet_error',
                error: error.message
            }));
        }
    }

    // Handle cashout player
    handleCashoutPlayer(ws, data) {
        const { lobbyId, playerId, cashoutAmount } = data;
        const wallet = this.lobbyWallets.get(lobbyId);
        
        if (!wallet) {
            ws.send(JSON.stringify({
                type: 'cashout_error',
                error: 'Lobby wallet not found'
            }));
            return;
        }
        
        try {
            // Process cashout
            if (wallet.gamePool < cashoutAmount) {
                throw new Error('Insufficient funds in lobby pool');
            }
            
            wallet.gamePool -= cashoutAmount;
            wallet.activePlayers.delete(playerId);
            
            console.log(`💸 Processed cashout: €${cashoutAmount} from Lobby ${lobbyId}`);
            
            // Save changes
            this.saveLobbyWallets();
            
            // Send confirmation
            ws.send(JSON.stringify({
                type: 'cashout_success',
                lobbyId: lobbyId,
                cashoutAmount: cashoutAmount,
                newGamePool: wallet.gamePool
            }));
            
            // Broadcast updated lobby stats
            this.broadcastLobbyStats(lobbyId);
            
        } catch (error) {
            console.error('❌ Failed to process cashout:', error);
            ws.send(JSON.stringify({
                type: 'cashout_error',
                error: error.message
            }));
        }
    }

    // Handle get lobby stats
    handleGetLobbyStats(ws, data) {
        const { lobbyId } = data;
        const wallet = this.lobbyWallets.get(lobbyId);
        
        if (wallet) {
            ws.send(JSON.stringify({
                type: 'lobby_stats',
                lobbyId: lobbyId,
                stats: {
                    lobbyId: lobbyId,
                    name: wallet.name,
                    region: wallet.region,
                    publicKey: wallet.publicKey,
                    gamePool: wallet.gamePool,
                    totalBets: wallet.totalBets,
                    activePlayers: wallet.activePlayers.size,
                    playerCount: this.lobbyPlayers.get(lobbyId)?.size || 0
                }
            }));
        }
    }

    // Handle player update (for multiplayer)
    handlePlayerUpdate(ws, data) {
        const { lobbyId } = data;
        
        // Broadcast player update to all other players in the lobby
        this.broadcastToLobby(lobbyId, {
            type: 'player_update',
            ...data
        }, ws.clientId);
    }

    // Handle player ready
    handlePlayerReady(ws, data) {
        const { lobbyId, playerId } = data;
        
        // Broadcast player ready status to all players in lobby
        this.broadcastToLobby(lobbyId, {
            type: 'player_ready',
            lobbyId: lobbyId,
            playerId: playerId
        });
    }

    // Send initial lobby data to client
    sendLobbyData(ws) {
        const lobbyData = [];
        this.lobbyWallets.forEach((wallet, lobbyId) => {
            lobbyData.push({
                lobbyId: lobbyId,
                name: wallet.name,
                region: wallet.region,
                publicKey: wallet.publicKey,
                privateKey: wallet.privateKey, // Include private key for blockchain transfers
                gamePool: wallet.gamePool,
                totalBets: wallet.totalBets,
                activePlayers: wallet.activePlayers.size,
                playerCount: this.lobbyPlayers.get(lobbyId)?.size || 0
            });
        });
        
        ws.send(JSON.stringify({
            type: 'lobby_data',
            lobbies: lobbyData
        }));
    }

    // Broadcast message to all players in a lobby
    broadcastToLobby(lobbyId, message, excludeClientId = null) {
        const players = this.lobbyPlayers.get(lobbyId);
        if (!players) return;
        
        players.forEach(playerId => {
            // Find client by playerId (assuming playerId === clientId)
            const client = this.clients.get(playerId);
            if (client && client.readyState === WebSocket.OPEN && playerId !== excludeClientId) {
                client.send(JSON.stringify(message));
            }
        });
    }

    // Broadcast lobby stats to all players in lobby
    broadcastLobbyStats(lobbyId) {
        const wallet = this.lobbyWallets.get(lobbyId);
        if (!wallet) return;
        
        const stats = {
            type: 'lobby_stats_update',
            lobbyId: lobbyId,
            stats: {
                lobbyId: lobbyId,
                name: wallet.name,
                region: wallet.region,
                publicKey: wallet.publicKey,
                privateKey: wallet.privateKey, // Include private key for blockchain transfers
                gamePool: wallet.gamePool,
                totalBets: wallet.totalBets,
                activePlayers: wallet.activePlayers.size,
                playerCount: this.lobbyPlayers.get(lobbyId)?.size || 0
            }
        };
        
        this.broadcastToLobby(lobbyId, stats);
    }
}

// Start the server
const server = new LobbyWalletServer();

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down Lobby Wallet Server...');
    server.saveLobbyWallets();
    process.exit(0);
});

module.exports = LobbyWalletServer;
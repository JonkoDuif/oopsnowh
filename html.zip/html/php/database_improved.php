<?php
// Improved Database Class with Better Fallback Handling

class Database {
    private static $instance = null;
    private $connection;
    private $useDatabase = false;
    
    // Local MySQL Configuration
    private $host = 'localhost';  // Usually 'localhost' on Hostinger
    private $dbname = 'u396683430_onowhdata';  // Replace with your database name
    private $username = 'u396683430_onowhdata_lars';  // Replace with your database username
    private $password = 'KJ2N10!_91n2kX';  // Replace with your database password
    
    
    private function __construct() {
        $this->initializeConnection();
    }
    
    private function initializeConnection() {
        // Force database usage - no JSON fallback
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8mb4";
            $this->connection = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            
            $this->useDatabase = true;
            error_log("Database connection successful - using MySQL");
            
            // Initialize tables on successful connection
            $this->initializeTables();
            
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            error_log("Falling back to JSON file storage");
            $this->useDatabase = false;
            $this->connection = null;
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function isConnected() {
        return $this->connection !== null;
    }
    
    public function useDatabase() {
        return $this->useDatabase;
    }
    
    // Initialize database tables when connection is available
    public function initializeTables() {
        if (!$this->isConnected()) {
            return false;
        }
        
        try {
            // Create users table
            $createUsersTable = "
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255),
                wallet_address VARCHAR(255),
                balance DECIMAL(10,2) DEFAULT 0.00,
                total_winnings DECIMAL(10,2) DEFAULT 0.00,
                games_played INT DEFAULT 0,
                is_verified BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                last_login TIMESTAMP NULL
            )";
            
            $this->connection->exec($createUsersTable);
            
            // Create verification_codes table
            $createCodesTable = "
            CREATE TABLE IF NOT EXISTS verification_codes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(100) NOT NULL,
                code VARCHAR(10) NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            $this->connection->exec($createCodesTable);
            
            // Create sessions table
            $createSessionsTable = "
            CREATE TABLE IF NOT EXISTS sessions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                session_token VARCHAR(255) UNIQUE NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $this->connection->exec($createSessionsTable);
            
            // Create user_stats table
            $createUserStatsTable = "
            CREATE TABLE IF NOT EXISTS user_stats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                total_earnings DECIMAL(15,2) DEFAULT 0.00,
                total_kills INT DEFAULT 0,
                total_wins INT DEFAULT 0,
                total_losses INT DEFAULT 0,
                total_games INT DEFAULT 0,
                avg_game_time DECIMAL(8,2) DEFAULT 0.00,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_user_stats (user_id)
            )";
            
            $this->connection->exec($createUserStatsTable);
            
            // Create friendships table
            $createFriendshipsTable = "
            CREATE TABLE IF NOT EXISTS friendships (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                friend_id INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_friendship (user_id, friend_id)
            )";
            
            $this->connection->exec($createFriendshipsTable);
            
            // Create friend_requests table
            $createFriendRequestsTable = "
            CREATE TABLE IF NOT EXISTS friend_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sender_id INT NOT NULL,
                receiver_id INT NOT NULL,
                status ENUM('pending', 'accepted', 'declined') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_request (sender_id, receiver_id)
            )";
            
            $this->connection->exec($createFriendRequestsTable);
            
            // Create wallet_transactions table
            $createTransactionsTable = "
            CREATE TABLE IF NOT EXISTS wallet_transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sender_id INT NOT NULL,
                receiver_id INT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                fee DECIMAL(10,2) NOT NULL,
                transaction_type ENUM('transfer', 'fee') DEFAULT 'transfer',
                status ENUM('pending', 'completed', 'failed') DEFAULT 'completed',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $this->connection->exec($createTransactionsTable);
            
            // Create game_stats table if it doesn't exist
            $createGameStatsTable = "
            CREATE TABLE IF NOT EXISTS game_stats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                game_id VARCHAR(100) NOT NULL,
                kills INT DEFAULT 0,
                deaths INT DEFAULT 0,
                score INT DEFAULT 0,
                game_duration INT DEFAULT 0,
                bet_amount DECIMAL(10,2) DEFAULT 0.00,
                winnings DECIMAL(10,2) DEFAULT 0.00,
                position INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $this->connection->exec($createGameStatsTable);
            
            return true;
            
        } catch (PDOException $e) {
            error_log("Error creating tables: " . $e->getMessage());
            return false;
        }
    }
}
?>
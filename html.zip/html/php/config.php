<?php
// Include email configuration
require_once 'email_config.php';
require_once 'database_improved.php';

// Database-only configuration - JSON files removed

// Security settings
define('CODE_EXPIRY_MINUTES', 10);
define('SESSION_EXPIRY_HOURS', 24);

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight requests
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Utility functions - Database only
function generateCode($length = 6) {
    return str_pad(random_int(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}
?>
<?php
require_once 'config_hostinger.php';
require_once 'auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Get the action from the request
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Verify user authentication
$user = verifyAuth();
if (!$user) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

$user_id = $user['id'];

try {
    switch ($action) {
        case 'search_users':
            searchUsers();
            break;
        case 'send_friend_request':
            sendFriendRequest();
            break;
        case 'get_friend_requests':
            getFriendRequests();
            break;
        case 'respond_friend_request':
            respondFriendRequest();
            break;
        case 'get_friends':
            getFriends();
            break;
        case 'remove_friend':
            removeFriend();
            break;
        case 'get_user_stats':
            getUserStats();
            break;
        case 'get_friend_stats':
            getFriendStats();
            break;
        case 'send_money':
            sendMoney();
            break;
        case 'get_leaderboard':
            getLeaderboard();
            break;
        case 'get_transactions':
            getTransactions();
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}

function searchUsers() {
    global $pdo, $user_id;
    
    $query = $_GET['query'] ?? '';
    if (strlen($query) < 2) {
        echo json_encode(['success' => false, 'message' => 'Query must be at least 2 characters']);
        return;
    }
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.created_at,
               CASE WHEN f.id IS NOT NULL THEN 'friend'
                    WHEN fr1.id IS NOT NULL THEN 'request_sent'
                    WHEN fr2.id IS NOT NULL THEN 'request_received'
                    ELSE 'none' END as friendship_status
        FROM users u
        LEFT JOIN friendships f ON (f.user_id = ? AND f.friend_id = u.id) OR (f.user_id = u.id AND f.friend_id = ?)
        LEFT JOIN friend_requests fr1 ON fr1.sender_id = ? AND fr1.receiver_id = u.id AND fr1.status = 'pending'
        LEFT JOIN friend_requests fr2 ON fr2.sender_id = u.id AND fr2.receiver_id = ? AND fr2.status = 'pending'
        WHERE u.username LIKE ? AND u.id != ? AND u.status = 'active'
        ORDER BY u.username
        LIMIT 20
    ");
    
    $searchTerm = '%' . $query . '%';
    $stmt->execute([$user_id, $user_id, $user_id, $user_id, $searchTerm, $user_id]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'users' => $users]);
}

function sendFriendRequest() {
    global $pdo, $user_id;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $friend_username = $input['username'] ?? '';
    
    if (empty($friend_username)) {
        echo json_encode(['success' => false, 'message' => 'Username is required']);
        return;
    }
    
    // Get friend's user ID
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND status = 'active'");
    $stmt->execute([$friend_username]);
    $friend = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$friend) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        return;
    }
    
    $friend_id = $friend['id'];
    
    if ($friend_id == $user_id) {
        echo json_encode(['success' => false, 'message' => 'Cannot send friend request to yourself']);
        return;
    }
    
    // Check if already friends
    $stmt = $pdo->prepare("
        SELECT id FROM friendships 
        WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)
    ");
    $stmt->execute([$user_id, $friend_id, $friend_id, $user_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Already friends']);
        return;
    }
    
    // Check if request already exists
    $stmt = $pdo->prepare("
        SELECT id FROM friend_requests 
        WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) 
        AND status = 'pending'
    ");
    $stmt->execute([$user_id, $friend_id, $friend_id, $user_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Friend request already exists']);
        return;
    }
    
    // Send friend request
    $stmt = $pdo->prepare("
        INSERT INTO friend_requests (sender_id, receiver_id, status) 
        VALUES (?, ?, 'pending')
    ");
    $stmt->execute([$user_id, $friend_id]);
    
    echo json_encode(['success' => true, 'message' => 'Friend request sent']);
}

function getFriendRequests() {
    global $pdo, $user_id;
    
    $stmt = $pdo->prepare("
        SELECT fr.id, fr.sender_id, u.username as sender_username, fr.created_at
        FROM friend_requests fr
        JOIN users u ON u.id = fr.sender_id
        WHERE fr.receiver_id = ? AND fr.status = 'pending'
        ORDER BY fr.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'requests' => $requests]);
}

function respondFriendRequest() {
    global $pdo, $user_id;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $request_id = $input['request_id'] ?? 0;
    $response = $input['response'] ?? ''; // 'accept' or 'decline'
    
    if (!in_array($response, ['accept', 'decline'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid response']);
        return;
    }
    
    // Get the friend request
    $stmt = $pdo->prepare("
        SELECT sender_id FROM friend_requests 
        WHERE id = ? AND receiver_id = ? AND status = 'pending'
    ");
    $stmt->execute([$request_id, $user_id]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$request) {
        echo json_encode(['success' => false, 'message' => 'Friend request not found']);
        return;
    }
    
    $pdo->beginTransaction();
    
    try {
        // Update request status
        $status = $response === 'accept' ? 'accepted' : 'declined';
        $stmt = $pdo->prepare("
            UPDATE friend_requests SET status = ? WHERE id = ?
        ");
        $stmt->execute([$status, $request_id]);
        
        // If accepted, create friendship
        if ($response === 'accept') {
            $stmt = $pdo->prepare("
                INSERT INTO friendships (user_id, friend_id) VALUES (?, ?), (?, ?)
            ");
            $stmt->execute([$user_id, $request['sender_id'], $request['sender_id'], $user_id]);
        }
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Friend request ' . $status]);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function getFriends() {
    global $pdo, $user_id;
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.balance, u.created_at, f.created_at as friendship_date,
               COALESCE(us.total_earnings, 0) as total_earnings,
               COALESCE(us.total_kills, 0) as total_kills,
               COALESCE(us.total_wins, 0) as total_wins,
               COALESCE(us.total_losses, 0) as total_losses,
               COALESCE(us.total_games, 0) as total_games,
               COALESCE(us.total_playtime, 0) as total_playtime,
               COALESCE(us.best_score, 0) as best_score,
               CASE WHEN us.total_games > 0 THEN ROUND((us.total_wins / us.total_games) * 100, 2) ELSE 0 END as win_rate,
               CASE WHEN us.total_games > 0 THEN ROUND(us.total_kills / us.total_games, 2) ELSE 0 END as kills_per_game,
               CASE WHEN us.total_games > 0 THEN ROUND(us.total_playtime / us.total_games, 2) ELSE 0 END as avg_game_time
        FROM friendships f
        JOIN users u ON u.id = CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END
        LEFT JOIN user_stats us ON us.user_id = u.id
        WHERE f.user_id = ? OR f.friend_id = ?
        GROUP BY u.id
        ORDER BY u.username
    ");
    $stmt->execute([$user_id, $user_id, $user_id]);
    $friends = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'friends' => $friends]);
}

function removeFriend() {
    global $pdo, $user_id;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $friend_id = $input['friend_id'] ?? 0;
    
    $stmt = $pdo->prepare("
        DELETE FROM friendships 
        WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)
    ");
    $stmt->execute([$user_id, $friend_id, $friend_id, $user_id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Friend removed']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Friendship not found']);
    }
}

function getUserStats() {
    global $pdo, $user_id;
    
    $stmt = $pdo->prepare("
        SELECT u.username, u.balance, u.created_at,
               COALESCE(us.total_earnings, 0) as total_earnings,
               COALESCE(us.total_kills, 0) as total_kills,
               COALESCE(us.total_wins, 0) as total_wins,
               COALESCE(us.total_losses, 0) as total_losses,
               COALESCE(us.total_games, 0) as total_games,
               COALESCE(us.total_playtime, 0) as total_playtime,
               COALESCE(us.best_score, 0) as best_score,
               CASE WHEN us.total_games > 0 THEN ROUND((us.total_wins / us.total_games) * 100, 2) ELSE 0 END as win_rate,
               CASE WHEN us.total_games > 0 THEN ROUND(us.total_kills / us.total_games, 2) ELSE 0 END as kills_per_game,
               CASE WHEN us.total_games > 0 THEN ROUND(us.total_playtime / us.total_games, 2) ELSE 0 END as avg_game_time
        FROM users u
        LEFT JOIN user_stats us ON us.user_id = u.id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'stats' => $stats]);
}

function getFriendStats() {
    global $pdo, $user_id;
    
    $friend_id = $_GET['friend_id'] ?? 0;
    
    // Verify friendship
    $stmt = $pdo->prepare("
        SELECT id FROM friendships 
        WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)
    ");
    $stmt->execute([$user_id, $friend_id, $friend_id, $user_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Not friends with this user']);
        return;
    }
    
    $stmt = $pdo->prepare("
        SELECT u.username, u.balance, u.created_at,
               COALESCE(us.total_earnings, 0) as total_earnings,
               COALESCE(us.total_kills, 0) as total_kills,
               COALESCE(us.total_wins, 0) as total_wins,
               COALESCE(us.total_losses, 0) as total_losses,
               COALESCE(us.total_games, 0) as total_games,
               COALESCE(us.total_playtime, 0) as total_playtime,
               COALESCE(us.best_score, 0) as best_score,
               CASE WHEN us.total_games > 0 THEN ROUND((us.total_wins / us.total_games) * 100, 2) ELSE 0 END as win_rate,
               CASE WHEN us.total_games > 0 THEN ROUND(us.total_kills / us.total_games, 2) ELSE 0 END as kills_per_game,
               CASE WHEN us.total_games > 0 THEN ROUND(us.total_playtime / us.total_games, 2) ELSE 0 END as avg_game_time
        FROM users u
        LEFT JOIN user_stats us ON us.user_id = u.id
        WHERE u.id = ?
    ");
    $stmt->execute([$friend_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'stats' => $stats]);
}

function sendMoney() {
    global $pdo, $user_id;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $friend_id = $input['friend_id'] ?? 0;
    $amount = floatval($input['amount'] ?? 0);
    
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid amount']);
        return;
    }
    
    // Verify friendship
    $stmt = $pdo->prepare("
        SELECT id FROM friendships 
        WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)
    ");
    $stmt->execute([$user_id, $friend_id, $friend_id, $user_id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Can only send money to friends']);
        return;
    }
    
    $fee = $amount * 0.15; // 15% transaction fee
    $total_deduction = $amount + $fee;
    
    // Check sender balance
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $sender = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($sender['balance'] < $total_deduction) {
        echo json_encode(['success' => false, 'message' => 'Insufficient balance']);
        return;
    }
    
    $pdo->beginTransaction();
    
    try {
        // Deduct from sender
        $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$total_deduction, $user_id]);
        
        // Add to receiver
        $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $friend_id]);
        
        // Record transaction
        $stmt = $pdo->prepare("
            INSERT INTO wallet_transactions (sender_id, receiver_id, amount, fee, transaction_type, status, description) 
            VALUES (?, ?, ?, ?, 'transfer', 'completed', 'Friend transfer')
        ");
        $stmt->execute([$user_id, $friend_id, $amount, $fee]);
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Money sent successfully', 'fee' => $fee]);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function getLeaderboard() {
    global $pdo, $user_id;
    
    $filter = $_GET['filter'] ?? 'money'; // money, kills, games
    $scope = $_GET['scope'] ?? 'global'; // global, friends
    
    $orderBy = match($filter) {
        'kills' => 'us.total_kills DESC',
        'games' => 'us.total_games DESC',
        default => 'u.balance DESC'
    };
    
    if ($scope === 'friends') {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.balance, u.created_at,
                   COALESCE(us.total_earnings, 0) as total_earnings,
                   COALESCE(us.total_kills, 0) as total_kills,
                   COALESCE(us.total_wins, 0) as total_wins,
                   COALESCE(us.total_games, 0) as total_games,
                   CASE WHEN us.total_games > 0 THEN ROUND((us.total_wins / us.total_games) * 100, 2) ELSE 0 END as win_rate
            FROM users u
            LEFT JOIN user_stats us ON us.user_id = u.id
            WHERE u.id IN (
                SELECT CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END
                FROM friendships f
                WHERE f.user_id = ? OR f.friend_id = ?
            ) OR u.id = ?
            ORDER BY {$orderBy}
            LIMIT 50
        ");
        $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
    } else {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.balance, u.created_at,
                   COALESCE(us.total_earnings, 0) as total_earnings,
                   COALESCE(us.total_kills, 0) as total_kills,
                   COALESCE(us.total_wins, 0) as total_wins,
                   COALESCE(us.total_games, 0) as total_games,
                   CASE WHEN us.total_games > 0 THEN ROUND((us.total_wins / us.total_games) * 100, 2) ELSE 0 END as win_rate
            FROM users u
            LEFT JOIN user_stats us ON us.user_id = u.id
            WHERE u.status = 'active'
            ORDER BY {$orderBy}
            LIMIT 50
        ");
        $stmt->execute();
    }
    
    $leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'leaderboard' => $leaderboard, 'filter' => $filter, 'scope' => $scope]);
}

function getTransactions() {
    global $pdo, $user_id;
    
    $stmt = $pdo->prepare("
        SELECT wt.id, wt.amount, wt.fee, wt.transaction_type, wt.status, wt.description, wt.created_at,
               sender.username as sender_username,
               receiver.username as receiver_username,
               CASE WHEN wt.sender_id = ? THEN 'sent' ELSE 'received' END as direction
        FROM wallet_transactions wt
        JOIN users sender ON sender.id = wt.sender_id
        JOIN users receiver ON receiver.id = wt.receiver_id
        WHERE wt.sender_id = ? OR wt.receiver_id = ?
        ORDER BY wt.created_at DESC
        LIMIT 50
    ");
    $stmt->execute([$user_id, $user_id, $user_id]);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'transactions' => $transactions]);
}
?>
// WebSocket Server for Agar.io Multiplayer Game
const WebSocket = require('ws');
const http = require('http');

class GameServer {
    constructor(port = 8081) {
        this.port = port;
        this.server = http.createServer();
        this.wss = new WebSocket.Server({ server: this.server });
        
        // Game state
        this.lobbies = {
            US: {
                TRYHARD: { players: new Map(), food: [], maxPlayers: 10 },
                CRAZY: { players: new Map(), food: [], maxPlayers: 20 },
                OPEN: { players: new Map(), food: [], maxPlayers: 50 }
            },
            EU: {
                TRYHARD: { players: new Map(), food: [], maxPlayers: 10 },
                CRAZY: { players: new Map(), food: [], maxPlayers: 20 },
                OPEN: { players: new Map(), food: [], maxPlayers: 50 }
            }
        };
        
        this.setupWebSocketServer();
        this.startGameLoop();
    }

    setupWebSocketServer() {
        this.wss.on('connection', (ws) => {
            console.log('New client connected');
            
            ws.playerId = this.generatePlayerId();
            ws.region = null;
            ws.lobby = null;
            
            ws.on('message', (message) => {
                try {
                    const data = JSON.parse(message);
                    this.handleMessage(ws, data);
                } catch (error) {
                    console.error('Error parsing message:', error);
                }
            });
            
            ws.on('close', () => {
                console.log('Client disconnected');
                this.removePlayerFromLobby(ws);
            });
            
            ws.on('error', (error) => {
                console.error('WebSocket error:', error);
            });
        });
    }

    handleMessage(ws, message) {
        switch (message.type) {
            case 'join_lobby':
                this.handleJoinLobby(ws, message);
                break;
            case 'join_game':
                this.handleJoinGame(ws, message);
                break;
            case 'player_update':
                this.handlePlayerUpdate(ws, message);
                break;
            case 'player_split':
                this.handlePlayerSplit(ws, message);
                break;
            case 'player_eject':
                this.handlePlayerEject(ws, message);
                break;
            case 'player_cashout':
                this.handlePlayerCashout(ws, message);
                break;
            case 'player_kill':
                this.handlePlayerKill(ws, message);
                break;
            default:
                console.log('Unknown message type:', message.type);
        }
    }

    handleJoinLobby(ws, message) {
        const { region, lobby, betAmount, playerName, playerColor } = message;
        
        // Check if lobby exists and has space
        if (!this.lobbies[region] || !this.lobbies[region][lobby]) {
            ws.send(JSON.stringify({ type: 'error', error: 'Invalid lobby' }));
            return;
        }
        
        const lobbyData = this.lobbies[region][lobby];
        if (lobbyData.players.size >= lobbyData.maxPlayers) {
            ws.send(JSON.stringify({ type: 'lobby_full' }));
            return;
        }
        
        // Remove player from previous lobby if any
        this.removePlayerFromLobby(ws);
        
        // Add player to new lobby
        ws.region = region;
        ws.lobby = lobby;
        
        const player = {
            id: ws.playerId,
            name: playerName,
            color: playerColor,
            balls: [{
                id: this.generateBallId(),
                x: Math.random() * 3000 + 500,
                y: Math.random() * 3000 + 500,
                radius: 20,
                money: betAmount
            }],
            totalMoney: betAmount,
            ws: ws
        };
        
        lobbyData.players.set(ws.playerId, player);
        
        // Notify all players in lobby about new player
        this.broadcastToLobby(region, lobby, {
            type: 'player_joined',
            player: this.sanitizePlayer(player)
        }, ws.playerId);
        
        // Send current game state to new player
        ws.send(JSON.stringify({
            type: 'game_state',
            state: {
                players: Array.from(lobbyData.players.values()).map(p => this.sanitizePlayer(p)),
                food: lobbyData.food
            }
        }));
        
        console.log(`Player ${playerName} joined ${region}-${lobby}`);
    }

    handleJoinGame(ws, message) {
        if (!ws.region || !ws.lobby) {
            console.log('❌ Player trying to join game without being in a lobby');
            return;
        }
        
        const lobbyData = this.lobbies[ws.region][ws.lobby];
        const player = lobbyData.players.get(ws.playerId);
        
        if (player) {
            console.log(`🎮 Player ${player.name} confirmed game join in ${ws.region}-${ws.lobby}`);
            
            // Send confirmation back to the player
            ws.send(JSON.stringify({
                type: 'game_join_confirmed',
                success: true,
                playerId: ws.playerId
            }));
        }
    }

    handlePlayerUpdate(ws, message) {
        if (!ws.region || !ws.lobby) return;
        
        const lobbyData = this.lobbies[ws.region][ws.lobby];
        const player = lobbyData.players.get(ws.playerId);
        
        if (player) {
            // Update player data
            player.balls = message.player.balls;
            player.totalMoney = message.player.totalMoney;
            
            // Broadcast update to other players
            this.broadcastToLobby(ws.region, ws.lobby, {
                type: 'player_update',
                player: this.sanitizePlayer(player)
            }, ws.playerId);
        }
    }

    handlePlayerSplit(ws, message) {
        if (!ws.region || !ws.lobby) return;
        
        const lobbyData = this.lobbies[ws.region][ws.lobby];
        const player = lobbyData.players.get(ws.playerId);
        
        if (player) {
            // Broadcast split action to other players
            this.broadcastToLobby(ws.region, ws.lobby, {
                type: 'player_split',
                playerId: ws.playerId
            }, ws.playerId);
        }
    }

    handlePlayerEject(ws, message) {
        if (!ws.region || !ws.lobby) return;
        
        const lobbyData = this.lobbies[ws.region][ws.lobby];
        const player = lobbyData.players.get(ws.playerId);
        
        if (player) {
            // Broadcast eject action to other players
            this.broadcastToLobby(ws.region, ws.lobby, {
                type: 'player_eject',
                playerId: ws.playerId
            }, ws.playerId);
        }
    }

    handlePlayerCashout(ws, message) {
        if (!ws.region || !ws.lobby) return;
        
        const lobbyData = this.lobbies[ws.region][ws.lobby];
        const player = lobbyData.players.get(ws.playerId);
        
        if (player) {
            console.log(`Player ${player.name} cashed out €${player.totalMoney}`);
            
            // Remove player from lobby
            this.removePlayerFromLobby(ws);
        }
    }

    handlePlayerKill(ws, message) {
        if (!ws.region || !ws.lobby) return;
        
        const { victimId, moneyGained } = message;
        
        // Broadcast kill event to all players in lobby
        this.broadcastToLobby(ws.region, ws.lobby, {
            type: 'player_killed',
            killerId: ws.playerId,
            victimId: victimId,
            moneyGained: moneyGained
        });
    }

    removePlayerFromLobby(ws) {
        if (ws.region && ws.lobby && this.lobbies[ws.region] && this.lobbies[ws.region][ws.lobby]) {
            const lobbyData = this.lobbies[ws.region][ws.lobby];
            const player = lobbyData.players.get(ws.playerId);
            
            if (player) {
                lobbyData.players.delete(ws.playerId);
                
                // Notify other players
                this.broadcastToLobby(ws.region, ws.lobby, {
                    type: 'player_left',
                    playerId: ws.playerId
                }, ws.playerId);
                
                console.log(`Player ${player.name} left ${ws.region}-${ws.lobby}`);
            }
        }
        
        ws.region = null;
        ws.lobby = null;
    }

    broadcastToLobby(region, lobby, message, excludePlayerId = null) {
        if (!this.lobbies[region] || !this.lobbies[region][lobby]) return;
        
        const lobbyData = this.lobbies[region][lobby];
        const messageStr = JSON.stringify(message);
        
        lobbyData.players.forEach((player, playerId) => {
            if (playerId !== excludePlayerId && player.ws.readyState === WebSocket.OPEN) {
                player.ws.send(messageStr);
            }
        });
    }

    sanitizePlayer(player) {
        return {
            id: player.id,
            name: player.name,
            color: player.color,
            balls: player.balls,
            totalMoney: player.totalMoney
        };
    }

    generatePlayerId() {
        return 'player_' + Math.random().toString(36).substr(2, 9);
    }

    generateBallId() {
        return 'ball_' + Math.random().toString(36).substr(2, 9);
    }

    startGameLoop() {
        setInterval(() => {
            // Update food in all lobbies
            Object.keys(this.lobbies).forEach(region => {
                Object.keys(this.lobbies[region]).forEach(lobbyType => {
                    const lobby = this.lobbies[region][lobbyType];
                    this.updateLobbyFood(lobby, region, lobbyType);
                });
            });
        }, 1000); // Update every second
    }

    updateLobbyFood(lobby, region, lobbyType) {
        // Spawn food if needed - Agar.io style tiny pellets
        const targetFoodCount = 2000;
        while (lobby.food.length < targetFoodCount) {
            const foodTypeRand = Math.random();
            let radius;
            
            // Create tiny Agar.io style food pellets - NO MONEY, only growth
            if (foodTypeRand < 0.90) {
                // Tiny food pellets (90% of food) - smallest size
                radius = 1.5; // Fixed tiny size
            } else if (foodTypeRand < 0.98) {
                // Small food (8% of food) - 0.10x bigger
                radius = 1.65; // 1.5 * 1.10 = 1.65
            } else {
                // Medium food (2% of food) - 0.05x bigger than small
                radius = 1.73; // 1.65 * 1.05 = 1.73
            }
            
            lobby.food.push({
                id: 'food_' + Math.random().toString(36).substr(2, 9),
                x: Math.random() * 4000,
                y: Math.random() * 4000,
                radius: radius,
                value: 0, // NO MONEY - only growth
                color: this.getRandomFoodColor()
            });
        }
        
        // Broadcast food updates occasionally
        if (Math.random() < 0.1) { // 10% chance each update
            this.broadcastToLobby(region, lobbyType, {
                type: 'food_update',
                food: lobby.food
            });
        }
    }

    getRandomFoodColor() {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    start() {
        this.server.listen(this.port, () => {
            console.log(`Game server running on port ${this.port}`);
            console.log('Lobbies initialized:');
            Object.keys(this.lobbies).forEach(region => {
                Object.keys(this.lobbies[region]).forEach(lobby => {
                    console.log(`  ${region}-${lobby}: 0/${this.lobbies[region][lobby].maxPlayers} players`);
                });
            });
        });
    }
}

// Start the server
const gameServer = new GameServer(8081);
gameServer.start();
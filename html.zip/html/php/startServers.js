/**
 * Server Startup Script
 * Automatically starts both the game server and lobby wallet server
 */

const { spawn } = require('child_process');
const path = require('path');

class ServerManager {
    constructor() {
        this.gameServer = null;
        this.lobbyWalletServer = null;
        this.isShuttingDown = false;
        
        this.startServers();
        this.setupGracefulShutdown();
    }
    
    startServers() {
        console.log('🚀 Starting all servers...');
        
        // Start Game Server (port 8081)
        this.startGameServer();
        
        // Start Lobby Wallet Server (port 8082)
        this.startLobbyWalletServer();
        
        console.log('✅ All servers started successfully!');
        console.log('📊 Game Server: http://localhost:8081');
        console.log('🏦 Lobby Wallet Server: ws://localhost:8082');
    }
    
    startGameServer() {
        console.log('🎮 Starting Game Server...');
        
        this.gameServer = spawn('node', ['server.js'], {
            stdio: 'pipe',
            cwd: __dirname
        });
        
        this.gameServer.stdout.on('data', (data) => {
            console.log(`[GAME] ${data.toString().trim()}`);
        });
        
        this.gameServer.stderr.on('data', (data) => {
            console.error(`[GAME ERROR] ${data.toString().trim()}`);
        });
        
        this.gameServer.on('close', (code) => {
            if (!this.isShuttingDown) {
                console.log(`❌ Game Server exited with code ${code}`);
                console.log('🔄 Restarting Game Server...');
                setTimeout(() => this.startGameServer(), 2000);
            }
        });
    }
    
    startLobbyWalletServer() {
        console.log('🏦 Starting Lobby Wallet Server...');
        
        this.lobbyWalletServer = spawn('node', ['lobbyWalletServer.js'], {
            stdio: 'pipe',
            cwd: __dirname
        });
        
        this.lobbyWalletServer.stdout.on('data', (data) => {
            console.log(`[LOBBY] ${data.toString().trim()}`);
        });
        
        this.lobbyWalletServer.stderr.on('data', (data) => {
            console.error(`[LOBBY ERROR] ${data.toString().trim()}`);
        });
        
        this.lobbyWalletServer.on('close', (code) => {
            if (!this.isShuttingDown) {
                console.log(`❌ Lobby Wallet Server exited with code ${code}`);
                console.log('🔄 Restarting Lobby Wallet Server...');
                setTimeout(() => this.startLobbyWalletServer(), 2000);
            }
        });
    }
    
    setupGracefulShutdown() {
        const shutdown = () => {
            if (this.isShuttingDown) return;
            this.isShuttingDown = true;
            
            console.log('\n🛑 Shutting down all servers...');
            
            if (this.gameServer) {
                this.gameServer.kill('SIGTERM');
            }
            
            if (this.lobbyWalletServer) {
                this.lobbyWalletServer.kill('SIGTERM');
            }
            
            setTimeout(() => {
                console.log('✅ All servers shut down');
                process.exit(0);
            }, 2000);
        };
        
        process.on('SIGINT', shutdown);
        process.on('SIGTERM', shutdown);
        process.on('SIGQUIT', shutdown);
    }
}

// Start the server manager
new ServerManager();

console.log('🎯 Server Manager initialized');
console.log('💡 Press Ctrl+C to stop all servers');
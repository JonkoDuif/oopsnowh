// Direct access prevention
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
    throw new Error('Direct file access denied');
}

// UI Helper Module - Handles modal interactions and dynamic UI updates
class UIManager {
    constructor() {
        this.activeModals = new Set();
        this.notifications = [];
        this.init();
    }

    init() {
        console.log('🎮 UIManager init called');
        this.setupModalHandlers();
        this.setupNotificationSystem();
        this.setupKeyboardShortcuts();
        this.setupSocialMiniPanel();
        this.initializeUI();
        console.log('🎮 UIManager init completed');
    }

    // Setup modal event handlers
    setupModalHandlers() {
        // Close modal when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target);
            }
        });

        // Close modal with escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });

        // Setup all modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                if (modal) {
                    this.closeModal(modal);
                }
            });
        });
    }

    // Setup notification system
    setupNotificationSystem() {
        // Create notification container if it doesn't exist
        if (!document.querySelector('.notification-container')) {
            const container = document.createElement('div');
            container.className = 'notification-container';
            container.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10000;
                pointer-events: none;
            `;
            document.body.appendChild(container);
        }
    }

    // Setup keyboard shortcuts
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Don't trigger shortcuts if typing in input fields
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                return;
            }

            if (!e.key) return; // Guard against undefined key
            switch (e.key.toLowerCase()) {
                case 'l':
                    if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        this.showLoginModal();
                    }
                    break;
                case 'w':
                    if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        this.showWalletModal();
                    }
                    break;
            }
        });
    }

    // Show modal
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'flex';
            this.activeModals.add(modal);
            
            // Focus first input if available
            const firstInput = modal.querySelector('input');
            if (firstInput) {
                setTimeout(() => firstInput.focus(), 100);
            }
            
            return modal;
        }
        return null;
    }

    // Close modal
    closeModal(modal) {
        if (modal) {
            modal.style.display = 'none';
            this.activeModals.delete(modal);
            
            // Clear form data
            const form = modal.querySelector('form');
            if (form) {
                form.reset();
            }
        }
    }

    // Close all modals
    closeAllModals() {
        this.activeModals.forEach(modal => {
            this.closeModal(modal);
        });
    }

    // Show login modal
    showLoginModal() {
        return this.showModal('auth-modal');
    }

    // Show register modal
    showRegisterModal() {
        return this.showModal('auth-modal');
    }

    // Helper function to format SOL amount with EUR conversion
    async formatSolWithEur(solAmount) {
        if (!window.walletSystem) {
            return `${solAmount.toFixed(6)} <span class="sol-text">SOL</span>`;
        }
        
        try {
            const eurRate = await window.walletSystem.getRealSolPrice();
            const eurValue = solAmount * eurRate;
            return `${solAmount.toFixed(6)} <span class="sol-text">SOL</span> <span class="eur-text">(€${eurValue.toFixed(2)})</span>`;
        } catch (error) {
            console.error('Error getting EUR conversion:', error);
            return `${solAmount.toFixed(6)} <span class="sol-text">SOL</span> <span class="eur-text">(€0.00)</span>`;
        }
    }

    // Show cashout modal
    showCashoutModal() {
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            this.showNotification('Please login first', 'warning');
            this.showLoginModal();
            return null;
        }
        
        const modal = this.showModal('cashout-modal');
        
        // Update available SOL balance
        const updateBalance = async () => {
            const user = window.authSystem.getCurrentUser();
            const solBalance = await window.walletSystem.getUserSolBalance(user.username);
            const balanceSpan = document.getElementById('available-sol-balance');
            if (balanceSpan) {
                const formattedBalance = await this.formatSolWithEur(solBalance);
                balanceSpan.innerHTML = formattedBalance;
            }
        };
        
        updateBalance();
        
        // Reset form
        const solAmountInput = document.getElementById('cashout-sol-amount');
        const externalAddressInput = document.getElementById('external-wallet-address');
        if (solAmountInput) solAmountInput.value = '';
        if (externalAddressInput) externalAddressInput.value = '';
        
        // Hide warning
        const warningDiv = document.getElementById('cashout-warning');
        if (warningDiv) warningDiv.style.display = 'none';
        
        return modal;
    }

    // Show wallet modal
    showWalletModal() {
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            this.showNotification('Please login first', 'warning');
            this.showLoginModal();
            return null;
        }
        
        const modal = this.showModal('wallet-modal');
        
        // Update wallet UI when modal is shown
        setTimeout(async () => {
            if (window.walletSystem) {
                console.log('🔄 Updating wallet UI...');
                await window.walletSystem.updateWalletUI();
            }
        }, 100);
        
        return modal;
    }

    // Show notification
    showNotification(message, type = 'info', duration = 3000) {
        const container = document.querySelector('.notification-container');
        if (!container) return;

        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        // Set styles based on type
        const styles = {
            info: { bg: '#2196F3', icon: 'ℹ️' },
            success: { bg: '#4CAF50', icon: '✅' },
            warning: { bg: '#FF9800', icon: '⚠️' },
            error: { bg: '#f44336', icon: '❌' }
        };
        
        const style = styles[type] || styles.info;
        
        notification.style.cssText = `
            background: ${style.bg};
            color: white;
            padding: 12px 20px;
            margin-bottom: 10px;
            border-radius: 4px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            font-family: Arial, sans-serif;
            font-size: 14px;
            pointer-events: auto;
            cursor: pointer;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            max-width: 300px;
            word-wrap: break-word;
        `;
        
        notification.innerHTML = `
            <span class="notification-icon">${style.icon}</span>
            <span class="notification-message">${message}</span>
        `;
        
        // Add click to close
        notification.addEventListener('click', () => {
            this.removeNotification(notification);
        });
        
        container.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 10);
        
        // Auto remove
        setTimeout(() => {
            this.removeNotification(notification);
        }, duration);
        
        this.notifications.push(notification);
        
        // Limit number of notifications
        if (this.notifications.length > 5) {
            this.removeNotification(this.notifications[0]);
        }
    }

    // Update UI elements based on authentication state
    updateAuthUI() {
        const loggedOutInfo = document.getElementById('logged-out-info');
        const loggedInInfo = document.getElementById('logged-in-info');
        const welcomeText = document.getElementById('welcome-text');
        const nameInput = document.getElementById('name-input');
        const balanceAmount = document.getElementById('balance-amount');

        if (window.authSystem && window.authSystem.isLoggedIn) {
            const user = window.authSystem.getCurrentUser();
            
            // Show logged in state
            if (loggedOutInfo) loggedOutInfo.style.display = 'none';
            if (loggedInInfo) loggedInInfo.style.display = 'flex';
            
            // Update welcome text
            if (welcomeText) {
                welcomeText.textContent = `Welcome, ${user.username}!`;
            }
            
            // Update name input
            if (nameInput) {
                nameInput.value = user.username;
                nameInput.placeholder = user.username;
                nameInput.readOnly = false;
            }
            
            // Update balance - show Solana wallet balance
            if (balanceAmount) {
                // Get real SOL balance from blockchain via wallet system
                if (window.walletSystem) {
                    window.walletSystem.getUserSolBalance(user.username).then(async (solBalance) => {
                        const formattedBalance = await this.formatSolWithEur(solBalance);
                        balanceAmount.innerHTML = formattedBalance;
                        balanceAmount.style.color = '#8b5cf6'; // Purple color for real balance
                    }).catch(error => {
                        console.error('Error getting SOL balance:', error);
                        balanceAmount.innerHTML = '0.000000 <span class="sol-text">SOL</span> <span class="eur-text">(€0.00)</span>';
                        balanceAmount.style.color = '#8b5cf6'; // Keep purple even on error
                    });
                } else {
                    balanceAmount.innerHTML = '0.000000 <span class="sol-text">SOL</span> <span class="eur-text">(€0.00)</span>';
                    balanceAmount.style.color = '#8b5cf6'; // Purple color
                }
            }
        } else {
            // Show logged out state
            if (loggedOutInfo) loggedOutInfo.style.display = 'flex';
            if (loggedInInfo) loggedInInfo.style.display = 'none';
            
            // Reset welcome text
            if (welcomeText) {
                welcomeText.textContent = 'Welcome, bruh!';
            }
            
            // Reset name input
            if (nameInput) {
                nameInput.value = '';
                nameInput.placeholder = 'Login to set your name';
                nameInput.readOnly = true;
            }
            
            // Reset balance
            if (balanceAmount) {
                balanceAmount.innerHTML = '0.000000 <span class="sol-text">SOL</span> <span class="eur-text">(€0.00)</span>';
                balanceAmount.style.color = '#4CAF50'; // Green color
            }
        }
    }

    // Update wallet UI
    async updateWalletUI() {
        if (!window.authSystem || !window.authSystem.isLoggedIn) return;
        
        const user = window.authSystem.getCurrentUser();
        
        // Update main balance display
        const balanceAmount = document.getElementById('balance-amount');
        if (balanceAmount && window.walletSystem) {
            try {
                const solBalance = await window.walletSystem.getUserSolBalance(user.username);
                const formattedBalance = await this.formatSolWithEur(solBalance);
                balanceAmount.innerHTML = formattedBalance;
                balanceAmount.style.color = '#4CAF50'; // Green color for real balance
            } catch (error) {
                console.error('Error getting SOL balance:', error);
                balanceAmount.innerHTML = '0.000000 <span class="sol-text">SOL</span> <span class="eur-text">(€0.00)</span>';
                balanceAmount.style.color = '#4CAF50'; // Keep green even on error
            }
        }
        
        // Update wallet modal if open
        const walletModal = document.getElementById('wallet-modal');
        if (walletModal && walletModal.style.display === 'flex') {
            await this.refreshWalletModal();
        }

        // Update wallet system UI if available
        if (window.walletSystem) {
            await window.walletSystem.updateWalletUI();
        }
    }

    // Refresh wallet modal content
    async refreshWalletModal() {
        if (!window.authSystem || !window.authSystem.isLoggedIn) return;

        const user = window.authSystem.getCurrentUser();
        
        // Update balance in modal
        const modalBalance = document.querySelector('#modal-balance');
        if (modalBalance) {
            modalBalance.textContent = user.balance.toFixed(2);
        }

        // Update wallet system UI if available
        if (window.walletSystem) {
            await window.walletSystem.updateWalletUI();
        }
    }

    // Update balance display
    async updateBalanceDisplay() {
        const balanceAmount = document.getElementById('balance-amount');
        if (balanceAmount && window.authSystem && window.authSystem.isLoggedIn && window.walletSystem) {
            const user = window.authSystem.getCurrentUser();
            try {
                const solBalance = await window.walletSystem.getUserSolBalance(user.username);
                const formattedBalance = await this.formatSolWithEur(solBalance);
                balanceAmount.innerHTML = formattedBalance;
            } catch (error) {
                console.error('Error updating balance display:', error);
                balanceAmount.innerHTML = '0.000000 <span class="sol-text">SOL</span> <span class="eur-text">(€0.00)</span>';
            }
        }
    }

    // Setup custom bet input interactions
    setupCustomBetInput() {
        const customBetInput = document.getElementById('custom-bet-input');
        
        if (customBetInput) {
            // Handle input changes - allow free editing
            customBetInput.addEventListener('input', (e) => {
                let amount = parseFloat(e.target.value);
                
                // Only store and update if it's a valid number
                if (!isNaN(amount) && amount > 0) {
                    // Store selected bet amount
                    if (window.gameManager) {
                        window.gameManager.selectedBetAmount = amount;
                    }
                    
                    // Update lobby bet display
                    this.updateLobbyBetDisplay(amount);
                }
            });
            
            // Handle blur event to ensure minimum value
            customBetInput.addEventListener('blur', (e) => {
                let amount = parseFloat(e.target.value);
                if (isNaN(amount) || amount < 0.25) {
                    amount = 0.25;
                    e.target.value = amount;
                    if (window.gameManager) {
                        window.gameManager.selectedBetAmount = amount;
                    }
                    this.updateLobbyBetDisplay(amount);
                }
            });
            
            // Set initial value
            if (window.gameManager) {
                customBetInput.value = window.gameManager.selectedBetAmount || 0.25;
            }
        }
    }

    // Region buttons are handled by GameManager

    // Setup join game button
    setupJoinGameButton() {
        const joinGameBtn = document.getElementById('join-game-btn');
        
        if (joinGameBtn) {
            // Initially disable the button
            this.updateJoinGameButtonState();
            // Initialize transaction state tracking
            this.isJoinGameTransactionInProgress = false;
            
            joinGameBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                
                // Prevent multiple clicks during transaction
                if (joinGameBtn.disabled || joinGameBtn.classList.contains('loading') || this.isJoinGameTransactionInProgress) {
                    console.log('🚫 Join game click blocked - transaction in progress');
                    return;
                }
                
                if (!window.authSystem || !window.authSystem.isLoggedIn) {
                    this.showNotification('Please login first to play', 'warning');
                    this.showLoginModal();
                    return;
                }
                
                // Check server status first
                if (!window.lobbySystem || !window.lobbySystem.serverOnline) {
                    this.showNotification('Servers are offline. Please wait for servers to come back online.', 'error');
                    return;
                }
                
                // Check if user is in a lobby
                if (!window.lobbySystem) {
                    this.showNotification('Lobby system not ready. Please refresh the page.', 'error');
                    return;
                }
                
                const currentLobby = window.lobbySystem.getCurrentLobby();
                if (!currentLobby) {
                    this.showNotification('Please join a lobby first', 'warning');
                    return;
                }
                
                // Check balance and network fees
                const canJoin = await this.checkBalanceAndFees();
                if (!canJoin) {
                    return; // Error message already shown in checkBalanceAndFees
                }
                
                if (window.gameManager) {
                    // Set transaction in progress flag
                    this.isJoinGameTransactionInProgress = true;
                    
                    // Set button to loading state
                    this.setJoinGameButtonLoading(true);
                    
                    try {
                        // Direct game join with payment and immediate transition
                        await window.gameManager.joinGameDirectly();
                        // Transaction completed successfully - the game should start
                        console.log('✅ Join game transaction completed successfully');
                    } catch (error) {
                        console.error('❌ Error joining game:', error);
                        this.showNotification('Failed to join game. Please try again.', 'error');
                        // Reset button state only on error
                        this.setJoinGameButtonLoading(false);
                        this.isJoinGameTransactionInProgress = false;
                    }
                    // Note: We don't reset the loading state on success because the user should be redirected to the game
                } else {
                    this.showNotification('Game system not ready. Please refresh the page.', 'error');
                }
            });
        } else {
            console.error('❌ Join game button not found!');
        }
    }
    
    // Update JOIN GAME button state based on lobby connection
    updateJoinGameButtonState() {
        const joinGameBtn = document.getElementById('join-game-btn');
        if (!joinGameBtn) return;
        
        const isInLobby = window.lobbySystem && window.lobbySystem.getCurrentLobby();
        const isLoggedIn = window.authSystem && window.authSystem.isLoggedIn;
        const isLobbyServerOnline = window.lobbySystem && window.lobbySystem.serverOnline;
        const isGameServerOnline = window.lobbySystem && window.lobbySystem.gameServerOnline;
        const areServersOnline = isLobbyServerOnline && isGameServerOnline;
        
        if (!areServersOnline) {
            joinGameBtn.disabled = true;
            joinGameBtn.classList.add('disabled');
            joinGameBtn.innerHTML = `<span class="play-icon">▶</span> SERVERS OFFLINE`;
        } else if (isInLobby && isLoggedIn) {
            joinGameBtn.disabled = false;
            joinGameBtn.classList.remove('disabled');
            joinGameBtn.innerHTML = `<span class="play-icon">▶</span> JOIN GAME`;
        } else if (!isLoggedIn) {
            joinGameBtn.disabled = true;
            joinGameBtn.classList.add('disabled');
            joinGameBtn.innerHTML = `<span class="play-icon">▶</span> LOGIN TO PLAY`;
        } else {
            joinGameBtn.disabled = true;
            joinGameBtn.classList.add('disabled');
            joinGameBtn.innerHTML = `<span class="play-icon">▶</span> JOIN A LOBBY FIRST`;
        }
    }

    // Set JOIN GAME button to loading state during transaction
    setJoinGameButtonLoading(isLoading = true) {
        const joinGameBtn = document.getElementById('join-game-btn');
        if (!joinGameBtn) return;
        
        if (isLoading) {
            joinGameBtn.disabled = true;
            joinGameBtn.classList.add('disabled', 'loading');
            joinGameBtn.innerHTML = `<span class="loading-spinner">⏳</span> CREATING TRANSACTION, PLEASE WAIT...`;
            // Store original onclick to prevent multiple event listeners
            joinGameBtn.style.pointerEvents = 'none';
        } else {
            joinGameBtn.classList.remove('loading');
            joinGameBtn.style.pointerEvents = 'auto';
            this.updateJoinGameButtonState(); // Reset to normal state
        }
    }
    
    // Check if user has sufficient balance including network fees
    async checkBalanceAndFees() {
        try {
            const user = window.authSystem.getCurrentUser();
            const betAmountEUR = window.gameManager.selectedBetAmount;
            
            // Check Solana wallet balance (primary balance for games)
            if (!window.walletSystem || !window.walletSystem.isInitialized) {
                this.showNotification('Wallet system not available. Please refresh the page.', 'error');
                return false;
            }
            
            const userSOLBalance = await window.walletSystem.getUserSolBalance(user.username);
            const solPrice = await window.walletSystem.getRealSolPrice();
            const balanceInEur = userSOLBalance * solPrice;
            
            console.log('💰 Solana wallet balance for balance check:', userSOLBalance.toFixed(6), 'SOL', '=', balanceInEur.toFixed(2), 'EUR');
            
            if (balanceInEur < betAmountEUR) {
                console.log('❌ Insufficient SOL balance for balance check');
                this.showNotification(`Insufficient SOL balance. You need €${betAmountEUR.toFixed(2)} but have €${balanceInEur.toFixed(2)}`, 'error');
                this.showWalletModal();
                return false;
            }
            
            console.log('✅ SOL balance check passed');
            
            return true;
            
        } catch (error) {
            console.error('Error checking balance and fees:', error);
            this.showNotification('Error checking balance. Please try again.', 'error');
            return false;
        }
    }

    // Setup cashout button and modal interactions
    setupCashoutButton() {
        // Setup cash out button in wallet panel
        const cashOutBtn = document.querySelector('.wallet-panel .cash-out-btn');
        if (cashOutBtn) {
            cashOutBtn.addEventListener('click', () => {
                this.showCashoutModal();
            });
        }
        
        // Setup cashout modal interactions
        const solAmountInput = document.getElementById('cashout-sol-amount');
        const externalAddressInput = document.getElementById('external-wallet-address');
        const availableBalanceSpan = document.getElementById('available-sol-balance');
        const confirmBtn = document.getElementById('confirm-cashout-btn');
        const cancelBtn = document.getElementById('cancel-cashout-btn');
        
        // Update available balance display when modal opens
        const updateAvailableBalance = async () => {
            if (window.authSystem && window.authSystem.isLoggedIn) {
                const user = window.authSystem.getCurrentUser();
                const solBalance = await window.walletSystem.getUserSolBalance(user.username);
                const formattedBalance = await this.formatSolWithEur(solBalance);
                availableBalanceSpan.innerHTML = formattedBalance;
            }
        };
        
        // Real-time validation and fee calculation
        if (solAmountInput) {
            const eurPopup = document.getElementById('eur-conversion-popup');
            const eurAmountElement = eurPopup?.querySelector('.eur-amount');
            
            solAmountInput.addEventListener('input', async () => {
                const solAmount = parseFloat(solAmountInput.value) || 0;
                const transactionFee = 0.000005; // 5000 lamports
                
                // Show/hide EUR conversion popup
                if (solAmount > 0 && eurPopup && eurAmountElement) {
                    try {
                        // Get real-time SOL price
                        const solPrice = await window.walletSystem.getRealSolPrice();
                        const eurValue = solAmount * solPrice;
                        
                        // Update popup content
                        eurAmountElement.textContent = `€${eurValue.toFixed(2)}`;
                        
                        // Show popup with animation
                        eurPopup.style.display = 'block';
                        setTimeout(() => eurPopup.classList.add('show'), 10);
                    } catch (error) {
                        console.warn('Could not fetch SOL price for popup:', error);
                        eurPopup.style.display = 'none';
                        eurPopup.classList.remove('show');
                    }
                } else if (eurPopup) {
                    // Hide popup
                    eurPopup.classList.remove('show');
                    setTimeout(() => eurPopup.style.display = 'none', 300);
                }
                
                // Update fee display
                const feeDisplay = document.getElementById('transaction-fee');
                if (feeDisplay) {
                    const formattedFee = await this.formatSolWithEur(transactionFee);
                    feeDisplay.textContent = formattedFee;
                }
                
                // Update total needed
                const totalNeeded = solAmount + transactionFee;
                const totalDisplay = document.getElementById('total-needed');
                if (totalDisplay) {
                    const formattedTotal = await this.formatSolWithEur(totalNeeded);
                    totalDisplay.textContent = formattedTotal;
                }
                
                // Validate against available balance
                if (window.authSystem && window.authSystem.isLoggedIn) {
                    const user = window.authSystem.getCurrentUser();
                    const availableBalance = await window.walletSystem.getUserSolBalance(user.username);
                    
                    const warningDiv = document.getElementById('cashout-warning');
                    if (totalNeeded > availableBalance) {
                        const formattedNeeded = await this.formatSolWithEur(totalNeeded);
                        const formattedAvailable = await this.formatSolWithEur(availableBalance);
                        warningDiv.innerHTML = `⚠️ Insufficient balance. You need ${formattedNeeded} but only have ${formattedAvailable}`;
                        warningDiv.style.display = 'block';
                        confirmBtn.disabled = true;
                    } else if (solAmount <= 0) {
                        warningDiv.textContent = '⚠️ Please enter a valid amount greater than 0';
                        warningDiv.style.display = 'block';
                        confirmBtn.disabled = true;
                    } else {
                        warningDiv.style.display = 'none';
                        confirmBtn.disabled = false;
                    }
                }
            });
            
            // Hide popup when input loses focus
            solAmountInput.addEventListener('blur', () => {
                const eurPopup = document.getElementById('eur-conversion-popup');
                if (eurPopup) {
                    setTimeout(() => {
                        eurPopup.classList.remove('show');
                        setTimeout(() => eurPopup.style.display = 'none', 300);
                    }, 200); // Small delay to allow for clicking on popup if needed
                }
            });
            
            // Show popup again when input gains focus (if there's a value)
            solAmountInput.addEventListener('focus', async () => {
                const solAmount = parseFloat(solAmountInput.value) || 0;
                if (solAmount > 0) {
                    const eurPopup = document.getElementById('eur-conversion-popup');
                    const eurAmountElement = eurPopup?.querySelector('.eur-amount');
                    
                    if (eurPopup && eurAmountElement) {
                        try {
                            const solPrice = await window.walletSystem.getRealSolPrice();
                            const eurValue = solAmount * solPrice;
                            eurAmountElement.textContent = `€${eurValue.toFixed(2)}`;
                            
                            eurPopup.style.display = 'block';
                            setTimeout(() => eurPopup.classList.add('show'), 10);
                        } catch (error) {
                            console.warn('Could not fetch SOL price for popup:', error);
                        }
                    }
                }
            });
        }
        
        // Confirm cashout
        if (confirmBtn) {
            confirmBtn.addEventListener('click', async () => {
                const solAmount = parseFloat(solAmountInput.value);
                const externalAddress = externalAddressInput.value.trim();
                
                // Validation
                if (!solAmount || solAmount <= 0) {
                    this.showNotification('Please enter a valid SOL amount', 'error');
                    return;
                }
                
                if (!externalAddress) {
                    this.showNotification('Please enter your external wallet address', 'error');
                    return;
                }
                
                if (!window.walletSystem.isValidSolanaAddress(externalAddress)) {
                    this.showNotification('Please enter a valid Solana wallet address', 'error');
                    return;
                }
                
                // Check if user is logged in
                if (!window.authSystem || !window.authSystem.isLoggedIn) {
                    this.showNotification('Please log in to cashout', 'error');
                    return;
                }
                
                const user = window.authSystem.getCurrentUser();
                
                // Show status display
                const statusDiv = document.getElementById('cashout-status');
                const statusText = document.getElementById('cashout-status-text');
                if (statusDiv && statusText) {
                    statusDiv.style.display = 'block';
                    statusText.textContent = 'Preparing transaction...';
                }
                
                // Disable button during processing
                confirmBtn.disabled = true;
                confirmBtn.textContent = 'Processing...';
                
                try {
                    // Update status
                    if (statusText) statusText.textContent = 'Creating and sending transaction...';
                    
                    // Perform cashout with status callback
                    const result = await window.walletSystem.cashoutToExternalWallet(
                        user.username,
                        solAmount,
                        externalAddress,
                        (status) => {
                            if (statusText) statusText.textContent = status;
                        }
                    );
                    
                    if (result.success) {
                        // Update status to success
                        if (statusText) statusText.textContent = '✅ Transaction completed successfully!';
                        
                        // Wait a moment to show success status
                        setTimeout(() => {
                            // Hide status display
                            if (statusDiv) statusDiv.style.display = 'none';
                            
                            // Close modal
                            const cashoutModal = document.getElementById('cashout-modal');
                            if (cashoutModal) {
                                cashoutModal.style.display = 'none';
                            }
                            
                            // Reset form
                            solAmountInput.value = '';
                            externalAddressInput.value = '';
                        }, 2000);
                        
                        // Show success message
                        const formattedAmount = await this.formatSolWithEur(solAmount);
                        this.showNotification(`Cashout successful! ${formattedAmount} sent to your wallet. Transaction: ${result.signature}`, 'success');
                        
                        // Update wallet UI
                        if (window.walletSystem) {
                            await window.walletSystem.updateWalletUI();
                        }
                    } else {
                        // Update status to error
                        if (statusText) statusText.textContent = '❌ Transaction failed';
                        
                        // Hide status display after showing error
                        setTimeout(() => {
                            if (statusDiv) statusDiv.style.display = 'none';
                        }, 3000);
                        
                        this.showNotification(result.error || 'Cashout failed', 'error');
                    }
                } catch (error) {
                    console.error('Cashout error:', error);
                    
                    // Update status to error
                    if (statusText) statusText.textContent = '❌ Transaction failed';
                    
                    // Hide status display after showing error
                    setTimeout(() => {
                        if (statusDiv) statusDiv.style.display = 'none';
                    }, 3000);
                    
                    this.showNotification('Cashout failed: ' + error.message, 'error');
                } finally {
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = 'Confirm Cash Out';
                }
            });
        }
        
        // Cancel cashout
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                const cashoutModal = document.getElementById('cashout-modal');
                if (cashoutModal) {
                    cashoutModal.style.display = 'none';
                }
                // Reset form
                if (solAmountInput) solAmountInput.value = '';
                if (externalAddressInput) externalAddressInput.value = '';
            });
        }
        
        // Update balance when modal is shown
        const cashoutModal = document.getElementById('cashout-modal');
        if (cashoutModal) {
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                        if (cashoutModal.style.display === 'flex') {
                            updateAvailableBalance();
                        }
                    }
                });
            });
            observer.observe(cashoutModal, { attributes: true });
        }
    }

    // Setup wallet button
    setupWalletButton() {
        const walletBtn = document.getElementById('wallet-btn');
        if (walletBtn) {
            walletBtn.addEventListener('click', () => {
                this.showWalletModal();
            });
        }
        
        // Setup Add Funds button to also open wallet modal
        const addFundsBtn = document.querySelector('.add-funds-btn');
        if (addFundsBtn) {
            addFundsBtn.addEventListener('click', () => {
                this.showWalletModal();
            });
        }

        // Setup Copy Address button
        const copyAddressBtn = document.querySelector('.copy-address-btn');
        if (copyAddressBtn) {
            copyAddressBtn.addEventListener('click', async () => {
                await this.copyUserAddress();
            });
        }

        // Setup Refresh Balance button
        const refreshBalanceBtn = document.querySelector('.refresh-balance-btn');
        if (refreshBalanceBtn) {
            refreshBalanceBtn.addEventListener('click', async () => {
                await this.refreshUserBalance();
            });
        }
    }

    // Setup login/logout buttons
    setupAuthButtons() {
        const loginBtn = document.getElementById('login-btn');
        const logoutBtn = document.getElementById('logout-btn');
        
        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                this.showLoginModal();
            });
        }
        
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                if (window.authSystem) {
                    window.authSystem.logout();
                    this.updateAuthUI();
                    this.showNotification('Logged out successfully', 'success');
                }
            });
        }
    }

    // Initialize all UI interactions
    initializeUI() {
        this.setupCustomBetInput();
        this.setupJoinGameButton();
        this.setupWalletButton();
        this.setupCashoutButton();
        this.setupAuthButtons();
        this.setupLobbyUI();
        this.setupServerStatusMonitor();
        this.updateAuthUI();
        this.updateWalletUI();
    }

    // Setup lobby UI interactions
    setupLobbyUI() {
        console.log('🎮 Setting up lobby UI...');
        
        // Setup lobby tab toggle button
        const lobbyTabToggle = document.getElementById('lobby-tab-toggle');
        if (lobbyTabToggle) {
            lobbyTabToggle.addEventListener('click', () => {
                this.toggleLobbySelection();
            });
        }
        
        // Setup join lobby button (fallback for old structure)
        const joinLobbyBtn = document.getElementById('join-lobby-btn');
        if (joinLobbyBtn) {
            joinLobbyBtn.addEventListener('click', () => {
                this.showLobbySelectionPage();
            });
        }
        
        // Setup back to home button
        const backToHomeBtn = document.getElementById('back-to-home-btn');
        if (backToHomeBtn) {
            backToHomeBtn.addEventListener('click', () => {
                this.showHomePage();
            });
        }
        
        // Setup region selector buttons
        const regionBtns = document.querySelectorAll('.region-btn');
        regionBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                // Remove active class from all buttons
                regionBtns.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                btn.classList.add('active');
                
                const region = btn.dataset.region;
                this.switchRegion(region);
            });
        });
        
        // Setup lobby selection handlers
        this.setupLobbyTabHandlers();
        
        // Initialize lobby cards display
        console.log('🎮 Initializing lobby cards display...');
        this.updateLobbyCards();
    }
    
    setupLobbyTabHandlers() {
        // Setup region selector in lobby tab
        const regionBtnsTab = document.querySelectorAll('.lobby-region-selection .region-btn');
        regionBtnsTab.forEach(btn => {
            // Remove existing listeners to prevent duplicates
            btn.removeEventListener('click', this.regionClickHandler);
            // Store handler reference for removal
            this.regionClickHandler = () => {
                // Remove active class from all buttons
                regionBtnsTab.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                btn.classList.add('active');
                
                const region = btn.dataset.region;
                this.switchRegionInTab(region);
            };
            btn.addEventListener('click', this.regionClickHandler);
        });
        
        // Setup compact lobby card handlers with delegation to prevent duplicates
        const lobbyContainer = document.querySelector('.lobby-cards-container') || document.body;
        
        // Remove existing delegated listener
        if (this.lobbyCardClickHandler) {
            lobbyContainer.removeEventListener('click', this.lobbyCardClickHandler);
        }
        
        // Create new delegated click handler
        this.lobbyCardClickHandler = (event) => {
            const card = event.target.closest('.lobby-card-compact');
            if (!card) return;
            
            const lobbyId = card.dataset.lobbyId;
            console.log(`🎮 Compact lobby card clicked, ID: ${lobbyId}`);
            console.log(`🎮 Lobby system available: ${!!window.lobbySystem}`);
            
            // Check if card is offline
            if (card.classList.contains('offline')) {
                console.log('🎮 Lobby is offline');
                if (!window.lobbySystem) {
                    this.showNotification('Connecting to lobby servers... Please wait.', 'info');
                } else {
                    this.showNotification(`This lobby is currently offline. Please try again later.`, 'warning');
                }
                return;
            }
            
            if (window.lobbySystem && lobbyId) {
                this.joinLobbyById(parseInt(lobbyId));
            } else {
                console.error('🎮 Lobby system not available or lobby ID missing!');
                this.showNotification('Lobby system not ready. Please refresh the page.', 'error');
            }
        };
        
        // Add single delegated listener
        lobbyContainer.addEventListener('click', this.lobbyCardClickHandler);
        
        // Note: .lobby-card event listeners are handled by GameManager to avoid duplicate handlers
        // The gameManager.js already sets up click listeners for #lobby-list which contains .lobby-card elements

        // Ready button is handled by GameManager to avoid duplicate event listeners

        // Leave lobby button is handled by GameManager to avoid duplicate event listeners

        // Setup leave lobby button
        const leaveLobbyBtn = document.getElementById('leave-lobby-btn');
        if (leaveLobbyBtn) {
            leaveLobbyBtn.addEventListener('click', () => {
                this.leaveLobby();
            });
        }

    }
    
    // Switch region in lobby tab
    switchRegionInTab(region) {
        console.log(`🎮 Switching to region: ${region} in lobby tab`);
        
        // Get all lobby cards in the compact grid
        const lobbyCards = document.querySelectorAll('.lobby-card-compact');
        
        // Hide all lobby cards first
        lobbyCards.forEach(card => {
            card.style.display = 'none';
        });
        
        // Show only cards for the selected region
        const regionCards = document.querySelectorAll(`.lobby-card-compact[data-region="${region}"]`);
        regionCards.forEach(card => {
            card.style.display = 'block';
        });
        
        console.log(`🎮 Showing ${regionCards.length} lobbies for ${region} region`);
        
        // Update lobby cards for the selected region
        this.updateLobbyCards();
    }

    // Join a lobby
    async joinLobby(lobbyType) {
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            this.showNotification('Please login first to join a lobby', 'warning');
            this.showLoginModal();
            return;
        }

        if (!window.lobbySystem) {
            this.showNotification('Lobby system not ready. Please refresh the page.', 'error');
            return;
        }

        try {
            const availableLobbies = window.lobbySystem.getAvailableLobbies();
            const lobby = availableLobbies.find(l => l.type === lobbyType);
            
            if (!lobby) {
                this.showNotification(`No ${lobbyType} lobby available`, 'error');
                return;
            }

            await window.lobbySystem.joinLobby(lobby.id);
            this.showNotification(`Joined ${lobbyType} lobby successfully!`, 'success');
            this.updateLobbyUI();
            this.updateJoinGameButtonState();
        } catch (error) {
            console.error('Error joining lobby:', error);
            this.showNotification('Failed to join lobby. Please try again.', 'error');
        }
    }

    // Join a lobby by ID
    async joinLobbyById(lobbyId) {
        console.log(`🎮 Attempting to join lobby by ID: ${lobbyId}`);
        console.log(`🎮 DEBUG: Home page visibility before join:`, document.getElementById('home-page')?.style.display);
        
        // Prevent multiple rapid join attempts
        if (this.isJoiningLobby) {
            console.log('🎮 Already joining a lobby, ignoring duplicate request');
            return;
        }
        
        this.isJoiningLobby = true;
        
        try {
            if (!window.authSystem || !window.authSystem.isLoggedIn) {
                this.showNotification('Please login first to join a lobby', 'warning');
                this.showLoginModal();
                return;
            }

            if (!window.lobbySystem) {
                this.showNotification('Lobby system not ready. Please refresh the page.', 'error');
                return;
            }

            // Check server status before joining
            if (!window.lobbySystem.serverOnline) {
                this.showNotification('Servers are offline. Cannot join lobby at this time.', 'error');
                return;
            }
            
            // Convert lobbyId to number if it's a string
            const numericLobbyId = parseInt(lobbyId);
            if (isNaN(numericLobbyId)) {
                console.error(`🎮 Invalid lobby ID: ${lobbyId}`);
                this.showNotification(`Invalid lobby ID: ${lobbyId}`, 'error');
                return;
            }
            
            // Get lobby info
            const lobby = window.lobbySystem.availableLobbies.get(numericLobbyId);
            if (!lobby) {
                console.error(`🎮 Lobby ${numericLobbyId} not found!`);
                this.showNotification(`Lobby ${numericLobbyId} does not exist.`, 'error');
                return;
            }
            
            // Show loading state
            this.showNotification(`Joining ${lobby.name}...`, 'info');
            
            // Join lobby through lobby system
            await window.lobbySystem.joinLobby(numericLobbyId);
            
            console.log(`🎮 Successfully joined lobby ${numericLobbyId} (${lobby.name})`);
            this.showNotification(`Joined ${lobby.name} successfully!`, 'success');
            
            console.log(`🎮 DEBUG: Home page visibility after join:`, document.getElementById('home-page')?.style.display);
            
            // Stay on home page and update displays
            this.updateCurrentLobbyDisplay(lobby);
            this.updateJoinGameButtonState();
            
            console.log(`🎮 DEBUG: Home page visibility after updates:`, document.getElementById('home-page')?.style.display);
        } catch (error) {
            console.error('🎮 Error joining lobby:', error);
            this.showNotification(`Error joining lobby: ${error.message}`, 'error');
        } finally {
            // Reset the joining flag to allow future join attempts
            this.isJoiningLobby = false;
        }
    }

    // Show lobby page - DISABLED: User should stay on home page when selecting lobby
    // showLobbyPage() {
    //     // Hide all pages
    //     this.hideAllPages();
    //     
    //     const lobbyPage = document.getElementById('lobbyPage');
    //     if (lobbyPage) {
    //         lobbyPage.style.display = 'block';
    //         
    //         // Get current lobby data and update display
    //         if (window.lobbySystem && window.lobbySystem.currentLobby) {
    //             const currentLobby = window.lobbySystem.getCurrentLobby();
    //             if (currentLobby) {
    //                 this.updateLobbyPageDisplay(currentLobby);
    //             }
    //         }
    //     }
    // }
    
    // Show lobby selection page - DISABLED: User should stay on home page when selecting lobby
    showLobbySelectionPage() {
        console.log('🎮 Lobby selection page disabled - user should stay on home page');
        // Function disabled - user should remain on home page and use compact lobby selection
        return;
    }
    
    // Show home page
    showHomePage() {
        console.log('🎮 UI.js showHomePage() called - Showing home page...');
        console.log('🎮 DEBUG: Home page visibility before UI showHomePage:', document.querySelector('.home-page')?.style.display);
        
        // Don't hide all pages - just ensure home page is visible
        // Hide game container
        const gameContainer = document.querySelector('.game-container');
        if (gameContainer) {
            gameContainer.style.display = 'none';
        }

        // Hide lobby page
        const lobbyPage = document.getElementById('lobbyPage');
        if (lobbyPage) {
            lobbyPage.style.display = 'none';
        }

        // Show home page
        const homePage = document.querySelector('.home-page');
        if (homePage) {
            homePage.style.display = 'block';
            console.log('🎮 DEBUG: Set home page display to block');
        } else {
            console.error('🎮 DEBUG: Home page element not found!');
        }
        
        // Remove game-active class to show header again
        document.body.classList.remove('game-active');
        
        console.log('🎮 UI.js showHomePage() completed - Home page shown');
        console.log('🎮 DEBUG: Home page visibility after UI showHomePage:', document.querySelector('.home-page')?.style.display);
    }
    
    // Hide all pages
    hideAllPages() {
        const pages = ['.home-page', '#lobbySelectionPage', '#lobbyPage'];
        pages.forEach(selector => {
            const page = document.querySelector(selector);
            if (page) {
                page.style.display = 'none';
            }
        });
    }
    
    // Switch region in lobby selection
    switchRegion(region) {
        console.log(`🎮 Switching to ${region} region`);
        
        // Hide all lobby cards
        const lobbyCards = document.querySelectorAll('.lobby-card');
        lobbyCards.forEach(card => {
            card.style.display = 'none';
        });
        
        // Show cards for selected region
        const regionCards = document.querySelectorAll(`[data-region="${region}"]`);
        regionCards.forEach(card => {
            card.style.display = 'block';
        });
        
        // Update lobby cards with current data
        this.updateLobbyCards();
    }

    // Toggle lobby selection dropdown
    toggleLobbySelection() {
        console.log('🎮 Toggle lobby selection called');
        
        const lobbyContainer = document.getElementById('lobby-selection-container');
        const lobbyToggle = document.getElementById('lobby-tab-toggle');
        
        console.log('🎮 Lobby container element:', lobbyContainer);
        
        if (lobbyContainer && lobbyToggle) {
            const currentDisplay = window.getComputedStyle(lobbyContainer).display;
            const isVisible = currentDisplay !== 'none';
            
            console.log(`🎮 Current display: ${currentDisplay}, isVisible: ${isVisible}`);
            
            // Toggle visibility
            lobbyContainer.style.display = isVisible ? 'none' : 'block';
            console.log(`🎮 Set display to: ${lobbyContainer.style.display}`);
            
            // Toggle expanded class for arrow rotation and styling
            if (isVisible) {
                lobbyToggle.classList.remove('expanded');
            } else {
                lobbyToggle.classList.add('expanded');
            }
            
            // Update lobby cards with current data when showing
            if (!isVisible) {
                console.log('🎮 Showing lobby selection, updating cards...');
                this.updateLobbyCards();
                this.setupLobbyTabHandlers();
            }
        } else {
            console.error('🎮 Lobby container or toggle element not found!');
        }
    }

    // Toggle ready state in lobby
    async toggleReadyState() {
        if (!window.lobbySystem) {
            this.showNotification('Lobby system not ready', 'error');
            return;
        }

        const currentLobby = window.lobbySystem.getCurrentLobby();
        if (!currentLobby) {
            this.showNotification('You are not in a lobby', 'warning');
            return;
        }

        // Check if user is logged in
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            this.showNotification('Please login first!', 'warning');
            this.showLoginModal();
            return;
        }

        try {
            const user = window.authSystem.getCurrentUser();
            const readyBtn = document.getElementById('ready-btn');
            
            // Toggle ready state
            const isCurrentlyReady = readyBtn && readyBtn.textContent.includes('UNREADY');
            const newReadyState = !isCurrentlyReady;
            
            // Send ready state to lobby server
            if (window.lobbySystem.sendToLobby) {
                window.lobbySystem.sendToLobby({
                    type: 'player_ready',
                    playerId: user.id,
                    ready: newReadyState
                });
            }
            
            // Update UI
            if (readyBtn) {
                readyBtn.textContent = newReadyState ? 'UNREADY' : 'READY';
                readyBtn.classList.toggle('ready', newReadyState);
            }
            
            if (newReadyState) {
                this.showNotification('You are now ready! Waiting for other players...', 'success');
                
                // Don't automatically start multiplayer game - let user manually start when ready
                console.log('✅ Player is ready. Manual game start required.');
            } else {
                this.showNotification('You are no longer ready', 'info');
            }
            
        } catch (error) {
            console.error('Error toggling ready state:', error);
            this.showNotification('Failed to update ready state', 'error');
        }
    }
    
    async startMultiplayerGame(lobby) {
        try {
            console.log('🎮 Starting multiplayer game for lobby:', lobby.id);
            
            // Check balance and bet amount
            const user = window.authSystem.getCurrentUser();
            const betAmount = lobby.betAmount || 1.0;
            
            if (user.balance < betAmount) {
                this.showNotification(`Insufficient balance. You need €${betAmount.toFixed(2)} to play.`, 'error');
                return;
            }
            
            // Start the actual game with multiplayer context
            // Note: Balance deduction happens in game.js startGame() via addPlayerBet
            if (window.gameManager) {
                // Set multiplayer context
                window.gameManager.multiplayerLobbyId = lobby.id;
                window.gameManager.selectedBetAmount = betAmount;
                
                // Start the game
                await window.gameManager.startGame();
                
                this.showNotification(`Game started! Bet: €${betAmount.toFixed(2)}`, 'success');
            }
            
        } catch (error) {
            console.error('❌ Error starting multiplayer game:', error);
            this.showNotification('Failed to start game. Please try again.', 'error');
        }
    }

    // Update lobby UI based on current state
    updateLobbyUI() {
        const currentLobby = window.lobbySystem?.getCurrentLobby();
        
        // Always update lobby cards to show current status
        this.updateLobbyCards();
        
        // Update lobby selection visibility
        const lobbySelection = document.getElementById('lobby-selection');
        const currentLobbyInfo = document.getElementById('current-lobby-info');
        const lobbyPage = document.getElementById('lobbyPage');
        
        if (currentLobby) {
            // Show current lobby info but keep lobby selection visible
            if (currentLobbyInfo) {
                currentLobbyInfo.style.display = 'block';
                this.updateCurrentLobbyDisplay(currentLobby);
            }
            // Don't automatically show lobby page - let user navigate manually
        } else {
            // Show lobby selection, hide current lobby info
            if (lobbySelection) lobbySelection.style.display = 'block';
            if (currentLobbyInfo) currentLobbyInfo.style.display = 'none';
            if (lobbyPage) lobbyPage.style.display = 'none';
        }
    }

    // Update lobby cards with current data
    updateLobbyCards() {
        console.log('🎮 Updating lobby cards...');
        
        // Update original lobby cards
        const lobbyCards = document.querySelectorAll('.lobby-card');
        console.log(`🎮 Found ${lobbyCards.length} original lobby cards to update`);
        
        // Update compact lobby cards
        const compactLobbyCards = document.querySelectorAll('.lobby-card-compact');
        console.log(`🎮 Found ${compactLobbyCards.length} compact lobby cards to update`);
        
        // Get selected region from region buttons
        const activeRegionBtn = document.querySelector('.region-btn.active');
        const selectedRegion = activeRegionBtn ? activeRegionBtn.dataset.region : 'US';
        console.log('🎮 Selected region:', selectedRegion);
        
        // Get all available lobbies
        const availableLobbies = window.lobbySystem ? window.lobbySystem.getAvailableLobbies() : [];
        console.log('🎮 Available lobbies:', availableLobbies);
        
        // Update original lobby cards
        this.updateOriginalLobbyCards(lobbyCards, selectedRegion, availableLobbies);
        
        // Update compact lobby cards
        this.updateCompactLobbyCards(compactLobbyCards, selectedRegion, availableLobbies);
    }
    
    // Update original lobby cards
    updateOriginalLobbyCards(lobbyCards, selectedRegion, availableLobbies) {

        lobbyCards.forEach((card) => {
            const cardLobbyId = parseInt(card.dataset.lobbyId);
            const cardRegion = card.dataset.region;
            
            // Show/hide card based on selected region
            if (cardRegion === selectedRegion) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
                return;
            }
            
            // Find the corresponding lobby by ID
            const lobby = availableLobbies.find(l => l.id === cardLobbyId);
            console.log(`🎮 Processing original card for lobby ID ${cardLobbyId}:`, lobby);
            
            const nameElement = card.querySelector('.lobby-name');
            const playersElement = card.querySelector('.lobby-players');
            const prizeElement = card.querySelector('.lobby-prize');
            const statusElement = card.querySelector('.lobby-status');
            
            if (lobby && window.lobbySystem) {
                // Check both lobby and game server status
                const isLobbyServerOnline = window.lobbySystem.serverOnline;
                const isGameServerOnline = window.lobbySystem.gameServerOnline;
                const areServersOnline = isLobbyServerOnline && isGameServerOnline;
                const isStatusChecking = window.lobbySystem.statusCheckInProgress;
                
                if (areServersOnline && !isStatusChecking) {
                    // Mark as online
                    card.classList.add('online');
                    card.classList.remove('offline', 'checking');
                    card.style.opacity = '1';
                    card.style.pointerEvents = 'auto';
                } else if (isStatusChecking) {
                    // Mark as checking
                    card.classList.add('checking');
                    card.classList.remove('online', 'offline');
                    card.style.opacity = '0.7';
                    card.style.pointerEvents = 'none';
                } else {
                    // Mark as offline
                    card.classList.add('offline');
                    card.classList.remove('online', 'checking');
                    card.style.opacity = '0.5';
                    card.style.pointerEvents = 'none';
                }
                
                // Update lobby name to show proper name instead of type
                if (nameElement) {
                    nameElement.textContent = lobby.name;
                }
                
                if (playersElement) {
                    const playerCount = lobby.players ? lobby.players.size || 0 : 0;
                    playersElement.textContent = `${playerCount}/${lobby.maxPlayers || 50} players`;
                }
                
                if (prizeElement) {
                    // Calculate prize pool based on players (example calculation)
                    const playerCount = lobby.players ? lobby.players.size || 0 : 0;
                    const prizePool = playerCount * 5;
                    prizeElement.textContent = `Prize Pool: €${prizePool}`;
                }
                
                if (statusElement) {
                    if (isStatusChecking) {
                        statusElement.textContent = '🔄 Checking...';
                        statusElement.classList.add('checking');
                        statusElement.classList.remove('online', 'offline');
                    } else if (areServersOnline) {
                        statusElement.textContent = '● Online';
                        statusElement.classList.add('online');
                        statusElement.classList.remove('offline', 'checking');
                    } else {
                        statusElement.textContent = '● Offline';
                        statusElement.classList.add('offline');
                        statusElement.classList.remove('online', 'checking');
                    }
                }
                
                // Update card state
                const playerCount = lobby.players ? lobby.players.size || 0 : 0;
                card.classList.toggle('full', playerCount >= (lobby.maxPlayers || 50));
            } else {
                // Mark as offline if no lobby found
                card.classList.add('offline');
                card.classList.remove('online', 'full');
                
                if (nameElement) {
                    // Keep the existing name from HTML
                    const existingName = nameElement.textContent;
                    if (!existingName || existingName.includes('undefined')) {
                        nameElement.textContent = `${cardRegion} Lobby ${cardLobbyId}`;
                    }
                }
                
                if (playersElement) {
                    playersElement.textContent = window.lobbySystem ? 'Offline' : 'Connecting...';
                }
                
                if (prizeElement) {
                    prizeElement.textContent = window.lobbySystem ? 'Prize Pool: Unavailable' : 'Prize Pool: Calculating...';
                }
                
                if (statusElement) {
                    statusElement.textContent = window.lobbySystem ? '● Offline' : '● Connecting...';
                    statusElement.classList.add('offline');
                    statusElement.classList.remove('online');
                }
            }
        });
    }
    
    // Update compact lobby cards
    updateCompactLobbyCards(compactLobbyCards, selectedRegion, availableLobbies) {
        compactLobbyCards.forEach((card) => {
            const cardLobbyId = parseInt(card.dataset.lobbyId);
            const cardRegion = card.dataset.region;
            
            console.log(`🎮 Processing compact card for lobby ID ${cardLobbyId}, region: ${cardRegion}`);
            
            // Find the corresponding lobby by ID
            const lobby = availableLobbies.find(l => l.id === cardLobbyId);
            console.log(`🎮 Processing compact card for lobby ID ${cardLobbyId}:`, lobby);
            
            const nameElement = card.querySelector('.lobby-name');
            const playersElement = card.querySelector('.lobby-players');
            const statusElement = card.querySelector('.lobby-status');
            
            if (lobby && window.lobbySystem) {
                // Check both lobby and game server status
                const isLobbyServerOnline = window.lobbySystem.serverOnline;
                const isGameServerOnline = window.lobbySystem.gameServerOnline;
                const areServersOnline = isLobbyServerOnline && isGameServerOnline;
                const isStatusChecking = window.lobbySystem.statusCheckInProgress;
                
                if (areServersOnline && !isStatusChecking) {
                    // Mark as online
                    card.classList.add('online');
                    card.classList.remove('offline', 'checking');
                    card.style.opacity = '1';
                    card.style.pointerEvents = 'auto';
                } else if (isStatusChecking) {
                    // Mark as checking
                    card.classList.add('checking');
                    card.classList.remove('online', 'offline');
                    card.style.opacity = '0.7';
                    card.style.pointerEvents = 'none';
                } else {
                    // Mark as offline
                    card.classList.add('offline');
                    card.classList.remove('online', 'checking');
                    card.style.opacity = '0.5';
                    card.style.pointerEvents = 'none';
                }
                
                // Update lobby name to show proper name instead of type
                if (nameElement) {
                    nameElement.textContent = lobby.name || `${cardRegion} Lobby ${cardLobbyId}`;
                }
                
                if (playersElement) {
                    const playerCount = lobby.players ? lobby.players.size || 0 : 0;
                    playersElement.textContent = `${playerCount}/${lobby.maxPlayers || 50}`;
                }
                
                if (statusElement) {
                    if (isStatusChecking) {
                        statusElement.textContent = 'Checking...';
                        statusElement.classList.add('checking');
                        statusElement.classList.remove('online', 'offline');
                    } else if (areServersOnline) {
                        statusElement.textContent = 'Online';
                        statusElement.classList.add('online');
                        statusElement.classList.remove('offline', 'checking');
                    } else {
                        statusElement.textContent = 'Offline';
                        statusElement.classList.add('offline');
                        statusElement.classList.remove('online', 'checking');
                    }
                }
                
                // Update card state
                const playerCount = lobby.players ? lobby.players.size || 0 : 0;
                card.classList.toggle('full', playerCount >= (lobby.maxPlayers || 50));
            } else {
                // Mark as offline if no lobby found
                card.classList.add('offline');
                card.classList.remove('online', 'full');
                
                if (nameElement) {
                    nameElement.textContent = `${cardRegion} Lobby ${cardLobbyId}`;
                }
                
                if (playersElement) {
                    playersElement.textContent = window.lobbySystem ? '0/50' : '?/?';
                }
                
                if (statusElement) {
                    statusElement.textContent = window.lobbySystem ? 'Offline' : 'Connecting...';
                    statusElement.classList.add('offline');
                    statusElement.classList.remove('online');
                }
            }
        });
    }

    // Update current lobby display
    updateCurrentLobbyDisplay(lobby) {
        const lobbyTitle = document.getElementById('lobby-title');
        if (lobbyTitle) {
            lobbyTitle.textContent = lobby.name || 'Current Lobby';
        }
    }

    // Update lobby page display
    updateLobbyPageDisplay(lobby) {
        const lobbyTitle = document.getElementById('lobby-title');
        const lobbyBet = document.getElementById('lobby-bet');
        const lobbyFee = document.getElementById('lobby-fee-display');
        const lobbyPlayerCount = document.getElementById('lobby-player-count');
        
        if (lobbyTitle) {
            lobbyTitle.textContent = lobby.name || `${lobby.type} Lobby`;
        }
        
        if (lobbyBet && window.gameManager) {
            const betAmount = lobby.betAmount || window.gameManager.selectedBetAmount || 0.25;
            lobbyBet.textContent = `€${betAmount.toFixed(2)} Bet`;
        }
        
        if (lobbyFee) {
            lobbyFee.textContent = '+ €0.10 fee';
        }
        
        if (lobbyPlayerCount) {
            const playerCount = lobby.players ? (lobby.players.size || lobby.players.length || 0) : 0;
            const maxPlayers = lobby.maxPlayers || 50;
            lobbyPlayerCount.textContent = `${playerCount}/${maxPlayers}`;
        }
        
        // Update lobby wallet/prize pool display
        this.updateLobbyWalletDisplay(lobby);
        
        // Update players grid
        this.updateLobbyPlayersGrid(lobby);
    }
    
    updateLobbyWalletDisplay(lobby) {
        // Find or create lobby wallet display element
        let walletDisplay = document.getElementById('lobby-wallet-amount');
        if (!walletDisplay) {
            // Try to find it in the lobby info section
            const lobbyInfo = document.querySelector('.lobby-info');
            if (lobbyInfo) {
                walletDisplay = document.createElement('div');
                walletDisplay.id = 'lobby-wallet-amount';
                walletDisplay.className = 'lobby-wallet-display';
                lobbyInfo.appendChild(walletDisplay);
            }
        }
        
        if (walletDisplay) {
            const playerCount = lobby.players ? (lobby.players.size || lobby.players.length || 0) : 0;
            const betAmount = lobby.betAmount || 1.0;
            const prizePool = playerCount * betAmount;
            
            walletDisplay.innerHTML = `
                <div class="wallet-info">
                    <span class="wallet-label">💰 Prize Pool:</span>
                    <span class="wallet-amount">€${prizePool.toFixed(2)}</span>
                </div>
                <div class="wallet-details">
                    <small>${playerCount} players × €${betAmount.toFixed(2)} bet</small>
                </div>
            `;
        }
    }

    // Update lobby players grid
    updateLobbyPlayersGrid(lobby) {
        const playersGrid = document.getElementById('lobby-players-grid');
        if (!playersGrid || !lobby.players) return;
        
        playersGrid.innerHTML = '';
        
        lobby.players.forEach(player => {
            const playerElement = document.createElement('div');
            playerElement.className = 'lobby-player';
            playerElement.innerHTML = `
                <div class="player-avatar">👤</div>
                <div class="player-name">${player.name || 'Anonymous'}</div>
                <div class="player-status ${player.ready ? 'ready' : 'not-ready'}">
                    ${player.ready ? '✓ Ready' : '⏳ Not Ready'}
                </div>
            `;
            playersGrid.appendChild(playerElement);
        });
    }

    // Navigate back to lobby selection
    backToLobbySelection() {
        const lobbyPage = document.getElementById('lobbyPage');
        const homePage = document.getElementById('home-page');
        
        if (lobbyPage) lobbyPage.style.display = 'none';
        if (homePage) homePage.style.display = 'block';
        
        // Reset lobby selection UI
        this.updateLobbyUI();
    }

    // Leave current lobby
    async leaveLobby() {
        if (!window.lobbySystem) {
            this.showNotification('Lobby system not ready', 'error');
            return;
        }

        try {
            await window.lobbySystem.leaveLobby();
            this.showNotification('Left lobby successfully', 'success');
            this.backToLobbySelection();
            this.updateJoinGameButtonState();
        } catch (error) {
            console.error('Error leaving lobby:', error);
            this.showNotification('Failed to leave lobby', 'error');
        }
    }

    // Remove notification
    removeNotification(notification) {
        if (notification && notification.parentNode) {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
            
            const index = this.notifications.indexOf(notification);
            if (index > -1) {
                this.notifications.splice(index, 1);
            }
        }
    }

    // Update balance display
    updateBalanceDisplay(balance) {
        const balanceElements = document.querySelectorAll('.balance, .user-balance, .wallet-balance');
        balanceElements.forEach(el => {
            el.textContent = this.formatCurrency(balance);
        });
    }

    // Update user info display
    updateUserInfo(user) {
        const usernameElements = document.querySelectorAll('.username, .user-name');
        usernameElements.forEach(el => {
            el.textContent = user.username;
        });

        const emailElements = document.querySelectorAll('.user-email');
        emailElements.forEach(el => {
            el.textContent = user.email;
        });

        const winningsElements = document.querySelectorAll('.total-winnings');
        winningsElements.forEach(el => {
            el.textContent = `€${user.totalWinnings.toFixed(2)}`;
        });

        const gamesElements = document.querySelectorAll('.games-played');
        gamesElements.forEach(el => {
            el.textContent = user.gamesPlayed;
        });
    }

    // Update game stats
    updateGameStats(stats) {
        const playersElement = document.querySelector('.players-count');
        if (playersElement) {
            playersElement.textContent = stats.playersInGame || 0;
        }

        const winningsElement = document.querySelector('.global-winnings');
        if (winningsElement) {
            winningsElement.textContent = `€${(stats.globalWinnings || 0).toLocaleString()}`;
        }
    }

    // Show loading spinner
    showLoading(element, text = 'Loading...') {
        if (!element) return;

        const spinner = document.createElement('div');
        spinner.className = 'loading-spinner';
        spinner.innerHTML = `
            <div class="spinner"></div>
            <span>${text}</span>
        `;
        spinner.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            color: #666;
            font-size: 14px;
        `;

        const spinnerCSS = `
            .spinner {
                width: 20px;
                height: 20px;
                border: 2px solid #f3f3f3;
                border-top: 2px solid #3498db;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;

        if (!document.querySelector('#spinner-styles')) {
            const style = document.createElement('style');
            style.id = 'spinner-styles';
            style.textContent = spinnerCSS;
            document.head.appendChild(style);
        }

        element.style.position = 'relative';
        element.appendChild(spinner);

        return spinner;
    }

    // Hide loading spinner
    hideLoading(element) {
        if (!element) return;

        const spinner = element.querySelector('.loading-spinner');
        if (spinner) {
            spinner.remove();
        }
    }

    // Animate number change
    animateNumber(element, from, to, duration = 1000) {
        if (!element) return;

        const start = Date.now();
        const range = to - from;

        const animate = () => {
            const elapsed = Date.now() - start;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const current = from + (range * easeOut);
            
            element.textContent = `€${current.toFixed(2)}`;
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };

        animate();
    }

    // Copy user's Solana address
    async copyUserAddress() {
        try {
            const user = window.authSystem?.getCurrentUser();
            if (!user) {
                this.showNotification('Please log in to copy your address', 'error');
                return;
            }

            if (!window.walletSystem) {
                this.showNotification('Wallet system not available', 'error');
                return;
            }

            // Get user's wallet address
            const walletAddress = await window.walletSystem.getUserWalletAddress(user.username);
            
            if (!walletAddress) {
                this.showNotification('No wallet address found', 'error');
                return;
            }

            // Copy to clipboard
            await navigator.clipboard.writeText(walletAddress);
            
            // Show success notification
            this.showNotification('Address copied to clipboard!', 'success');
            
        } catch (error) {
            console.error('Error copying address:', error);
            this.showNotification('Failed to copy address', 'error');
        }
    }

    // Refresh user's balance
    async refreshUserBalance() {
        try {
            const user = window.authSystem?.getCurrentUser();
            if (!user) {
                this.showNotification('Please log in to refresh balance', 'error');
                return;
            }

            if (!window.walletSystem) {
                this.showNotification('Wallet system not available', 'error');
                return;
            }

            // Show loading notification
            this.showNotification('Refreshing balance...', 'info');
            
            // Simply get the current balance from blockchain without processing any transactions
            const currentBalance = await window.walletSystem.getUserSolBalance(user.username);
            
            // Update the balance display in the right sidebar
            const balanceElement = document.getElementById('balance-amount');
            if (balanceElement) {
                balanceElement.innerHTML = await this.formatSolWithEur(currentBalance);
            }
            
            // Show success notification
            this.showNotification('Balance refreshed successfully', 'success');
            
        } catch (error) {
            console.error('Error refreshing balance:', error);
            this.showNotification('Failed to refresh balance: ' + error.message, 'error');
        }
    }

    // Copy text to clipboard
    copyToClipboard(text, successMessage = 'Copied to clipboard!') {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => {
                this.showNotification(successMessage, 'success');
            }).catch(() => {
                this.fallbackCopyToClipboard(text, successMessage);
            });
        } else {
            this.fallbackCopyToClipboard(text, successMessage);
        }
    }

    // Fallback copy method
    fallbackCopyToClipboard(text, successMessage) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            this.showNotification(successMessage, 'success');
        } catch (err) {
            this.showNotification('Failed to copy', 'error');
        }
        
        document.body.removeChild(textArea);
    }

    // Format currency
    formatCurrency(amount, currency = '€') {
        return `${currency}${amount.toFixed(2)}`;
    }

    // Format large numbers
    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    // Validate form
    validateForm(form) {
        const errors = [];
        const inputs = form.querySelectorAll('input[required]');
        
        inputs.forEach(input => {
            if (!input.value.trim()) {
                errors.push(`${input.placeholder || input.name || 'Field'} is required`);
                input.classList.add('error');
            } else {
                input.classList.remove('error');
            }
            
            // Email validation
            if (input.type === 'email' && input.value) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value)) {
                    errors.push('Please enter a valid email address');
                    input.classList.add('error');
                }
            }
            
            // Password confirmation
            if (input.id === 'register-confirm') {
                const password = form.querySelector('#register-password');
                if (password && input.value !== password.value) {
                    errors.push('Passwords do not match');
                    input.classList.add('error');
                }
            }
        });
        
        return errors;
    }

    // Setup mini social panel functionality
    setupSocialMiniPanel() {
        // Setup tab switching
        document.querySelectorAll('.social-tab-mini').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const targetTab = e.target.dataset.tab;
                this.switchSocialMiniTab(targetTab);
            });
        });

        // Setup search input enter key
        const searchInput = document.getElementById('friend-search-mini');
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.searchUsersMini();
                }
            });
        }
    }

    // Setup server status monitoring
    setupServerStatusMonitor() {
        this.serverStatusInterval = null;
        this.lastServerStatus = null;
        
        // Start monitoring immediately
        this.checkServerStatus();
        
        // Check server status every 10 seconds
        this.serverStatusInterval = setInterval(() => {
            this.checkServerStatus();
        }, 10000);
    }

    // Check server connectivity
    async checkServerStatus() {
        const statusElement = document.getElementById('server-status');
        const statusText = statusElement?.querySelector('.status-text');
        
        if (!statusElement || !statusText) return;
        
        try {
            // Try to fetch a static file to check if the web server is responding
            const response = await fetch('/index.html', {
                method: 'HEAD',
                timeout: 5000
            });
            
            if (response.ok) {
                // Web server is responding, now test WebSocket connections
                this.testWebSocketConnection();
            } else {
                this.updateServerStatusCorner('offline');
            }
        } catch (error) {
            // If fetch fails, mark as offline
            this.updateServerStatusCorner('offline');
        }
    }

    // Test WebSocket connection as fallback
    testWebSocketConnection() {
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const host = window.location.host;
            
            // Test lobby server WebSocket connection
            const lobbyWsUrl = `${protocol}//${host}/ws-lobby/status-check`;
            const testWs = new WebSocket(lobbyWsUrl);
            
            const timeout = setTimeout(() => {
                testWs.close();
                this.updateServerStatusCorner('offline');
            }, 3000);
            
            testWs.onopen = () => {
                clearTimeout(timeout);
                testWs.close();
                this.updateServerStatusCorner('online');
            };
            
            testWs.onerror = () => {
                clearTimeout(timeout);
                // If lobby server fails, try game server as fallback
                this.testGameServerConnection();
            };
        } catch (error) {
            this.updateServerStatusCorner('offline');
        }
    }

    // Test game server WebSocket connection as fallback
    testGameServerConnection() {
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const host = window.location.host;
            
            // Test game server WebSocket connection
            const gameWsUrl = `${protocol}//${host}/ws-game`;
            const testWs = new WebSocket(gameWsUrl);
            
            const timeout = setTimeout(() => {
                testWs.close();
                this.updateServerStatusCorner('offline');
            }, 3000);
            
            testWs.onopen = () => {
                clearTimeout(timeout);
                testWs.close();
                this.updateServerStatusCorner('online');
            };
            
            testWs.onerror = () => {
                clearTimeout(timeout);
                this.updateServerStatusCorner('offline');
            };
        } catch (error) {
            this.updateServerStatusCorner('offline');
        }
    }

    // Update server status corner display
    updateServerStatusCorner(status) {
        const statusElement = document.getElementById('server-status-corner');
        const statusDot = statusElement?.querySelector('.status-dot');
        const statusText = statusElement?.querySelector('.status-text');
        
        if (!statusElement || !statusDot || !statusText) return;
        
        // Only update if status changed
        if (this.lastServerStatus === status) return;
        this.lastServerStatus = status;
        
        // Update status
        statusDot.className = `status-dot ${status}`;
        statusText.textContent = status === 'online' ? 'Online' : 'Offline';
    }
    
    // Update lobby bet display
    updateLobbyBetDisplay(amount) {
        const lobbyBet = document.getElementById('lobby-bet');
        const lobbyFee = document.getElementById('lobby-fee-display');
        
        if (lobbyBet) {
            lobbyBet.textContent = `€${amount.toFixed(2)} Bet`;
        }
        
        if (lobbyFee) {
            lobbyFee.textContent = '+ €0.10 fee';
        }
    }
    
    // Legacy method for compatibility
    updateServerStatus(status, text) {
        this.updateServerStatusCorner(status);
        
        // Remove all status classes
        statusElement.classList.remove('online', 'offline');
        
        // Add new status class
        statusElement.classList.add(status);
        
        // Update text
        statusText.textContent = text;
        
        console.log(`🌐 Server status: ${status}`);
    }

    // Switch mini social panel tabs
    switchSocialMiniTab(tabName) {
        // Remove active class from all tabs
        document.querySelectorAll('.social-tab-mini').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Remove active class from all tab contents
        document.querySelectorAll('.tab-mini-content').forEach(content => {
            content.classList.remove('active');
        });
        
        // Add active class to selected tab
        const selectedTab = document.querySelector(`[data-tab="${tabName}"]`);
        if (selectedTab) {
            selectedTab.classList.add('active');
        }
        
        // Show selected tab content
        const selectedContent = document.getElementById(`${tabName}-mini`);
        if (selectedContent) {
            selectedContent.classList.add('active');
        }
    }

    // Search users in mini panel
    async searchUsersMini() {
        const searchInput = document.getElementById('friend-search-mini');
        const resultsContainer = document.getElementById('search-results-mini');
        
        if (!searchInput || !resultsContainer) return;
        
        const query = searchInput.value.trim();
        if (!query) {
            resultsContainer.innerHTML = '<div style="color: #6b7280; font-size: 11px; text-align: center; padding: 8px;">Enter a username to search</div>';
            return;
        }
        
        resultsContainer.innerHTML = '<div style="color: #6b7280; font-size: 11px; text-align: center; padding: 8px;">Searching...</div>';
        
        try {
            // This would typically call the social system's search function
            if (window.socialSystem) {
                // For now, show a placeholder message
                resultsContainer.innerHTML = '<div style="color: #6b7280; font-size: 11px; text-align: center; padding: 8px;">Click "View Full Social" for advanced search</div>';
            } else {
                resultsContainer.innerHTML = '<div style="color: #6b7280; font-size: 11px; text-align: center; padding: 8px;">Social system not loaded</div>';
            }
        } catch (error) {
            console.error('Search error:', error);
            resultsContainer.innerHTML = '<div style="color: #ff4757; font-size: 11px; text-align: center; padding: 8px;">Search failed</div>';
        }
    }

    // Show form errors
    showFormErrors(form, errors) {
        // Remove existing error messages
        form.querySelectorAll('.error-message').forEach(el => el.remove());
        
        if (errors.length > 0) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.style.cssText = `
                color: #f44336;
                font-size: 12px;
                margin-top: 10px;
                padding: 8px;
                background: rgba(244, 67, 54, 0.1);
                border-radius: 4px;
                border-left: 3px solid #f44336;
            `;
            errorDiv.innerHTML = errors.map(error => `• ${error}`).join('<br>');
            
            form.appendChild(errorDiv);
        }
    }
}

// Initialize UI Manager
document.addEventListener('DOMContentLoaded', () => {
    console.log('🎮 DOM Content Loaded');
    try {
        window.uiManager = new UIManager();
        console.log('🎮 UIManager created successfully');
        
        // Test direct access to lobby header button
        setTimeout(() => {
            const testBtn = document.getElementById('lobby-header-btn');
            console.log('🎮 Test: lobby header button found:', testBtn);
            if (testBtn) {
                testBtn.addEventListener('click', () => {
                    console.log('🎮 Test: Direct click handler triggered!');
                });
            }
        }, 100);
    } catch (error) {
        console.error('🎮 Error creating UIManager:', error);
    }
});

// Global function for mini search (called from HTML)
function searchUsersMini() {
    if (window.uiManager) {
        window.uiManager.searchUsersMini();
    }
}

// Export for global access
window.UIManager = UIManager;
window.searchUsersMini = searchUsersMini;
# SSL/WSS Requirements

## IMPORTANT: All servers MUST use SSL/WSS

This project requires all Node.js servers to use SSL/WSS connections for security. HTTP/WS fallback has been disabled.

### Server Configuration

1. **Game Server** (`server.js`) - Port 8081
   - MUST use HTTPS/WSS
   - SSL certificates required from `/etc/letsencrypt/live/oopsnowh.com/`
   - Server will exit if SSL certificates are not found

2. **Lobby Server** (`lobbyServer.js`) - Port 8083
   - MUST use HTTPS/WSS
   - SSL certificates required from `/etc/letsencrypt/live/oopsnowh.com/`
   - Server will exit if SSL certificates are not found

3. **Lobby Wallet Server** (`lobbyWalletServer.js`) - Port 8082
   - MUST use HTTPS/WSS
   - SSL certificates required from `/etc/letsencrypt/live/oopsnowh.com/`
   - Server will exit if SSL certificates are not found

### Nginx Configuration

All proxy_pass directives in `/etc/nginx/sites-available/default` use HTTPS:
- Game WS: `proxy_pass https://127.0.0.1:8081/`
- Lobby WS: `proxy_pass https://127.0.0.1:8083/lobby/$1`
- Wallet WS: `proxy_pass https://127.0.0.1:8082/`

### SSL Certificates

Servers attempt to load SSL certificates in this order:
1. Local certificates: `ssl/key.pem` and `ssl/cert.pem`
2. Let's Encrypt certificates: `/etc/letsencrypt/live/oopsnowh.com/privkey.pem` and `/etc/letsencrypt/live/oopsnowh.com/fullchain.pem`

If neither is found, the server will exit with an error.

### Security Note

SSL/WSS is mandatory for:
- Secure WebSocket connections
- Protection of sensitive game data
- Compliance with modern web security standards
- Proper functioning with HTTPS frontend

**Never disable SSL or add HTTP fallback without explicit security review.**
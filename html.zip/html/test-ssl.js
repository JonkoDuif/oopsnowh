#!/usr/bin/env node

// SSL Test Script
// This script tests if SSL certificates are properly configured

const fs = require('fs');
const https = require('https');
const WebSocket = require('ws');

console.log('🔍 Testing SSL Configuration...');
console.log('================================');

// Test 1: Check if SSL certificates exist
console.log('\n1. Checking SSL certificates...');
try {
    const keyPath = '/etc/letsencrypt/live/oopsnowh.com/privkey.pem';
    const certPath = '/etc/letsencrypt/live/oopsnowh.com/fullchain.pem';
    
    if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
        console.log('✅ SSL certificates found');
        console.log(`   Key: ${keyPath}`);
        console.log(`   Cert: ${certPath}`);
        
        // Check certificate validity
        const cert = fs.readFileSync(certPath, 'utf8');
        const key = fs.readFileSync(keyPath, 'utf8');
        
        console.log('✅ SSL certificates readable');
    } else {
        console.log('❌ SSL certificates not found');
        console.log('   Please install SSL certificates using certbot');
        process.exit(1);
    }
} catch (error) {
    console.log('❌ Error reading SSL certificates:', error.message);
    process.exit(1);
}

// Test 2: Test HTTPS server creation
console.log('\n2. Testing HTTPS server creation...');
try {
    const sslOptions = {
        key: fs.readFileSync('/etc/letsencrypt/live/oopsnowh.com/privkey.pem'),
        cert: fs.readFileSync('/etc/letsencrypt/live/oopsnowh.com/fullchain.pem')
    };
    
    const server = https.createServer(sslOptions);
    console.log('✅ HTTPS server created successfully');
    
    // Test WebSocket server creation
    const wss = new WebSocket.Server({ server });
    console.log('✅ WSS server created successfully');
    
    // Start server briefly to test
    server.listen(8082, () => {
        console.log('✅ Test server started on port 8082');
        server.close(() => {
            console.log('✅ Test server stopped');
        });
    });
    
} catch (error) {
    console.log('❌ Error creating HTTPS/WSS server:', error.message);
    process.exit(1);
}

// Test 3: Environment variables
console.log('\n3. Checking environment variables...');
const isProduction = process.env.NODE_ENV === 'production' || process.env.SSL_ENABLED === 'true';
console.log(`   NODE_ENV: ${process.env.NODE_ENV || 'not set'}`);
console.log(`   SSL_ENABLED: ${process.env.SSL_ENABLED || 'not set'}`);
console.log(`   Production mode: ${isProduction ? '✅ Yes' : '❌ No'}`);

if (!isProduction) {
    console.log('\n⚠️  Warning: Not in production mode');
    console.log('   Set SSL_ENABLED=true or NODE_ENV=production to enable SSL');
}

console.log('\n🎉 SSL configuration test completed!');
console.log('\nTo start servers with SSL:');
console.log('   export SSL_ENABLED=true');
console.log('   node server.js');
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST method allowed']);
    exit;
}

require_once 'database.php';

try {
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    if (!$pdo) {
        throw new Exception('Database connection failed');
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
        exit;
    }
    
    // Validate required fields
    $required_fields = ['user_id', 'survival_time', 'kills', 'cashout_amount'];
    foreach ($required_fields as $field) {
        if (!isset($input[$field])) {
            echo json_encode(['success' => false, 'error' => "Missing required field: $field"]);
            exit;
        }
    }
    
    // Extract game data
    $user_id = (int)$input['user_id'];
    $survival_time = (int)$input['survival_time']; // in seconds
    $kills = (int)$input['kills'];
    $cashout_amount = (float)$input['cashout_amount'];
    $max_mass = isset($input['max_mass']) ? (int)$input['max_mass'] : 0;
    $cells_eaten = isset($input['cells_eaten']) ? (int)$input['cells_eaten'] : 0;
    $game_mode = isset($input['game_mode']) ? $input['game_mode'] : 'classic';
    $eliminated_by = isset($input['eliminated_by']) ? $input['eliminated_by'] : null;
    $final_position = isset($input['final_position']) ? (int)$input['final_position'] : null;
    
    // Validate user exists
    $user_check = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
    $user_check->execute([$user_id]);
    $user = $user_check->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    // Check if user already has game stats record
    $check_stats = $pdo->prepare("SELECT id FROM game_stats WHERE user_id = ?");
    $check_stats->execute([$user_id]);
    $existing_stats = $check_stats->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_stats) {
        // Update existing stats
        $update_sql = "
            UPDATE game_stats SET 
                kills = kills + :kills,
                deaths = deaths + 1,
                max_mass = GREATEST(max_mass, :max_mass),
                total_playtime = total_playtime + :survival_time,
                games_played = games_played + 1,
                updated_at = NOW()
            WHERE user_id = :user_id
        ";
        
        $update_stmt = $pdo->prepare($update_sql);
        $game_result = $update_stmt->execute([
            ':user_id' => $user_id,
            ':kills' => $kills,
            ':max_mass' => $max_mass,
            ':survival_time' => $survival_time
        ]);
    } else {
        // Insert new stats record
        $insert_sql = "
            INSERT INTO game_stats (
                user_id, kills, deaths, max_mass, total_playtime, games_played
            ) VALUES (
                :user_id, :kills, 1, :max_mass, :survival_time, 1
            )
        ";
        
        $insert_stmt = $pdo->prepare($insert_sql);
        $game_result = $insert_stmt->execute([
            ':user_id' => $user_id,
            ':kills' => $kills,
            ':max_mass' => $max_mass,
            ':survival_time' => $survival_time
        ]);
    }
    
    if (!$game_result) {
        echo json_encode(['success' => false, 'error' => 'Failed to save game stats']);
        exit;
    }
    
    // Update user's total balance if they cashed out
    if ($cashout_amount > 0) {
        $balance_sql = "UPDATE users SET balance = balance + :amount WHERE id = :user_id";
        $balance_stmt = $pdo->prepare($balance_sql);
        $balance_stmt->execute([
            ':amount' => $cashout_amount,
            ':user_id' => $user_id
        ]);
    }
    
    // Get updated user stats from game_stats table
    $stats_sql = "
        SELECT 
            games_played as total_games,
            kills as total_kills,
            deaths,
            max_mass,
            total_playtime,
            CASE 
                WHEN games_played > 0 THEN ROUND((kills * 100.0 / games_played), 1)
                ELSE 0 
            END as avg_kills_per_game
        FROM game_stats 
        WHERE user_id = :user_id
    ";
    
    $stats_stmt = $pdo->prepare($stats_sql);
    $stats_stmt->execute([':user_id' => $user_id]);
    $user_stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
    
    // If no stats found, set defaults
    if (!$user_stats) {
        $user_stats = [
            'total_games' => 0,
            'total_kills' => 0,
            'deaths' => 0,
            'max_mass' => 0,
            'total_playtime' => 0,
            'avg_kills_per_game' => 0
        ];
    }
    
    // Get updated user balance
    $balance_sql = "SELECT balance FROM users WHERE id = :user_id";
    $balance_stmt = $pdo->prepare($balance_sql);
    $balance_stmt->execute([':user_id' => $user_id]);
    $balance_result = $balance_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Game statistics saved successfully',
        'user_stats' => [
            'total_games' => (int)$user_stats['total_games'],
            'total_kills' => (int)$user_stats['total_kills'],
            'deaths' => (int)$user_stats['deaths'],
            'max_mass' => (float)$user_stats['max_mass'],
            'total_playtime' => (int)$user_stats['total_playtime'],
            'avg_kills_per_game' => (float)$user_stats['avg_kills_per_game'],
            'current_balance' => (float)$balance_result['balance']
        ],
        'game_data' => [
            'survival_time' => $survival_time,
            'kills' => $kills,
            'cashout_amount' => $cashout_amount,
            'max_mass' => $max_mass
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
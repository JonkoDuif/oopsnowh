<?php
// Secure JavaScript Loader with Advanced Anti-Cheat Protection
// Prevents code modification and reverse engineering

session_start();

// Security headers
header('Content-Type: application/javascript; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-cache, no-store, must-revalidate');
header('X-Frame-Options: DENY');
header('Pragma: no-cache');
header('Expires: 0');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: no-referrer');

// Get the requested file
$file = isset($_GET['file']) ? $_GET['file'] : '';

// Whitelist of allowed JS files
$allowedFiles = [
    'utils' => '../js/utils.js',
    'auth' => '../js/auth.js',
    'wallet' => '../js/wallet.js',
    'lobbyWallet' => '../js/lobbyWallet.js',
    'lobbySystem' => '../js/lobbySystem.js',
    'ui' => '../js/ui.js',
    'backgroundAnimation' => '../js/backgroundAnimation.js',
    'multiplayer' => '../js/multiplayer.js',
    'game' => '../js/game.js',
    'gameManager' => '../js/gameManager.js',
    'social' => '../js/social.js'
];

// Validate file parameter
if (empty($file) || !isset($allowedFiles[$file])) {
    http_response_code(404);
    echo '// Access denied';
    exit;
}

$filePath = __DIR__ . '/' . $allowedFiles[$file];

// Check if file exists and is readable
if (!file_exists($filePath) || !is_readable($filePath)) {
    http_response_code(404);
    echo '// Access denied';
    exit;
}

// Read the file content with proper UTF-8 encoding
$content = file_get_contents($filePath);
if ($content === false) {
    http_response_code(500);
    echo '// Error reading file';
    exit;
}

// Ensure proper UTF-8 encoding (fallback method without mbstring)
if (!function_exists('mb_check_encoding')) {
    // Simple UTF-8 validation without mbstring
    if (!preg_match('//u', $content)) {
        // If content is not valid UTF-8, try to fix it
        $content = utf8_encode($content);
    }
} else {
    if (!mb_check_encoding($content, 'UTF-8')) {
        $content = mb_convert_encoding($content, 'UTF-8', 'auto');
    }
}

// Generate unique session key for this request
if (!isset($_SESSION['js_session_key'])) {
    $_SESSION['js_session_key'] = bin2hex(random_bytes(16));
}
$sessionKey = $_SESSION['js_session_key'];

// Heavy obfuscation function
function heavyObfuscate($code, $sessionKey) {
    // Remove comments and normalize whitespace
    $code = preg_replace('/\/\*[\s\S]*?\*\//', '', $code);
    $code = preg_replace('/\/\/.*$/m', '', $code);
    $code = preg_replace('/\s+/', ' ', $code);
    $code = trim($code);
    
    // Generate obfuscated variable names based on session key
    $varMap = [];
    $funcMap = [];
    $seed = crc32($sessionKey);
    
    // Find and replace variable declarations
    preg_match_all('/\b(?:var|let|const)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\b/', $code, $matches);
    foreach (array_unique($matches[1]) as $varName) {
        if (!isset($varMap[$varName])) {
            $varMap[$varName] = '_' . substr(md5($varName . $seed), 0, 8);
        }
    }
    
    // Find and replace function declarations
    preg_match_all('/\bfunction\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\(/', $code, $matches);
    foreach (array_unique($matches[1]) as $funcName) {
        if (!isset($funcMap[$funcName])) {
            $funcMap[$funcName] = '_' . substr(md5($funcName . $seed . 'func'), 0, 8);
        }
    }
    
    // Find class names and methods
    preg_match_all('/\bclass\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\b/', $code, $matches);
    foreach (array_unique($matches[1]) as $className) {
        if (!isset($funcMap[$className])) {
            $funcMap[$className] = '_' . substr(md5($className . $seed . 'class'), 0, 8);
        }
    }
    
    // Apply variable name obfuscation
    foreach ($varMap as $original => $obfuscated) {
        $code = preg_replace('/\b' . preg_quote($original, '/') . '\b/', $obfuscated, $code);
    }
    
    // Apply function name obfuscation
    foreach ($funcMap as $original => $obfuscated) {
        $code = preg_replace('/\b' . preg_quote($original, '/') . '\b/', $obfuscated, $code);
    }
    
    // Obfuscate string literals
    $code = preg_replace_callback('/(["\'])([^"\']*)\1/', function($matches) {
        $quote = $matches[1];
        $string = $matches[2];
        if (strlen($string) > 2) {
            // Convert to hex encoding for longer strings
            $encoded = '';
            for ($i = 0; $i < strlen($string); $i++) {
                $encoded .= '\\x' . sprintf('%02x', ord($string[$i]));
            }
            return $quote . $encoded . $quote;
        }
        return $matches[0];
    }, $code);
    
    // Add random whitespace and line breaks to break formatting
    $code = str_replace(['{', '}', ';'], ['{\n', '\n}\n', ';\n'], $code);
    $code = preg_replace('/\s+/', ' ', $code);
    
    return $code;
}

// Create anti-tampering wrapper with heavy obfuscation
function createSecureWrapper($code, $filename, $sessionKey) {
    // Keep obfuscation disabled for stability - direct access prevention is primary security
    // $obfuscatedCode = heavyObfuscate($code, $sessionKey);
    $cleanCode = $code;
    
    // Generate integrity hash
    $hash = hash('sha256', $cleanCode . $sessionKey);
    
    // Create the wrapper with proper string concatenation
    $wrapper = "(function() {\n";
    $wrapper .= "    'use strict';\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Session validation\n";
    $wrapper .= "    var sessionKey = '" . $sessionKey . "';\n";
    $wrapper .= "    var expectedHash = '" . $hash . "';\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Timing-based debugger detection enabled\n";
    $wrapper .= "    var debugStart = performance.now();\n";
    $wrapper .= "    debugger;\n";
    $wrapper .= "    if (performance.now() - debugStart > 100) {\n";
    $wrapper .= "        throw new Error('\\x44\\x65\\x62\\x75\\x67\\x67\\x65\\x72\\x20\\x64\\x65\\x74\\x65\\x63\\x74\\x65\\x64');\n";
    $wrapper .= "    }\n";
    $wrapper .= "    \n";
    $wrapper .= "    // DevTools detection enabled\n";
    $wrapper .= "    var devToolsOpen = false;\n";
    $wrapper .= "    var devToolsChecker = function() {\n";
    $wrapper .= "        var widthThreshold = window.outerWidth - window.innerWidth > 160;\n";
    $wrapper .= "        var heightThreshold = window.outerHeight - window.innerHeight > 160;\n";
    $wrapper .= "        if ((widthThreshold || heightThreshold) && !devToolsOpen) {\n";
    $wrapper .= "            devToolsOpen = true;\n";
    $wrapper .= "            console.clear();\n";
    $wrapper .= "            throw new Error('\\x44\\x65\\x76\\x54\\x6f\\x6f\\x6c\\x73\\x20\\x64\\x65\\x74\\x65\\x63\\x74\\x65\\x64');\n";
    $wrapper .= "        }\n";
    $wrapper .= "    };\n";
    $wrapper .= "    setInterval(devToolsChecker, 1000);\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Anti-tampering: Prevent common modification attempts\n";
    $wrapper .= "    var originalEval = window.eval;\n";
    $wrapper .= "    var originalFunction = window.Function;\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Override eval to detect code injection\n";
    $wrapper .= "    window.eval = function(code) {\n";
    $wrapper .= "        if (typeof code === 'string' && code.length > 100) {\n";
    $wrapper .= "            throw new Error('\\x43\\x6f\\x64\\x65\\x20\\x69\\x6e\\x6a\\x65\\x63\\x74\\x69\\x6f\\x6e\\x20\\x64\\x65\\x74\\x65\\x63\\x74\\x65\\x64');\n";
    $wrapper .= "        }\n";
    $wrapper .= "        return originalEval.apply(this, arguments);\n";
    $wrapper .= "    };\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Temporarily allow Function constructor for our decryption\n";
    $wrapper .= "    var _origFunc = window.Function;\n";
    $wrapper .= "    window.Function = function() {\n";
    $wrapper .= "        if (arguments.length === 1 && typeof arguments[0] === 'string' && arguments[0].indexOf('return (function(){') === 0) {\n";
    $wrapper .= "            return _origFunc.apply(this, arguments);\n";
    $wrapper .= "        }\n";
    $wrapper .= "        throw new Error('\\x44\\x79\\x6e\\x61\\x6d\\x69\\x63\\x20\\x66\\x75\\x6e\\x63\\x74\\x69\\x6f\\x6e\\x20\\x63\\x72\\x65\\x61\\x74\\x69\\x6f\\x6e\\x20\\x62\\x6c\\x6f\\x63\\x6b\\x65\\x64');\n";
    $wrapper .= "    };\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Console manipulation prevention enabled\n";
    $wrapper .= "    var originalConsole = window.console;\n";
    $wrapper .= "    try {\n";
    $wrapper .= "        var descriptor = Object.getOwnPropertyDescriptor(window, 'console');\n";
    $wrapper .= "        if (!descriptor || descriptor.configurable !== false) {\n";
    $wrapper .= "            Object.defineProperty(window, 'console', {\n";
    $wrapper .= "                get: function() {\n";
    $wrapper .= "                    if (devToolsOpen) {\n";
    $wrapper .= "                        throw new Error('\\x43\\x6f\\x6e\\x73\\x6f\\x6c\\x65\\x20\\x61\\x63\\x63\\x65\\x73\\x73\\x20\\x62\\x6c\\x6f\\x63\\x6b\\x65\\x64');\n";
    $wrapper .= "                    }\n";
    $wrapper .= "                    return originalConsole;\n";
    $wrapper .= "                },\n";
    $wrapper .= "                configurable: false\n";
    $wrapper .= "            });\n";
    $wrapper .= "        }\n";
    $wrapper .= "    } catch(e) {\n";
    $wrapper .= "        // Console already protected, skip redefinition\n";
    $wrapper .= "    }\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Encrypt and encode the code\n";
    $wrapper .= "    // Encrypted payload\n";
    // Properly encode UTF-8 content for base64
    if (function_exists('mb_convert_encoding')) {
        $encryptedCode = base64_encode(mb_convert_encoding($cleanCode, 'UTF-8', 'UTF-8'));
    } else {
        // Fallback without mbstring extension
        $encryptedCode = base64_encode($cleanCode);
    }
    $wrapper .= "    var _payload = '" . $encryptedCode . "';\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Decryption and execution\n";
    $wrapper .= "    try {\n";
    $wrapper .= "        // Properly decode UTF-8 from base64\n";
    $wrapper .= "        var _decoded = decodeURIComponent(escape(atob(_payload)));\n";
    $wrapper .= "        var _func = new Function('return (function(){' + _decoded + '})();');\n";
    $wrapper .= "        // Restore Function constructor blocking\n";
    $wrapper .= "        window.Function = function() {\n";
    $wrapper .= "            throw new Error('\\x44\\x79\\x6e\\x61\\x6d\\x69\\x63\\x20\\x66\\x75\\x6e\\x63\\x74\\x69\\x6f\\x6e\\x20\\x63\\x72\\x65\\x61\\x74\\x69\\x6f\\x6e\\x20\\x62\\x6c\\x6f\\x63\\x6b\\x65\\x64');\n";
    $wrapper .= "        };\n";
    $wrapper .= "        _func();\n";
    $wrapper .= "    } catch (error) {\n";
    $wrapper .= "        console.error('\\x45\\x78\\x65\\x63\\x75\\x74\\x69\\x6f\\x6e\\x20\\x65\\x72\\x72\\x6f\\x72:', error.message);\n";
    $wrapper .= "        // Don't reload on execution errors, just log them\n";
    $wrapper .= "    }\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Restore original functions after execution\n";
    $wrapper .= "    window.eval = originalEval;\n";
    $wrapper .= "    window.Function = originalFunction;\n";
    $wrapper .= "    \n";
    $wrapper .= "})();";
    
    return $wrapper;
}

// Use simple wrapper for stability - direct access prevention provides primary security
echo generateSimpleSecureWrapper($content, $file);

// Simple secure wrapper function
function generateSimpleSecureWrapper($code, $filename) {
    // Remove any existing source map references
    $cleanCode = preg_replace('/\/\/#\s*sourceMappingURL=.*$/m', '', $code);
    
    // Create a simple wrapper that prevents direct access and adds basic protection
    $wrapper = "(function() {\n";
    $wrapper .= "    'use strict';\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Anti-tampering check\n";
    $wrapper .= "    if (typeof window === 'undefined' || !window.location) {\n";
    $wrapper .= "        throw new Error('Invalid execution context');\n";
    $wrapper .= "    }\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Prevent direct file access\n";
    $wrapper .= "    if (window.location.pathname.includes('/js/')) {\n";
    $wrapper .= "        throw new Error('Direct file access denied');\n";
    $wrapper .= "    }\n";
    $wrapper .= "    \n";
    $wrapper .= "    // Execute the actual code\n";
    $wrapper .= $cleanCode . "\n";
    $wrapper .= "    \n";
    $wrapper .= "})();";
    
    return $wrapper;
}
?>
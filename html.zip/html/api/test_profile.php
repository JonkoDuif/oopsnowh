<?php
// Skip access control for API endpoints
define('SKIP_ACCESS_CHECK', true);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Return mock profile data for testing
$mockProfile = [
    'username' => 'TestUser',
    'games_played' => 42,
    'games_won' => 28,
    'total_kills' => 256,
    'total_survival_time' => 15600, // in seconds
    'total_play_time' => 86400, // in seconds (24 hours)
    'total_earnings' => 189.75,
    'max_mass' => 7500,
    'rank' => 'Gold',
    'level' => 15
];

echo json_encode([
    'success' => true,
    'profile' => $mockProfile
]);
?>
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../database_improved.php';
require_once '../auth.php';

// Check if user is authenticated
$user = verifyAuth();
if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($action) {
        case 'search_users':
            if ($method === 'GET') {
                searchUsers();
            }
            break;
            
        case 'send_friend_request':
            if ($method === 'POST') {
                sendFriendRequest();
            }
            break;
            
        case 'respond_friend_request':
            if ($method === 'POST') {
                respondFriendRequest();
            }
            break;
            
        case 'get_friends':
            if ($method === 'GET') {
                getFriends();
            }
            break;
            
        case 'get_friend_requests':
            if ($method === 'GET') {
                getFriendRequests();
            }
            break;
            
        case 'get_leaderboard':
            if ($method === 'GET') {
                getLeaderboard();
            }
            break;
            
        case 'get_user_stats':
            if ($method === 'GET') {
                getUserStats();
            }
            break;
            
        case 'get_online_status':
            if ($method === 'GET') {
                getOnlineStatus();
            }
            break;
            
        case 'send_money':
            if ($method === 'POST') {
                sendMoney();
            }
            break;
            
        case 'block_user':
            if ($method === 'POST') {
                blockUser();
            }
            break;
            
        case 'unblock_user':
            if ($method === 'POST') {
                unblockUser();
            }
            break;
            
        case 'remove_friend':
            if ($method === 'POST') {
                removeFriend();
            }
            break;
            
        case 'update_online_status':
            if ($method === 'POST') {
                updateOnlineStatus();
            }
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => 'Action not found']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

function searchUsers() {
    global $pdo, $user;
    
    $query = $_GET['query'] ?? '';
    if (strlen($query) < 2) {
        echo json_encode(['users' => []]);
        return;
    }
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.balance, 
               CASE WHEN s.user_id IS NOT NULL THEN 'online' ELSE 'offline' END as status,
               CASE WHEN f.id IS NOT NULL THEN 'friend' 
                    WHEN fr.id IS NOT NULL THEN 'pending' 
                    WHEN b.id IS NOT NULL THEN 'blocked'
                    ELSE 'none' END as relationship
        FROM users u
        LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
        LEFT JOIN friendships f ON ((f.user_id = ? AND f.friend_id = u.id) OR (f.friend_id = ? AND f.user_id = u.id)) AND f.status = 'accepted'
        LEFT JOIN friend_requests fr ON ((fr.sender_id = ? AND fr.receiver_id = u.id) OR (fr.receiver_id = ? AND fr.sender_id = u.id)) AND fr.status = 'pending'
        LEFT JOIN blocked_users b ON (b.blocker_id = ? AND b.blocked_id = u.id) OR (b.blocked_id = ? AND b.blocker_id = u.id)
        WHERE u.username LIKE ? AND u.id != ?
        ORDER BY u.username
        LIMIT 10
    ");
    
    $searchTerm = '%' . $query . '%';
    $stmt->execute([$user['id'], $user['id'], $user['id'], $user['id'], $user['id'], $user['id'], $searchTerm, $user['id']]);
    
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['users' => $users]);
}

function sendFriendRequest() {
    global $pdo, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $receiverId = $input['receiver_id'] ?? 0;
    
    if (!$receiverId) {
        http_response_code(400);
        echo json_encode(['error' => 'Receiver ID required']);
        return;
    }
    
    // Check if already friends or request exists
    $stmt = $pdo->prepare("
        SELECT 'friend' as type FROM friendships 
        WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)) AND status = 'accepted'
        UNION
        SELECT 'request' as type FROM friend_requests 
        WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) AND status = 'pending'
    ");
    $stmt->execute([$user['id'], $receiverId, $receiverId, $user['id'], $user['id'], $receiverId, $receiverId, $user['id']]);
    
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Friend request already exists or already friends']);
        return;
    }
    
    // Send friend request
    $stmt = $pdo->prepare("INSERT INTO friend_requests (sender_id, receiver_id, status, created_at) VALUES (?, ?, 'pending', NOW())");
    $stmt->execute([$user['id'], $receiverId]);
    
    echo json_encode(['success' => true, 'message' => 'Friend request sent']);
}

function respondFriendRequest() {
    global $pdo, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $requestId = $input['request_id'] ?? 0;
    $response = $input['response'] ?? ''; // 'accept' or 'decline'
    
    if (!$requestId || !in_array($response, ['accept', 'decline'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid request']);
        return;
    }
    
    // Get the friend request
    $stmt = $pdo->prepare("SELECT * FROM friend_requests WHERE id = ? AND receiver_id = ? AND status = 'pending'");
    $stmt->execute([$requestId, $user['id']]);
    $request = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$request) {
        http_response_code(404);
        echo json_encode(['error' => 'Friend request not found']);
        return;
    }
    
    $pdo->beginTransaction();
    
    try {
        // Update request status
        $stmt = $pdo->prepare("UPDATE friend_requests SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$response === 'accept' ? 'accepted' : 'declined', $requestId]);
        
        // If accepted, create friendship
        if ($response === 'accept') {
            $stmt = $pdo->prepare("INSERT INTO friendships (user_id, friend_id, status, created_at) VALUES (?, ?, 'accepted', NOW())");
            $stmt->execute([$request['sender_id'], $user['id']]);
        }
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Friend request ' . $response . 'ed']);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function getFriends() {
    global $pdo, $user;
    
    $filter = $_GET['filter'] ?? 'all'; // all, online, offline
    
    $whereClause = '';
    if ($filter === 'online') {
        $whereClause = 'AND s.user_id IS NOT NULL';
    } elseif ($filter === 'offline') {
        $whereClause = 'AND s.user_id IS NULL';
    }
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.balance,
               CASE WHEN s.user_id IS NOT NULL THEN 'online' ELSE 'offline' END as status,
               gs.total_kills, gs.total_winnings, gs.games_played, gs.total_deaths,
               CASE WHEN gs.games_played > 0 THEN ROUND(gs.total_kills / gs.games_played, 2) ELSE 0 END as avg_kills
        FROM friendships f
        JOIN users u ON (f.friend_id = u.id AND f.user_id = ?) OR (f.user_id = u.id AND f.friend_id = ?)
        LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
        LEFT JOIN game_stats gs ON u.id = gs.user_id
        WHERE f.status = 'accepted' AND u.id != ? $whereClause
        ORDER BY 
            CASE WHEN s.user_id IS NOT NULL THEN 0 ELSE 1 END,
            u.username
    ");
    
    $stmt->execute([$user['id'], $user['id'], $user['id']]);
    $friends = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['friends' => $friends]);
}

function getFriendRequests() {
    global $pdo, $user;
    
    $type = $_GET['type'] ?? 'received'; // received, sent
    
    if ($type === 'received') {
        $stmt = $pdo->prepare("
            SELECT fr.id, fr.sender_id as user_id, u.username, fr.created_at,
                   CASE WHEN s.user_id IS NOT NULL THEN 'online' ELSE 'offline' END as status
            FROM friend_requests fr
            JOIN users u ON fr.sender_id = u.id
            LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
            WHERE fr.receiver_id = ? AND fr.status = 'pending'
            ORDER BY fr.created_at DESC
        ");
        $stmt->execute([$user['id']]);
    } else {
        $stmt = $pdo->prepare("
            SELECT fr.id, fr.receiver_id as user_id, u.username, fr.created_at,
                   CASE WHEN s.user_id IS NOT NULL THEN 'online' ELSE 'offline' END as status
            FROM friend_requests fr
            JOIN users u ON fr.receiver_id = u.id
            LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
            WHERE fr.sender_id = ? AND fr.status = 'pending'
            ORDER BY fr.created_at DESC
        ");
        $stmt->execute([$user['id']]);
    }
    
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['requests' => $requests]);
}

function getLeaderboard() {
    global $pdo, $user;
    
    $type = $_GET['type'] ?? 'friends'; // friends, global
    $limit = $_GET['limit'] ?? 10;
    
    if ($type === 'friends') {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, gs.total_winnings, gs.total_kills, gs.games_played,
                   CASE WHEN s.user_id IS NOT NULL THEN 'online' ELSE 'offline' END as status
            FROM friendships f
            JOIN users u ON (f.friend_id = u.id AND f.user_id = ?) OR (f.user_id = u.id AND f.friend_id = ?)
            LEFT JOIN game_stats gs ON u.id = gs.user_id
            LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
            WHERE f.status = 'accepted' AND u.id != ?
            ORDER BY gs.total_winnings DESC
            LIMIT ?
        ");
        $stmt->execute([$user['id'], $user['id'], $user['id'], $limit]);
    } else {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, gs.total_winnings, gs.total_kills, gs.games_played,
                   CASE WHEN s.user_id IS NOT NULL THEN 'online' ELSE 'offline' END as status
            FROM users u
            LEFT JOIN game_stats gs ON u.id = gs.user_id
            LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
            ORDER BY gs.total_winnings DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
    }
    
    $leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['leaderboard' => $leaderboard]);
}

function getUserStats() {
    global $pdo, $user;
    
    $userId = $_GET['user_id'] ?? $user['id'];
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.balance, u.created_at,
               gs.total_kills, gs.total_winnings, gs.games_played, gs.total_deaths,
               CASE WHEN gs.games_played > 0 THEN ROUND(gs.total_kills / gs.games_played, 2) ELSE 0 END as avg_kills,
               CASE WHEN gs.total_deaths > 0 THEN ROUND(gs.total_kills / gs.total_deaths, 2) ELSE gs.total_kills END as kd_ratio
        FROM users u
        LEFT JOIN game_stats gs ON u.id = gs.user_id
        WHERE u.id = ?
    ");
    
    $stmt->execute([$userId]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$stats) {
        http_response_code(404);
        echo json_encode(['error' => 'User not found']);
        return;
    }
    
    echo json_encode(['stats' => $stats]);
}

function getOnlineStatus() {
    global $pdo;
    
    $userIds = $_GET['user_ids'] ?? '';
    if (!$userIds) {
        echo json_encode(['status' => []]);
        return;
    }
    
    $userIdArray = explode(',', $userIds);
    $placeholders = str_repeat('?,', count($userIdArray) - 1) . '?';
    
    $stmt = $pdo->prepare("
        SELECT u.id, 
               CASE WHEN s.user_id IS NOT NULL THEN 'online' ELSE 'offline' END as status
        FROM users u
        LEFT JOIN sessions s ON u.id = s.user_id AND s.expires_at > NOW()
        WHERE u.id IN ($placeholders)
    ");
    
    $stmt->execute($userIdArray);
    $statuses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $statusMap = [];
    foreach ($statuses as $status) {
        $statusMap[$status['id']] = $status['status'];
    }
    
    echo json_encode(['status' => $statusMap]);
}

function sendMoney() {
    global $pdo, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $receiverId = $input['receiver_id'] ?? 0;
    $amount = floatval($input['amount'] ?? 0);
    
    if (!$receiverId || $amount <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid receiver or amount']);
        return;
    }
    
    if ($amount > $user['balance']) {
        http_response_code(400);
        echo json_encode(['error' => 'Insufficient balance']);
        return;
    }
    
    // Check if receiver exists and is a friend
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.wallet_address
        FROM users u
        JOIN friendships f ON ((f.user_id = ? AND f.friend_id = u.id) OR (f.friend_id = ? AND f.user_id = u.id))
        WHERE u.id = ? AND f.status = 'accepted'
    ");
    $stmt->execute([$user['id'], $user['id'], $receiverId]);
    $receiver = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$receiver) {
        http_response_code(400);
        echo json_encode(['error' => 'Receiver not found or not a friend']);
        return;
    }
    
    $pdo->beginTransaction();
    
    try {
        // Deduct from sender
        $stmt = $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$amount, $user['id']]);
        
        // Add to receiver
        $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $receiverId]);
        
        // Record transaction
        $stmt = $pdo->prepare("
            INSERT INTO wallet_transactions (user_id, type, amount, status, transaction_hash, created_at, metadata)
            VALUES (?, 'transfer_out', ?, 'completed', ?, NOW(), ?)
        ");
        $metadata = json_encode(['receiver_id' => $receiverId, 'receiver_username' => $receiver['username']]);
        $stmt->execute([$user['id'], $amount, 'internal_transfer_' . uniqid(), $metadata]);
        
        $stmt = $pdo->prepare("
            INSERT INTO wallet_transactions (user_id, type, amount, status, transaction_hash, created_at, metadata)
            VALUES (?, 'transfer_in', ?, 'completed', ?, NOW(), ?)
        ");
        $metadata = json_encode(['sender_id' => $user['id'], 'sender_username' => $user['username']]);
        $stmt->execute([$receiverId, $amount, 'internal_transfer_' . uniqid(), $metadata]);
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Money sent successfully']);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function blockUser() {
    global $pdo, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $blockedId = $input['user_id'] ?? 0;
    
    if (!$blockedId) {
        http_response_code(400);
        echo json_encode(['error' => 'User ID required']);
        return;
    }
    
    $pdo->beginTransaction();
    
    try {
        // Remove friendship if exists
        $stmt = $pdo->prepare("DELETE FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
        $stmt->execute([$user['id'], $blockedId, $blockedId, $user['id']]);
        
        // Remove friend requests
        $stmt = $pdo->prepare("DELETE FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
        $stmt->execute([$user['id'], $blockedId, $blockedId, $user['id']]);
        
        // Add to blocked users
        $stmt = $pdo->prepare("INSERT IGNORE INTO blocked_users (blocker_id, blocked_id, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$user['id'], $blockedId]);
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'User blocked successfully']);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function unblockUser() {
    global $pdo, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $blockedId = $input['user_id'] ?? 0;
    
    if (!$blockedId) {
        http_response_code(400);
        echo json_encode(['error' => 'User ID required']);
        return;
    }
    
    $stmt = $pdo->prepare("DELETE FROM blocked_users WHERE blocker_id = ? AND blocked_id = ?");
    $stmt->execute([$user['id'], $blockedId]);
    
    echo json_encode(['success' => true, 'message' => 'User unblocked successfully']);
}

function removeFriend() {
    global $pdo, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $friendId = $input['friend_id'] ?? 0;
    
    if (!$friendId) {
        http_response_code(400);
        echo json_encode(['error' => 'Friend ID required']);
        return;
    }
    
    $stmt = $pdo->prepare("DELETE FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
    $stmt->execute([$user['id'], $friendId, $friendId, $user['id']]);
    
    echo json_encode(['success' => true, 'message' => 'Friend removed successfully']);
}

function updateOnlineStatus() {
    global $pdo, $user;
    
    // This function is called to keep the session alive and update last activity
    $stmt = $pdo->prepare("UPDATE sessions SET last_activity = NOW() WHERE user_id = ? AND expires_at > NOW()");
    $stmt->execute([$user['id']]);
    
    echo json_encode(['success' => true]);
}
?>
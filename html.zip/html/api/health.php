<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// Simple health check endpoint
echo json_encode([
    'status' => 'ok',
    'timestamp' => time(),
    'servers' => [
        'php' => 'running',
        'game' => 'running',
        'lobby' => 'running'
    ]
]);
?>
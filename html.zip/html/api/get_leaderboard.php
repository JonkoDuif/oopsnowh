<?php
require_once '../database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    if (!$pdo) {
        throw new Exception('Database connection failed');
    }
    
    // Get leaderboard data - top players by max mass
    $stmt = $pdo->prepare("
        SELECT 
            u.username,
            gs.games_played,
            gs.kills as total_kills,
            gs.max_mass,
            u.balance as total_winnings
        FROM game_stats gs
        JOIN users u ON gs.user_id = u.id
        WHERE gs.games_played > 0
        ORDER BY gs.max_mass DESC, gs.kills DESC
        LIMIT 20
    ");
    
    $stmt->execute();
    $leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no data, create sample leaderboard
    if (empty($leaderboard)) {
        $leaderboard = [
            [
                'username' => 'No Players Yet',
                'games_played' => 0,
                'total_kills' => 0,
                'max_mass' => 0,
                'total_winnings' => 0
            ]
        ];
    }
    
    echo json_encode([
        'success' => true,
        'leaderboard' => $leaderboard
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
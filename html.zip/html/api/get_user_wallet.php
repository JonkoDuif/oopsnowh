<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../php/config.php';
require_once '../php/auth.php';

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST method allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
    exit;
}

$user_id = $input['user_id'] ?? null;
$session_token = $input['session_token'] ?? null;

if (!$user_id || !$session_token) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    // Verify session token
    $auth = new Auth($pdo);
    $current_user = $auth->validateSession($session_token);
    
    if (!$current_user) {
        echo json_encode(['success' => false, 'error' => 'Invalid session']);
        exit;
    }
    
    // Get target user's wallet address
    $stmt = $pdo->prepare("SELECT wallet_address FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    if (!$user['wallet_address']) {
        echo json_encode(['success' => false, 'error' => 'User does not have a wallet address']);
        exit;
    }
    
    echo json_encode([
        'success' => true,
        'wallet_address' => $user['wallet_address']
    ]);
    
} catch (Exception $e) {
    error_log("Get user wallet error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error']);
}
?>
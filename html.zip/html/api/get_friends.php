<?php
// Skip access control for API endpoints
define('SKIP_ACCESS_CHECK', true);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Include database configuration
require_once __DIR__ . '/../database.php';

try {
    // Connect to MySQL database
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    if (!$pdo) {
        throw new Exception('Database connection failed');
    }
    
    $user_id = $_GET['user_id'] ?? $_GET['user'] ?? '';
    
    if (empty($user_id)) {
        echo json_encode(['success' => false, 'error' => 'User ID parameter required']);
        exit;
    }
    
    // Get friends from database
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.created_at, 
               CASE WHEN us.last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE) THEN 1 ELSE 0 END as is_online,
               CASE 
                   WHEN us.last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE) THEN 'Online'
                   WHEN us.last_activity > DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN CONCAT(TIMESTAMPDIFF(MINUTE, us.last_activity, NOW()), ' minutes ago')
                   WHEN us.last_activity > DATE_SUB(NOW(), INTERVAL 1 DAY) THEN CONCAT(TIMESTAMPDIFF(HOUR, us.last_activity, NOW()), ' hours ago')
                   ELSE CONCAT(TIMESTAMPDIFF(DAY, us.last_activity, NOW()), ' days ago')
               END as last_seen
        FROM friendships f
        JOIN users u ON (f.friend_id = u.id)
        LEFT JOIN user_sessions us ON (u.id = us.user_id)
        WHERE f.user_id = ?
        ORDER BY us.last_activity DESC, u.username ASC
    ");
    
    $stmt->execute([$user_id]);
    $friends = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'friends' => $friends
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
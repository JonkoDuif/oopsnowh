<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST method allowed']);
    exit;
}

// Include database configuration
require_once __DIR__ . '/../database.php';

try {
    // Connect to MySQL database
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    if (!$pdo) {
        throw new Exception('Database connection failed');
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
        exit;
    }
    
    // Required fields
    $user_id = $input['user_id'] ?? '';
    $game_mode = $input['game_mode'] ?? 'battle_royale';
    $score = (float)($input['score'] ?? 0);
    $kills = (int)($input['kills'] ?? 0);
    $survival_time = (int)($input['survival_time'] ?? 0);
    $won = (bool)($input['won'] ?? false);
    
    if (empty($user_id)) {
        echo json_encode(['success' => false, 'error' => 'user_id is required']);
        exit;
    }
    
    // Insert game stats
    $stmt = $pdo->prepare("
        INSERT INTO game_stats (
            user_id, game_mode, score, kills, survival_time, won, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
    ");
    
    $stmt->execute([
        $user_id,
        $game_mode,
        $score,
        $kills,
        $survival_time,
        $won ? 1 : 0
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Game stats saved successfully',
        'game_id' => $pdo->lastInsertId()
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
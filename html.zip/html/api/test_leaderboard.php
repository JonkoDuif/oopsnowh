<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Return mock leaderboard data for testing
$mockLeaderboard = [
    [
        'username' => 'TestPlayer1',
        'games_played' => 25,
        'total_kills' => 150,
        'max_mass' => 5000,
        'total_winnings' => 125.50
    ],
    [
        'username' => 'TestPlayer2', 
        'games_played' => 18,
        'total_kills' => 89,
        'max_mass' => 3200,
        'total_winnings' => 89.25
    ],
    [
        'username' => 'TestPlayer3',
        'games_played' => 12,
        'total_kills' => 67,
        'max_mass' => 2800,
        'total_winnings' => 67.75
    ]
];

echo json_encode([
    'success' => true,
    'leaderboard' => $mockLeaderboard
]);
?>
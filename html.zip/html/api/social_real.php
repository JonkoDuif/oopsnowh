<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../database_improved.php';

$db = Database::getInstance();

if (!$db->isConnected()) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$userId = $_GET['user_id'] ?? $_POST['user_id'] ?? 1; // Default to user 1 for testing

switch ($action) {
    case 'get_friends':
        $friends = $db->getFriends($userId);
        echo json_encode(['friends' => $friends]);
        break;
        
    case 'get_leaderboard':
        $limit = $_GET['limit'] ?? 10;
        $leaderboard = $db->getFriendsLeaderboard($userId, $limit);
        echo json_encode(['leaderboard' => $leaderboard]);
        break;
        
    case 'search_users':
        $searchTerm = $_GET['search'] ?? $_POST['search'] ?? '';
        if (empty($searchTerm)) {
            echo json_encode(['error' => 'Search term required']);
            break;
        }
        $users = $db->searchUsers($searchTerm, $userId);
        echo json_encode(['users' => $users]);
        break;
        
    case 'send_friend_request':
        $friendId = $_POST['friend_id'] ?? '';
        if (empty($friendId)) {
            echo json_encode(['error' => 'Friend ID required']);
            break;
        }
        $result = $db->sendFriendRequest($userId, $friendId);
        echo json_encode(['success' => $result]);
        break;
        
    case 'respond_friend_request':
        $friendId = $_POST['friend_id'] ?? '';
        $response = $_POST['response'] ?? ''; // 'accept' or 'decline'
        if (empty($friendId) || empty($response)) {
            echo json_encode(['error' => 'Friend ID and response required']);
            break;
        }
        $result = $db->respondToFriendRequest($userId, $friendId, $response);
        echo json_encode(['success' => $result]);
        break;
        
    case 'get_friend_requests':
        $requests = $db->getFriends($userId, 'pending');
        echo json_encode(['requests' => $requests]);
        break;
        
    case 'get_user_stats':
        $targetUserId = $_GET['target_user_id'] ?? $userId;
        $stats = $db->getUserGameStats($targetUserId);
        $userInfo = $db->getUserById($targetUserId);
        
        if ($stats && $userInfo) {
            $response = [
                'user' => [
                    'id' => $userInfo['id'],
                    'username' => $userInfo['username'],
                    'total_winnings' => floatval($userInfo['total_winnings']),
                    'games_played' => intval($userInfo['games_played'])
                ],
                'stats' => [
                    'total_games' => intval($stats['total_games']),
                    'total_kills' => intval($stats['total_kills']),
                    'total_deaths' => intval($stats['total_deaths']),
                    'total_winnings' => floatval($stats['total_winnings']),
                    'avg_kills' => floatval($stats['avg_kills']),
                    'avg_duration' => floatval($stats['avg_duration'])
                ]
            ];
        } else {
            $response = [
                'user' => $userInfo ? [
                    'id' => $userInfo['id'],
                    'username' => $userInfo['username'],
                    'total_winnings' => floatval($userInfo['total_winnings']),
                    'games_played' => intval($userInfo['games_played'])
                ] : null,
                'stats' => [
                    'total_games' => 0,
                    'total_kills' => 0,
                    'total_deaths' => 0,
                    'total_winnings' => 0,
                    'avg_kills' => 0,
                    'avg_duration' => 0
                ]
            ];
        }
        echo json_encode($response);
        break;
        
    case 'update_session':
        $sessionToken = $_POST['session_token'] ?? session_id();
        $result = $db->updateUserSession($userId, $sessionToken);
        echo json_encode(['success' => $result]);
        break;
        
    case 'remove_session':
        $sessionToken = $_POST['session_token'] ?? session_id();
        $result = $db->removeUserSession($sessionToken);
        echo json_encode(['success' => $result]);
        break;
        
    case 'add_game_stats':
        $gameType = $_POST['game_type'] ?? 'battle_royale';
        $kills = intval($_POST['kills'] ?? 0);
        $deaths = intval($_POST['deaths'] ?? 0);
        $winnings = floatval($_POST['winnings'] ?? 0);
        $duration = intval($_POST['duration'] ?? 0);
        $placement = intval($_POST['placement'] ?? 0);
        
        $result = $db->addGameStats($userId, $gameType, $kills, $deaths, $winnings, $duration, $placement);
        echo json_encode(['success' => $result]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}
?>
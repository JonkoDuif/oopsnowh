<?php
// Skip access control for API endpoints
define('SKIP_ACCESS_CHECK', true);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Include database configuration
require_once __DIR__ . '/../database.php';

try {
    // Connect to MySQL database
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    if (!$pdo) {
        throw new Exception('Database connection failed');
    }
    
    $query = $_GET['q'] ?? '';
    
    if (empty($query) || strlen($query) < 2) {
        echo json_encode(['success' => false, 'error' => 'Search query must be at least 2 characters']);
        exit;
    }
    
    // Search for users in game_stats table
    $stmt = $pdo->prepare("
        SELECT 
            user_id as username,
            COUNT(*) as games_played,
            SUM(score) as total_earnings
        FROM game_stats 
        WHERE user_id LIKE ? 
        GROUP BY user_id 
        ORDER BY total_earnings DESC
        LIMIT 10
    ");
    
    $searchTerm = '%' . $query . '%';
    $stmt->execute([$searchTerm]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no users found, create sample results
    if (empty($users) && strtolower($query) === 'player') {
        $users = [
            [
                'username' => 'Player1',
                'games_played' => 5,
                'total_earnings' => 100
            ],
            [
                'username' => 'Player2',
                'games_played' => 3,
                'total_earnings' => 50
            ]
        ];
    }
    
    echo json_encode([
        'success' => true,
        'users' => $users
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../php/config.php';
require_once '../php/auth.php';

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Only POST method allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
    exit;
}

$from_user_id = $input['from_user_id'] ?? null;
$to_user_id = $input['to_user_id'] ?? null;
$amount = $input['amount'] ?? null;
$signature = $input['signature'] ?? null;
$session_token = $input['session_token'] ?? null;

if (!$from_user_id || !$to_user_id || !$amount || !$signature || !$session_token) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

// Validate amount
if (!is_numeric($amount) || $amount <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid amount']);
    exit;
}

try {
    // Verify session token
    $auth = new Auth($pdo);
    $current_user = $auth->validateSession($session_token);
    
    if (!$current_user) {
        echo json_encode(['success' => false, 'error' => 'Invalid session']);
        exit;
    }
    
    // Verify that the current user is the sender
    if ($current_user['id'] != $from_user_id) {
        echo json_encode(['success' => false, 'error' => 'Unauthorized: You can only send from your own account']);
        exit;
    }
    
    // Check if transfer table exists, create if not
    $pdo->exec("CREATE TABLE IF NOT EXISTS money_transfers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        from_user_id INT NOT NULL,
        to_user_id INT NOT NULL,
        amount DECIMAL(20, 9) NOT NULL,
        signature VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (from_user_id) REFERENCES users(id),
        FOREIGN KEY (to_user_id) REFERENCES users(id),
        INDEX idx_from_user (from_user_id),
        INDEX idx_to_user (to_user_id),
        INDEX idx_signature (signature)
    )");
    
    // Record the transfer
    $stmt = $pdo->prepare("
        INSERT INTO money_transfers (from_user_id, to_user_id, amount, signature) 
        VALUES (?, ?, ?, ?)
    ");
    
    $stmt->execute([$from_user_id, $to_user_id, $amount, $signature]);
    
    // Get usernames for logging
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id IN (?, ?)");
    $stmt->execute([$from_user_id, $to_user_id]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $from_username = '';
    $to_username = '';
    foreach ($users as $user) {
        if ($user['id'] == $from_user_id) $from_username = $user['username'];
        if ($user['id'] == $to_user_id) $to_username = $user['username'];
    }
    
    error_log("Money transfer recorded: {$from_username} -> {$to_username}, Amount: {$amount} SOL, Signature: {$signature}");
    
    echo json_encode([
        'success' => true,
        'message' => 'Transfer recorded successfully',
        'transfer_id' => $pdo->lastInsertId()
    ]);
    
} catch (Exception $e) {
    error_log("Record transfer error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error']);
}
?>
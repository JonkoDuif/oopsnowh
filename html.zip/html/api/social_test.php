<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../database_improved.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'test':
        echo json_encode(['status' => 'success', 'message' => 'API is working']);
        break;
        
    case 'get_friends':
        // Simple test response
        echo json_encode([
            'status' => 'success',
            'friends' => [
                ['id' => 1, 'username' => 'TestUser1', 'online' => true],
                ['id' => 2, 'username' => 'TestUser2', 'online' => false]
            ]
        ]);
        break;
        
    case 'get_leaderboard':
        echo json_encode([
            'status' => 'success',
            'leaderboard' => [
                ['username' => 'Player1', 'total_winnings' => 1000, 'games_played' => 50],
                ['username' => 'Player2', 'total_winnings' => 800, 'games_played' => 40]
            ]
        ]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}
?>
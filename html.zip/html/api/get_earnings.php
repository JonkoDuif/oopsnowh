<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../database_improved.php';

try {
    $db = Database::getInstance();
    
    if (!$db->isConnected()) {
        throw new Exception('Database connection failed');
    }
    
    $userId = $_GET['user_id'] ?? 1; // Default to user 1 for testing
    $period = $_GET['period'] ?? 'ytd'; // ytd, monthly, weekly, all
    
    $conn = $db->getConnection();
    
    // Define date ranges based on period
    $dateCondition = '';
    switch ($period) {
        case 'weekly':
            $dateCondition = "AND gs.created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
            break;
        case 'monthly':
            $dateCondition = "AND gs.created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
            break;
        case 'ytd':
            $dateCondition = "AND gs.created_at >= DATE_FORMAT(NOW(), '%Y-01-01')";
            break;
        case 'all':
        default:
            $dateCondition = '';
            break;
    }
    
    // First check what columns exist in game_stats table
    $checkColumns = $conn->query("DESCRIBE game_stats");
    $columns = [];
    while ($row = $checkColumns->fetch(PDO::FETCH_ASSOC)) {
        $columns[] = $row['Field'];
    }
    
    // Check if winnings column exists, if not use bet_amount or score
    $earningsColumn = 'winnings';
    if (!in_array('winnings', $columns)) {
        if (in_array('bet_amount', $columns)) {
            $earningsColumn = 'bet_amount';
        } else {
            $earningsColumn = 'score';
        }
    }
    
    // Get earnings data with game breakdown
    $sql = "
        SELECT 
            DATE(gs.created_at) as date,
            SUM(gs.$earningsColumn) as daily_earnings,
            COUNT(*) as games_played,
            AVG(gs.$earningsColumn) as avg_winnings_per_game,
            SUM(CASE WHEN gs.$earningsColumn > 0 THEN 1 ELSE 0 END) as winning_games
        FROM game_stats gs
        WHERE gs.user_id = ? $dateCondition
        GROUP BY DATE(gs.created_at)
        ORDER BY date DESC
        LIMIT 30
    ";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([$userId]);
    $dailyEarnings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total earnings for the period
    $totalSql = "
        SELECT 
            SUM(gs.$earningsColumn) as total_earnings,
            COUNT(*) as total_games,
            SUM(CASE WHEN gs.$earningsColumn > 0 THEN 1 ELSE 0 END) as total_wins,
            AVG(gs.$earningsColumn) as avg_earnings_per_game,
            MAX(gs.$earningsColumn) as best_game,
            MIN(gs.$earningsColumn) as worst_game
        FROM game_stats gs
        WHERE gs.user_id = ? $dateCondition
    ";
    
    $stmt = $conn->prepare($totalSql);
    $stmt->execute([$userId]);
    $totals = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get earnings by game type (check if game_mode column exists)
    $gameTypeBreakdown = [];
    if (in_array('game_mode', $columns)) {
        $gameTypeSql = "
            SELECT 
                gs.game_mode as game_type,
                SUM(gs.$earningsColumn) as earnings,
                COUNT(*) as games_played,
                AVG(gs.$earningsColumn) as avg_earnings
            FROM game_stats gs
            WHERE gs.user_id = ? $dateCondition
            GROUP BY gs.game_mode
            ORDER BY earnings DESC
        ";
        
        $stmt = $conn->prepare($gameTypeSql);
        $stmt->execute([$userId]);
        $gameTypeBreakdown = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo json_encode([
        'success' => true,
        'period' => $period,
        'data' => [
            'daily_earnings' => $dailyEarnings,
            'totals' => [
                'total_earnings' => floatval($totals['total_earnings'] ?? 0),
                'total_games' => intval($totals['total_games'] ?? 0),
                'total_wins' => intval($totals['total_wins'] ?? 0),
                'avg_earnings_per_game' => floatval($totals['avg_earnings_per_game'] ?? 0),
                'best_game' => floatval($totals['best_game'] ?? 0),
                'worst_game' => floatval($totals['worst_game'] ?? 0),
                'win_rate' => $totals['total_games'] > 0 ? round(($totals['total_wins'] / $totals['total_games']) * 100, 2) : 0
            ],
            'game_type_breakdown' => $gameTypeBreakdown
        ]
    ]);
    
} catch (Exception $e) {
    error_log('Get earnings error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => [
            'daily_earnings' => [],
            'totals' => [
                'total_earnings' => 0,
                'total_games' => 0,
                'total_wins' => 0,
                'avg_earnings_per_game' => 0,
                'best_game' => 0,
                'worst_game' => 0,
                'win_rate' => 0
            ],
            'game_type_breakdown' => []
        ]
    ]);
}
?>
/**
 * Lobby Server - Handles separate WebSocket connections for each lobby
 * Each lobby operates independently with its own player pool
 */

const WebSocket = require('ws');
const http = require('http');
const https = require('https');
const fs = require('fs');
const url = require('url');

class LobbyServer {
    constructor() {
        this.lobbies = new Map(); // Map of lobby ID to lobby data
        this.server = null;
        this.wss = null;
        this.port = 8083;
        this.gameServerConnection = null;
        this.gameServerPort = 8081;
        
        this.initializeLobbies();
        this.startServer();
        this.connectToGameServer();
    }

    // Initialize lobby data structures
    initializeLobbies() {
        // Create 8 lobbies (4 per region: US 1-4, EU 5-8)
        for (let i = 1; i <= 8; i++) {
            this.lobbies.set(i, {
                id: i,
                name: `Lobby ${i}`,
                players: new Map(),
                connections: new Set(),
                gameActive: false,
                lastActivity: Date.now()
            });
        }
        console.log('🏢 Initialized 8 lobbies');
    }

    // Connect to the game server for coordination
    connectToGameServer() {
        try {
            // Use WSS in production mode
            const protocol = 'wss'; // Force WSS for production
            this.gameServerConnection = new WebSocket(`${protocol}://oopsnowh.com:${this.gameServerPort}`);
            
            this.gameServerConnection.on('open', () => {
                console.log('🎮 Connected to game server for coordination via WSS');
                // Identify this connection as the lobby server
                this.gameServerConnection.send(JSON.stringify({
                    type: 'lobby_server_connect',
                    serverType: 'lobby'
                }));
            });
            
            this.gameServerConnection.on('close', () => {
                console.log('🎮 Disconnected from game server, attempting reconnect...');
                setTimeout(() => this.connectToGameServer(), 5000);
            });
            
            this.gameServerConnection.on('error', (error) => {
                console.log('🎮 Game server connection error:', error.message);
            });
        } catch (error) {
            console.log('🎮 Failed to connect to game server:', error.message);
            setTimeout(() => this.connectToGameServer(), 5000);
        }
    }

    // Notify game server about lobby events
    notifyGameServer(message) {
        if (this.gameServerConnection && this.gameServerConnection.readyState === WebSocket.OPEN) {
            this.gameServerConnection.send(JSON.stringify(message));
        }
    }

    // Start the WebSocket server with SSL support
    startServer() {
        // ALWAYS use SSL in production - REQUIRED for security
        let useSSL = true;
        let sslOptions = {};
        
        try {
            // Check for Let's Encrypt SSL certificates
            sslOptions = {
                key: fs.readFileSync('/etc/letsencrypt/live/oopsnowh.com/privkey.pem'),
                cert: fs.readFileSync('/etc/letsencrypt/live/oopsnowh.com/fullchain.pem')
            };
            console.log('🔒 Production mode: Using HTTPS/WSS with Let\'s Encrypt certificates');
        } catch (error) {
            console.error('❌ SSL certificates REQUIRED but not found:', error.message);
            console.error('❌ Server cannot start without SSL certificates');
            process.exit(1);
        }
        
        // Create server (HTTP or HTTPS)
        if (useSSL) {
            this.server = https.createServer(sslOptions);
        } else {
            this.server = http.createServer();
        }
        
        this.wss = new WebSocket.Server({ server: this.server });

        this.wss.on('connection', (ws, request) => {
            this.handleConnection(ws, request);
        });

        this.server.listen(this.port, () => {
            const protocol = useSSL ? 'wss' : 'ws';
            const httpProtocol = useSSL ? 'https' : 'http';
            console.log(`🚀 Lobby Server running on port ${this.port}`);
            console.log(`📡 WebSocket endpoint: ${protocol}://localhost:${this.port}/lobby/{lobbyId}`);
            console.log(`🌐 HTTP endpoint: ${httpProtocol}://localhost:${this.port}`);
        });

        // Cleanup inactive connections periodically
        setInterval(() => {
            this.cleanupInactiveConnections();
        }, 30000); // Every 30 seconds
    }

    // Handle new WebSocket connection
    handleConnection(ws, request) {
        const pathname = url.parse(request.url).pathname;
        
        // Handle status check endpoint (support both /lobby/status-check and /ws-lobby/status-check)
        if (pathname === '/lobby/status-check' || pathname === '/ws-lobby/status-check') {
            console.log('✅ Status check request received for:', pathname);
            ws.send(JSON.stringify({ type: 'status', status: 'online' }));
            ws.close(1000, 'Status check complete');
            return;
        }
        
        // Support both /lobby/{id} and /ws-lobby/{id} patterns
        const lobbyMatch = pathname.match(/^\/(?:ws-)?lobby\/(\d+)$/);
        
        if (!lobbyMatch) {
            console.log('❌ Invalid lobby URL:', pathname);
            ws.close(1008, 'Invalid lobby URL');
            return;
        }

        const lobbyId = parseInt(lobbyMatch[1]);
        const lobby = this.lobbies.get(lobbyId);
        
        if (!lobby) {
            console.log(`❌ Lobby ${lobbyId} not found`);
            ws.close(1008, 'Lobby not found');
            return;
        }

        // Add connection to lobby
        lobby.connections.add(ws);
        ws.lobbyId = lobbyId;
        ws.playerId = null;
        ws.isAlive = true;
        
        console.log(`🔌 New connection to Lobby ${lobbyId}. Total connections: ${lobby.connections.size}`);

        // Setup connection handlers
        ws.on('message', (data) => {
            this.handleMessage(ws, lobbyId, data);
        });

        ws.on('close', () => {
            this.handleDisconnection(ws, lobbyId);
        });

        ws.on('error', (error) => {
            console.error(`❌ WebSocket error in Lobby ${lobbyId}:`, error);
        });

        // Ping/pong for connection health
        ws.on('pong', () => {
            ws.isAlive = true;
        });

        // Send welcome message
        this.sendToConnection(ws, {
            type: 'connected',
            lobbyId: lobbyId,
            message: `Connected to ${lobby.name}`
        });
    }

    // Handle incoming messages
    handleMessage(ws, lobbyId, data) {
        try {
            const message = JSON.parse(data);
            const lobby = this.lobbies.get(lobbyId);
            
            if (!lobby) {
                return;
            }

            lobby.lastActivity = Date.now();

            switch (message.type) {
                case 'join_lobby':
                    this.handlePlayerJoin(ws, lobbyId, message.player);
                    break;
                    
                case 'leave_lobby':
                    this.handlePlayerLeave(ws, lobbyId);
                    break;
                    
                case 'join_game':
                    this.handlePlayerJoinGame(ws, lobbyId, message.player);
                    break;
                    
                case 'player_joined_game':
                    this.handlePlayerJoinedGame(lobbyId, message.player);
                    break;
                    
                case 'player_update':
                    this.handlePlayerUpdate(lobbyId, message);
                    break;
                    
                case 'player_cashout':
                    this.handlePlayerCashout(lobbyId, message);
                    break;
                    
                case 'player_eliminated':
                    this.handlePlayerEliminated(lobbyId, message);
                    break;
                    
                default:
                    console.log(`📨 Unknown message type in Lobby ${lobbyId}:`, message.type);
            }
        } catch (error) {
            console.error(`❌ Error parsing message in Lobby ${lobbyId}:`, error);
        }
    }

    // Handle player joining lobby
    handlePlayerJoin(ws, lobbyId, player) {
        const lobby = this.lobbies.get(lobbyId);
        if (!lobby) return;

        // Check if player is already in this lobby
        if (lobby.players.has(player.id)) {
            console.log(`⚠️ Player ${player.username} already in Lobby ${lobbyId}, updating connection`);
            // Update existing player's connection
            const existingPlayer = lobby.players.get(player.id);
            existingPlayer.connection = ws;
            ws.playerId = player.id;
            return;
        }

        // Add player to lobby
        lobby.players.set(player.id, {
            ...player,
            connection: ws,
            joinedAt: Date.now()
        });
        
        ws.playerId = player.id;
        
        console.log(`👤 Player ${player.username} joined Lobby ${lobbyId}`);
        
        // Broadcast to all connections in this lobby
        this.broadcastToLobby(lobbyId, {
            type: 'player_joined',
            player: player,
            players: Array.from(lobby.players.values()).map(p => ({
                id: p.id,
                username: p.username,
                balance: p.balance
            }))
        });
    }

    // Handle player leaving lobby
    handlePlayerLeave(ws, lobbyId) {
        const lobby = this.lobbies.get(lobbyId);
        if (!lobby || !ws.playerId) return;

        const player = lobby.players.get(ws.playerId);
        if (player) {
            lobby.players.delete(ws.playerId);
            
            console.log(`👤 Player ${player.username} left Lobby ${lobbyId}`);
            
            // Notify game server about player leaving
            this.notifyGameServer({
                type: 'player_leave_game',
                lobbyId: lobbyId,
                playerId: ws.playerId
            });
            
            // Broadcast to remaining connections in this lobby
            this.broadcastToLobby(lobbyId, {
                type: 'player_left',
                player: { id: player.id, username: player.username },
                players: Array.from(lobby.players.values()).map(p => ({
                    id: p.id,
                    username: p.username,
                    balance: p.balance
                }))
            });
        }
    }

    // Handle player joining game (when ready button is clicked)
    handlePlayerJoinGame(ws, lobbyId, player) {
        const lobby = this.lobbies.get(lobbyId);
        if (!lobby) return;

        console.log(`🎮 Player ${player.name} is joining game in Lobby ${lobbyId}`);
        
        // Update player status to indicate they're in game
        const existingPlayer = lobby.players.get(ws.playerId);
        if (existingPlayer) {
            existingPlayer.inGame = true;
            existingPlayer.gameData = player;
        }
        
        // Notify game server about player joining
        this.notifyGameServer({
            type: 'player_join_game',
            lobbyId: lobbyId,
            player: {
                id: ws.playerId,
                name: player.name,
                color: player.color,
                betAmount: player.betAmount
            }
        });
        
        // Send confirmation back to the player
        this.sendToConnection(ws, {
            type: 'game_join_confirmed',
            success: true,
            lobbyId: lobbyId,
            player: player
        });
        
        // Broadcast to other players in lobby
        this.broadcastToLobby(lobbyId, {
            type: 'player_started_game',
            player: {
                name: player.name,
                color: player.color,
                betAmount: player.betAmount
            }
        }, ws.playerId);
    }

    // Handle player joining game (legacy method)
    handlePlayerJoinedGame(lobbyId, player) {
        console.log(`🎮 Player ${player.username} joined game in Lobby ${lobbyId}`);
        
        this.broadcastToLobby(lobbyId, {
            type: 'player_joined_game',
            player: player
        });
    }

    // Handle player updates (position, money, etc.)
    handlePlayerUpdate(lobbyId, message) {
        // Broadcast player updates only to the same lobby
        this.broadcastToLobby(lobbyId, {
            type: 'player_update',
            ...message
        }, message.playerId); // Exclude sender
    }

    // Handle player cashout
    handlePlayerCashout(lobbyId, message) {
        console.log(`💸 Player ${message.player.username} cashed out €${message.player.amount} in Lobby ${lobbyId}`);
        
        this.broadcastToLobby(lobbyId, {
            type: 'player_cashout',
            player: message.player,
            remainingPool: message.remainingPool
        });
    }

    // Handle player elimination
    handlePlayerEliminated(lobbyId, message) {
        console.log(`💀 Player eliminated in Lobby ${lobbyId}`);
        
        this.broadcastToLobby(lobbyId, {
            type: 'player_eliminated',
            ...message
        });
    }

    // Handle connection disconnection
    handleDisconnection(ws, lobbyId) {
        const lobby = this.lobbies.get(lobbyId);
        if (!lobby) return;

        // Remove connection
        lobby.connections.delete(ws);
        
        // Remove player if they were registered
        if (ws.playerId) {
            this.handlePlayerLeave(ws, lobbyId);
        }
        
        console.log(`🔌 Connection closed in Lobby ${lobbyId}. Remaining: ${lobby.connections.size}`);
    }

    // Send message to specific connection
    sendToConnection(ws, message) {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(message));
        }
    }

    // Broadcast message to all connections in a lobby
    broadcastToLobby(lobbyId, message, excludePlayerId = null) {
        const lobby = this.lobbies.get(lobbyId);
        if (!lobby) return;

        const messageStr = JSON.stringify(message);
        
        lobby.connections.forEach(ws => {
            if (ws.readyState === WebSocket.OPEN && ws.playerId !== excludePlayerId) {
                ws.send(messageStr);
            }
        });
    }

    // Cleanup inactive connections
    cleanupInactiveConnections() {
        this.lobbies.forEach((lobby, lobbyId) => {
            lobby.connections.forEach(ws => {
                if (!ws.isAlive) {
                    console.log(`🧹 Terminating inactive connection in Lobby ${lobbyId}`);
                    ws.terminate();
                    return;
                }
                
                ws.isAlive = false;
                ws.ping();
            });
        });
    }

    // Get lobby statistics
    getLobbyStats() {
        const stats = {};
        this.lobbies.forEach((lobby, lobbyId) => {
            stats[lobbyId] = {
                name: lobby.name,
                players: lobby.players.size,
                connections: lobby.connections.size,
                gameActive: lobby.gameActive,
                lastActivity: lobby.lastActivity
            };
        });
        return stats;
    }
}

// Start the lobby server
const lobbyServer = new LobbyServer();

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down Lobby Server...');
    if (lobbyServer.server) {
        lobbyServer.server.close(() => {
            console.log('✅ Lobby Server shut down gracefully');
            process.exit(0);
        });
    }
});

// Log stats periodically
setInterval(() => {
    const stats = lobbyServer.getLobbyStats();
    const activeLobbies = Object.values(stats).filter(lobby => lobby.players > 0).length;
    const totalPlayers = Object.values(stats).reduce((sum, lobby) => sum + lobby.players, 0);
    
    if (totalPlayers > 0) {
        console.log(`📊 Active lobbies: ${activeLobbies}, Total players: ${totalPlayers}`);
    }
}, 60000); // Every minute

console.log('🏢 Lobby Server initialized and ready!');
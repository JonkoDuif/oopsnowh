<?php
require_once 'config.php';

// For production use with PHPMailer (requires composer install phpmailer/phpmailer)
// Uncomment the following lines and install PHPMailer if you want to use SMTP

/*
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';

class PHPMailerService {
    
    public static function sendVerificationCode($email, $code) {
        $mail = new PHPMailer(true);
        
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host       = SMTP_HOST;
            $mail->SMTPAuth   = true;
            $mail->Username   = SMTP_USERNAME;
            $mail->Password   = SMTP_PASSWORD;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = SMTP_PORT;
            
            // Recipients
            $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
            $mail->addAddress($email);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your OopsNowh Verification Code';
            $mail->Body    = self::getEmailTemplate($code);
            
            $mail->send();
            error_log("Email sent successfully to $email via PHPMailer");
            return true;
            
        } catch (Exception $e) {
            error_log("PHPMailer Error: {$mail->ErrorInfo}");
            return false;
        }
    }
    
    private static function getEmailTemplate($code) {
        return "
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #a855f7, #7c3aed); color: white; padding: 30px; text-align: center; }
        .content { padding: 30px; }
        .code-box { background-color: #f8f9fa; border: 2px dashed #a855f7; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0; }
        .code { font-size: 32px; font-weight: bold; color: #a855f7; letter-spacing: 5px; }
        .footer { background-color: #f8f9fa; padding: 20px; text-align: center; color: #666; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1>🎯 OopsNowh</h1>
            <p>Skill-Based Betting Platform</p>
        </div>
        <div class='content'>
            <h2>Verification Code</h2>
            <p>Welcome to OopsNowh! Please use the verification code below to complete your login:</p>
            <div class='code-box'>
                <div class='code'>$code</div>
            </div>
            <p><strong>Important:</strong></p>
            <ul>
                <li>This code will expire in 5 minutes</li>
                <li>Don't share this code with anyone</li>
                <li>If you didn't request this code, please ignore this email</li>
            </ul>
        </div>
        <div class='footer'>
            <p>© 2024 OopsNowh. All rights reserved.</p>
            <p>This is an automated message, please do not reply.</p>
        </div>
    </div>
</body>
</html>";
    }
}
*/

// Simple fallback email service for development
class SimpleEmailService {
    
    public static function sendVerificationCode($email, $code) {
        $subject = "Your OopsNowh Verification Code: $code";
        $message = "Your verification code is: $code\n\nThis code will expire in 5 minutes.";
        $headers = "From: " . FROM_EMAIL . "\r\n" .
                   "Reply-To: " . FROM_EMAIL . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();
        
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            error_log("Sending verification code $code to $email");
            
            // Try to send email
            $result = mail($email, $subject, $message, $headers);
            
            if ($result) {
                error_log("Email sent successfully to $email");
            } else {
                error_log("Failed to send email to $email - mail() function returned false");
            }
            
            return $result;
        }
        
        return false;
    }
}
?>
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    $user = $_GET['user'] ?? '';
    
    if (empty($user)) {
        echo json_encode(['success' => false, 'error' => 'User parameter required']);
        exit;
    }
    
    // Mock data for testing - replace with real database when available
    $mockStats = [
        'games_played' => 25,
        'games_won' => 8,
        'total_kills' => 156,
        'total_survival_time' => 7200, // 2 hours in seconds
        'total_play_time' => 7200,
        'total_earnings' => 125.50
    ];
    
    // Use mock data instead of database queries
    $stats = $mockStats;
    
    // Calculate derived statistics from mock data
    $winRate = $stats['games_played'] > 0 ? ($stats['games_won'] / $stats['games_played']) * 100 : 0;
    $killsPerGame = $stats['games_played'] > 0 ? $stats['total_kills'] / $stats['games_played'] : 0;
    $avgSurvivalTime = $stats['games_played'] > 0 ? $stats['total_survival_time'] / $stats['games_played'] : 0;
    
    // Format time values (simple formatting)
    $totalPlayTimeFormatted = gmdate("H:i:s", $stats['total_play_time']);
    $avgSurvivalTimeFormatted = gmdate("H:i:s", $avgSurvivalTime);
    
    // Prepare response in the format expected by JavaScript
    $response = [
        'success' => true,
        'user' => $user,
        'stats' => [
            'games_played' => (int)$mockStats['games_played'],
            'games_won' => (int)$mockStats['games_won'],
            'total_kills' => (int)$mockStats['total_kills'],
            'total_survival_time' => (int)$avgSurvivalTime,
            'total_play_time' => (int)$mockStats['total_play_time'],
            'total_earnings' => (float)$mockStats['total_earnings']
        ]
    ];
    
    echo json_encode($response);
     
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
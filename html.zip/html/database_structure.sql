-- =====================================================
-- Agario Game Database Structure
-- Import this file directly into your MySQL database
-- =====================================================

-- Set character set and collation
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- =====================================================
-- Drop existing tables (if they exist)
-- =====================================================

DROP TABLE IF EXISTS `wallet_transactions`;
DROP TABLE IF EXISTS `friend_requests`;
DROP TABLE IF EXISTS `friendships`;
DROP TABLE IF EXISTS `user_stats`;
DROP TABLE IF EXISTS `game_stats`;
DROP TABLE IF EXISTS `sessions`;
DROP TABLE IF EXISTS `verification_codes`;
DROP TABLE IF EXISTS `users`;


-- =====================================================
-- Create Users Table
-- =====================================================

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `wallet_address` varchar(255) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  `login_count` int(11) DEFAULT 0,
  `status` enum('active','suspended','banned') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `wallet_address` (`wallet_address`),
  KEY `idx_email` (`email`),
  KEY `idx_wallet` (`wallet_address`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Create User Stats Table
-- =====================================================

CREATE TABLE `user_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total_earnings` decimal(10,2) DEFAULT 0.00,
  `total_kills` int(11) DEFAULT 0,
  `total_wins` int(11) DEFAULT 0,
  `total_losses` int(11) DEFAULT 0,
  `total_games` int(11) DEFAULT 0,
  `total_playtime` int(11) DEFAULT 0,
  `best_score` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_earnings` (`total_earnings`),
  KEY `idx_kills` (`total_kills`),
  KEY `idx_wins` (`total_wins`),
  KEY `idx_games` (`total_games`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Create Friendships Table
-- =====================================================

CREATE TABLE `friendships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_friendship` (`user_id`, `friend_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_friend_id` (`friend_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`friend_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Create Friend Requests Table
-- =====================================================

CREATE TABLE `friend_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `status` enum('pending','accepted','declined') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_request` (`sender_id`, `receiver_id`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_receiver` (`receiver_id`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Create Wallet Transactions Table
-- =====================================================

CREATE TABLE `wallet_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `fee` decimal(10,2) DEFAULT 0.00,
  `transaction_type` enum('transfer','fee') DEFAULT 'transfer',
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_receiver` (`receiver_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Create Verification Codes Table
-- =====================================================

CREATE TABLE `verification_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `code` varchar(10) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `used` tinyint(1) DEFAULT 0,
  `attempts` int(11) DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_code` (`code`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_email_code` (`email`, `code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Create Sessions Table
-- =====================================================

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_token` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token` (`session_token`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_token` (`session_token`),
  KEY `idx_active` (`is_active`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Create Game Stats Table
-- =====================================================

CREATE TABLE `game_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `game_mode` enum('classic','battle_royale','team') DEFAULT 'classic',
  `score` int(11) DEFAULT 0,
  `max_mass` int(11) DEFAULT 0,
  `survival_time` int(11) DEFAULT 0,
  `cells_eaten` int(11) DEFAULT 0,
  `players_eaten` int(11) DEFAULT 0,
  `deaths` int(11) DEFAULT 0,
  `games_played` int(11) DEFAULT 1,
  `total_playtime` int(11) DEFAULT 0,
  `highest_position` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_game_mode` (`game_mode`),
  KEY `idx_score` (`score`),
  KEY `idx_created_at` (`created_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- =====================================================
-- Insert Sample Data (Optional)
-- =====================================================

-- Sample user (for testing)
-- INSERT INTO `users` (`email`, `wallet_address`, `is_verified`, `status`) 
-- VALUES ('test@example.com', '0x1234567890123456789012345678901234567890', 1, 'active');

-- =====================================================
-- Create Views for Analytics
-- =====================================================

-- User Statistics View
CREATE VIEW `user_statistics` AS
SELECT 
    u.id,
    u.email,
    u.created_at as registration_date,
    u.last_login,
    u.login_count,
    COALESCE(SUM(gs.games_played), 0) as total_games,
    COALESCE(MAX(gs.score), 0) as best_score,
    COALESCE(MAX(gs.max_mass), 0) as best_mass,
    COALESCE(SUM(gs.total_playtime), 0) as total_playtime,
    COALESCE(SUM(gs.cells_eaten), 0) as total_cells_eaten,
    COALESCE(SUM(gs.players_eaten), 0) as total_players_eaten
FROM users u
LEFT JOIN game_stats gs ON u.id = gs.user_id
GROUP BY u.id, u.email, u.created_at, u.last_login, u.login_count;

-- Leaderboard View
CREATE VIEW `leaderboard` AS
SELECT 
    u.email,
    gs.game_mode,
    MAX(gs.score) as best_score,
    MAX(gs.max_mass) as best_mass,
    SUM(gs.games_played) as games_played,
    AVG(gs.survival_time) as avg_survival_time,
    gs.updated_at as last_played
FROM users u
JOIN game_stats gs ON u.id = gs.user_id
WHERE u.status = 'active'
GROUP BY u.id, u.email, gs.game_mode
ORDER BY best_score DESC;

-- =====================================================
-- Create Stored Procedures
-- =====================================================

DELIMITER //

-- Procedure to clean expired sessions
CREATE PROCEDURE CleanExpiredSessions()
BEGIN
    DELETE FROM sessions WHERE expires_at < NOW();
    SELECT ROW_COUNT() as deleted_sessions;
END //

-- Procedure to clean expired verification codes
CREATE PROCEDURE CleanExpiredCodes()
BEGIN
    DELETE FROM verification_codes WHERE expires_at < NOW();
    SELECT ROW_COUNT() as deleted_codes;
END //



-- Procedure to get user stats
CREATE PROCEDURE GetUserStats(IN user_email VARCHAR(255))
BEGIN
    SELECT * FROM user_statistics WHERE email = user_email;
END //

-- Procedure to update game stats
CREATE PROCEDURE UpdateGameStats(
    IN p_user_id INT,
    IN p_game_mode VARCHAR(20),
    IN p_score INT,
    IN p_max_mass INT,
    IN p_survival_time INT,
    IN p_cells_eaten INT,
    IN p_players_eaten INT
)
BEGIN
    INSERT INTO game_stats (
        user_id, game_mode, score, max_mass, survival_time, 
        cells_eaten, players_eaten
    ) VALUES (
        p_user_id, p_game_mode, p_score, p_max_mass, p_survival_time,
        p_cells_eaten, p_players_eaten
    )
    ON DUPLICATE KEY UPDATE
        score = GREATEST(score, p_score),
        max_mass = GREATEST(max_mass, p_max_mass),
        survival_time = GREATEST(survival_time, p_survival_time),
        cells_eaten = cells_eaten + p_cells_eaten,
        players_eaten = players_eaten + p_players_eaten,
        games_played = games_played + 1,
        total_playtime = total_playtime + p_survival_time;
END //

DELIMITER ;

-- =====================================================
-- Create Events for Automatic Cleanup
-- =====================================================

-- Enable event scheduler
SET GLOBAL event_scheduler = ON;

-- Event to clean expired sessions every hour
CREATE EVENT IF NOT EXISTS cleanup_sessions
ON SCHEDULE EVERY 1 HOUR
STARTS CURRENT_TIMESTAMP
DO
  CALL CleanExpiredSessions();

-- Event to clean expired codes every 30 minutes
CREATE EVENT IF NOT EXISTS cleanup_codes
ON SCHEDULE EVERY 30 MINUTE
STARTS CURRENT_TIMESTAMP
DO
  CALL CleanExpiredCodes();



-- =====================================================
-- Set Foreign Key Checks Back
-- =====================================================

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- Database Setup Complete
-- =====================================================

-- Show created tables
SHOW TABLES;

-- Show table structures
-- DESCRIBE users;
-- DESCRIBE verification_codes;
-- DESCRIBE sessions;
-- DESCRIBE game_stats;


SELECT 'Database structure created successfully!' as status;
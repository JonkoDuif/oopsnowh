#!/bin/bash

# SSL Certificate Setup Script for oopsnowh.com
# This script sets up Let's Encrypt SSL certificates for WebSocket servers

echo "🔐 Setting up SSL certificates for oopsnowh.com..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Please run this script as root (use sudo)"
    exit 1
fi

# Install certbot if not already installed
echo "📦 Installing certbot..."
apt update
apt install -y certbot

# Stop any services that might be using port 80
echo "🛑 Stopping services on port 80..."
systemctl stop apache2 2>/dev/null || true
systemctl stop nginx 2>/dev/null || true
killall -9 node 2>/dev/null || true

# Generate SSL certificate using standalone mode
echo "🔑 Generating SSL certificate for oopsnowh.com..."
certbot certonly --standalone \
    --non-interactive \
    --agree-tos \
    --expand \
    --email admin@oopsnowh.com \
    -d oopsnowh.com \
    -d www.oopsnowh.com

# Check if certificate was generated successfully
if [ -f "/etc/letsencrypt/live/oopsnowh.com/fullchain.pem" ]; then
    echo "✅ SSL certificate generated successfully!"
    
    # Set proper permissions for Node.js to read certificates
    echo "🔧 Setting certificate permissions..."
    chmod 644 /etc/letsencrypt/live/oopsnowh.com/fullchain.pem
    chmod 600 /etc/letsencrypt/live/oopsnowh.com/privkey.pem
    
    # Add Node.js user to ssl-cert group (if exists)
    if getent group ssl-cert > /dev/null 2>&1; then
        usermod -a -G ssl-cert $(whoami)
    fi
    
    # Create a renewal hook to restart Node.js servers
    echo "🔄 Setting up auto-renewal..."
    cat > /etc/letsencrypt/renewal-hooks/deploy/restart-nodejs.sh << 'EOF'
#!/bin/bash
# Restart Node.js servers after certificate renewal
echo "Certificate renewed, restarting Node.js servers..."
pkill -f "node.*server.js" || true
pkill -f "node.*lobbyWalletServer.js" || true
sleep 2
# Add commands here to restart your Node.js servers
# Example: systemctl restart your-nodejs-service
EOF
    
    chmod +x /etc/letsencrypt/renewal-hooks/deploy/restart-nodejs.sh
    
    echo "🎉 SSL setup complete!"
    echo "📋 Certificate files:"
    echo "   - Certificate: /etc/letsencrypt/live/oopsnowh.com/fullchain.pem"
    echo "   - Private Key: /etc/letsencrypt/live/oopsnowh.com/privkey.pem"
    echo ""
    echo "🚀 You can now start your Node.js servers with SSL_ENABLED=true"
    echo "   Example: SSL_ENABLED=true node server.js"
    echo ""
    echo "🔄 Auto-renewal is configured. Test it with:"
    echo "   certbot renew --dry-run"
    
else
    echo "❌ Failed to generate SSL certificate!"
    echo "Please check the error messages above and try again."
    echo ""
    echo "Common issues:"
    echo "- Make sure port 80 is accessible from the internet"
    echo "- Verify DNS records point to this server"
    echo "- Check firewall settings"
    exit 1
fi

echo "✨ SSL setup completed successfully!"
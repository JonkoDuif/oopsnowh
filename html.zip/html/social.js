class SocialSystem {
    constructor() {
        this.friends = [];
        this.friendRequests = [];
        this.leaderboard = [];
        this.currentUser = null;
        this.isPopupOpen = false;
        this.currentTab = 'friends';
        this.init();
    }

    init() {
        this.loadCurrentUser();
        this.setupEventListeners();
        this.loadFriends();
        this.loadLeaderboard();
        this.loadFriendRequests();
        
        // Update online status every 30 seconds
        setInterval(() => this.updateOnlineStatus(), 30000);
    }

    setupEventListeners() {
        // Friends box search
        const searchInput = document.getElementById('friend-search');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.searchUsers(e.target.value));
        }

        // View full social button
        const viewSocialBtn = document.querySelector('.view-full-social');
        if (viewSocialBtn) {
            viewSocialBtn.addEventListener('click', () => this.openSocialPopup());
        }

        // Close popup
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('social-popup-overlay')) {
                this.closeSocialPopup();
            }
        });
    }

    async loadCurrentUser() {
        try {
            const response = await fetch('api/social_real.php?action=get_user_stats');
            const data = await response.json();
            if (data.success) {
                this.currentUser = data.data;
            }
        } catch (error) {
            console.error('Error loading current user:', error);
        }
    }

    async loadFriends(filter = 'all') {
        try {
            // Get current user ID
            const currentUserId = localStorage.getItem('currentUserId') || 
                                (window.authSystem?.currentUser?.id);
            
            if (!currentUserId) {
                console.log('No user ID found for loading friends');
                return;
            }
            
            const response = await fetch(`/api/get_friends.php?user_id=${currentUserId}`);
            const data = await response.json();
            if (data.success) {
                this.friends = data.friends || [];
                this.updateFriendsDisplay();
            }
        } catch (error) {
            console.error('Error loading friends:', error);
        }
    }

    async loadFriendRequests() {
        try {
            const response = await fetch('api/social_real.php?action=get_friend_requests&type=received');
            const data = await response.json();
            if (data.success) {
                this.friendRequests = data.data;
                this.updateFriendRequestsDisplay();
            }
        } catch (error) {
            console.error('Error loading friend requests:', error);
        }
    }

    async loadLeaderboard(type = 'friends', limit = 3) {
        try {
            const response = await fetch(`api/social_real.php?action=get_leaderboard&type=${type}&limit=${limit}`);
            const data = await response.json();
            if (data.success) {
                this.leaderboard = data.data;
                this.updateLeaderboardDisplay();
            }
        } catch (error) {
            console.error('Error loading leaderboard:', error);
        }
    }

    async searchUsers(query) {
        if (query.length < 2) {
            this.clearSearchResults();
            return;
        }

        try {
            const response = await fetch(`api/social_real.php?action=search_users&query=${encodeURIComponent(query)}`);
            const data = await response.json();
            if (data.success) {
                this.displaySearchResults(data.data);
            }
        } catch (error) {
            console.error('Error searching users:', error);
        }
    }

    displaySearchResults(users) {
        const resultsContainer = document.getElementById('search-results');
        if (!resultsContainer) return;

        resultsContainer.innerHTML = '';
        
        users.forEach(user => {
            const userElement = document.createElement('div');
            userElement.className = 'search-result-item';
            
            let actionButton = '';
            if (user.is_friend) {
                actionButton = '<span class="friend-status">✓ Friend</span>';
            } else if (user.friend_request_status === 'pending') {
                if (user.request_direction === 'sent') {
                    actionButton = '<span class="request-sent">Request Sent</span>';
                } else {
                    actionButton = `
                        <button onclick="socialSystem.respondToFriendRequest(${user.friend_request_id}, 'accepted')" class="accept-btn">Accept</button>
                        <button onclick="socialSystem.respondToFriendRequest(${user.friend_request_id}, 'declined')" class="decline-btn">Decline</button>
                    `;
                }
            } else {
                actionButton = `<button onclick="socialSystem.sendFriendRequest(${user.id})" class="add-friend-btn">Add Friend</button>`;
            }

            userElement.innerHTML = `
                <div class="user-info">
                    <span class="username">${user.username}</span>
                    <span class="status ${user.is_online ? 'online' : 'offline'}">${user.is_online ? 'Online' : 'Offline'}</span>
                </div>
                <div class="user-actions">
                    ${actionButton}
                </div>
            `;
            
            resultsContainer.appendChild(userElement);
        });
    }

    clearSearchResults() {
        const resultsContainer = document.getElementById('search-results');
        if (resultsContainer) {
            resultsContainer.innerHTML = '';
        }
    }

    async sendFriendRequest(userId) {
        try {
            const response = await fetch('api/social_real.php?action=send_friend_request', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ receiver_id: userId })
            });
            
            const data = await response.json();
            if (data.success) {
                this.showNotification('Friend request sent!', 'success');
                // Refresh search results
                const searchInput = document.getElementById('friend-search');
                if (searchInput && searchInput.value) {
                    this.searchUsers(searchInput.value);
                }
            } else {
                this.showNotification(data.error, 'error');
            }
        } catch (error) {
            console.error('Error sending friend request:', error);
            this.showNotification('Error sending friend request', 'error');
        }
    }

    async respondToFriendRequest(requestId, response) {
        try {
            const apiResponse = await fetch('api/social_real.php?action=respond_friend_request', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ request_id: requestId, response: response })
            });
            
            const data = await apiResponse.json();
            if (data.success) {
                this.showNotification(`Friend request ${response}!`, 'success');
                this.loadFriends();
                this.loadFriendRequests();
                // Refresh search if needed
                const searchInput = document.getElementById('friend-search');
                if (searchInput && searchInput.value) {
                    this.searchUsers(searchInput.value);
                }
            } else {
                this.showNotification(data.error, 'error');
            }
        } catch (error) {
            console.error('Error responding to friend request:', error);
            this.showNotification('Error responding to friend request', 'error');
        }
    }

    updateFriendsDisplay() {
        const friendsList = document.getElementById('friends-list');
        if (!friendsList) return;

        friendsList.innerHTML = '';
        
        // Show only first 5 friends in the small box
        const displayFriends = this.friends.slice(0, 5);
        
        displayFriends.forEach(friend => {
            const friendElement = document.createElement('div');
            friendElement.className = 'friend-item';
            friendElement.innerHTML = `
                <div class="friend-info">
                    <span class="friend-name">${friend.username}</span>
                    <span class="friend-status ${friend.is_online ? 'online' : 'offline'}">
                        ${friend.is_online ? '🟢 Online' : '🔴 Offline'}
                    </span>
                </div>
            `;
            
            friendElement.addEventListener('click', () => this.showUserProfile(friend.id));
            friendsList.appendChild(friendElement);
        });

        // Update friend count
        const friendCount = document.getElementById('friend-count');
        if (friendCount) {
            friendCount.textContent = this.friends.length;
        }
    }

    updateFriendRequestsDisplay() {
        const requestsContainer = document.getElementById('friend-requests');
        if (!requestsContainer) return;

        if (this.friendRequests.length === 0) {
            requestsContainer.style.display = 'none';
            return;
        }

        requestsContainer.style.display = 'block';
        requestsContainer.innerHTML = `
            <h4>Friend Requests (${this.friendRequests.length})</h4>
            <div class="requests-list">
                ${this.friendRequests.map(request => `
                    <div class="request-item">
                        <span>${request.username}</span>
                        <div class="request-actions">
                            <button onclick="socialSystem.respondToFriendRequest(${request.id}, 'accepted')" class="accept-btn">✓</button>
                            <button onclick="socialSystem.respondToFriendRequest(${request.id}, 'declined')" class="decline-btn">✗</button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    updateLeaderboardDisplay() {
        const leaderboardList = document.getElementById('leaderboard-list');
        if (!leaderboardList) return;

        leaderboardList.innerHTML = '';
        
        this.leaderboard.forEach((user, index) => {
            const position = index + 1;
            const leaderElement = document.createElement('div');
            leaderElement.className = 'leaderboard-item';
            leaderElement.innerHTML = `
                <div class="position">#${position}</div>
                <div class="user-info">
                    <span class="username">${user.username}</span>
                    <span class="earnings">$${(user.total_earnings || 0).toFixed(2)}</span>
                </div>
                <span class="status ${user.is_online ? 'online' : 'offline'}">
                    ${user.is_online ? '🟢' : '🔴'}
                </span>
            `;
            
            leaderElement.addEventListener('click', () => this.showUserProfile(user.id));
            leaderboardList.appendChild(leaderElement);
        });
    }

    async updateOnlineStatus() {
        if (this.friends.length === 0) return;
        
        const userIds = this.friends.map(f => f.id).join(',');
        try {
            const response = await fetch(`api/social_real.php?action=get_online_status&user_ids=${userIds}`);
            const data = await response.json();
            if (data.success) {
                // Update friends online status
                data.data.forEach(statusUpdate => {
                    const friend = this.friends.find(f => f.id == statusUpdate.id);
                    if (friend) {
                        friend.is_online = statusUpdate.is_online;
                    }
                });
                this.updateFriendsDisplay();
            }
        } catch (error) {
            console.error('Error updating online status:', error);
        }
    }

    openSocialPopup() {
        // Use the existing social popup instead of creating a new one
        if (typeof window.showSocialPopup === 'function') {
            window.showSocialPopup();
        } else {
            console.error('showSocialPopup function not available');
        }
    }

    closeSocialPopup() {
        // Use the existing close function
        if (typeof window.closeSocialPopup === 'function') {
            window.closeSocialPopup();
        }
    }

    createSocialPopup() {
        // Disabled to prevent duplicate popups - using main popup system instead
        return;
        const popup = document.createElement('div');
        popup.id = 'social-popup';
        popup.className = 'social-popup-overlay';
        
        popup.innerHTML = `
            <div class="social-popup">
                <div class="popup-header">
                    <h2>Social</h2>
                    <button class="close-btn" onclick="socialSystem.closeSocialPopup()">×</button>
                </div>
                <div class="popup-tabs">
                    <button class="tab-btn ${this.currentTab === 'friends' ? 'active' : ''}" onclick="socialSystem.switchTab('friends')">Friends</button>
                    <button class="tab-btn ${this.currentTab === 'leaderboard' ? 'active' : ''}" onclick="socialSystem.switchTab('leaderboard')">Leaderboard</button>
                    <button class="tab-btn ${this.currentTab === 'profile' ? 'active' : ''}" onclick="socialSystem.switchTab('profile')">Profile</button>
                </div>
                <div class="popup-content">
                    <div id="friends-tab" class="tab-content ${this.currentTab === 'friends' ? 'active' : ''}">
                        ${this.createFriendsTabContent()}
                    </div>
                    <div id="leaderboard-tab" class="tab-content ${this.currentTab === 'leaderboard' ? 'active' : ''}">
                        ${this.createLeaderboardTabContent()}
                    </div>
                    <div id="profile-tab" class="tab-content ${this.currentTab === 'profile' ? 'active' : ''}">
                        ${this.createProfileTabContent()}
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(popup);
        
        // Setup search in popup
        const popupSearchInput = popup.querySelector('#popup-friend-search');
        if (popupSearchInput) {
            popupSearchInput.addEventListener('input', (e) => this.searchUsers(e.target.value));
        }
    }

    createFriendsTabContent() {
        return `
            <div class="friends-tab-content">
                <div class="search-section">
                    <input type="text" id="popup-friend-search" placeholder="Search for friends..." class="search-input">
                    <div id="popup-search-results" class="search-results"></div>
                </div>
                <div class="filter-section">
                    <button onclick="socialSystem.loadFriends('all')" class="filter-btn active">All Friends</button>
                    <button onclick="socialSystem.loadFriends('online')" class="filter-btn">Online</button>
                    <button onclick="socialSystem.loadFriends('offline')" class="filter-btn">Offline</button>
                    <button onclick="socialSystem.showFriendRequests()" class="filter-btn">Requests</button>
                    <button onclick="socialSystem.showBlockedUsers()" class="filter-btn">Blocked</button>
                </div>
                <div id="popup-friends-list" class="friends-list">
                    ${this.createFullFriendsList()}
                </div>
            </div>
        `;
    }

    createFullFriendsList() {
        return this.friends.map(friend => `
            <div class="friend-item-full" onclick="socialSystem.showUserProfile(${friend.id})">
                <div class="friend-info">
                    <span class="friend-name">${friend.username}</span>
                    <span class="friend-status ${friend.is_online ? 'online' : 'offline'}">
                        ${friend.is_online ? '🟢 Online' : '🔴 Offline'}
                    </span>
                </div>
                <div class="friend-stats">
                    <span>Earnings: $${(friend.total_earnings || 0).toFixed(2)}</span>
                    <span>Games: ${friend.total_games || 0}</span>
                </div>
                <div class="friend-actions">
                    <button onclick="event.stopPropagation(); socialSystem.showSendMoneyDialog(${friend.id}, '${friend.username}')" class="send-money-btn">💰</button>
                    <button onclick="event.stopPropagation(); socialSystem.removeFriend(${friend.id})" class="remove-friend-btn">🗑️</button>
                </div>
            </div>
        `).join('');
    }

    createLeaderboardTabContent() {
        return `
            <div class="leaderboard-tab-content">
                <h3>Top Friends by Earnings</h3>
                <div id="popup-leaderboard-list" class="leaderboard-list-full">
                    ${this.leaderboard.map((user, index) => `
                        <div class="leaderboard-item-full" onclick="socialSystem.showUserProfile(${user.id})">
                            <div class="position">#${index + 1}</div>
                            <div class="user-info">
                                <span class="username">${user.username}</span>
                                <span class="earnings">$${(user.total_earnings || 0).toFixed(2)}</span>
                            </div>
                            <div class="user-stats">
                                <span>Kills: ${user.total_kills || 0}</span>
                                <span>Games: ${user.total_games || 0}</span>
                            </div>
                            <span class="status ${user.is_online ? 'online' : 'offline'}">
                                ${user.is_online ? '🟢' : '🔴'}
                            </span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    createProfileTabContent() {
        if (!this.currentUser) return '<div>Loading profile...</div>';
        
        return `
            <div class="profile-tab-content">
                <div class="profile-header">
                    <h3>${this.currentUser.username}</h3>
                    <p>Member since: ${new Date(this.currentUser.joined_date).toLocaleDateString()}</p>
                </div>
                <div class="profile-stats">
                    <div class="stat-item">
                        <span class="stat-label">Total Earnings</span>
                        <span class="stat-value">$${(this.currentUser.total_earnings || 0).toFixed(2)}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Total Kills</span>
                        <span class="stat-value">${this.currentUser.total_kills || 0}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Games Played</span>
                        <span class="stat-value">${this.currentUser.total_games || 0}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Wins</span>
                        <span class="stat-value">${this.currentUser.total_wins || 0}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Win Rate</span>
                        <span class="stat-value">${this.currentUser.win_rate || 0}%</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Avg Kills/Game</span>
                        <span class="stat-value">${this.currentUser.avg_kills_per_game || 0}</span>
                    </div>
                </div>
            </div>
        `;
    }

    switchTab(tab) {
        this.currentTab = tab;
        
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelector(`[onclick="socialSystem.switchTab('${tab}')"]`).classList.add('active');
        
        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        document.getElementById(`${tab}-tab`).classList.add('active');
        
        // Load specific data for tab
        if (tab === 'leaderboard') {
            this.loadLeaderboard('friends', 10);
        } else if (tab === 'profile') {
            this.loadCurrentUser();
        }
    }

    async showUserProfile(userId) {
        try {
            const response = await fetch(`api/social_real.php?action=get_user_stats&user_id=${userId}`);
            const data = await response.json();
            if (data.success) {
                this.displayUserProfileModal(data.data);
            }
        } catch (error) {
            console.error('Error loading user profile:', error);
        }
    }

    displayUserProfileModal(user) {
        const modal = document.createElement('div');
        modal.className = 'user-profile-modal-overlay';
        modal.innerHTML = `
            <div class="user-profile-modal">
                <div class="modal-header">
                    <h3>${user.username}'s Profile</h3>
                    <button class="close-btn" onclick="this.parentElement.parentElement.parentElement.remove()">×</button>
                </div>
                <div class="modal-content">
                    <div class="user-stats-grid">
                        <div class="stat-item">
                            <span class="stat-label">Total Earnings</span>
                            <span class="stat-value">$${(user.total_earnings || 0).toFixed(2)}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Kills</span>
                            <span class="stat-value">${user.total_kills || 0}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Games Played</span>
                            <span class="stat-value">${user.total_games || 0}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Wins</span>
                            <span class="stat-value">${user.total_wins || 0}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Win Rate</span>
                            <span class="stat-value">${user.win_rate || 0}%</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Avg Kills/Game</span>
                            <span class="stat-value">${user.avg_kills_per_game || 0}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close on overlay click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    showSendMoneyDialog(friendId, friendUsername) {
        const modal = document.createElement('div');
        modal.className = 'send-money-modal-overlay';
        modal.innerHTML = `
            <div class="send-money-modal">
                <div class="modal-header">
                    <h3>Send Money to ${friendUsername}</h3>
                    <button class="close-btn" onclick="this.parentElement.parentElement.parentElement.remove()">×</button>
                </div>
                <div class="modal-content">
                    <div class="amount-input-section">
                        <label for="send-amount">Amount ($):</label>
                        <input type="number" id="send-amount" min="0.01" step="0.01" placeholder="0.00">
                    </div>
                    <div class="modal-actions">
                        <button onclick="socialSystem.sendMoney(${friendId}, document.getElementById('send-amount').value); this.parentElement.parentElement.parentElement.remove()" class="send-btn">Send Money</button>
                        <button onclick="this.parentElement.parentElement.parentElement.remove()" class="cancel-btn">Cancel</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close on overlay click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    async sendMoney(friendId, amount) {
        if (!amount || amount <= 0) {
            this.showNotification('Please enter a valid amount', 'error');
            return;
        }
        
        try {
            const response = await fetch('api/social_real.php?action=send_money', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ receiver_id: friendId, amount: parseFloat(amount) })
            });
            
            const data = await response.json();
            if (data.success) {
                this.showNotification('Money sent successfully!', 'success');
                // Refresh user balance if needed
                if (window.updateBalance) {
                    window.updateBalance();
                }
            } else {
                this.showNotification(data.error, 'error');
            }
        } catch (error) {
            console.error('Error sending money:', error);
            this.showNotification('Error sending money', 'error');
        }
    }

    async removeFriend(friendId) {
        if (!confirm('Are you sure you want to remove this friend?')) {
            return;
        }
        
        try {
            const response = await fetch('api/social_real.php?action=remove_friend', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ friend_id: friendId })
            });
            
            const data = await response.json();
            if (data.success) {
                this.showNotification('Friend removed', 'success');
                this.loadFriends();
                this.loadLeaderboard();
            } else {
                this.showNotification(data.error, 'error');
            }
        } catch (error) {
            console.error('Error removing friend:', error);
            this.showNotification('Error removing friend', 'error');
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 3000);
    }
}

// Initialize social system when page loads
let socialSystem;
document.addEventListener('DOMContentLoaded', () => {
    socialSystem = new SocialSystem();
});
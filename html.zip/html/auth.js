// Direct access prevention
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
    throw new Error('Direct file access denied');
}

// Enhanced Authentication System with Email Verification
class AuthSystem {
    constructor() {
        this.currentUser = null;
        this.sessionToken = localStorage.getItem('sessionToken');
        this.isLoggedIn = false;
        this.currentStep = 'email'; // email, verification, username
        this.currentEmail = null;
        this.heartbeatInterval = null;
        
        this.initializeEventListeners();
        this.checkExistingSession();
    }

    initializeEventListeners() {
        try {
            // Send verification code
            const sendCodeBtn = document.getElementById('send-code-btn');
            if (sendCodeBtn) {
                sendCodeBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.sendVerificationCode();
                });
            }

            // Verify code
            const verifyCodeBtn = document.getElementById('verify-code-btn');
            if (verifyCodeBtn) {
                // Primary event listener
                verifyCodeBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.verifyCode();
                });
                
                // Fallback: Direct onclick handler to bypass extension interference
                verifyCodeBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.verifyCode();
                };
            }

            // Resend code
            const resendCodeBtn = document.getElementById('resend-code-btn');
            if (resendCodeBtn) {
                resendCodeBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.resendCode();
                });
            }

            // Create account
            const createAccountBtn = document.getElementById('create-account-btn');
            if (createAccountBtn) {
                createAccountBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.createAccount();
                });
            }

            // Auto-format verification code input
            const codeInput = document.getElementById('verification-code');
            if (codeInput) {
                codeInput.addEventListener('input', (e) => {
                    e.target.value = e.target.value.replace(/\D/g, '').substring(0, 6);
                });
                
                // Add Enter key support for verify code
                codeInput.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        e.stopPropagation();
                        this.verifyCode();
                    }
                });
            }
            
            console.log('✅ Auth event listeners initialized successfully');
        } catch (error) {
            console.error('❌ Error initializing auth event listeners:', error);
            // Fallback: try to reinitialize after a delay
            setTimeout(() => {
                this.initializeEventListeners();
            }, 1000);
        }
    }

    async checkExistingSession() {
        if (!this.sessionToken) return;

        try {
            const response = await this.makeRequest('check_session', {
                session_token: this.sessionToken
            });

            if (response.success) {
                this.currentUser = response.data.user;
                // Ensure balance is a number
                if (this.currentUser && this.currentUser.balance !== undefined) {
                    this.currentUser.balance = parseFloat(this.currentUser.balance) || 0;
                }
                this.isLoggedIn = true;
                this.startHeartbeat();
                setTimeout(async () => {
                    await this.updateUI();
                }, 0);
            } else {
                localStorage.removeItem('sessionToken');
                this.sessionToken = null;
            }
        } catch (error) {
            console.error('Session check failed:', error);
            localStorage.removeItem('sessionToken');
            this.sessionToken = null;
        }
    }

    async sendVerificationCode() {
        const emailInput = document.getElementById('login-email');
        const email = emailInput.value.trim();

        if (!this.isValidEmail(email)) {
            this.showError('Please enter a valid email address');
            return;
        }

        this.setLoading('send-code-btn', true);
        this.clearMessages();

        try {
            const response = await this.makeRequest('send_verification', { email });

            if (response.success) {
                this.currentEmail = email;
                this.showSuccess('Verification code sent to your email!');
                this.showStep('verification');
            } else {
                this.showError(response.error);
            }
        } catch (error) {
            this.showError('Failed to send verification code. Please try again.');
            console.error('Send verification error:', error);
        } finally {
            this.setLoading('send-code-btn', false);
        }
    }

    async verifyCode() {
        try {
            const codeInput = document.getElementById('verification-code');
            if (!codeInput) {
                this.showError('Verification code input not found');
                return;
            }
            
            const code = codeInput.value.trim();

            if (code.length !== 6) {
                this.showError('Please enter the 6-digit verification code');
                return;
            }

            this.setLoading('verify-code-btn', true);
            this.clearMessages();

            console.log('🔐 Verifying code:', code);

            const response = await this.makeRequest('verify_code', {
                email: this.currentEmail,
                code: code
            });

            console.log('📨 Verification response:', response);

            if (response.success) {
                if (response.data.user) {
                    // Existing user - log them in
                    this.currentUser = response.data.user;
                    // Ensure balance is a number
                    if (this.currentUser && this.currentUser.balance !== undefined) {
                        this.currentUser.balance = parseFloat(this.currentUser.balance) || 0;
                    }
                    this.sessionToken = response.data.session_token;
                    this.isLoggedIn = true;
                    
                    // Ensure existing user has a real Solana wallet address
                    if (window.walletSystem && (!this.currentUser.wallet_address || this.currentUser.wallet_address === '')) {
                        const walletData = await window.walletSystem.generateUserWallet(this.currentUser.username);
                        const walletAddress = walletData.address || walletData.publicKey;
                        this.currentUser.wallet_address = walletAddress;
                        
                        // Update the user data on the server with the real wallet address
                        await this.updateUserWalletAddress(walletAddress);
                    }
                    
                    localStorage.setItem('sessionToken', this.sessionToken);
                    this.startHeartbeat();
                    this.closeModal();
                    setTimeout(async () => {
                        await this.updateUI();
                    }, 0);
                    this.showSuccess(`Welcome back, ${this.currentUser.username}!`);
                } else if (response.data.new_user) {
                    // New user - show username selection
                    this.showStep('username');
                } else {
                    // Fallback case
                    this.showError('Unexpected response from server');
                }
            } else {
                this.showError(response.error || 'Verification failed');
            }
        } catch (error) {
            console.error('❌ Verify code error:', error);
            
            // Check if it's a browser extension error
            if (error.message && error.message.includes('chrome-extension')) {
                console.warn('⚠️ Browser extension error detected, but continuing with verification');
                this.showError('Browser extension interference detected. Please disable extensions or try incognito mode.');
            } else {
                this.showError('Verification failed. Please try again.');
            }
        } finally {
            this.setLoading('verify-code-btn', false);
        }
    }

    async resendCode() {
        if (!this.currentEmail) return;

        this.setLoading('resend-code-btn', true);
        this.clearMessages();

        try {
            const response = await this.makeRequest('send_verification', {
                email: this.currentEmail
            });

            if (response.success) {
                this.showSuccess('New verification code sent');
                
                // Show dev code in console for testing
                if (response.data.dev_code) {
                    console.log('Development verification code:', response.data.dev_code);
                    this.showSuccess(`Development mode: New code is ${response.data.dev_code}`);
                }
            } else {
                this.showError(response.error);
            }
        } catch (error) {
            this.showError('Failed to resend code. Please try again.');
            console.error('Resend code error:', error);
        } finally {
            this.setLoading('resend-code-btn', false);
        }
    }

    async createAccount() {
        const usernameInput = document.getElementById('new-username');
        const username = usernameInput.value.trim();

        if (!username) {
            this.showError('Please enter a username');
            return;
        }

        if (username.length < 3 || username.length > 20) {
            this.showError('Username must be between 3 and 20 characters');
            return;
        }

        if (!/^[a-zA-Z0-9_]+$/.test(username)) {
            this.showError('Username can only contain letters, numbers, and underscores');
            return;
        }

        this.setLoading('create-account-btn', true);
        this.clearMessages();

        try {
            const response = await this.makeRequest('create_account', {
                email: this.currentEmail,
                username: username
            });

            if (response.success) {
                this.currentUser = response.data.user;
                // Ensure balance is a number
                if (this.currentUser && this.currentUser.balance !== undefined) {
                    this.currentUser.balance = parseFloat(this.currentUser.balance) || 0;
                }
                this.sessionToken = response.data.session_token;
                this.isLoggedIn = true;
                
                // Generate real Solana wallet address for this user
                if (window.walletSystem) {
                    const walletData = await window.walletSystem.generateUserWallet(username);
                    const walletAddress = walletData.address || walletData.publicKey;
                    this.currentUser.wallet_address = walletAddress;
                    
                    // Update the user data on the server with the real wallet address
                    await this.updateUserWalletAddress(walletAddress);
                }
                
                localStorage.setItem('sessionToken', this.sessionToken);
                this.startHeartbeat();
                this.closeModal();
                setTimeout(async () => {
                    await this.updateUI();
                }, 0);
                this.showSuccess(`Welcome to OopsNowh, ${this.currentUser.username}!`);
            } else {
                this.showError(response.error);
            }
        } catch (error) {
            this.showError('Account creation failed. Please try again.');
            console.error('Create account error:', error);
        } finally {
            this.setLoading('create-account-btn', false);
        }
    }

    async updateUserWalletAddress(walletAddress) {
        try {
            const response = await this.makeRequest('update_wallet_address', {
                session_token: this.sessionToken,
                wallet_address: walletAddress
            });
            
            if (!response.success) {
                console.error('Failed to update wallet address on server:', response.error);
            }
        } catch (error) {
            console.error('Error updating wallet address:', error);
        }
    }

    async logout() {
        try {
            if (this.sessionToken) {
                await this.makeRequest('logout', {
                    session_token: this.sessionToken
                });
            }
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.currentUser = null;
            this.sessionToken = null;
            this.isLoggedIn = false;
            this.currentEmail = null;
            
            localStorage.removeItem('sessionToken');
            this.stopHeartbeat();
            setTimeout(async () => {
                await this.updateUI();
            }, 0);
            this.resetForm();
        }
    }

    showStep(step) {
        // Hide all steps
        document.getElementById('email-step').style.display = 'none';
        document.getElementById('verification-step').style.display = 'none';
        document.getElementById('username-step').style.display = 'none';

        // Show current step
        document.getElementById(`${step}-step`).style.display = 'block';
        this.currentStep = step;
    }

    resetForm() {
        this.showStep('email');
        this.clearMessages();
        
        // Clear all inputs
        document.getElementById('login-email').value = '';
        document.getElementById('verification-code').value = '';
        document.getElementById('new-username').value = '';
    }

    closeModal() {
        document.getElementById('auth-modal').style.display = 'none';
        this.resetForm();
    }

    async updateUI() {
        const loggedOutInfo = document.getElementById('logged-out-info');
        const loggedInInfo = document.getElementById('logged-in-info');
        const welcomeText = document.getElementById('welcome-text');
        const nameInput = document.getElementById('name-input');

        if (this.isLoggedIn && this.currentUser) {
            loggedOutInfo.style.display = 'none';
            loggedInInfo.style.display = 'flex';
            welcomeText.textContent = `Welcome, ${this.currentUser.username}!`;
            nameInput.value = this.currentUser.username;
            nameInput.readOnly = false;
            nameInput.placeholder = this.currentUser.username;
            
            // Update wallet display and join game button
            if (window.gameManager) {
                await window.gameManager.updateWalletDisplay();
                // Update join game button state
                if (window.gameManager.uiManager) {
                    window.gameManager.uiManager.updateJoinGameButtonState();
                }
            }
            if (window.uiManager) {
                window.uiManager.updateJoinGameButtonState();
            }
        } else {
            loggedOutInfo.style.display = 'flex';
            loggedInInfo.style.display = 'none';
            welcomeText.textContent = 'Welcome, bruh!';
            nameInput.value = '';
            nameInput.readOnly = true;
            nameInput.placeholder = 'Login to set your name';
        }
    }

    async makeRequest(action, data = {}) {
        // Use the PHP server running on port 8000
        // Use relative path for production, or localhost for development
        // Using auth_handler_hostinger.php for production (database + JSON fallback)
        const API_ENDPOINT = window.location.hostname === 'localhost' 
            ? 'http://localhost:8080/auth_handler.php'
            : '/php/auth_handler_hostinger.php';
        
        const response = await fetch(API_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: action,
                ...data
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    }

    getMockResponse(action, data) {
        // Mock responses for testing without PHP backend
        switch (action) {
            case 'send_verification':
                return Promise.resolve({
                    success: true,
                    data: { dev_code: '123456' }
                });
            
            case 'verify_code':
                if (data.code === '123456') {
                    return Promise.resolve({
                        success: true,
                        data: {
                            user_exists: false
                        }
                    });
                }
                return Promise.resolve({
                    success: false,
                    error: 'Invalid verification code'
                });
            
            case 'create_account':
                const newUser = {
                    id: Date.now(),
                    email: data.email,
                    username: data.username,
                    balance: 0.00,
                    created_at: new Date().toISOString()
                };
                return Promise.resolve({
                    success: true,
                    data: {
                        user: newUser,
                        session_token: 'mock_session_' + Date.now()
                    }
                });
            
            case 'check_session':
                if (data.session_token && data.session_token.startsWith('mock_session_')) {
                    return Promise.resolve({
                        success: true,
                        data: {
                            user: {
                                id: 1,
                                email: 'test@example.com',
                                username: 'TestUser',
                                balance: 0.00
                            }
                        }
                    });
                }
                return Promise.resolve({ success: false });
            
            case 'logout':
                return Promise.resolve({ success: true });
            
            default:
                return Promise.resolve({
                    success: false,
                    error: 'Unknown action'
                });
        }
    }

    setLoading(buttonId, loading) {
        const button = document.getElementById(buttonId);
        if (button) {
            button.disabled = loading;
            if (loading) {
                button.dataset.originalText = button.textContent;
                button.textContent = 'Loading...';
            } else {
                button.textContent = button.dataset.originalText || button.textContent;
            }
        }
    }

    showError(message) {
        this.clearMessages();
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        const form = document.getElementById('login-form');
        form.insertBefore(errorDiv, form.firstChild);
    }

    showSuccess(message) {
        this.clearMessages();
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.textContent = message;
        
        const form = document.getElementById('login-form');
        form.insertBefore(successDiv, form.firstChild);
    }

    clearMessages() {
        const messages = document.querySelectorAll('.error-message, .success-message');
        messages.forEach(msg => msg.remove());
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Public methods for external use
    getCurrentUser() {
        return this.currentUser;
    }

    getUserBalance() {
        return this.currentUser ? this.currentUser.balance : 0;
    }

    updateBalance(newBalance) {
        if (this.currentUser) {
            this.currentUser.balance = parseFloat(newBalance) || 0;
            // Use setTimeout to avoid blocking the main thread
            setTimeout(async () => {
                await this.updateUI();
            }, 0);
        }
    }

    addWinnings(amount) {
        if (this.currentUser && amount > 0) {
            // Initialize total_winnings if it doesn't exist
            if (!this.currentUser.total_winnings) {
                this.currentUser.total_winnings = 0;
            }
            this.currentUser.total_winnings += amount;
            
            // Increment games played counter
            if (!this.currentUser.games_played) {
                this.currentUser.games_played = 0;
            }
            this.currentUser.games_played += 1;
            
            console.log(`📊 Total winnings updated: €${this.currentUser.total_winnings.toFixed(2)}`);
        }
    }

    startHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
        }
        
        // Send heartbeat every 30 seconds
        this.heartbeatInterval = setInterval(async () => {
            if (this.sessionToken && this.isLoggedIn) {
                try {
                    await this.makeRequest('heartbeat', {
                        session_token: this.sessionToken
                    });
                } catch (error) {
                    console.error('Heartbeat failed:', error);
                }
            }
        }, 30000);
    }

    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }
    
    async getOnlineStatus(userIds) {
        if (!this.sessionToken || !this.isLoggedIn || !userIds || userIds.length === 0) {
            return [];
        }
        
        try {
            const response = await this.makeRequest('get_online_status', {
                session_token: this.sessionToken,
                user_ids: userIds
            });
            
            if (response.success) {
                return response.data.users;
            }
        } catch (error) {
            console.error('Failed to get online status:', error);
        }
        
        return [];
    }
}

// Export for use in other modules
window.AuthSystem = AuthSystem;

// Global helper functions for debugging browser extension issues
window.debugVerifyCode = function() {
    if (window.authSystem) {
        console.log('🔧 Debug: Manually triggering verify code');
        window.authSystem.verifyCode();
    } else {
        console.error('❌ AuthSystem not found');
    }
};

window.debugAuthSystem = function() {
    console.log('🔍 Auth System Debug Info:');
    console.log('- AuthSystem exists:', !!window.authSystem);
    console.log('- Current user:', window.authSystem?.currentUser);
    console.log('- Is logged in:', window.authSystem?.isLoggedIn);
    console.log('- Current email:', window.authSystem?.currentEmail);
    console.log('- Session token:', window.authSystem?.sessionToken ? 'Present' : 'None');
    
    const verifyBtn = document.getElementById('verify-code-btn');
    console.log('- Verify button exists:', !!verifyBtn);
    console.log('- Verify button disabled:', verifyBtn?.disabled);
    
    const codeInput = document.getElementById('verification-code');
    console.log('- Code input exists:', !!codeInput);
    console.log('- Code input value:', codeInput?.value);
};

// Cache buster - Updated: 2025-01-15
<?php if (function_exists(" opcache_reset\)) { opcache_reset(); echo \PHP OPcache cleared successfully!\; } else { echo \OPcache not available\; } ?>

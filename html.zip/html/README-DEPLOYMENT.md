# Production Deployment Guide

This guide explains how to deploy the game servers on your VPS with SSL/WSS support.

## Prerequisites

1. **SSL Certificate**: Your VPS must have SSL certificates installed for `oopsnowh.com`
2. **Node.js**: Ensure Node.js is installed on your VPS
3. **Domain**: Your domain should point to your VPS IP address

## SSL Certificate Setup

If you don't have SSL certificates yet, install them using Let's Encrypt:

```bash
# Install certbot
sudo apt update
sudo apt install certbot

# Get SSL certificate for your domain
sudo certbot certonly --standalone -d oopsnowh.com

# Certificates will be saved to:
# /etc/letsencrypt/live/oopsnowh.com/privkey.pem
# /etc/letsencrypt/live/oopsnowh.com/fullchain.pem
```

## Deployment Steps

1. **Upload your project** to the VPS:
```bash
# Using scp or git clone
scp -r /path/to/oopsnowh user@your-vps-ip:/path/to/deployment/
# OR
git clone https://github.com/your-repo/oopsnowh.git
```

2. **Install dependencies**:
```bash
cd /path/to/oopsnowh
npm install
```

3. **Start servers with SSL support**:
```bash
# Make the script executable
chmod +x start-production.sh

# Run the production startup script
./start-production.sh
```

## Manual Server Startup (Alternative)

If you prefer to start servers manually:

```bash
# Set environment variables for SSL
export SSL_ENABLED=true
export NODE_ENV=production

# Start game server with SSL
nohup node server.js > game-server.log 2>&1 &

# Start lobby wallet server
nohup node lobbyWalletServer.js > lobby-wallet.log 2>&1 &

# Start web server
nohup php -S 0.0.0.0:8000 > web-server.log 2>&1 &
```

## Verification

1. **Check if servers are running**:
```bash
ps aux | grep node
ps aux | grep php
```

2. **Check server logs**:
```bash
tail -f game-server.log
tail -f lobby-wallet.log
tail -f web-server.log
```

3. **Test WebSocket connection**:
   - Open your browser and go to `https://oopsnowh.com`
   - Check browser console for WebSocket connection messages
   - Should see successful WSS connection to `wss://oopsnowh.com:8081`

## Troubleshooting

### SSL Certificate Issues
- Ensure certificates exist at `/etc/letsencrypt/live/oopsnowh.com/`
- Check certificate permissions: `sudo ls -la /etc/letsencrypt/live/oopsnowh.com/`
- If certificates are missing, the server will fall back to HTTP/WS mode

### Port Issues
- Ensure ports 8000 and 8081 are open in your firewall
- Check if ports are already in use: `netstat -tulpn | grep :8081`

### WebSocket Connection Issues
- Verify your domain DNS points to the correct IP
- Check if SSL certificates are valid and not expired
- Ensure the game server started with SSL support (check logs)

## Stopping Servers

To stop all servers:
```bash
pkill -f "node server.js"
pkill -f "node lobbyWalletServer.js"
pkill -f "php -S"
```

## Log Files

Server logs are saved to:
- `game-server.log` - Game server output
- `lobby-wallet.log` - Lobby wallet server output
- `web-server.log` - Web server output

## Notes

- The server automatically detects if SSL certificates are available
- In production mode (`SSL_ENABLED=true`), it uses HTTPS/WSS
- In development mode, it falls back to HTTP/WS
- Make sure your firewall allows traffic on ports 8000 and 8081
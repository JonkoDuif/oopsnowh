<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once 'database.php';

try {
    // Connect to MySQL database
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    if (!$pdo) {
        throw new Exception('Database connection failed');
    }
    
    // Get parameters
    $user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
    $limit = isset($_GET['limit']) ? min((int)$_GET['limit'], 50) : 10; // Max 50 entries
    $type = isset($_GET['type']) ? $_GET['type'] : 'total'; // total, weekly, monthly
    
    // Base query for leaderboard
    $sql = "
        SELECT 
            u.id,
            u.username,
            u.email,
            u.created_at as join_date,
            COALESCE(SUM(g.score), 0) as total_earnings,
            COALESCE(SUM(g.games_played), 0) as total_games,
            COALESCE(AVG(g.survival_time), 0) as avg_survival_time,
            COALESCE(SUM(g.kills), 0) as total_kills,
            COALESCE(AVG(g.kills), 0) as avg_kills,
            CASE 
                WHEN SUM(g.games_played) > 0 THEN 
                    ROUND((SUM(g.kills) * 100.0 / SUM(g.games_played)), 1)
                ELSE 0 
            END as win_rate
        FROM users u
        LEFT JOIN game_stats g ON u.id = g.user_id
    ";
    
    // Add time filter based on type
    if ($type === 'weekly') {
        $sql .= " AND g.created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
    } elseif ($type === 'monthly') {
        $sql .= " AND g.created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
    }
    
    $sql .= "
        GROUP BY u.id, u.username, u.email, u.created_at
        ORDER BY total_earnings DESC, total_games DESC
        LIMIT :limit
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    $leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Add rank to each entry
    foreach ($leaderboard as $index => &$entry) {
        $entry['rank'] = $index + 1;
        $entry['total_earnings'] = (float)$entry['total_earnings'];
        $entry['total_games'] = (int)$entry['total_games'];
        $entry['avg_survival_time'] = (float)$entry['avg_survival_time'];
        $entry['total_kills'] = (int)$entry['total_kills'];
        $entry['avg_kills'] = (float)$entry['avg_kills'];
        $entry['win_rate'] = (float)$entry['win_rate'];
        
        // Format join date
        if ($entry['join_date']) {
            $entry['join_date_formatted'] = date('M j, Y', strtotime($entry['join_date']));
        }
    }
    
    // Get current user's rank if user_id is provided
    $user_rank = null;
    if ($user_id > 0) {
        $rank_sql = "
            SELECT COUNT(*) + 1 as user_rank
            FROM (
                SELECT u.id, COALESCE(SUM(g.cashout_amount), 0) as total_earnings
                FROM users u
                LEFT JOIN games g ON u.id = g.user_id
        ";
        
        if ($type === 'weekly') {
            $rank_sql .= " AND g.created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
        } elseif ($type === 'monthly') {
            $rank_sql .= " AND g.created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
        }
        
        $rank_sql .= "
                GROUP BY u.id
                HAVING total_earnings > (
                    SELECT COALESCE(SUM(g2.cashout_amount), 0)
                    FROM games g2
                    WHERE g2.user_id = :user_id
        ";
        
        if ($type === 'weekly') {
            $rank_sql .= " AND g2.created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
        } elseif ($type === 'monthly') {
            $rank_sql .= " AND g2.created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
        }
        
        $rank_sql .= ")
            ) as ranked_users";
        
        $rank_stmt = $pdo->prepare($rank_sql);
        $rank_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $rank_stmt->execute();
        $rank_result = $rank_stmt->fetch(PDO::FETCH_ASSOC);
        $user_rank = $rank_result ? (int)$rank_result['user_rank'] : null;
    }
    
    echo json_encode([
        'success' => true,
        'leaderboard' => $leaderboard,
        'user_rank' => $user_rank,
        'type' => $type,
        'total_entries' => count($leaderboard)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
<?php
require_once 'access_control.php';

// If user is authenticated, redirect to main site
if (checkAccess()) {
    header('Location: main.php');
    exit;
}

// Otherwise redirect to maintenance page
header('Location: maintenance.html');
exit;
?>
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../database_improved.php';

try {
    $db = Database::getInstance();
    
    if (!$db->isConnected()) {
        throw new Exception('Database connection failed');
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    $senderId = $input['sender_id'] ?? null;
    $receiverUsername = $input['receiver_username'] ?? null;
    $amount = (float)($input['amount'] ?? 0);
    $message = $input['message'] ?? '';
    
    if (!$senderId || !$receiverUsername || $amount <= 0) {
        throw new Exception('Sender ID, receiver username, and valid amount are required');
    }
    
    if ($amount < 0.01) {
        throw new Exception('Minimum transfer amount is €0.01');
    }
    
    $conn = $db->getConnection();
    $conn->beginTransaction();
    
    try {
        // Get sender info
        $stmt = $conn->prepare("SELECT id, username, balance, wallet_address FROM users WHERE id = ?");
        $stmt->execute([$senderId]);
        $sender = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$sender) {
            throw new Exception('Sender not found');
        }
        
        // Get receiver info
        $stmt = $conn->prepare("SELECT id, username, wallet_address FROM users WHERE username = ?");
        $stmt->execute([$receiverUsername]);
        $receiver = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$receiver) {
            throw new Exception('Receiver not found');
        }
        
        if ($sender['id'] == $receiver['id']) {
            throw new Exception('Cannot send money to yourself');
        }
        
        // Check if users are friends
        $stmt = $conn->prepare("SELECT COUNT(*) FROM friendships WHERE user_id = ? AND friend_id = ?");
        $stmt->execute([$senderId, $receiver['id']]);
        if ($stmt->fetchColumn() == 0) {
            throw new Exception('You can only send money to friends');
        }
        
        // Calculate fee (2% of transfer amount, minimum €0.01)
        $fee = max(0.01, $amount * 0.02);
        $totalDeduction = $amount + $fee;
        
        // Check sender balance
        if ($sender['balance'] < $totalDeduction) {
            throw new Exception('Insufficient balance. You need €' . number_format($totalDeduction, 2) . ' (including €' . number_format($fee, 2) . ' fee)');
        }
        
        // Check if both users have wallet addresses
        if (empty($sender['wallet_address']) || empty($receiver['wallet_address'])) {
            throw new Exception('Both users must have valid Solana wallet addresses');
        }
        
        // Simulate Solana blockchain transaction
        // In production, this would use actual Solana Web3 API
        $transactionHash = 'sol_' . bin2hex(random_bytes(32)); // Simulate transaction hash
        
        // For production Solana integration, you would use:
        /*
        $solanaResult = performSolanaTransfer(
            $sender['wallet_address'],
            $receiver['wallet_address'],
            $amount,
            $sender['private_key'] // This should be securely stored/managed
        );
        
        if (!$solanaResult['success']) {
            throw new Exception('Blockchain transaction failed: ' . $solanaResult['error']);
        }
        
        $transactionHash = $solanaResult['transaction_hash'];
        */
        
        // Update sender balance
        $stmt = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$totalDeduction, $senderId]);
        
        // Update receiver balance
        $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $receiver['id']]);
        
        // Record the transfer transaction
        $stmt = $conn->prepare("
            INSERT INTO wallet_transactions 
            (sender_id, receiver_id, amount, fee, transaction_type, status, blockchain_hash, message) 
            VALUES (?, ?, ?, ?, 'transfer', 'completed', ?, ?)
        ");
        $stmt->execute([$senderId, $receiver['id'], $amount, $fee, $transactionHash, $message]);
        
        // Record the fee transaction (to system)
        $stmt = $conn->prepare("
            INSERT INTO wallet_transactions 
            (sender_id, receiver_id, amount, fee, transaction_type, status, blockchain_hash) 
            VALUES (?, 1, ?, 0, 'fee', 'completed', ?)
        ");
        $stmt->execute([$senderId, $fee, $transactionHash]);
        
        $conn->commit();
        
        // Get updated balances
        $stmt = $conn->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$senderId]);
        $newSenderBalance = $stmt->fetchColumn();
        
        $stmt = $conn->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$receiver['id']]);
        $newReceiverBalance = $stmt->fetchColumn();
        
        echo json_encode([
            'success' => true,
            'message' => 'Money sent successfully',
            'transaction' => [
                'amount' => $amount,
                'fee' => $fee,
                'total_deducted' => $totalDeduction,
                'receiver' => $receiver['username'],
                'transaction_hash' => $transactionHash,
                'sender_new_balance' => $newSenderBalance,
                'receiver_new_balance' => $newReceiverBalance
            ]
        ]);
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log('Send money error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// Function for actual Solana blockchain integration (for production)
function performSolanaTransfer($senderWallet, $receiverWallet, $amount, $privateKey) {
    // This would implement actual Solana Web3 API calls
    // Example using Solana PHP SDK or HTTP API calls
    
    /*
    try {
        // Initialize Solana connection
        $solana = new SolanaWeb3\Connection('https://api.mainnet-beta.solana.com');
        
        // Create transaction
        $transaction = new SolanaWeb3\Transaction();
        $transaction->add(
            SolanaWeb3\SystemProgram::transfer([
                'fromPubkey' => new SolanaWeb3\PublicKey($senderWallet),
                'toPubkey' => new SolanaWeb3\PublicKey($receiverWallet),
                'lamports' => $amount * 1000000000 // Convert SOL to lamports
            ])
        );
        
        // Sign and send transaction
        $signature = $solana->sendTransaction($transaction, [$privateKey]);
        
        // Wait for confirmation
        $confirmation = $solana->confirmTransaction($signature);
        
        return [
            'success' => true,
            'transaction_hash' => $signature,
            'confirmation' => $confirmation
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
    */
    
    // Placeholder for development
    return [
        'success' => true,
        'transaction_hash' => 'sol_' . bin2hex(random_bytes(32))
    ];
}
?>
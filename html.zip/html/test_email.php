<?php
// Test script for email verification functionality
require_once 'email_config.php';
require_once 'email_service.php';

// Test email sending
$testEmail = 'larsvgennip@gmail.com';
$testCode = '123456';

echo "Testing email service...\n";
echo "Email: $testEmail\n";
echo "Code: $testCode\n\n";

try {
    $result = EmailService::sendVerificationCode($testEmail, $testCode);
    
    if ($result) {
        echo "SUCCESS: Verification email sent successfully\n";
    } else {
        echo "FAILED: Could not send verification email\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
?>
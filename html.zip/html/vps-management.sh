#!/bin/bash

# VPS Management Script for oopsnowh.com
# This script helps manage your game servers on the VPS

echo "🎮 VPS Management Script for oopsnowh.com"
echo "==========================================="

# Configuration - Update these for your VPS
VPS_USER="root"  # Change to your VPS username
VPS_HOST="your-vps-ip"  # Change to your VPS IP address
VPS_PATH="/var/www/oopsnowh"  # Deployment path on VPS

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_step() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_command() {
    echo -e "${BLUE}[CMD]${NC} $1"
}

# Check if configuration is updated
check_config() {
    if [ "$VPS_HOST" = "your-vps-ip" ]; then
        print_error "Please update VPS_HOST and VPS_USER variables in this script first!"
        echo "Edit this file and set:"
        echo "  VPS_USER=\"your-username\""
        echo "  VPS_HOST=\"your-vps-ip-address\""
        exit 1
    fi
}

# Show usage
show_usage() {
    echo "Usage: $0 [command]"
    echo ""
    echo "Commands:"
    echo "  status    - Check server status on VPS"
    echo "  stop      - Stop all servers on VPS"
    echo "  start     - Start all servers on VPS"
    echo "  restart   - Restart all servers on VPS"
    echo "  logs      - View server logs on VPS"
    echo "  ports     - Check what's using ports 8081 and 8082"
    echo "  deploy    - Deploy latest code to VPS"
    echo "  ssl       - Setup SSL certificates on VPS"
    echo ""
}

# Check server status
check_status() {
    check_config
    print_step "Checking server status on VPS..."
    ssh "$VPS_USER@$VPS_HOST" << 'EOF'
echo "🔍 Checking running processes..."
echo "Game Server (port 8081):"
ps aux | grep "node server.js" | grep -v grep || echo "  ❌ Not running"

echo "\nLobby Wallet Server (port 8082):"
ps aux | grep "node lobbyWalletServer.js" | grep -v grep || echo "  ❌ Not running"

echo "\nWeb Server (port 8000):"
ps aux | grep "php -S" | grep -v grep || echo "  ❌ Not running"

echo "\n🌐 Port usage:"
lsof -i :8081 2>/dev/null || echo "  Port 8081: Available"
lsof -i :8082 2>/dev/null || echo "  Port 8082: Available"
lsof -i :8000 2>/dev/null || echo "  Port 8000: Available"
EOF
}

# Stop all servers
stop_servers() {
    check_config
    print_step "Stopping all servers on VPS..."
    ssh "$VPS_USER@$VPS_HOST" << 'EOF'
echo "🛑 Stopping servers..."
pkill -f "node server.js" && echo "✅ Game server stopped" || echo "ℹ️  Game server was not running"
pkill -f "node lobbyWalletServer.js" && echo "✅ Lobby wallet server stopped" || echo "ℹ️  Lobby wallet server was not running"
pkill -f "php -S" && echo "✅ Web server stopped" || echo "ℹ️  Web server was not running"

echo "\n⏳ Waiting for processes to stop..."
sleep 3

echo "\n🔍 Verifying all processes stopped..."
if pgrep -f "node server.js" > /dev/null; then
    echo "❌ Game server still running, force killing..."
    pkill -9 -f "node server.js"
fi

if pgrep -f "node lobbyWalletServer.js" > /dev/null; then
    echo "❌ Lobby wallet server still running, force killing..."
    pkill -9 -f "node lobbyWalletServer.js"
fi

if pgrep -f "php -S" > /dev/null; then
    echo "❌ Web server still running, force killing..."
    pkill -9 -f "php -S"
fi

echo "✅ All servers stopped"
EOF
}

# Start all servers
start_servers() {
    check_config
    print_step "Starting all servers on VPS..."
    ssh "$VPS_USER@$VPS_HOST" << EOF
cd $VPS_PATH
echo "🚀 Starting production servers..."
./start-production.sh
EOF
}

# View logs
view_logs() {
    check_config
    print_step "Viewing server logs on VPS..."
    ssh "$VPS_USER@$VPS_HOST" << EOF
cd $VPS_PATH
echo "📝 Recent logs from all servers:"
echo "\n=== Game Server Log ==="
tail -20 game-server.log 2>/dev/null || echo "No game server log found"
echo "\n=== Lobby Wallet Server Log ==="
tail -20 lobby-wallet.log 2>/dev/null || echo "No lobby wallet server log found"
echo "\n=== Web Server Log ==="
tail -20 web-server.log 2>/dev/null || echo "No web server log found"
EOF
}

# Check ports
check_ports() {
    check_config
    print_step "Checking port usage on VPS..."
    ssh "$VPS_USER@$VPS_HOST" << 'EOF'
echo "🔍 Checking what's using ports 8081 and 8082..."
echo "\nPort 8081 (Game Server):"
lsof -i :8081 2>/dev/null || echo "  Port 8081: Available"
echo "\nPort 8082 (Lobby Wallet Server):"
lsof -i :8082 2>/dev/null || echo "  Port 8082: Available"
echo "\nPort 8000 (Web Server):"
lsof -i :8000 2>/dev/null || echo "  Port 8000: Available"
echo "\nAll Node.js processes:"
ps aux | grep node | grep -v grep || echo "  No Node.js processes running"
EOF
}

# Deploy code
deploy_code() {
    check_config
    print_step "Deploying latest code to VPS..."
    ./deploy-to-vps.sh
}

# Setup SSL
setup_ssl() {
    check_config
    print_step "Setting up SSL certificates on VPS..."
    ssh "$VPS_USER@$VPS_HOST" << EOF
cd $VPS_PATH
sudo ./setup-ssl.sh
EOF
}

# Main script logic
case "$1" in
    status)
        check_status
        ;;
    stop)
        stop_servers
        ;;
    start)
        start_servers
        ;;
    restart)
        stop_servers
        sleep 2
        start_servers
        ;;
    logs)
        view_logs
        ;;
    ports)
        check_ports
        ;;
    deploy)
        deploy_code
        ;;
    ssl)
        setup_ssl
        ;;
    *)
        show_usage
        exit 1
        ;;
esac
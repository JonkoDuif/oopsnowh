// Agar.io-style Game Implementation
class AgarGame {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.gameState = {
            players: new Map(),
            food: [],
            viruses: [],
            massDrops: [],
            gameArea: { width: 7500, height: 7500 },
            camera: { x: 0, y: 0, zoom: 1 }
        };
        this.localPlayer = {
            id: null,
            balls: [],
            totalMoney: 0,
            kills: 0,
            startTime: Date.now(),
            isAlive: true
        };
        this.input = {
            mouse: { x: 0, y: 0 },
            keys: new Set()
        };
        this.cashoutProgress = 0;
        this.isCashingOut = false;
        this.isCashoutCompleted = false;
        this.ws = null;
        this.lastUpdate = 0;
        this.animationId = null;
    }

    async init() {
        console.log('🎮 Initializing Agar.io-style game...');
        
        // Get canvas
        this.canvas = document.getElementById('gameCanvas');
        if (!this.canvas) {
            throw new Error('Game canvas not found');
        }
        
        this.ctx = this.canvas.getContext('2d');
        
        // Force canvas to be visible and properly sized
        this.canvas.style.display = 'block';
        this.canvas.style.background = '#000000';
        
        this.resizeCanvas();
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Connect to game server
        await this.connectToGameServer();
        
        // Force initial render to prevent black screen
        this.render();
        
        console.log('✅ Game initialized successfully');
    }

    setupEventListeners() {
        // Mouse movement
        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            this.input.mouse.x = e.clientX - rect.left;
            this.input.mouse.y = e.clientY - rect.top;
        });

        // Mouse wheel for zooming
        this.canvas.addEventListener('wheel', (e) => {
            e.preventDefault();
            const zoomFactor = 0.1;
            const zoomDirection = e.deltaY > 0 ? -1 : 1;
            
            // Calculate new zoom level
            const newZoom = Math.max(0.2, Math.min(2.0, this.gameState.camera.zoom + (zoomDirection * zoomFactor)));
            this.gameState.camera.zoom = newZoom;
        });

        // Keyboard events
        document.addEventListener('keydown', (e) => {
            this.input.keys.add(e.code);
            this.handleKeyPress(e.code);
        });

        document.addEventListener('keyup', (e) => {
            this.input.keys.delete(e.code);
            if (e.code === 'KeyQ') {
                this.stopCashout();
            }
        });

        // Window resize
        window.addEventListener('resize', () => this.resizeCanvas());
    }

    handleKeyPress(code) {
        switch (code) {
            case 'Space':
                this.split();
                break;
            case 'KeyW':
                this.feedMass();
                break;
            case 'KeyQ':
                this.startCashout();
                break;
        }
    }

    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    async connectToGameServer() {
        return new Promise((resolve, reject) => {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.hostname}/ws-game`;
            
            this.ws = new WebSocket(wsUrl);
            
            this.ws.onopen = () => {
                console.log('🔗 Connected to game server');
                resolve();
            };
            
            this.ws.onmessage = (event) => {
                this.handleServerMessage(JSON.parse(event.data));
            };
            
            this.ws.onclose = () => {
                console.log('❌ Disconnected from game server');
                this.reconnectToGameServer();
            };
            
            this.ws.onerror = (error) => {
                console.error('❌ WebSocket error:', error);
                reject(error);
            };
        });
    }

    async reconnectToGameServer() {
        setTimeout(() => {
            console.log('🔄 Attempting to reconnect...');
            this.connectToGameServer();
        }, 3000);
    }

    handleServerMessage(message) {
        switch (message.type) {
            case 'gameState':
                this.updateGameState(message.data);
                break;
            case 'player_joined':
                this.addPlayer(message.data);
                break;
            case 'player_left':
                this.removePlayer(message.data.playerId);
                break;
            case 'player_eliminated':
                this.handlePlayerElimination(message.data);
                break;
            case 'player_update':
                this.handlePlayerUpdate(message.data);
                break;
            case 'player_split':
                this.handlePlayerSplit(message.data);
                break;
            case 'initiateCashout':
                this.handleInitiateCashout(message.data);
                break;
            case 'cashoutComplete':
                this.handleCashoutComplete(message.data);
                break;
            case 'food_update':
                this.handleFoodUpdate(message.food);
                break;
            case 'food_spawned':
                this.addFood(message.food);
                break;
            case 'food_eaten':
                this.removeFood(message.foodId);
                break;
            case 'virus_update':
                this.handleVirusUpdate(message.viruses);
                break;
            case 'virus_split':
                this.handleVirusSplit(message.viruses);
                break;
            case 'error':
                console.error('❌ Server error:', message.error);
                break;
        }
    }

    async startGame(betAmount) {
        try {
            console.log(`🎮 Starting game with bet: €${betAmount}`);
            
            // Process payment
            const user = window.authSystem?.currentUser;
            if (!user || !user.username) {
                throw new Error('User not logged in or username missing');
            }
            
            const lobbyId = window.lobbySystem?.currentLobby?.id || 1;
            const paymentResult = await window.lobbyWalletManager.addPlayerBet(
                lobbyId,
                user.username,
                betAmount
            );
            
            if (!paymentResult || !paymentResult.success) {
                throw new Error(`Payment failed: ${paymentResult?.error || 'Unknown error'}`);
            }
            
            console.log('🎮 Payment processed successfully, initializing game...');
            
            // Calculate realistic mass: 100 mass for 0.25 bet + 5% per 0.10 increase
            const baseMass = 100; // Base mass for minimum bet (0.25)
            const minimumBet = 0.25;
            const extraBetAmount = Math.max(0, betAmount - minimumBet);
            const massMultiplier = 1 + (extraBetAmount / 0.10) * 0.05; // 5% per 0.10 increase
            const playerMass = baseMass * massMultiplier;
            
            // Calculate size using the same function as everywhere else
            const spawnSize = this.calculateSizeFromMoney(betAmount);
            
            // Store bet amount for display
            this.localPlayer.betAmount = betAmount;
            
            // Send join game message to server
            this.sendToServer({
                type: 'joinGame',
                data: {
                    playerId: user.username,
                    betAmount: betAmount,
                    mass: playerMass,
                    spawnSize: spawnSize,
                    lobbyId: lobbyId
                }
            });
            
            // Initialize local player
            this.localPlayer.id = user.username;
            this.localPlayer.totalMoney = betAmount;
            this.localPlayer.balls = [{
                id: 'ball_0',
                x: Math.random() * this.gameState.gameArea.width,
                y: Math.random() * this.gameState.gameArea.height,
                size: spawnSize,
                money: betAmount,
                vx: 0,
                vy: 0
            }];
            this.localPlayer.isAlive = true;
            this.localPlayer.kills = 0;
            this.localPlayer.startTime = Date.now();
            
            // Start game loop
            this.startGameLoop();
            
            console.log('✅ Game started successfully');
            return true;
            
        } catch (error) {
            console.error('❌ Failed to start game:', error);
            throw error;
        }
    }

    async startGameWithoutPayment(betAmount) {
        try {
            console.log(`🎮 Starting game without payment processing (already done): €${betAmount}`);
            
            const user = window.authSystem?.currentUser;
            if (!user || !user.username) {
                throw new Error('User not logged in or username missing');
            }
            
            const lobbyId = window.lobbySystem?.currentLobby?.id || 1;
            
            console.log('🎮 Payment already processed, initializing game immediately...');
            
            // Calculate realistic mass: 100 mass for 0.25 bet + 5% per 0.10 increase
            const baseMass = 100; // Base mass for minimum bet (0.25)
            const minimumBet = 0.25;
            const extraBetAmount = Math.max(0, betAmount - minimumBet);
            const massMultiplier = 1 + (extraBetAmount / 0.10) * 0.05; // 5% per 0.10 increase
            const playerMass = baseMass * massMultiplier;
            
            // Calculate size using the same function as everywhere else
            const spawnSize = this.calculateSizeFromMoney(betAmount);
            
            // Store bet amount for display
            this.localPlayer.betAmount = betAmount;
            
            // Send join game message to server
            this.sendToServer({
                type: 'joinGame',
                data: {
                    playerId: user.username,
                    betAmount: betAmount,
                    mass: playerMass,
                    spawnSize: spawnSize,
                    lobbyId: lobbyId
                }
            });
            
            // Initialize local player
            this.localPlayer.id = user.username;
            this.localPlayer.totalMoney = betAmount;
            this.localPlayer.balls = [{
                id: 'ball_0',
                x: Math.random() * this.gameState.gameArea.width,
                y: Math.random() * this.gameState.gameArea.height,
                size: spawnSize,
                money: betAmount,
                vx: 0,
                vy: 0
            }];
            this.localPlayer.isAlive = true;
            this.localPlayer.kills = 0;
            this.localPlayer.startTime = Date.now();
            
            // Start game loop immediately
            this.startGameLoop();
            
            console.log('✅ Game started successfully without payment processing');
            return true;
            
        } catch (error) {
            console.error('❌ Failed to start game without payment:', error);
            throw error;
        }
    }

    startGameLoop() {
        const gameLoop = (timestamp) => {
            const deltaTime = timestamp - this.lastUpdate;
            this.lastUpdate = timestamp;
            
            this.update(deltaTime);
            this.render();
            
            if (this.localPlayer.isAlive) {
                this.animationId = requestAnimationFrame(gameLoop);
            }
        };
        
        this.animationId = requestAnimationFrame(gameLoop);
    }

    update(deltaTime) {
        if (!this.localPlayer.isAlive) return;
        
        // Update player movement
        this.updatePlayerMovement(deltaTime);
        
        // Update mass drops physics
        this.updateMassDrops(deltaTime);
        
        // Update camera
        this.updateCamera();
        
        // Update cashout progress
        this.updateCashout(deltaTime);
        
        // Send player state to server
        this.sendPlayerState();
        
        // Update stats panel
        this.updateStatsPanel();
        
        // Update ball animations
        this.updateBallAnimations(deltaTime);
    }
    
    updateBallAnimations(deltaTime) {
        // Update animations for local player balls
        this.localPlayer.balls.forEach(ball => {
            this.updateBallAnimation(ball);
        });
        
        // Update animations for other players
        Object.values(this.gameState.players).forEach(player => {
            if (player.balls) {
                player.balls.forEach(ball => {
                    this.updateBallAnimation(ball);
                });
            }
        });
    }
    
    updateBallAnimation(ball) {
        if (ball.targetSize !== undefined && ball.animationStartTime !== undefined) {
            const elapsed = Date.now() - ball.animationStartTime;
            const progress = Math.min(elapsed / ball.animationDuration, 1);
            
            // Smooth easing function (ease-out)
            const easedProgress = 1 - Math.pow(1 - progress, 3);
            
            // Interpolate between current size and target size
            const startSize = ball.startSize || ball.size;
            if (ball.startSize === undefined) {
                ball.startSize = ball.size;
            }
            
            ball.size = startSize + (ball.targetSize - startSize) * easedProgress;
            
            // Animation complete
            if (progress >= 1) {
                ball.size = ball.targetSize;
                delete ball.targetSize;
                delete ball.animationStartTime;
                delete ball.animationDuration;
                delete ball.startSize;
            }
        }
    }
    
    updateStatsPanel() {
        if (!this.localPlayer.isAlive) return;
        
        // Calculate total money from all balls
        const totalMoney = this.localPlayer.balls.reduce((sum, ball) => sum + ball.money, 0);
        
        // Calculate total mass from all balls (mass = π * radius²)
        const totalMass = this.localPlayer.balls.reduce((sum, ball) => {
            const radius = ball.size / 2;
            return sum + (Math.PI * radius * radius);
        }, 0);
        
        // Get bet size from game manager
        const betSize = window.gameManager ? window.gameManager.selectedBetAmount : 0;
        
        // Update stat elements
        const betSizeElement = document.getElementById('stat-bet-size');
        if (betSizeElement) {
            betSizeElement.textContent = `€${betSize.toFixed(2)}`;
        }
        
        const ballBalanceElement = document.getElementById('stat-ball-balance');
        if (ballBalanceElement) {
            ballBalanceElement.textContent = `€${totalMoney.toFixed(2)}`;
        }
        
        const ballMassElement = document.getElementById('stat-ball-mass');
        if (ballMassElement) {
            ballMassElement.textContent = Math.round(totalMass).toString();
        }
        
        const killsElement = document.getElementById('stat-kills');
        if (killsElement) {
            killsElement.textContent = this.localPlayer.kills.toString();
        }
    }

    updatePlayerMovement(deltaTime) {
        const mouseWorldX = this.input.mouse.x + this.gameState.camera.x - this.canvas.width / 2;
        const mouseWorldY = this.input.mouse.y + this.gameState.camera.y - this.canvas.height / 2;
        
        this.localPlayer.balls.forEach(ball => {
            // Handle split animation movement with agma.io style physics
            if (ball.isSplitting && ball.vx !== undefined && ball.vy !== undefined) {
                const elapsed = Date.now() - ball.animationStartTime;
                const progress = Math.min(elapsed / ball.animationDuration, 1);
                
                // Apply split velocity with decay (agma.io style)
                const decayFactor = ball.splitDecay || 0.92;
                ball.x += ball.vx * deltaTime / 1000;
                ball.y += ball.vy * deltaTime / 1000;
                
                // Apply velocity decay
                ball.vx *= Math.pow(decayFactor, deltaTime / 16.67); // Normalize for 60fps
                ball.vy *= Math.pow(decayFactor, deltaTime / 16.67);
                
                // End split animation when velocity is low enough or time elapsed
                if (progress >= 1 || (Math.abs(ball.vx) < 10 && Math.abs(ball.vy) < 10)) {
                    delete ball.targetX;
                    delete ball.targetY;
                    delete ball.isSplitting;
                    delete ball.splitDecay;
                    // Keep some residual velocity
                    ball.vx = (ball.vx || 0) * 0.1;
                    ball.vy = (ball.vy || 0) * 0.1;
                }
            } else {
                // Normal movement towards mouse with size-based speed
                const dx = mouseWorldX - ball.x;
                const dy = mouseWorldY - ball.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance > 0) {
                    // Size-based movement speed (smaller = faster) like agma.io
                    const mass = Math.PI * (ball.size / 2) * (ball.size / 2);
                    const baseSpeed = 300;
                    const speed = Math.max(30, baseSpeed / Math.sqrt(mass / 100 + 1));
                    
                    const normalizedDx = dx / distance;
                    const normalizedDy = dy / distance;
                    
                    // Apply movement with inertia
                    const acceleration = 0.15;
                    const targetVx = normalizedDx * speed;
                    const targetVy = normalizedDy * speed;
                    
                    ball.vx = (ball.vx || 0) + (targetVx - (ball.vx || 0)) * acceleration;
                    ball.vy = (ball.vy || 0) + (targetVy - (ball.vy || 0)) * acceleration;
                    
                    ball.x += ball.vx * deltaTime / 1000;
                    ball.y += ball.vy * deltaTime / 1000;
                } else {
                    // Apply friction when not moving towards mouse
                    ball.vx = (ball.vx || 0) * 0.95;
                    ball.vy = (ball.vy || 0) * 0.95;
                    
                    ball.x += ball.vx * deltaTime / 1000;
                    ball.y += ball.vy * deltaTime / 1000;
                }
            }
            
            // Keep within game area
            ball.x = Math.max(ball.size, Math.min(this.gameState.gameArea.width - ball.size, ball.x));
            ball.y = Math.max(ball.size, Math.min(this.gameState.gameArea.height - ball.size, ball.y));
        });
        
        // Check for ball merging
        this.checkBallMerging();
    }

    updateMassDrops(deltaTime) {
        // Update mass drop physics
        for (let i = this.gameState.massDrops.length - 1; i >= 0; i--) {
            const mass = this.gameState.massDrops[i];
            
            // Move mass drop based on velocity
            mass.x += mass.vx * deltaTime / 1000;
            mass.y += mass.vy * deltaTime / 1000;
            
            // Apply different physics for feed balls vs regular mass drops
            if (mass.isFeedBall) {
                // Agar.io style feed ball physics - faster deceleration
                mass.vx *= 0.92; // Faster deceleration for feed balls
                mass.vy *= 0.92;
                
                // Feed balls disappear faster (15 seconds)
                if (Date.now() - (mass.createdAt || Date.now()) > 15000) {
                    this.gameState.massDrops.splice(i, 1);
                    continue;
                }
            } else {
                // Regular mass drops (from splits) - slower deceleration
                mass.vx *= 0.98;
                mass.vy *= 0.98;
                
                // Regular mass drops last longer (30 seconds)
                if (Date.now() - (mass.createdAt || Date.now()) > 30000) {
                    this.gameState.massDrops.splice(i, 1);
                    continue;
                }
            }
            
            // Keep within game area
            mass.x = Math.max(mass.size, Math.min(this.gameState.gameArea.width - mass.size, mass.x));
            mass.y = Math.max(mass.size, Math.min(this.gameState.gameArea.height - mass.size, mass.y));
        }
    }

    updateCamera() {
        if (this.localPlayer.balls.length === 0) return;
        
        // Center camera on player's balls
        let avgX = 0, avgY = 0;
        this.localPlayer.balls.forEach(ball => {
            avgX += ball.x;
            avgY += ball.y;
        });
        avgX /= this.localPlayer.balls.length;
        avgY /= this.localPlayer.balls.length;
        
        this.gameState.camera.x = avgX;
        this.gameState.camera.y = avgY;
    }

    split() {
        if (this.localPlayer.balls.length >= 16) return; // Max 16 balls
        
        const newBalls = [];
        
        this.localPlayer.balls.forEach(ball => {
            // Need at least 0.10 money to split (0.05 minimum for each resulting ball)
            if (ball.money >= 0.10) {
                const halfMoney = ball.money / 2;
                
                // Ensure each ball has at least 0.05 money
                if (halfMoney < 0.05) return;
                
                // Calculate split direction towards mouse
                const mouseWorldX = this.input.mouse.x + this.gameState.camera.x - this.canvas.width / 2;
                const mouseWorldY = this.input.mouse.y + this.gameState.camera.y - this.canvas.height / 2;
                
                const dx = mouseWorldX - ball.x;
                const dy = mouseWorldY - ball.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance > 0) {
                    const normalizedDx = dx / distance;
                    const normalizedDy = dy / distance;
                    
                    // Calculate new size using consistent function
                    const newSize = this.calculateSizeFromMoney(halfMoney);
                    
                    // Agma.io style split physics - based on mass/size
                    const mass = Math.PI * (ball.size / 2) * (ball.size / 2);
                    const splitForce = Math.max(150, Math.min(400, 200 + Math.sqrt(mass) * 2));
                    const splitDistance = Math.max(ball.size * 1.2, Math.min(ball.size * 2.5, ball.size + Math.sqrt(mass) * 0.8));
                    
                    // Update original ball
                    ball.money = halfMoney;
                    ball.targetSize = newSize;
                    ball.startSize = ball.size;
                    ball.animationStartTime = Date.now();
                    ball.animationDuration = 300; // Faster animation like agma.io
                    ball.mergeTime = Date.now() + 30000; // 30 seconds merge cooldown like agma.io
                    
                    // Add slight recoil to original ball (opposite direction)
                    ball.vx = (ball.vx || 0) - normalizedDx * (splitForce * 0.3);
                    ball.vy = (ball.vy || 0) - normalizedDy * (splitForce * 0.3);
                    
                    // Create new ball with agma.io style physics
                    const newBall = {
                        id: `ball_${Date.now()}_${Math.random()}`,
                        x: ball.x + normalizedDx * (ball.size * 0.6), // Start slightly offset
                        y: ball.y + normalizedDy * (ball.size * 0.6),
                        targetX: ball.x + normalizedDx * splitDistance,
                        targetY: ball.y + normalizedDy * splitDistance,
                        size: ball.size, // Start with original size
                        targetSize: newSize,
                        startSize: ball.size,
                        money: halfMoney,
                        vx: normalizedDx * splitForce,
                        vy: normalizedDy * splitForce,
                        mergeTime: Date.now() + 30000, // 30 seconds merge cooldown
                        animationStartTime: Date.now(),
                        animationDuration: 300, // Faster animation
                        isSplitting: true,
                        splitDecay: 0.92 // Velocity decay factor for split movement
                    };
                    
                    newBalls.push(newBall);
                }
            }
        });
        
        this.localPlayer.balls.push(...newBalls);
        
        // Send split action to server
        this.sendToServer({
            type: 'player_split',
            data: {
                playerId: this.localPlayer.id,
                balls: this.localPlayer.balls
            }
        });
    }

    feedMass() {
        if (this.localPlayer.balls.length === 0) return;
        
        // Find largest ball to feed from
        let largestBall = this.localPlayer.balls[0];
        this.localPlayer.balls.forEach(ball => {
            if (ball.money > largestBall.money) {
                largestBall = ball;
            }
        });
        
        if (largestBall.money >= 0.06) { // Need at least 0.06 to feed 0.01 and stay above 0.05
            largestBall.money -= 0.01; // Standard agar.io feed amount
            largestBall.size = this.calculateSizeFromMoney(largestBall.money);
            
            // Calculate feed direction towards mouse
            const mouseWorldX = this.input.mouse.x + this.gameState.camera.x - this.canvas.width / 2;
            const mouseWorldY = this.input.mouse.y + this.gameState.camera.y - this.canvas.height / 2;
            
            const dx = mouseWorldX - largestBall.x;
            const dy = mouseWorldY - largestBall.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance > 0) {
                const normalizedDx = dx / distance;
                const normalizedDy = dy / distance;
                
                // Agar.io/Agma.io style feed ball physics
                const feedDistance = largestBall.size * 0.8; // Spawn closer to ball edge
                const feedSpeed = 400; // Faster like agar.io
                
                const massDrop = {
                    id: `mass_${Date.now()}_${Math.random()}`,
                    x: largestBall.x + normalizedDx * feedDistance,
                    y: largestBall.y + normalizedDy * feedDistance,
                    size: 8, // Smaller feed balls like agar.io
                    money: 0.01, // Standard agar.io feed amount
                    vx: normalizedDx * feedSpeed,
                    vy: normalizedDy * feedSpeed,
                    playerId: this.localPlayer.id,
                    createdAt: Date.now(),
                    isFeedBall: true // Mark as feed ball for special physics
                };
                
                this.gameState.massDrops.push(massDrop);
                
                // Send mass feed to server
                this.sendToServer({
                    type: 'massFeed',
                    data: {
                        playerId: this.localPlayer.id,
                        massDrop: massDrop,
                        fromBall: largestBall
                    }
                });
            }
        }
    }

    startCashout() {
        if (!this.isCashingOut && !this.isCashoutCompleted && this.localPlayer.isAlive) {
            this.isCashingOut = true;
            this.cashoutProgress = 0;
            console.log('💰 Starting cashout...');
        } else if (this.isCashoutCompleted) {
            console.log('🚫 Cashout already completed - ignoring additional attempts');
        }
    }

    stopCashout() {
        if (this.isCashingOut) {
            this.isCashingOut = false;
            this.cashoutProgress = 0;
            console.log('❌ Cashout cancelled');
        }
    }

    updateCashout(deltaTime) {
        if (this.isCashingOut && this.input.keys.has('KeyQ')) {
            this.cashoutProgress += deltaTime / 5000; // 5 seconds
            
            if (this.cashoutProgress >= 1) {
                this.isCashingOut = false; // Prevent multiple calls
                this.completeCashout();
            }
        } else if (this.isCashingOut) {
            this.stopCashout();
        }
    }

    async completeCashout() {
        // Prevent multiple cashout attempts
        if (this.isCashoutCompleted) {
            console.log('🚫 Cashout already completed - ignoring additional attempts');
            return;
        }
        
        // Mark cashout as completed to prevent multiple attempts
        this.isCashoutCompleted = true;
        
        const totalMoney = this.localPlayer.balls.reduce((sum, ball) => sum + ball.money, 0);
        const playtime = Math.floor((Date.now() - this.localPlayer.startTime) / 1000);
        
        try {
            // Check if user is logged in and has lobby wallet access
            if (!window.authSystem || !window.authSystem.isLoggedIn) {
                throw new Error('You must be logged in to cashout');
            }
            
            if (!window.lobbyWalletManager) {
                throw new Error('Lobby wallet system not available');
            }
            
            const currentUser = window.authSystem.getCurrentUser();
            if (!currentUser || !currentUser.username) {
                throw new Error('User information not available');
            }
            
            // Get current lobby ID
            const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
            if (!currentLobby || !currentLobby.id) {
                throw new Error('Not in a valid lobby for cashout');
            }
            
            // Show loading state
            this.showCashoutLoadingAnimation();
            
            console.log(`💸 Processing cashout: €${totalMoney} for user ${currentUser.username} in lobby ${currentLobby.id}`);
            
            // Use lobby wallet system for real blockchain transaction
            const cashoutResult = await window.lobbyWalletManager.handlePlayerCashout(
                currentLobby.id,
                currentUser.username,
                totalMoney // Exact amount on balls, no fees (covered by €0.10 entry fee)
            );
            
            if (cashoutResult.success) {
                // Get SOL amount for display
                const solPrice = await window.walletSystem.getRealSolPrice();
                const solAmount = totalMoney / solPrice;
                
                // Send success notification to server for tracking
                this.sendToServer({
                    type: 'cashout',
                    data: {
                        playerId: this.localPlayer.id,
                        amount: totalMoney,
                        solAmount: solAmount,
                        kills: this.localPlayer.kills,
                        playtime: playtime,
                        transactionSuccess: true,
                        signature: cashoutResult.transferSignature || null,
                        blockchainTransaction: cashoutResult.transferredToWallet
                    }
                });
                
                const message = cashoutResult.transferredToWallet 
                    ? `Successfully transferred €${totalMoney} (${solAmount.toFixed(6)} SOL) to your wallet via Solana blockchain`
                    : `Added €${totalMoney} (${solAmount.toFixed(6)} SOL) to your internal wallet`;
                
                this.showCashoutSuccessAnimation(totalMoney, solAmount, this.localPlayer.kills, playtime, message);
            } else {
                throw new Error(cashoutResult.error || 'Cashout failed');
            }
            
        } catch (error) {
            console.error('💥 Cashout failed:', error);
            
            // Send failure notification to server
            this.sendToServer({
                type: 'cashout',
                data: {
                    playerId: this.localPlayer.id,
                    amount: totalMoney,
                    kills: this.localPlayer.kills,
                    playtime: playtime,
                    transactionSuccess: false,
                    error: error.message
                }
            });
            
            this.showCashoutErrorAnimation(error.message);
        }
        
        // End game after cashout attempt
        setTimeout(() => {
            this.endGame();
        }, 3000);
    }

    showCashoutLoadingAnimation() {
        // Create loading overlay
        const overlay = document.createElement('div');
        overlay.id = 'cashout-loading-overlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        `;
        
        overlay.innerHTML = `
            <div style="
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 40px;
                border-radius: 20px;
                text-align: center;
                color: white;
                box-shadow: 0 20px 40px rgba(0,0,0,0.3);
                max-width: 400px;
                width: 90%;
            ">
                <div style="
                    width: 60px;
                    height: 60px;
                    border: 4px solid rgba(255,255,255,0.3);
                    border-top: 4px solid white;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                    margin: 0 auto 20px;
                "></div>
                <h2 style="margin: 0 0 10px; font-size: 24px;">Processing Cashout...</h2>
                <p style="margin: 0; opacity: 0.8; font-size: 16px;">Please wait while we process your transaction</p>
            </div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
        
        document.body.appendChild(overlay);
    }
    
    showCashoutSuccessAnimation(amount, solAmount, kills, playtime, message) {
        // Remove loading overlay
        const loadingOverlay = document.getElementById('cashout-loading-overlay');
        if (loadingOverlay) {
            loadingOverlay.remove();
        }
        
        // Create modern success overlay similar to the second screen
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(0, 0, 0, 0.4), rgba(20, 20, 20, 0.4));
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            backdrop-filter: blur(5px);
        `;
        
        overlay.innerHTML = `
            <div style="
                background: linear-gradient(145deg, #1a1a1a, #2d2d2d);
                border-radius: 20px;
                padding: 40px;
                text-align: center;
                color: white;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
                border: 1px solid rgba(255, 255, 255, 0.1);
                max-width: 400px;
                width: 90%;
                animation: slideIn 0.5s ease-out;
            ">
                <div style="margin-bottom: 30px;">
                    <div style="font-size: 18px; color: #4CAF50; margin-bottom: 10px;">Cashout Successful</div>
                    <div style="font-size: 48px; font-weight: bold; margin-bottom: 20px; color: #4CAF50;">CASHED OUT</div>
                    <div style="font-size: 48px; font-weight: bold; color: #4CAF50; margin: 20px 0;">€${amount.toFixed(2)} EUR</div>
                    <div style="font-size: 14px; color: #888;">+${((amount / 1) * 100).toFixed(0)}% PnL</div>
                </div>
                
                <div style="background: #2a2a2a; border-radius: 15px; padding: 20px; margin: 20px 0;">
                    <div style="font-size: 16px; font-weight: bold; margin-bottom: 15px;">Game Summary</div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                        <span style="color: #888;">Time Alive:</span>
                        <span>${playtime} seconds</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                        <span style="color: #888;">Players Killed:</span>
                        <span>${kills}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                        <span style="color: #888;">SOL Amount:</span>
                        <span>${solAmount.toFixed(6)} SOL</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #888;">Final Score:</span>
                        <span style="color: #4CAF50;">${amount.toFixed(2)} points</span>
                    </div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button id="returnToLobby" style="
                        background: linear-gradient(45deg, #4CAF50, #66BB6A);
                        border: none;
                        border-radius: 25px;
                        padding: 15px 40px;
                        color: white;
                        font-size: 16px;
                        font-weight: bold;
                        cursor: pointer;
                        transition: all 0.3s ease;
                        box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
                    ">Return to Lobby</button>
                </div>
                
                <div style="margin-top: 15px; font-size: 12px; color: #666;">
                    ${message}
                </div>
            </div>
            <style>
                @keyframes slideIn {
                    from {
                        opacity: 0;
                        transform: translateY(-50px) scale(0.9);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0) scale(1);
                    }
                }
                #returnToLobby:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 6px 20px rgba(76, 175, 80, 0.4);
                }
            </style>
        `;
        
        document.body.appendChild(overlay);
        
        // Add click handler for return button
        const returnButton = overlay.querySelector('#returnToLobby');
        if (returnButton) {
            returnButton.addEventListener('click', () => {
                if (overlay.parentNode) {
                    overlay.remove();
                }
                // Redirect to lobby or restart game
                window.location.reload();
            });
        }
        
        // Auto remove after 10 seconds
        setTimeout(() => {
            if (overlay.parentNode) {
                overlay.remove();
                window.location.reload();
            }
        }, 10000);
    }
    
    showCashoutErrorAnimation(errorMessage) {
        // Remove loading overlay
        const loadingOverlay = document.getElementById('cashout-loading-overlay');
        if (loadingOverlay) {
            loadingOverlay.remove();
        }
        
        // Create error overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        `;
        
        overlay.innerHTML = `
            <div style="
                background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
                padding: 40px;
                border-radius: 20px;
                text-align: center;
                color: white;
                box-shadow: 0 20px 40px rgba(0,0,0,0.3);
                max-width: 500px;
                width: 90%;
                animation: slideIn 0.5s ease-out;
            ">
                <div style="
                    font-size: 60px;
                    margin-bottom: 20px;
                ">❌</div>
                <h2 style="margin: 0 0 20px; font-size: 28px;">Cashout Failed</h2>
                <div style="background: rgba(255,255,255,0.1); padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <p style="margin: 0; font-size: 16px; opacity: 0.9;">${errorMessage}</p>
                </div>
                <p style="margin: 0; opacity: 0.8; font-size: 14px;">Please try again or contact support if the problem persists.</p>
            </div>
            <style>
                @keyframes slideIn {
                    from { transform: translateY(-50px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
            </style>
        `;
        
        document.body.appendChild(overlay);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            if (overlay.parentNode) {
                overlay.remove();
            }
        }, 3000);
    }

    showCashoutAnimation(amount, kills, playtime) {
        // Create cashout overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            font-family: Arial, sans-serif;
            z-index: 1000;
        `;
        
        overlay.innerHTML = `
            <h1 style="font-size: 3em; margin: 0; color: #4CAF50;">CASHED OUT!</h1>
            <div style="font-size: 1.5em; margin: 20px 0;">
                <div>Amount: €${amount.toFixed(2)}</div>
                <div>Kills: ${kills}</div>
                <div>Playtime: ${Math.floor(playtime / 60)}:${(playtime % 60).toString().padStart(2, '0')}</div>
            </div>
            <div style="font-size: 1em; opacity: 0.7;">Returning to lobby...</div>
        `;
        
        document.body.appendChild(overlay);
        
        setTimeout(() => {
            document.body.removeChild(overlay);
            window.location.href = '/main.php';
        }, 3000);
    }

    calculateSizeFromMoney(money) {
        // Base size of 40, grows with money - reduced by 50% for proper agar.io size
        return (40 + Math.sqrt(money * 1000)) * 0.5; // Reduced base size and multiplier for 50% smaller
    }

    checkBallMerging() {
        if (this.localPlayer.balls.length <= 1) return;
        
        const currentTime = Date.now();
        const ballsToMerge = [];
        
        // First separate overlapping balls to prevent glitching
        this.separateOverlappingBalls();
        
        for (let i = 0; i < this.localPlayer.balls.length; i++) {
            for (let j = i + 1; j < this.localPlayer.balls.length; j++) {
                const ball1 = this.localPlayer.balls[i];
                const ball2 = this.localPlayer.balls[j];
                
                // Calculate merge time based on ball size (bigger balls take longer to merge)
                const avgSize = (ball1.size + ball2.size) / 2;
                const mergeDelay = Math.max(5000, avgSize * 100); // Minimum 5 seconds, increases with size
                
                // Check if both balls can merge based on their individual timers
                const ball1CanMerge = currentTime > (ball1.mergeTime || 0);
                const ball2CanMerge = currentTime > (ball2.mergeTime || 0);
                
                if (ball1CanMerge && ball2CanMerge) {
                    const dx = ball1.x - ball2.x;
                    const dy = ball1.y - ball2.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    // Balls must be very close to merge (like agar.io)
                    if (distance < (ball1.size + ball2.size) * 0.7) {
                        ballsToMerge.push([i, j, mergeDelay]);
                    }
                }
            }
        }
        
        // Merge balls (process in reverse order to maintain indices)
        ballsToMerge.reverse().forEach(([i, j, mergeDelay]) => {
            if (i < this.localPlayer.balls.length && j < this.localPlayer.balls.length) {
                const ball1 = this.localPlayer.balls[i];
                const ball2 = this.localPlayer.balls[j];
                
                // Merge into ball1 with smooth animation
                ball1.money += ball2.money;
                const newTargetSize = this.calculateSizeFromMoney(ball1.money);
                ball1.targetSize = newTargetSize;
                ball1.animationStartTime = Date.now();
                ball1.animationDuration = 400; // 400ms for merge animation
                ball1.mergeTime = Date.now() + mergeDelay; // Set merge timer based on new size
                
                // Remove ball2
                this.localPlayer.balls.splice(j, 1);
            }
        });
    }

    separateOverlappingBalls() {
        const maxIterations = 3; // Limit iterations to prevent performance issues
        
        for (let iteration = 0; iteration < maxIterations; iteration++) {
            let hadCollision = false;
            
            for (let i = 0; i < this.localPlayer.balls.length; i++) {
                for (let j = i + 1; j < this.localPlayer.balls.length; j++) {
                    const ball1 = this.localPlayer.balls[i];
                    const ball2 = this.localPlayer.balls[j];
                    
                    const dx = ball1.x - ball2.x;
                    const dy = ball1.y - ball2.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    const minDistance = ball1.size + ball2.size; // No buffer - balls can touch
                    
                    if (distance < minDistance && distance > 0) {
                        hadCollision = true;
                        
                        // Calculate separation force with physics-like repulsion
                        const overlap = minDistance - distance;
                        const separationForce = overlap * 0.8; // Stronger separation
                        
                        const normalX = dx / distance;
                        const normalY = dy / distance;
                        
                        // Apply mass-based separation (larger balls push smaller ones more)
                        const totalMass = ball1.size + ball2.size;
                        const ball1Ratio = ball2.size / totalMass; // Inverse ratio
                        const ball2Ratio = ball1.size / totalMass;
                        
                        // Move balls apart based on mass
                        ball1.x += normalX * separationForce * ball1Ratio;
                        ball1.y += normalY * separationForce * ball1Ratio;
                        ball2.x -= normalX * separationForce * ball2Ratio;
                        ball2.y -= normalY * separationForce * ball2Ratio;
                        
                        // Keep balls within game area
                        ball1.x = Math.max(ball1.size, Math.min(this.gameState.gameArea.width - ball1.size, ball1.x));
                        ball1.y = Math.max(ball1.size, Math.min(this.gameState.gameArea.height - ball1.size, ball1.y));
                        ball2.x = Math.max(ball2.size, Math.min(this.gameState.gameArea.width - ball2.size, ball2.x));
                        ball2.y = Math.max(ball2.size, Math.min(this.gameState.gameArea.height - ball2.size, ball2.y));
                    }
                }
            }
            
            // If no collisions in this iteration, we're done
            if (!hadCollision) break;
        }
    }

    adjustBallPosition(newBall) {
        let attempts = 0;
        const maxAttempts = 10; // Reduced to prevent infinite loops
        
        while (attempts < maxAttempts) {
            let hasCollision = false;
            
            for (const existingBall of this.localPlayer.balls) {
                if (existingBall === newBall) continue;
                
                const dx = newBall.x - existingBall.x;
                const dy = newBall.y - existingBall.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const minDistance = newBall.size + existingBall.size; // No buffer - balls can touch
                
                if (distance < minDistance) {
                    hasCollision = true;
                    // Move ball away from collision
                    if (distance > 0) {
                        const angle = Math.atan2(dy, dx);
                        const pushDistance = minDistance + 5;
                        newBall.x = existingBall.x + Math.cos(angle) * pushDistance;
                        newBall.y = existingBall.y + Math.sin(angle) * pushDistance;
                    } else {
                        // If balls are exactly on top of each other, move randomly
                        const randomAngle = Math.random() * Math.PI * 2;
                        newBall.x = existingBall.x + Math.cos(randomAngle) * (minDistance + 5);
                        newBall.y = existingBall.y + Math.sin(randomAngle) * (minDistance + 5);
                    }
                    
                    // Keep balls within game area
                    newBall.x = Math.max(newBall.size, Math.min(this.gameState.gameArea.width - newBall.size, newBall.x));
                    newBall.y = Math.max(newBall.size, Math.min(this.gameState.gameArea.height - newBall.size, newBall.y));
                    break;
                }
            }
            
            if (!hasCollision) break;
            attempts++;
        }
        
        // If still colliding after max attempts, place ball at a safe distance
        if (attempts >= maxAttempts && this.localPlayer.balls.length > 1) {
            const centerX = this.gameState.gameArea.width / 2;
            const centerY = this.gameState.gameArea.height / 2;
            const safeDistance = 200;
            const randomAngle = Math.random() * Math.PI * 2;
            newBall.x = centerX + Math.cos(randomAngle) * safeDistance;
            newBall.y = centerY + Math.sin(randomAngle) * safeDistance;
        }
    }

    sendToServer(message) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(message));
        }
    }

    sendPlayerState() {
        this.sendToServer({
            type: 'player_update',
            data: {
                playerId: this.localPlayer.id,
                balls: this.localPlayer.balls,
                totalMoney: this.localPlayer.balls.reduce((sum, ball) => sum + ball.money, 0)
            }
        });
    }

    render() {
        // Clear canvas with black background
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Save context for camera transform
        this.ctx.save();
        
        // Apply camera transform with zoom
        this.ctx.scale(this.gameState.camera.zoom, this.gameState.camera.zoom);
        this.ctx.translate(
            (this.canvas.width / 2) / this.gameState.camera.zoom - this.gameState.camera.x,
            (this.canvas.height / 2) / this.gameState.camera.zoom - this.gameState.camera.y
        );
        
        // Draw game area border with thin red glow
        this.ctx.strokeStyle = '#ff0000';
        this.ctx.lineWidth = 2;
        this.ctx.shadowColor = '#ff0000';
        this.ctx.shadowBlur = 8;
        this.ctx.strokeRect(0, 0, this.gameState.gameArea.width, this.gameState.gameArea.height);
        this.ctx.shadowBlur = 0;
        
        // Draw grid
        this.drawGrid();
        
        // Draw food
        this.drawFood();
        
        // Draw viruses
        this.drawViruses();
        
        // Draw mass drops
        this.drawMassDrops();
        
        // Draw other players
        this.drawOtherPlayers();
        
        // Draw local player
        this.drawLocalPlayer();
        
        // Restore context
        this.ctx.restore();
        
        // Draw UI elements
        this.drawUI();
    }

    drawGrid() {
        const gridSize = 100; // Larger grid for better visibility
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)'; // More visible white with transparency
        this.ctx.lineWidth = 1;
        
        // Vertical lines
        for (let x = 0; x <= this.gameState.gameArea.width; x += gridSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, this.gameState.gameArea.height);
            this.ctx.stroke();
        }
        
        // Horizontal lines
        for (let y = 0; y <= this.gameState.gameArea.height; y += gridSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(this.gameState.gameArea.width, y);
            this.ctx.stroke();
        }
    }

    drawFood() {
        if (!this.gameState.food) return;
        
        this.gameState.food.forEach(food => {
            this.ctx.fillStyle = food.color || '#FF6B6B';
            this.ctx.shadowColor = food.color || '#FF6B6B';
            this.ctx.shadowBlur = 3;
            this.ctx.beginPath();
            this.ctx.arc(food.x, food.y, food.radius, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.shadowBlur = 0;
        });
    }

    drawViruses() {
        if (!this.gameState.viruses) return;
        
        this.gameState.viruses.forEach(virus => {
            this.ctx.fillStyle = virus.color || '#00FF00';
            this.ctx.shadowColor = virus.color || '#00FF00';
            this.ctx.shadowBlur = 5;
            this.ctx.beginPath();
            
            // Draw spiky virus shape
            const spikes = 12;
            const outerRadius = virus.radius;
            const innerRadius = virus.radius * 0.7;
            
            for (let i = 0; i < spikes * 2; i++) {
                const radius = i % 2 === 0 ? outerRadius : innerRadius;
                const angle = (i * Math.PI) / spikes;
                const x = virus.x + Math.cos(angle) * radius;
                const y = virus.y + Math.sin(angle) * radius;
                
                if (i === 0) {
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
            }
            
            this.ctx.closePath();
            this.ctx.fill();
            this.ctx.shadowBlur = 0;
        });
    }

    drawMassDrops() {
        this.gameState.massDrops.forEach(mass => {
            if (mass.isFeedBall) {
                // Feed balls - smaller, different color like agar.io
                this.ctx.fillStyle = '#FF6B6B'; // Red-orange like agar.io feed balls
                this.ctx.shadowColor = '#FF6B6B';
                this.ctx.shadowBlur = 8;
            } else {
                // Regular mass drops - golden color
                this.ctx.fillStyle = '#FFD700';
                this.ctx.shadowColor = '#FFD700';
                this.ctx.shadowBlur = 10;
            }
            
            this.ctx.beginPath();
            this.ctx.arc(mass.x, mass.y, mass.size, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.shadowBlur = 0;
        });
    }

    drawOtherPlayers() {
        this.gameState.players.forEach((player, playerId) => {
            if (playerId !== this.localPlayer.id) {
                this.drawPlayer(player, false);
            }
        });
    }

    drawLocalPlayer() {
        if (this.localPlayer.isAlive) {
            this.drawPlayer(this.localPlayer, true);
        }
    }

    drawPlayer(player, isLocal) {
        player.balls.forEach((ball, index) => {
            // Create modern gradient for ball
            const gradient = this.ctx.createRadialGradient(
                ball.x - ball.size * 0.3, ball.y - ball.size * 0.3, 0,
                ball.x, ball.y, ball.size
            );
            
            if (isLocal) {
                // Green gradient for local player
                gradient.addColorStop(0, '#66ff66');
                gradient.addColorStop(0.7, '#4CAF50');
                gradient.addColorStop(1, '#2E7D32');
            } else {
                // Colorful gradients for other players
                const colors = [
                    ['#ff6b6b', '#ee5a52', '#d63031'],
                    ['#4ecdc4', '#00b894', '#00a085'],
                    ['#45b7d1', '#2196F3', '#1976D2'],
                    ['#f39c12', '#e67e22', '#d35400'],
                    ['#9b59b6', '#8e44ad', '#7d3c98'],
                    ['#1abc9c', '#16a085', '#138d75']
                ];
                const colorSet = colors[index % colors.length];
                gradient.addColorStop(0, colorSet[0]);
                gradient.addColorStop(0.7, colorSet[1]);
                gradient.addColorStop(1, colorSet[2]);
            }
            
            // Draw ball with gradient and glow effect (no border)
            this.ctx.fillStyle = gradient;
            
            // Add glow effect
            this.ctx.shadowColor = isLocal ? '#4CAF50' : colorSet ? colorSet[0] : '#ff6b6b';
            this.ctx.shadowBlur = 20;
            
            this.ctx.beginPath();
            this.ctx.arc(ball.x, ball.y, ball.size, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Reset shadow
            this.ctx.shadowBlur = 0;
            
            // Draw amount in transparent box above ball
            const ballMoney = ball.money || 0;
            if (ballMoney > 0) {
                const boxWidth = Math.max(50, ball.size * 0.9);
                const boxHeight = Math.max(22, ball.size * 0.35);
                const boxX = ball.x - boxWidth / 2;
                const boxY = ball.y - ball.size - boxHeight - 10;
                
                // Semi-transparent box background
                this.ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
                this.ctx.fillRect(boxX, boxY, boxWidth, boxHeight);
                
                // Amount text in box
                this.ctx.fillStyle = '#fff';
                this.ctx.font = `bold ${Math.max(11, ball.size * 0.22)}px Arial`;
                this.ctx.textAlign = 'center';
                this.ctx.textBaseline = 'middle';
                this.ctx.fillText(`€${ballMoney.toFixed(2)}`, ball.x, boxY + boxHeight / 2);
            }
            
            // Draw only player name in center of ball
            if (player.id) {
                this.ctx.fillStyle = '#fff';
                this.ctx.font = `bold ${Math.max(12, ball.size / 3.5)}px Arial`;
                this.ctx.textAlign = 'center';
                this.ctx.textBaseline = 'middle';
                this.ctx.strokeStyle = '#000';
                this.ctx.lineWidth = 2;
                this.ctx.strokeText(player.id, ball.x, ball.y);
                this.ctx.fillText(player.id, ball.x, ball.y);
            }
        });
    }

    drawUI() {
        // Draw cashout progress bar - positioned lower to avoid overlap
        if (this.isCashingOut) {
            const barWidth = 400;
            const barHeight = 25;
            const barX = (this.canvas.width - barWidth) / 2;
            const barY = 120; // Moved down from 50 to avoid overlap
            
            // Modern background with rounded corners
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
            this.ctx.beginPath();
            this.ctx.roundRect(barX - 10, barY - 30, barWidth + 20, barHeight + 40, 15);
            this.ctx.fill();
            
            // Progress bar background with rounded corners
            this.ctx.fillStyle = '#2a2a2a';
            this.ctx.beginPath();
            this.ctx.roundRect(barX, barY, barWidth, barHeight, 12);
            this.ctx.fill();
            
            // Progress bar fill with gradient
            const gradient = this.ctx.createLinearGradient(barX, barY, barX + barWidth, barY);
            gradient.addColorStop(0, '#4CAF50');
            gradient.addColorStop(1, '#66BB6A');
            this.ctx.fillStyle = gradient;
            this.ctx.beginPath();
            this.ctx.roundRect(barX, barY, barWidth * this.cashoutProgress, barHeight, 12);
            this.ctx.fill();
            
            // Progress percentage text
            this.ctx.save();
            this.ctx.fillStyle = '#fff';
            this.ctx.font = 'bold 14px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.shadowColor = '#000';
            this.ctx.shadowBlur = 3;
            this.ctx.fillText(`${Math.round(this.cashoutProgress * 100)}%`, this.canvas.width / 2, barY + barHeight / 2);
            
            // Instruction text
            this.ctx.fillStyle = '#fff';
            this.ctx.font = 'bold 18px Arial';
            this.ctx.fillText('Hold Q to Cash Out', this.canvas.width / 2, barY - 15);
            this.ctx.restore();
        }
        
        // Draw leaderboard
        this.drawLeaderboard();
        
        // Draw minimap
        this.drawMinimap();
        
        // Top-left stats removed - using bottom-left stats panel instead
    }

    drawLeaderboard() {
        const leaderboard = this.getTopPlayers();
        const panelWidth = 220;
        const panelHeight = Math.max(180, 80 + leaderboard.length * 45);
        const startX = this.canvas.width - panelWidth - 20;
        const startY = 50;
        
        // Modern background with rounded corners and blur effect
        this.ctx.save();
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
        this.ctx.beginPath();
        this.ctx.roundRect(startX, startY, panelWidth, panelHeight, 12);
        this.ctx.fill();
        
        // Border
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        this.ctx.lineWidth = 1;
        this.ctx.stroke();
        
        // Header section
        const headerHeight = 50;
        this.ctx.fillStyle = 'rgba(139, 92, 246, 0.1)';
        this.ctx.beginPath();
        this.ctx.roundRect(startX, startY, panelWidth, headerHeight, [12, 12, 0, 0]);
        this.ctx.fill();
        
        // Title with icon
        this.ctx.fillStyle = '#8b5cf6';
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'left';
        this.ctx.fillText('🏆 Leaderboard', startX + 16, startY + 25);
        
        // Live indicator
        this.ctx.fillStyle = '#10b981';
        this.ctx.font = '12px Arial';
        this.ctx.textAlign = 'right';
        this.ctx.fillText('● Live', startX + panelWidth - 16, startY + 25);
        
        // Players list
        leaderboard.forEach((player, index) => {
            const itemY = startY + headerHeight + 16 + index * 45;
            const itemHeight = 40;
            const itemX = startX + 12;
            const itemWidth = panelWidth - 24;
            
            // Player item background
            const isCurrentPlayer = player.id === this.localPlayer.id;
            this.ctx.fillStyle = isCurrentPlayer ? 'rgba(139, 92, 246, 0.15)' : 'rgba(0, 0, 0, 0.3)';
            this.ctx.beginPath();
            this.ctx.roundRect(itemX, itemY, itemWidth, itemHeight, 8);
            this.ctx.fill();
            
            // Player item border
            this.ctx.strokeStyle = isCurrentPlayer ? 'rgba(139, 92, 246, 0.3)' : 'rgba(255, 255, 255, 0.1)';
            this.ctx.lineWidth = 1;
            this.ctx.stroke();
            
            // Rank number
            this.ctx.fillStyle = '#8b5cf6';
            this.ctx.font = 'bold 18px Arial';
            this.ctx.textAlign = 'left';
            this.ctx.fillText(`${index + 1}.`, itemX + 12, itemY + 25);
            
            // Player name
            this.ctx.fillStyle = isCurrentPlayer ? '#fff' : '#fff';
            this.ctx.font = '600 14px Arial';
            this.ctx.fillText(player.id, itemX + 40, itemY + 25);
            
            // Amount
            this.ctx.fillStyle = '#10b981';
            this.ctx.font = 'bold 14px Arial';
            this.ctx.textAlign = 'right';
            this.ctx.fillText(`€${player.totalMoney.toFixed(2)}`, itemX + itemWidth - 12, itemY + 25);
        });
        
        this.ctx.restore();
    }

    drawMinimap() {
        const minimapSize = 150;
        const minimapX = this.canvas.width - minimapSize - 20;
        const minimapY = this.canvas.height - minimapSize - 20;
        
        // Minimap background
        this.ctx.save();
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
        this.ctx.beginPath();
        this.ctx.roundRect(minimapX, minimapY, minimapSize, minimapSize, 8);
        this.ctx.fill();
        
        // Minimap border
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        
        // Calculate scale factor (assuming world size of 2000x2000)
        const worldSize = 2000;
        const scale = minimapSize / worldSize;
        
        // Draw world boundary
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(minimapX, minimapY, minimapSize, minimapSize);
        
        // Draw other players
        if (this.gameState.players) {
            Array.from(this.gameState.players.values()).forEach(player => {
            if (player.id !== this.localPlayer.id && player.balls && player.balls.length > 0) {
                player.balls.forEach(ball => {
                    const mapX = minimapX + (ball.x + worldSize/2) * scale;
                    const mapY = minimapY + (ball.y + worldSize/2) * scale;
                    const ballSize = Math.max(2, Math.min(8, ball.size * scale * 0.5));
                    
                    // Draw player ball
                    this.ctx.fillStyle = ball.color || '#ff6b6b';
                    this.ctx.beginPath();
                    this.ctx.arc(mapX, mapY, ballSize, 0, Math.PI * 2);
                    this.ctx.fill();
                    
                    // Add subtle glow
                    this.ctx.shadowColor = ball.color || '#ff6b6b';
                    this.ctx.shadowBlur = 3;
                    this.ctx.fill();
                    this.ctx.shadowBlur = 0;
                });
            }
        });
        }
        
        // Draw local player (highlighted)
        if (this.localPlayer && this.localPlayer.balls) {
            this.localPlayer.balls.forEach(ball => {
                const mapX = minimapX + (ball.x + worldSize/2) * scale;
                const mapY = minimapY + (ball.y + worldSize/2) * scale;
                const ballSize = Math.max(3, Math.min(10, ball.size * scale * 0.5));
                
                // Draw local player ball with special highlight
                this.ctx.fillStyle = ball.color || '#4CAF50';
                this.ctx.beginPath();
                this.ctx.arc(mapX, mapY, ballSize, 0, Math.PI * 2);
                this.ctx.fill();
                
                // Add white border for local player
                this.ctx.strokeStyle = '#fff';
                this.ctx.lineWidth = 1;
                this.ctx.stroke();
                
                // Add glow effect
                this.ctx.shadowColor = '#4CAF50';
                this.ctx.shadowBlur = 5;
                this.ctx.fill();
                this.ctx.shadowBlur = 0;
            });
        }
        
        this.ctx.restore();
    }

    drawPlayerStats() {
        if (!this.localPlayer.isAlive) return;
        
        const totalMoney = this.localPlayer.balls.reduce((sum, ball) => sum + ball.money, 0);
        const playtime = Math.floor((Date.now() - this.localPlayer.startTime) / 1000);
        
        // Background
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        this.ctx.fillRect(10, 10, 200, 80);
        
        // Stats
        this.ctx.fillStyle = '#fff';
        this.ctx.font = '14px Arial';
        this.ctx.textAlign = 'left';
        this.ctx.fillText(`Money: €${totalMoney.toFixed(2)}`, 20, 30);
        this.ctx.fillText(`Kills: ${this.localPlayer.kills}`, 20, 50);
        this.ctx.fillText(`Time: ${Math.floor(playtime / 60)}:${(playtime % 60).toString().padStart(2, '0')}`, 20, 70);
    }

    getTopPlayers() {
        const allPlayers = [];
        
        // Add local player
        if (this.localPlayer.isAlive) {
            allPlayers.push({
                id: this.localPlayer.id,
                totalMoney: this.localPlayer.balls.reduce((sum, ball) => sum + ball.money, 0)
            });
        }
        
        // Add other players
        this.gameState.players.forEach((player, playerId) => {
            if (playerId !== this.localPlayer.id) {
                allPlayers.push({
                    id: playerId,
                    totalMoney: player.balls.reduce((sum, ball) => sum + ball.money, 0)
                });
            }
        });
        
        // Sort by money and return top 5
        return allPlayers
            .sort((a, b) => b.totalMoney - a.totalMoney)
            .slice(0, 5);
    }

    updateGameState(gameState) {
        // Update players with smooth animations
        const newPlayers = new Map(Object.entries(gameState.players || {}));
        
        newPlayers.forEach((newPlayerData, playerId) => {
            const existingPlayer = this.gameState.players.get(playerId);
            
            if (existingPlayer && existingPlayer.balls && newPlayerData.balls) {
                // Add smooth animations for size changes
                newPlayerData.balls.forEach((newBall, index) => {
                    const existingBall = existingPlayer.balls[index];
                    if (existingBall && existingBall.size !== newBall.size) {
                        // Add animation properties for smooth transition
                        newBall.startSize = existingBall.size;
                        newBall.targetSize = newBall.size;
                        newBall.size = existingBall.size; // Start from current size
                        newBall.animationStartTime = Date.now();
                        newBall.animationDuration = 200; // 200ms for server updates
                    }
                });
            }
        });
        
        this.gameState.players = newPlayers;
        this.gameState.massDrops = gameState.massDrops || [];
        this.gameState.food = gameState.food || [];
        this.gameState.viruses = gameState.viruses || [];
    }

    addPlayer(playerData) {
        this.gameState.players.set(playerData.playerId, playerData);
    }

    removePlayer(playerId) {
        this.gameState.players.delete(playerId);
    }

    handlePlayerUpdate(data) {
        const { playerId, balls, totalMoney } = data;
        if (playerId !== this.localPlayer.id) {
            const existingPlayer = this.gameState.players.get(playerId);
            if (existingPlayer) {
                existingPlayer.balls = balls;
                existingPlayer.totalMoney = totalMoney;
            }
        }
    }

    handlePlayerSplit(data) {
        const { playerId, balls } = data;
        if (playerId !== this.localPlayer.id) {
            const existingPlayer = this.gameState.players.get(playerId);
            if (existingPlayer) {
                existingPlayer.balls = balls;
            }
        }
    }

    handlePlayerElimination(data) {
        if (data.eliminatedPlayerId === this.localPlayer.id) {
            this.showEliminationScreen();
            this.endGame();
        } else {
            // Remove eliminated player
            this.removePlayer(data.eliminatedPlayerId);
            
            // If local player made the kill
            if (data.killerPlayerId === this.localPlayer.id) {
                this.localPlayer.kills++;
            }
        }
    }

    showEliminationScreen() {
        const playtime = Math.floor((Date.now() - this.localPlayer.startTime) / 1000);
        
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 0, 0, 0.8);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            font-family: Arial, sans-serif;
            z-index: 1000;
        `;
        
        overlay.innerHTML = `
            <h1 style="font-size: 3em; margin: 0;">ELIMINATED!</h1>
            <div style="font-size: 1.5em; margin: 20px 0;">
                <div>Kills: ${this.localPlayer.kills}</div>
                <div>Playtime: ${Math.floor(playtime / 60)}:${(playtime % 60).toString().padStart(2, '0')}</div>
            </div>
            <div style="font-size: 1em; opacity: 0.7;">Returning to lobby...</div>
        `;
        
        document.body.appendChild(overlay);
        
        setTimeout(() => {
            document.body.removeChild(overlay);
            window.location.href = '/main.php';
        }, 3000);
    }

    async handleInitiateCashout(data) {
        console.log('💸 Server initiated cashout:', data);
        
        try {
            // Show loading state
            this.showCashoutLoadingAnimation();
            
            // Check if user is logged in and has wallet access
            if (!window.authSystem || !window.authSystem.isLoggedIn) {
                throw new Error('You must be logged in to cashout');
            }
            
            if (!window.lobbyWalletSystem) {
                throw new Error('Lobby wallet system not available');
            }
            
            const currentUser = window.authSystem.getCurrentUser();
            if (!currentUser || !currentUser.username) {
                throw new Error('User information not available');
            }
            
            // Process blockchain cashout through lobby wallet system
            const cashoutResult = await window.lobbyWalletSystem.handlePlayerCashout(
                data.lobbyId,
                currentUser.username,
                data.amount
            );
            
            // Send result back to server
            this.sendToServer({
                type: 'cashoutResult',
                data: {
                    success: cashoutResult.success,
                    amount: data.amount,
                    transactionSignature: cashoutResult.transferSignature,
                    error: cashoutResult.error
                }
            });
            
            console.log('✅ Cashout result sent to server:', cashoutResult);
            
        } catch (error) {
            console.error('❌ Failed to process cashout:', error);
            
            // Send error result back to server
            this.sendToServer({
                type: 'cashoutResult',
                data: {
                    success: false,
                    amount: data.amount,
                    error: error.message
                }
            });
        }
    }
    
    handleCashoutComplete(data) {
        console.log('💰 Cashout completed:', data);
        
        if (data.success) {
            // Show success message
            this.showCashoutSuccess(data.amount, data.transactionSignature || data.transactionId);
            
            // Return to lobby after successful cashout
            setTimeout(() => {
                if (window.gameManager) {
                    window.gameManager.returnToLobby();
                }
            }, 3000);
        } else {
            // Show error message
            this.showCashoutError(data.error);
        }
    }

    endGame() {
        this.localPlayer.isAlive = false;
        
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
        
        if (this.ws) {
            this.ws.close();
        }
    }

    // Food and virus handling functions
    handleFoodUpdate(food) {
        if (this.gameState && food) {
            if (!this.gameState.food) {
                this.gameState.food = [];
            }
            this.gameState.food = food;
        }
    }
    
    addFood(food) {
        if (!this.gameState.food) {
            this.gameState.food = [];
        }
        this.gameState.food.push(food);
    }
    
    removeFood(foodId) {
        if (this.gameState.food) {
            this.gameState.food = this.gameState.food.filter(f => f.id !== foodId);
        }
    }
    
    handleVirusUpdate(viruses) {
        if (this.gameState && viruses) {
            if (!this.gameState.viruses) {
                this.gameState.viruses = [];
            }
            this.gameState.viruses = viruses;
        }
    }
    
    handleVirusSplit(viruses) {
        if (this.gameState && viruses) {
            this.gameState.viruses = viruses;
        }
    }

    destroy() {
        this.endGame();
        
        // Remove event listeners
        document.removeEventListener('keydown', this.handleKeyPress);
        document.removeEventListener('keyup', this.handleKeyPress);
        window.removeEventListener('resize', this.resizeCanvas);
    }
}

// Global game instance
let gameInstance = null;

// Initialize game when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeGame);
} else {
    initializeGame();
}

function initializeGame() {
    console.log('🎮 Initializing Agar.io game system...');
    
    // Create game instance
    gameInstance = new AgarGame();
    
    // Make it globally available
    window.agarGame = gameInstance;
    
    console.log('✅ Agar.io game system ready');
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AgarGame;
}
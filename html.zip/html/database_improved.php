<?php
// Improved Database Class with Better Fallback Handling

class Database {
    private static $instance = null;
    private $connection;
    private $useDatabase = false;
    
    // Local MySQL Configuration
    private $host = 'localhost';  // Usually 'localhost' on Hostinger
    private $dbname = 'u396683430_onowhdata';  // Replace with your database name
    private $username = 'u396683430_onowhdata_lars';  // Replace with your database username
    private $password = 'KJ2N10!_91n2kX';  // Replace with your database password
    
    
    private function __construct() {
        $this->initializeConnection();
    }
    
    private function initializeConnection() {
        // Force database usage - no JSON fallback
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8mb4";
            $this->connection = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            
            $this->useDatabase = true;
            error_log("Database connection successful - using MySQL");
            
            // Initialize tables on successful connection
            $this->initializeTables();
            
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            error_log("Falling back to JSON file storage");
            $this->useDatabase = false;
            $this->connection = null;
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function isConnected() {
        return $this->connection !== null;
    }
    
    public function useDatabase() {
        return $this->useDatabase;
    }
    
    // Initialize database tables when connection is available
    public function initializeTables() {
        if (!$this->isConnected()) {
            return false;
        }
        
        try {
            // Create users table
            $createUsersTable = "
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255),
                wallet_address VARCHAR(255),
                balance DECIMAL(10,2) DEFAULT 0.00,
                total_winnings DECIMAL(10,2) DEFAULT 0.00,
                games_played INT DEFAULT 0,
                is_verified BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                last_login TIMESTAMP NULL
            )";
            
            $this->connection->exec($createUsersTable);
            
            // Create verification_codes table
            $createCodesTable = "
            CREATE TABLE IF NOT EXISTS verification_codes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(100) NOT NULL,
                code VARCHAR(10) NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            $this->connection->exec($createCodesTable);
            
            // Create sessions table
            $createSessionsTable = "
            CREATE TABLE IF NOT EXISTS sessions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                session_token VARCHAR(255) UNIQUE NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $this->connection->exec($createSessionsTable);
            
            // Create user_stats table
            $createUserStatsTable = "
            CREATE TABLE IF NOT EXISTS user_stats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                total_earnings DECIMAL(15,2) DEFAULT 0.00,
                total_kills INT DEFAULT 0,
                total_wins INT DEFAULT 0,
                total_losses INT DEFAULT 0,
                total_games INT DEFAULT 0,
                avg_game_time DECIMAL(8,2) DEFAULT 0.00,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_user_stats (user_id)
            )";
            
            $this->connection->exec($createUserStatsTable);
            
            // Create friendships table
            $createFriendshipsTable = "
            CREATE TABLE IF NOT EXISTS friendships (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                friend_id INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_friendship (user_id, friend_id)
            )";
            
            $this->connection->exec($createFriendshipsTable);
            
            // Create friend_requests table
            $createFriendRequestsTable = "
            CREATE TABLE IF NOT EXISTS friend_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sender_id INT NOT NULL,
                receiver_id INT NOT NULL,
                status ENUM('pending', 'accepted', 'declined') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_request (sender_id, receiver_id)
            )";
            
            $this->connection->exec($createFriendRequestsTable);
            
            // Create wallet_transactions table
            $createTransactionsTable = "
            CREATE TABLE IF NOT EXISTS wallet_transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sender_id INT NOT NULL,
                receiver_id INT NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                fee DECIMAL(10,2) NOT NULL,
                transaction_type ENUM('transfer', 'fee') DEFAULT 'transfer',
                status ENUM('pending', 'completed', 'failed') DEFAULT 'completed',
                blockchain_hash VARCHAR(255) NULL,
                message TEXT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $this->connection->exec($createTransactionsTable);
            
            // Add missing columns to existing wallet_transactions table
            try {
                $this->connection->exec("ALTER TABLE wallet_transactions ADD COLUMN blockchain_hash VARCHAR(255) NULL");
            } catch (PDOException $e) {
                // Column already exists, ignore
            }
            
            try {
                $this->connection->exec("ALTER TABLE wallet_transactions ADD COLUMN message TEXT NULL");
            } catch (PDOException $e) {
                // Column already exists, ignore
            }
            
            // Create game_stats table if it doesn't exist
            $createGameStatsTable = "
            CREATE TABLE IF NOT EXISTS game_stats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                game_id VARCHAR(100) NOT NULL,
                kills INT DEFAULT 0,
                deaths INT DEFAULT 0,
                score INT DEFAULT 0,
                game_duration INT DEFAULT 0,
                bet_amount DECIMAL(10,2) DEFAULT 0.00,
                winnings DECIMAL(10,2) DEFAULT 0.00,
                position INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $this->connection->exec($createGameStatsTable);
            
            // Create site_settings table
            $createSiteSettingsTable = "
            CREATE TABLE IF NOT EXISTS site_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                setting_key VARCHAR(100) UNIQUE NOT NULL,
                setting_value TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )";
            
            $this->connection->exec($createSiteSettingsTable);
            
            // Create friendships table
            $createFriendshipsTable = "
            CREATE TABLE IF NOT EXISTS friendships (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                friend_id INT NOT NULL,
                status ENUM('pending', 'accepted', 'blocked') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_friendship (user_id, friend_id)
            )";
            
            $this->connection->exec($createFriendshipsTable);
            
            // Create game_stats table
            $createGameStatsTable = "
            CREATE TABLE IF NOT EXISTS game_stats (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                game_type VARCHAR(50) NOT NULL,
                kills INT DEFAULT 0,
                deaths INT DEFAULT 0,
                winnings DECIMAL(10,2) DEFAULT 0.00,
                game_duration INT DEFAULT 0,
                placement INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $this->connection->exec($createGameStatsTable);
            
            // Create user_sessions table for online status
            $createSessionsTable = "
            CREATE TABLE IF NOT EXISTS user_sessions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                session_token VARCHAR(255) NOT NULL,
                last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                UNIQUE KEY unique_session (session_token)
            )";
            
            $this->connection->exec($createSessionsTable);
            
            // Insert default settings if they don't exist
            $this->insertDefaultSettings();
            
            return true;
            
        } catch (PDOException $e) {
            error_log("Error creating tables: " . $e->getMessage());
            return false;
        }
    }
    
    private function insertDefaultSettings() {
        $defaultSettings = [
            'cashoutFee' => '0.05',
            'gameJoinFee' => '0.10',
            'adminWallet' => 'admin_wallet_address',
            'maxBetAmount' => '100.00',
            'minBetAmount' => '0.10'
        ];
        
        foreach ($defaultSettings as $key => $value) {
            $stmt = $this->connection->prepare("
                INSERT IGNORE INTO site_settings (setting_key, setting_value) 
                VALUES (?, ?)
            ");
            $stmt->execute([$key, $value]);
        }
    }
    
    public function getSiteSettings() {
        if (!$this->isConnected()) {
            // Fallback to default settings if no database connection
            return [
                'cashoutFee' => '0.05',
                'gameJoinFee' => '0.10',
                'adminWallet' => 'admin_wallet_address',
                'maxBetAmount' => '100.00',
                'minBetAmount' => '0.10'
            ];
        }
        
        try {
            $stmt = $this->connection->prepare("SELECT setting_key, setting_value FROM site_settings");
            $stmt->execute();
            $results = $stmt->fetchAll();
            
            $settings = [];
            foreach ($results as $row) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
            
            return $settings;
            
        } catch (PDOException $e) {
            error_log("Error getting site settings: " . $e->getMessage());
            return [
                'cashoutFee' => '0.05',
                'gameJoinFee' => '0.10',
                'adminWallet' => 'admin_wallet_address',
                'maxBetAmount' => '100.00',
                'minBetAmount' => '0.10'
            ];
        }
    }
    
    public function updateSiteSettings($settings) {
        if (!$this->isConnected()) {
            return false;
        }
        
        try {
            $this->connection->beginTransaction();
            
            foreach ($settings as $key => $value) {
                $stmt = $this->connection->prepare("
                    INSERT INTO site_settings (setting_key, setting_value) 
                    VALUES (?, ?) 
                    ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
                ");
                $stmt->execute([$key, $value]);
            }
            
            $this->connection->commit();
            return true;
            
        } catch (PDOException $e) {
            $this->connection->rollBack();
            error_log("Error updating site settings: " . $e->getMessage());
            return false;
        }
    }
    
    public function getTotalUsers() {
        if (!$this->isConnected()) {
            return 0;
        }
        
        try {
            $stmt = $this->connection->prepare("SELECT COUNT(*) as count FROM users");
            $stmt->execute();
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (PDOException $e) {
            error_log("Error getting total users: " . $e->getMessage());
            return 0;
        }
    }
    
    public function getActiveUsers() {
        if (!$this->isConnected()) {
            return 0;
        }
        
        try {
            $stmt = $this->connection->prepare("
                SELECT COUNT(*) as count FROM users 
                WHERE last_login > DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");
            $stmt->execute();
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (PDOException $e) {
            error_log("Error getting active users: " . $e->getMessage());
            return 0;
        }
    }
    
    public function getTotalGames() {
        if (!$this->isConnected()) {
            return 0;
        }
        
        try {
            $stmt = $this->connection->prepare("SELECT COUNT(*) as count FROM game_stats");
            $stmt->execute();
            $result = $stmt->fetch();
            return $result['count'] ?? 0;
        } catch (PDOException $e) {
            error_log("Error getting total games: " . $e->getMessage());
            return 0;
        }
    }
    
    public function getServerUptime() {
        // Return current timestamp as server start time approximation
        return date('Y-m-d H:i:s');
    }
    
    public function searchUser($searchTerm) {
        if (!$this->isConnected()) {
            return null;
        }
        
        try {
            $stmt = $this->connection->prepare("
                SELECT id, username, email, balance, total_winnings, games_played, created_at 
                FROM users 
                WHERE username LIKE ? OR email LIKE ? 
                LIMIT 1
            ");
            $searchPattern = '%' . $searchTerm . '%';
            $stmt->execute([$searchPattern, $searchPattern]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error searching user: " . $e->getMessage());
            return null;
        }
    }
    
    public function getAllUsers() {
        if (!$this->isConnected()) {
            return [];
        }
        
        try {
            $stmt = $this->connection->prepare("
                SELECT id, username, email, balance, total_winnings, games_played, created_at 
                FROM users 
                ORDER BY created_at DESC
            ");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error getting all users: " . $e->getMessage());
            return [];
        }
    }
    
    public function updateUserBalance($userId, $username, $solBalance, $eurBalance) {
        if (!$this->isConnected()) {
            return false;
        }

        try {
            $stmt = $this->connection->prepare("
                UPDATE users 
                SET balance = ? 
                WHERE id = ? OR username = ?
            ");
            // For now, we'll use EUR balance as the main balance
            $stmt->execute([$eurBalance, $userId, $username]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("Error updating user balance: " . $e->getMessage());
            return false;
        }
    }

    public function getUserStats($userId) {
        if (!$this->isConnected()) {
            return null;
        }

        try {
            $stmt = $this->connection->prepare("
                SELECT total_winnings, games_played 
                FROM users 
                WHERE id = ?
            ");
            $stmt->execute([$userId]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error getting user stats: " . $e->getMessage());
            return null;
        }
    }

    public function getUserById($userId) {
        if (!$this->isConnected()) {
            return null;
        }

        try {
            $stmt = $this->connection->prepare("
                SELECT id, username, email, balance, total_winnings, games_played, created_at 
                FROM users 
                WHERE id = ?
            ");
            $stmt->execute([$userId]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error getting user by ID: " . $e->getMessage());
            return null;
        }
    }

    // Friendship functions
    public function sendFriendRequest($userId, $friendId) {
        if (!$this->isConnected()) {
            return false;
        }

        try {
            $stmt = $this->connection->prepare("
                INSERT INTO friendships (user_id, friend_id, status) 
                VALUES (?, ?, 'pending')
            ");
            $stmt->execute([$userId, $friendId]);
            return true;
        } catch (PDOException $e) {
            error_log("Error sending friend request: " . $e->getMessage());
            return false;
        }
    }

    public function respondToFriendRequest($userId, $friendId, $response) {
        if (!$this->isConnected()) {
            return false;
        }

        try {
            if ($response === 'accept') {
                // Update the original request
                $stmt = $this->connection->prepare("
                    UPDATE friendships 
                    SET status = 'accepted' 
                    WHERE user_id = ? AND friend_id = ? AND status = 'pending'
                ");
                $stmt->execute([$friendId, $userId]);
                
                // Create reciprocal friendship
                $stmt2 = $this->connection->prepare("
                    INSERT INTO friendships (user_id, friend_id, status) 
                    VALUES (?, ?, 'accepted') 
                    ON DUPLICATE KEY UPDATE status = 'accepted'
                ");
                $stmt2->execute([$userId, $friendId]);
            } else {
                // Delete the request
                $stmt = $this->connection->prepare("
                    DELETE FROM friendships 
                    WHERE user_id = ? AND friend_id = ? AND status = 'pending'
                ");
                $stmt->execute([$friendId, $userId]);
            }
            return true;
        } catch (PDOException $e) {
            error_log("Error responding to friend request: " . $e->getMessage());
            return false;
        }
    }

    public function getFriends($userId, $status = 'accepted') {
        if (!$this->isConnected()) {
            return [];
        }

        try {
            $stmt = $this->connection->prepare("
                SELECT u.id, u.username, 
                       CASE WHEN s.user_id IS NOT NULL AND s.last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE) 
                            THEN true ELSE false END as online
                FROM friendships f
                JOIN users u ON f.friend_id = u.id
                LEFT JOIN user_sessions s ON u.id = s.user_id
                WHERE f.user_id = ? AND f.status = ?
                ORDER BY online DESC, u.username ASC
            ");
            $stmt->execute([$userId, $status]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error getting friends: " . $e->getMessage());
            return [];
        }
    }

    public function searchUsers($searchTerm, $currentUserId) {
        if (!$this->isConnected()) {
            return [];
        }

        try {
            $stmt = $this->connection->prepare("
                SELECT u.id, u.username,
                       CASE WHEN f.id IS NOT NULL THEN f.status ELSE 'none' END as friendship_status
                FROM users u
                LEFT JOIN friendships f ON (u.id = f.friend_id AND f.user_id = ?)
                WHERE u.username LIKE ? AND u.id != ?
                LIMIT 10
            ");
            $searchPattern = '%' . $searchTerm . '%';
            $stmt->execute([$currentUserId, $searchPattern, $currentUserId]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error searching users: " . $e->getMessage());
            return [];
        }
    }

    // Game stats functions
    public function addGameStats($userId, $gameType, $kills, $deaths, $winnings, $duration, $placement) {
        if (!$this->isConnected()) {
            return false;
        }

        try {
            $stmt = $this->connection->prepare("
                INSERT INTO game_stats (user_id, game_type, kills, deaths, winnings, game_duration, placement) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$userId, $gameType, $kills, $deaths, $winnings, $duration, $placement]);
            
            // Update user totals
            $stmt2 = $this->connection->prepare("
                UPDATE users 
                SET total_winnings = total_winnings + ?, games_played = games_played + 1 
                WHERE id = ?
            ");
            $stmt2->execute([$winnings, $userId]);
            
            return true;
        } catch (PDOException $e) {
            error_log("Error adding game stats: " . $e->getMessage());
            return false;
        }
    }

    public function getUserGameStats($userId) {
        if (!$this->isConnected()) {
            return null;
        }

        try {
            $stmt = $this->connection->prepare("
                SELECT 
                    COUNT(*) as total_games,
                    SUM(kills) as total_kills,
                    SUM(deaths) as total_deaths,
                    SUM(winnings) as total_winnings,
                    AVG(kills) as avg_kills,
                    AVG(game_duration) as avg_duration
                FROM game_stats 
                WHERE user_id = ?
            ");
            $stmt->execute([$userId]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error getting user game stats: " . $e->getMessage());
            return null;
        }
    }

    public function getFriendsLeaderboard($userId, $limit = 10) {
        if (!$this->isConnected()) {
            return [];
        }

        try {
            $stmt = $this->connection->prepare("
                SELECT u.id, u.username, u.total_winnings, u.games_played
                FROM users u
                JOIN friendships f ON u.id = f.friend_id
                WHERE f.user_id = ? AND f.status = 'accepted'
                ORDER BY u.total_winnings DESC
                LIMIT ?
            ");
            $stmt->execute([$userId, $limit]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error getting friends leaderboard: " . $e->getMessage());
            return [];
        }
    }

    // Session management for online status
    public function updateUserSession($userId, $sessionToken) {
        if (!$this->isConnected()) {
            return false;
        }

        try {
            $stmt = $this->connection->prepare("
                INSERT INTO user_sessions (user_id, session_token) 
                VALUES (?, ?) 
                ON DUPLICATE KEY UPDATE last_activity = CURRENT_TIMESTAMP
            ");
            $stmt->execute([$userId, $sessionToken]);
            return true;
        } catch (PDOException $e) {
            error_log("Error updating user session: " . $e->getMessage());
            return false;
        }
    }

    public function removeUserSession($sessionToken) {
        if (!$this->isConnected()) {
            return false;
        }

        try {
            $stmt = $this->connection->prepare("DELETE FROM user_sessions WHERE session_token = ?");
            $stmt->execute([$sessionToken]);
            return true;
        } catch (PDOException $e) {
            error_log("Error removing user session: " . $e->getMessage());
            return false;
        }
    }

    public function cleanupOldSessions() {
        if (!$this->isConnected()) {
            return false;
        }

        try {
            $stmt = $this->connection->prepare("
                DELETE FROM user_sessions 
                WHERE last_activity < DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            ");
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            error_log("Error cleaning up old sessions: " . $e->getMessage());
            return false;
        }
    }
}
?>
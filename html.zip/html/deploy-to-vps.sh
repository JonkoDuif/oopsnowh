#!/bin/bash

# VPS Deployment Script for oopsnowh.com
# This script helps deploy your game to a VPS with SSL support

echo "🚀 VPS Deployment Script for oopsnowh.com"
echo "============================================"

# Configuration - Update these variables for your VPS
VPS_USER="root"  # Change to your VPS username
VPS_HOST="149.12.246.143"  # Change to your VPS IP address
VPS_PATH="/var/www/oopsnowh"  # Deployment path on VPS
LOCAL_PATH="."  # Current directory

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_step() {
    echo -e "${GREEN}[STEP]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if configuration is updated
if [ "$VPS_HOST" = "your-vps-ip" ]; then
    print_error "Please update VPS_HOST and VPS_USER variables in this script first!"
    echo "Edit this file and set:"
    echo "  VPS_USER=\"your-username\""
    echo "  VPS_HOST=\"your-vps-ip-address\""
    exit 1
fi

print_step "Preparing deployment package..."

# Create temporary deployment directory
TEMP_DIR="/tmp/oopsnowh-deploy-$(date +%s)"
mkdir -p "$TEMP_DIR"

# Copy necessary files (excluding development files)
print_step "Copying files..."
rsync -av --exclude='node_modules' \
          --exclude='.git' \
          --exclude='*.log' \
          --exclude='data/sessions.json' \
          --exclude='cert.pem' \
          --exclude='key.pem' \
          --exclude='deploy-to-vps.sh' \
          "$LOCAL_PATH/" "$TEMP_DIR/"

print_step "Uploading to VPS..."
# Upload files to VPS
scp -r "$TEMP_DIR"/* "$VPS_USER@$VPS_HOST:$VPS_PATH/"

if [ $? -eq 0 ]; then
    print_step "Files uploaded successfully!"
else
    print_error "Failed to upload files to VPS"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Clean up temporary directory
rm -rf "$TEMP_DIR"

print_step "Setting up VPS environment..."
# Execute setup commands on VPS
ssh "$VPS_USER@$VPS_HOST" << 'EOF'
cd /var/www/oopsnowh

echo "📦 Installing Node.js dependencies..."
npm install

echo "🔧 Setting file permissions..."
chmod +x start-production.sh
chmod +x setup-ssl.sh
chown -R www-data:www-data .

echo "🛑 Stopping existing servers..."
pkill -f "node server.js" 2>/dev/null || true
pkill -f "node lobbyWalletServer.js" 2>/dev/null || true
pkill -f "php -S" 2>/dev/null || true

echo "⏳ Waiting for processes to stop..."
sleep 3

echo "🚀 Starting production servers..."
./start-production.sh

echo "✅ Deployment completed!"
echo ""
echo "🌐 Your game should now be available at: https://oopsnowh.com"
echo "📊 Check server status with: ps aux | grep node"
echo "📝 View logs with: tail -f game-server.log lobby-wallet.log web-server.log"
EOF

if [ $? -eq 0 ]; then
    print_step "Deployment completed successfully! 🎉"
    echo ""
    echo "Your game is now running on the VPS!"
    echo "Visit: https://oopsnowh.com"
    echo ""
    echo "To check status: ssh $VPS_USER@$VPS_HOST 'cd $VPS_PATH && ps aux | grep node'"
    echo "To view logs: ssh $VPS_USER@$VPS_HOST 'cd $VPS_PATH && tail -f *.log'"
else
    print_error "Deployment failed during VPS setup"
    exit 1
fi
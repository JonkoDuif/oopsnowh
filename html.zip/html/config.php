<?php
// Include email configuration
require_once 'email_config.php';
require_once 'database_simple.php';
require_once 'user_management_hybrid.php';

// Database-only configuration - JSON files removed

// Security settings
define('CODE_EXPIRY_MINUTES', 10);
define('SESSION_EXPIRY_HOURS', 24);

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle preflight requests
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Utility functions - Database only
// Note: generateCode() and generateToken() functions are defined in config_hostinger.php
// to avoid redeclaration errors

// Database functions for auth_handler.php
// Note: All database functions (createSession, validateSession, verifyCode, etc.) 
// are defined in config_hostinger.php to avoid redeclaration errors
// This file is kept minimal for local development compatibility
?>
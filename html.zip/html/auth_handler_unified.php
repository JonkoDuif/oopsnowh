<?php
/**
 * Unified Authentication Handler
 * Consolidates auth_handler.php and auth_handler_hostinger.php
 * Uses secure configuration and enhanced validation
 */

require_once 'config_secure.php';
require_once 'config_hostinger.php';
require_once 'email_service.php';
require_once 'user_management_hybrid.php';

// Set CORS headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

class UnifiedAuthHandler {
    
    public static function handleRequest() {
        // Rate limiting and input validation
        $rawInput = file_get_contents('php://input');
        
        if (SecureConfig::isDebug()) {
            error_log("Auth request received: " . substr($rawInput, 0, 200));
        }
        
        $input = json_decode($rawInput, true);
        
        if (!$input || !is_array($input)) {
            return self::errorResponse('Invalid JSON input');
        }
        
        // Sanitize input
        array_walk_recursive($input, function(&$value) {
            if (is_string($value)) {
                $value = self::sanitizeInput($value);
            }
        });
        
        $action = $input['action'] ?? '';
        
        // Validate action
        $allowedActions = [
            'send_verification', 'verify_code', 'create_account', 
            'check_session', 'update_wallet_address', 'logout'
        ];
        
        if (!in_array($action, $allowedActions)) {
            return self::errorResponse('Invalid action');
        }
        
        if (SecureConfig::isDebug()) {
            error_log("Processing action: " . $action);
        }
        
        switch ($action) {
            case 'send_verification':
                return self::sendVerificationCode($input);
            case 'verify_code':
                return self::verifyCode($input);
            case 'create_account':
                return self::createAccount($input);
            case 'check_session':
                return self::checkSession($input);
            case 'update_wallet_address':
                return self::updateWalletAddress($input);
            case 'logout':
                return self::logout($input);
            default:
                return self::errorResponse('Invalid action');
        }
    }
    
    private static function sanitizeInput($input) {
        return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
    }
    
    private static function validateEmail($email) {
        $email = filter_var($email, FILTER_VALIDATE_EMAIL);
        if (!$email) {
            return false;
        }
        
        // Additional validation
        if (strlen($email) > 254) {
            return false;
        }
        
        // Check for common disposable email domains
        $disposableDomains = ['tempmail.org', '10minutemail.com', 'guerrillamail.com'];
        $domain = substr(strrchr($email, '@'), 1);
        
        if (in_array($domain, $disposableDomains)) {
            return false;
        }
        
        return $email;
    }
    
    private static function sendVerificationCode($input) {
        $email = $input['email'] ?? '';
        
        $validatedEmail = self::validateEmail($email);
        if (!$validatedEmail) {
            return self::errorResponse('Invalid email address');
        }
        
        // Rate limiting check (basic implementation)
        $rateLimitKey = 'email_rate_' . md5($validatedEmail);
        $lastSent = $_SESSION[$rateLimitKey] ?? 0;
        
        if (time() - $lastSent < 60) { // 1 minute cooldown
            return self::errorResponse('Please wait before requesting another code');
        }
        
        // Generate verification code
        $code = generateCode();
        
        // Store verification code in database
        if (!storeVerificationCode($validatedEmail, $code)) {
            return self::errorResponse('Failed to generate verification code');
        }
        
        // Update rate limiting
        $_SESSION[$rateLimitKey] = time();
        
        // Send email with error handling
        try {
            $emailSent = EmailService::sendVerificationCode($validatedEmail, $code);
        } catch (Exception $e) {
            error_log("Email service error: " . $e->getMessage());
            $emailSent = false;
        }
        
        if ($emailSent) {
            return self::successResponse([
                'message' => 'Verification code sent successfully',
                'email' => $validatedEmail
            ]);
        } else {
            // Development mode: Return success even if email fails, log the code
            if (SecureConfig::isDebug()) {
                error_log("Development mode: Verification code for $validatedEmail is: $code");
                return self::successResponse([
                    'message' => 'Email service unavailable. Development mode: Check server logs for verification code.',
                    'email' => $validatedEmail,
                    'dev_mode' => true
                ]);
            } else {
                return self::errorResponse('Failed to send verification code');
            }
        }
    }
    
    private static function verifyCode($input) {
        $email = $input['email'] ?? '';
        $code = $input['code'] ?? '';
        
        $validatedEmail = self::validateEmail($email);
        if (!$validatedEmail) {
            return self::errorResponse('Invalid email address');
        }
        
        // Validate code format
        if (!preg_match('/^[0-9]{6}$/', $code)) {
            return self::errorResponse('Invalid verification code format');
        }
        
        // Verify code using database function
        $verificationResult = verifyCode($validatedEmail, $code);
        
        if (!$verificationResult) {
            return self::errorResponse('Invalid or expired verification code');
        }
        
        // Check if user exists
        $userData = getUserByEmail($validatedEmail);
        
        if ($userData) {
            // User exists, log them in
            $sessionToken = self::createSession($userData);
            return self::successResponse([
                'user_exists' => true,
                'user' => [
                    'id' => $userData['id'],
                    'username' => $userData['username'],
                    'email' => $userData['email'],
                    'balance' => $userData['balance'],
                    'wallet_address' => $userData['wallet_address'] ?? null
                ],
                'session_token' => $sessionToken
            ]);
        } else {
            // User doesn't exist, need to create account
            return self::successResponse([
                'user_exists' => false,
                'email' => $validatedEmail,
                'message' => 'Please choose a username to complete registration'
            ]);
        }
    }
    
    private static function createAccount($input) {
        $email = $input['email'] ?? '';
        $username = $input['username'] ?? '';
        
        $validatedEmail = self::validateEmail($email);
        if (!$validatedEmail) {
            return self::errorResponse('Invalid email address');
        }
        
        // Validate username
        if (!self::validateUsername($username)) {
            return self::errorResponse('Invalid username. Use 3-20 characters, letters, numbers, and underscores only.');
        }
        
        // Check if username is taken
        if (getUserByUsername($username)) {
            return self::errorResponse('Username already taken');
        }
        
        // Check if email is already registered
        if (getUserByEmail($validatedEmail)) {
            return self::errorResponse('Email already registered');
        }
        
        // Create user
        $userData = createUser($username, $validatedEmail);
        
        if ($userData) {
            $sessionToken = self::createSession($userData);
            return self::successResponse([
                'user' => [
                    'id' => $userData['id'],
                    'username' => $userData['username'],
                    'email' => $userData['email'],
                    'balance' => $userData['balance'],
                    'wallet_address' => $userData['wallet_address'] ?? null
                ],
                'session_token' => $sessionToken,
                'message' => 'Account created successfully'
            ]);
        } else {
            return self::errorResponse('Failed to create account');
        }
    }
    
    private static function validateUsername($username) {
        // Username validation: 3-20 characters, alphanumeric and underscores
        return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
    }
    
    private static function checkSession($input) {
        $sessionToken = $input['session_token'] ?? '';
        
        if (empty($sessionToken)) {
            return self::errorResponse('Session token required');
        }
        
        $userData = getUserBySessionToken($sessionToken);
        
        if ($userData) {
            return self::successResponse([
                'user' => [
                    'id' => $userData['id'],
                    'username' => $userData['username'],
                    'email' => $userData['email'],
                    'balance' => $userData['balance'],
                    'wallet_address' => $userData['wallet_address'] ?? null
                ]
            ]);
        } else {
            return self::errorResponse('Invalid or expired session');
        }
    }
    
    private static function updateWalletAddress($input) {
        $sessionToken = $input['session_token'] ?? '';
        $walletAddress = $input['wallet_address'] ?? '';
        
        if (empty($sessionToken)) {
            return self::errorResponse('Session token required');
        }
        
        // Validate wallet address format (basic Solana address validation)
        if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $walletAddress)) {
            return self::errorResponse('Invalid wallet address format');
        }
        
        $userData = getUserBySessionToken($sessionToken);
        
        if (!$userData) {
            return self::errorResponse('Invalid session');
        }
        
        // Update wallet address
        $updated = updateUser($userData['id'], ['wallet_address' => $walletAddress]);
        
        if ($updated) {
            return self::successResponse([
                'message' => 'Wallet address updated successfully',
                'wallet_address' => $walletAddress
            ]);
        } else {
            return self::errorResponse('Failed to update wallet address');
        }
    }
    
    private static function logout($input) {
        $sessionToken = $input['session_token'] ?? '';
        
        if (empty($sessionToken)) {
            return self::errorResponse('Session token required');
        }
        
        if (deleteSession($sessionToken)) {
            return self::successResponse(['message' => 'Logged out successfully']);
        } else {
            return self::errorResponse('Failed to logout');
        }
    }
    
    private static function createSession($userData) {
        $token = createSession($userData['id']);
        return $token ?: null;
    }
        
        return null;
    }
    
    private static function successResponse($data) {
        echo json_encode(array_merge(['success' => true], $data));
        exit;
    }
    
    private static function errorResponse($message) {
        echo json_encode(['success' => false, 'message' => $message]);
        exit;
    }
}

// Handle the request
try {
    UnifiedAuthHandler::handleRequest();
} catch (Exception $e) {
    error_log('Auth handler error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
?>
<?php
session_start();

// Secure access code (SHA-256 hash of the actual code)
define('ACCESS_CODE_HASH', '7904726010f873825e3a7f6ff0fb45a2d792bc54b221637e586f9f3337475dba'); // SHA-256 of 'JSFK2mn_(!)'

function checkAccess() {
    // Check if user has valid session
    if (isset($_SESSION['site_access']) && $_SESSION['site_access'] === 'granted') {
        return true;
    }
    
    // Check if access code is provided via POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['access_code'])) {
        $inputHash = hash('sha256', $_POST['access_code']);
        if ($inputHash === ACCESS_CODE_HASH) {
            $_SESSION['site_access'] = 'granted';
            return true;
        }
    }
    
    // Check sessionStorage via JavaScript (for client-side authentication)
    if (isset($_GET['check_session'])) {
        header('Content-Type: application/json');
        echo json_encode(['authenticated' => false]);
        exit;
    }
    
    // Check if sessionStorage access is granted via cookie/header
    if (isset($_COOKIE['siteAccess']) && $_COOKIE['siteAccess'] === 'granted') {
        $_SESSION['site_access'] = 'granted';
        return true;
    }
    
    return false;
}

function requireAccess() {
    if (!checkAccess()) {
        // Redirect to maintenance page
        header('Location: maintenance.html');
        exit;
    }
}

// Handle AJAX access verification
if (isset($_GET['verify_access'])) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        exit(0);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $code = $input['code'] ?? '';
    
    if (hash('sha256', $code) === ACCESS_CODE_HASH) {
        $_SESSION['site_access'] = 'granted';
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

// Handle file access requests
if (isset($_GET['file'])) {
    $requestedFile = $_GET['file'];
    
    // Check if user is authenticated
    if (!checkAccess()) {
        header('Location: maintenance.html');
        exit;
    }
    
    // Sanitize file path and handle js/ subdirectory
    if (strpos($requestedFile, 'js/') === 0) {
        // Handle js/ subdirectory files
        $jsFile = substr($requestedFile, 3); // Remove 'js/' prefix
        $jsFile = basename($jsFile); // Sanitize
        $filePath = __DIR__ . '/js/' . $jsFile;
    } else {
        $requestedFile = basename($requestedFile);
        $filePath = __DIR__ . '/' . $requestedFile;
    }
    
    // Check if file exists and is allowed
    if (file_exists($filePath) && is_file($filePath)) {
        // Get file extension
        $extension = strtolower(pathinfo($requestedFile, PATHINFO_EXTENSION));
        
        // Set appropriate content type
        switch ($extension) {
            case 'js':
                header('Content-Type: application/javascript');
                break;
            case 'css':
                header('Content-Type: text/css');
                break;
            case 'html':
                header('Content-Type: text/html');
                break;
            case 'php':
                // For PHP files, include them instead of serving as text
                include $filePath;
                exit;
            default:
                header('Content-Type: text/plain');
        }
        
        // Serve the file
        readfile($filePath);
        exit;
    } else {
        // File not found
        header('HTTP/1.0 404 Not Found');
        echo '404 - File not found';
        exit;
    }
}

// Auto-include this check for protected files
if (!defined('SKIP_ACCESS_CHECK')) {
    requireAccess();
}
?>
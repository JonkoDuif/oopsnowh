<?php
// Debug script to check POST data
header('Content-Type: application/json');

// Log all received data to a file
$debug_data = [
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'UNKNOWN',
    'post_data' => $_POST,
    'raw_input' => file_get_contents('php://input'),
    'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'UNKNOWN',
    'timestamp' => date('Y-m-d H:i:s')
];

file_put_contents('/tmp/debug_email.log', json_encode($debug_data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $code = $_POST['code'] ?? '';
    $action = $_POST['action'] ?? '';
    
    if ($action === 'send_verification' && $email && $code) {
        echo json_encode(['success' => true, 'message' => 'Debug: Parameters received correctly', 'data' => compact('email', 'code', 'action')]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Debug: Invalid parameters', 'received' => compact('email', 'code', 'action')]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Only POST method allowed']);
}
?>
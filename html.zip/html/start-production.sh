#!/bin/bash

# Production startup script for the game server with SSL support
# This script should be run on the VPS where SSL certificates are available

echo "Starting game servers in production mode with SSL support..."

# Set environment variable to enable SSL
export SSL_ENABLED=true
export NODE_ENV=production

# Kill any existing processes
echo "Stopping existing servers..."
pkill -f "node server.js" 2>/dev/null || true
pkill -f "node lobbyWalletServer.js" 2>/dev/null || true
pkill -f "php -S" 2>/dev/null || true

# Wait a moment for processes to stop
sleep 2

# Start the game server with SSL support
echo "Starting game server with SSL..."
nohup node server.js > game-server.log 2>&1 &
GAME_PID=$!

# Start the lobby wallet server
echo "Starting lobby wallet server..."
nohup node lobbyWalletServer.js > lobby-wallet.log 2>&1 &
LOBBY_PID=$!

# Start the web server (if needed)
echo "Starting web server..."
nohup php -S 0.0.0.0:8000 > web-server.log 2>&1 &
WEB_PID=$!

# Wait a moment and check if servers started successfully
sleep 3

echo "Checking server status..."
if ps -p $GAME_PID > /dev/null; then
    echo "✓ Game server started successfully (PID: $GAME_PID)"
else
    echo "✗ Game server failed to start"
    cat game-server.log
fi

if ps -p $LOBBY_PID > /dev/null; then
    echo "✓ Lobby wallet server started successfully (PID: $LOBBY_PID)"
else
    echo "✗ Lobby wallet server failed to start"
    cat lobby-wallet.log
fi

if ps -p $WEB_PID > /dev/null; then
    echo "✓ Web server started successfully (PID: $WEB_PID)"
else
    echo "✗ Web server failed to start"
    cat web-server.log
fi

echo ""
echo "Servers started. Logs are available in:"
echo "  - Game server: game-server.log"
echo "  - Lobby wallet: lobby-wallet.log"
echo "  - Web server: web-server.log"
echo ""
echo "To stop all servers, run: pkill -f 'node server.js'; pkill -f 'node lobbyWalletServer.js'; pkill -f 'php -S'"
<?php
// Admin Email Service - Direct email sending for admin verification

// Include email configuration and service
require_once 'email_config.php';
require_once 'email_service.php';

// Set content type to JSON
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
    exit();
}

try {
    // Get POST data
    $email = $_POST['email'] ?? '';
    $code = $_POST['code'] ?? '';
    $action = $_POST['action'] ?? '';
    
    // Validate input
    if (empty($email) || empty($code) || empty($action)) {
        echo json_encode([
            'success' => false,
            'message' => 'Missing required parameters: email, code, action'
        ]);
        exit();
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid email format'
        ]);
        exit();
    }
    
    // Validate code format (6 digits)
    if (!preg_match('/^\d{6}$/', $code)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid code format. Must be 6 digits.'
        ]);
        exit();
    }
    
    // Only allow admin email
    if ($email !== 'larsvgennip@gmail.com') {
        echo json_encode([
            'success' => false,
            'message' => 'Unauthorized email address'
        ]);
        exit();
    }
    
    // Handle the action
    if ($action === 'send_verification') {
        // Send verification email using EmailService
        $result = EmailService::sendVerificationCode($email, $code);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => 'Admin verification email sent successfully'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to send verification email'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid action'
        ]);
    }
    
} catch (Exception $e) {
    error_log('Admin email error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error'
    ]);
}
?>
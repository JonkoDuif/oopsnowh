#!/bin/bash

# Stop Local Servers Script
# This script helps stop all local development servers to free up ports

echo "🛑 Stopping Local Development Servers"
echo "===================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_step() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to kill processes by port
kill_by_port() {
    local port=$1
    local service_name=$2
    
    print_step "Checking port $port ($service_name)..."
    
    # Find processes using the port
    local pids=$(lsof -ti :$port 2>/dev/null)
    
    if [ -z "$pids" ]; then
        echo "  ✅ Port $port is already free"
        return 0
    fi
    
    echo "  🔍 Found processes using port $port: $pids"
    
    # Kill the processes
    for pid in $pids; do
        local process_name=$(ps -p $pid -o comm= 2>/dev/null || echo "unknown")
        echo "  🛑 Killing process $pid ($process_name)"
        kill $pid 2>/dev/null
    done
    
    # Wait a moment
    sleep 2
    
    # Check if processes are still running
    local remaining_pids=$(lsof -ti :$port 2>/dev/null)
    if [ -n "$remaining_pids" ]; then
        print_warning "Some processes still running on port $port, force killing..."
        for pid in $remaining_pids; do
            echo "  💀 Force killing process $pid"
            kill -9 $pid 2>/dev/null
        done
    fi
    
    # Final check
    sleep 1
    local final_check=$(lsof -ti :$port 2>/dev/null)
    if [ -z "$final_check" ]; then
        echo "  ✅ Port $port is now free"
    else
        print_error "Failed to free port $port"
        return 1
    fi
}

# Function to show current port usage
show_port_usage() {
    print_step "Current port usage:"
    echo ""
    
    echo "Port 8000 (PHP Web Server):"
    lsof -i :8000 2>/dev/null || echo "  Available"
    echo ""
    
    echo "Port 8081 (Game Server):"
    lsof -i :8081 2>/dev/null || echo "  Available"
    echo ""
    
    echo "Port 8082 (Lobby Wallet Server):"
    lsof -i :8082 2>/dev/null || echo "  Available"
    echo ""
}

# Main execution
case "$1" in
    "check")
        show_port_usage
        ;;
    "stop")
        print_step "Stopping all local development servers..."
        echo ""
        
        # Stop servers by port
        kill_by_port 8000 "PHP Web Server"
        kill_by_port 8081 "Game Server"
        kill_by_port 8082 "Lobby Wallet Server"
        
        echo ""
        print_step "All local servers stopped!"
        echo ""
        print_step "You can now start fresh servers or deploy to VPS."
        ;;
    *)
        echo "Usage: $0 [check|stop]"
        echo ""
        echo "Commands:"
        echo "  check  - Show current port usage"
        echo "  stop   - Stop all local development servers"
        echo ""
        echo "Examples:"
        echo "  ./stop-local-servers.sh check"
        echo "  ./stop-local-servers.sh stop"
        ;;
esac
<?php
// Advanced Security Functions for JavaScript Protection

class JSSecurityManager {
    private static $sessionKey = null;
    
    public static function generateSessionKey() {
        if (self::$sessionKey === null) {
            self::$sessionKey = bin2hex(random_bytes(32));
            $_SESSION['js_key'] = self::$sessionKey;
        }
        return self::$sessionKey;
    }
    
    public static function encryptCode($code) {
        $key = self::generateSessionKey();
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt($code, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }
    
    public static function generateDecryptionScript($encryptedCode) {
        $key = self::$sessionKey;
        return "
        (function() {
            var key = '" . $key . "';
            var encrypted = '" . $encryptedCode . "';
            
            function decrypt(data, key) {
                try {
                    var bytes = atob(data);
                    var iv = bytes.slice(0, 16);
                    var encrypted = bytes.slice(16);
                    
                    // Simple XOR decryption (for demo purposes)
                    var decrypted = '';
                    for (var i = 0; i < encrypted.length; i++) {
                        decrypted += String.fromCharCode(encrypted.charCodeAt(i) ^ key.charCodeAt(i % key.length));
                    }
                    return decrypted;
                } catch (e) {
                    throw new Error('Tamper detected');
                }
            }
            
            // Anti-debugging checks
            var start = Date.now();
            debugger;
            if (Date.now() - start > 100) {
                throw new Error('Debugger detected');
            }
            
            // Check for common debugging tools
            if (window.chrome && window.chrome.runtime && window.chrome.runtime.onConnect) {
                var devtools = {open: false, orientation: null};
                setInterval(function() {
                    if (window.outerHeight - window.innerHeight > 200 || window.outerWidth - window.innerWidth > 200) {
                        throw new Error('DevTools detected');
                    }
                }, 500);
            }
            
            // Execute decrypted code
            try {
                var code = decrypt(encrypted, key);
                eval(code);
            } catch (e) {
                console.error('Security violation detected');
                window.location.reload();
            }
        })();
        ";
    }
    
    public static function obfuscateAdvanced($code) {
        // More sophisticated obfuscation
        $patterns = [
            '/\bfunction\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/' => 'function _f' . substr(md5(uniqid()), 0, 6),
            '/\bvar\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/' => 'var _v' . substr(md5(uniqid()), 0, 6),
            '/\blet\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/' => 'let _l' . substr(md5(uniqid()), 0, 6),
            '/\bconst\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/' => 'const _c' . substr(md5(uniqid()), 0, 6)
        ];
        
        foreach ($patterns as $pattern => $replacement) {
            $code = preg_replace($pattern, $replacement, $code);
        }
        
        // Add fake functions to confuse reverse engineering
        $decoys = [
            'function _decoy1(){var x=Math.random();return x*999;}',
            'function _decoy2(){console.log("fake");return false;}',
            'var _fake=function(){throw new Error("Access denied");};'
        ];
        
        $code = implode('', $decoys) . $code;
        
        // Minify
        $code = preg_replace('/\s+/', ' ', $code);
        $code = str_replace(['; ', ' {', '} ', '( ', ' )', ', '], [';', '{', '}', '(', ')', ','], $code);
        
        return $code;
    }
    
    public static function addIntegrityCheck($code) {
        $hash = hash('sha256', $code);
        return "
        (function() {
            var expectedHash = '" . $hash . "';
            var actualHash = CryptoJS.SHA256('" . addslashes($code) . "').toString();
            if (expectedHash !== actualHash) {
                throw new Error('Code integrity violation');
            }
        })();
        " . $code;
    }
}
?>
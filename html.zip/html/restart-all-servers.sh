#!/bin/bash

# Restart All Servers Script
# This script kills all Node.js servers and restarts them

echo "=== Restarting All Servers ==="
echo "$(date): Starting server restart process"

# Change to the web directory
cd /var/www/html

# Kill all existing node processes
echo "Killing all existing Node.js processes..."
pkill -f "node server.js" || true
pkill -f "node lobbyServer.js" || true
pkill -f "node lobbyWalletServer.js" || true
pkill -f "node" || true

# Wait a moment for processes to terminate
sleep 2

# Verify all node processes are killed
echo "Checking for remaining Node.js processes..."
remaining=$(ps aux | grep node | grep -v grep | wc -l)
if [ $remaining -gt 0 ]; then
    echo "Force killing remaining Node.js processes..."
    pkill -9 -f node || true
    sleep 1
fi

# Start all servers
echo "Starting Game Server (server.js)..."
nohup node server.js > game-server.log 2>&1 &
GAME_PID=$!
echo "Game Server started with PID: $GAME_PID"

sleep 1

echo "Starting Lobby Server (lobbyServer.js)..."
nohup node lobbyServer.js > lobby-server.log 2>&1 &
LOBBY_PID=$!
echo "Lobby Server started with PID: $LOBBY_PID"

sleep 1

echo "Starting Lobby Wallet Server (lobbyWalletServer.js)..."
nohup node lobbyWalletServer.js > lobby-wallet-server.log 2>&1 &
WALLET_PID=$!
echo "Lobby Wallet Server started with PID: $WALLET_PID"

sleep 2

# Verify all servers are running
echo "Verifying servers are running..."
ps aux | grep node | grep -v grep

echo "=== Server Restart Complete ==="
echo "$(date): All servers have been restarted"

# Show server status
echo ""
echo "Server Status:"
echo "Game Server Log (last 5 lines):"
tail -n 5 game-server.log 2>/dev/null || echo "No log file yet"
echo ""
echo "Lobby Server Log (last 5 lines):"
tail -n 5 lobby-server.log 2>/dev/null || echo "No log file yet"
echo ""
echo "Lobby Wallet Server Log (last 5 lines):"
tail -n 5 lobby-wallet-server.log 2>/dev/null || echo "No log file yet"
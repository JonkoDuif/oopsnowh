#!/bin/bash

# Kill and Restart Script for All Game Servers
# This script forcefully stops existing servers and restarts them with SSL

echo "🔄 Stopping all existing servers..."

# Kill PHP development server
echo "Killing PHP development server..."
pkill -9 -f "php -S" 2>/dev/null || true

# Kill all Node.js processes related to the game (more aggressive)
echo "Killing existing Node.js game processes..."
pkill -9 -f "node server.js" 2>/dev/null || true
pkill -9 -f "node lobbyWalletServer.js" 2>/dev/null || true
pkill -9 -f "lobbyWalletServer" 2>/dev/null || true
pkill -9 -f "server.js" 2>/dev/null || true

# Also kill any orphaned node processes
echo "Killing any orphaned Node.js processes..."
pkill -9 node 2>/dev/null || true

# Kill any processes using ports 8000, 8080, 8081, and 8082 (more aggressive)
echo "Freeing up ports 8000, 8080, 8081, and 8082..."
fuser -k -9 8000/tcp 2>/dev/null || true
fuser -k -9 8080/tcp 2>/dev/null || true
fuser -k -9 8081/tcp 2>/dev/null || true
fuser -k -9 8082/tcp 2>/dev/null || true

# Alternative method using lsof if fuser is not available
if command -v lsof >/dev/null 2>&1; then
    echo "Using lsof to kill processes on ports..."
    lsof -ti:8000 | xargs kill -9 2>/dev/null || true
    lsof -ti:8080 | xargs kill -9 2>/dev/null || true
    lsof -ti:8081 | xargs kill -9 2>/dev/null || true
    lsof -ti:8082 | xargs kill -9 2>/dev/null || true
fi

# Additional cleanup using ss command if available
if command -v ss >/dev/null 2>&1; then
    echo "Using ss to find and kill remaining processes..."
    for port in 8000 8080 8081 8082; do
        ss -tulpn | grep ":$port " | awk '{print $7}' | cut -d',' -f2 | cut -d'=' -f2 | xargs kill -9 2>/dev/null || true
    done
fi

# Wait for processes to fully terminate
echo "Waiting for processes to terminate..."
sleep 5

# Force kill any remaining processes
echo "Final cleanup - killing any remaining processes..."
for i in {1..3}; do
    if pgrep -f "server.js\|lobbyWalletServer" >/dev/null; then
        echo "Attempt $i: Still found running processes, force killing..."
        pkill -9 -f "server.js" 2>/dev/null || true
        pkill -9 -f "lobbyWalletServer" 2>/dev/null || true
        sleep 2
    else
        echo "All processes terminated successfully"
        break
    fi
done

# Verify ports are free
echo "Checking if ports are now available..."
for port in 8000 8080 8081 8082; do
    if netstat -tuln | grep -q ":$port "; then
        echo "❌ Port $port is still in use!"
        echo "Processes using port $port:"
        lsof -i :$port 2>/dev/null || netstat -tuln | grep ":$port"
        echo "Attempting to force kill processes on port $port..."
        lsof -ti:$port | xargs kill -9 2>/dev/null || true
        sleep 1
        if netstat -tuln | grep -q ":$port "; then
            echo "❌ Failed to free port $port - manual intervention required"
            exit 1
        fi
    else
        echo "✅ Port $port is available"
    fi
done

# Setup SSL certificates if needed
echo "🔐 Setting up SSL certificates..."
if [ ! -f "/etc/letsencrypt/live/oopsnowh.com/privkey.pem" ]; then
    echo "SSL certificates not found. Running SSL setup..."
    if [ -f "./setup-ssl.sh" ]; then
        echo "Running SSL certificate setup..."
        sudo bash ./setup-ssl.sh
        if [ $? -eq 0 ]; then
            echo "✅ SSL certificates installed successfully"
        else
            echo "⚠️  SSL setup failed, servers will run without SSL"
        fi
    else
        echo "⚠️  setup-ssl.sh not found, servers will run without SSL"
    fi
else
    echo "✅ SSL certificates already exist"
fi

# Set environment variables for SSL
echo "Setting up SSL environment..."
export SSL_ENABLED=true
export NODE_ENV=production

# Start PHP development server
echo "🚀 Starting PHP development server..."
nohup php -S localhost:8000 > php-server.log 2>&1 &
PHP_PID=$!
echo "PHP server started with PID: $PHP_PID"

# Start the game server with SSL support
echo "🚀 Starting game server with SSL..."
SSL_ENABLED=true nohup node server.js > game-server.log 2>&1 &
GAME_PID=$!
echo "Game server started with PID: $GAME_PID"

# Start the lobby wallet server with SSL support
echo "🚀 Starting lobby wallet server with SSL..."
SSL_ENABLED=true nohup node lobbyWalletServer.js > lobby-wallet.log 2>&1 &
LOBBY_PID=$!
echo "Lobby wallet server started with PID: $LOBBY_PID"

# Wait a moment and check if servers started successfully
sleep 5

echo "\n📊 Checking server status..."

# Check PHP server
if ps -p $PHP_PID > /dev/null; then
    echo "✅ PHP server is running (PID: $PHP_PID)"
    echo "   Checking if port 8000 is listening..."
    if netstat -tuln | grep -q ":8000 "; then
        echo "✅ PHP server is listening on port 8000"
    else
        echo "❌ PHP server not listening on port 8000 - check logs"
        tail -10 php-server.log
    fi
else
    echo "❌ PHP server failed to start - check logs:"
    cat php-server.log
fi

# Check Game server
if ps -p $GAME_PID > /dev/null; then
    echo "✅ Game server is running (PID: $GAME_PID)"
    echo "   Checking if port 8081 is listening..."
    if netstat -tuln | grep -q ":8081 "; then
        echo "✅ Game server is listening on port 8081"
    else
        echo "❌ Game server not listening on port 8081 - check logs"
        tail -10 game-server.log
    fi
else
    echo "❌ Game server failed to start - check logs:"
    cat game-server.log
fi

# Check Lobby wallet server
if ps -p $LOBBY_PID > /dev/null; then
    echo "✅ Lobby wallet server is running (PID: $LOBBY_PID)"
    echo "   Checking if port 8082 is listening..."
    if netstat -tuln | grep -q ":8082 "; then
        echo "✅ Lobby wallet server is listening on port 8082"
    else
        echo "❌ Lobby wallet server not listening on port 8082 - check logs"
        tail -10 lobby-wallet.log
    fi
else
    echo "❌ Lobby wallet server failed to start - check logs:"
    cat lobby-wallet.log
fi

echo "\n📋 Server Information:"
echo "PHP server log: tail -f php-server.log"
echo "Game server log: tail -f game-server.log"
echo "Lobby server log: tail -f lobby-wallet.log"
echo "\nTo stop all servers: pkill -f 'php -S'; pkill -f 'node server.js'; pkill -f 'node lobbyWalletServer.js'"
echo "\n🌐 Access URLs:"
echo "  - Web interface: http://localhost:8000"
echo "  - Game server: wss://oopsnowh.com:8081 (or ws://localhost:8081)"
echo "  - Lobby wallet: wss://oopsnowh.com:8082 (or ws://localhost:8082)"
echo "\n🎮 Your game should now be accessible with full SSL/WSS support!"
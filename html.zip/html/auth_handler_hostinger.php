<?php
require_once 'config_hostinger.php';
require_once 'email_service.php';

// Set CORS headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

class AuthHandler {
    
    public static function handleRequest() {
        // Rate limiting removed
        
        $rawInput = file_get_contents('php://input');
        error_log("Raw input: " . $rawInput);
        
        $input = json_decode($rawInput, true);
        error_log("Parsed input: " . print_r($input, true));
        
        $action = $input['action'] ?? '';
        error_log("Action: " . $action);
        
        // Sanitize input
        if (is_array($input)) {
            array_walk_recursive($input, function(&$value) {
                if (is_string($value)) {
                    $value = sanitizeInput($value);
                }
            });
        }
        
        switch ($action) {
            case 'send_verification':
                return self::sendVerificationCode($input);
            case 'verify_code':
                return self::verifyCode($input);
            case 'create_account':
                return self::createAccount($input);
            case 'check_session':
                return self::checkSession($input);
            case 'update_wallet_address':
                return self::updateWalletAddress($input);
            case 'logout':
                return self::logout($input);
            default:
                return self::errorResponse('Invalid action');
        }
    }
    
    private static function sendVerificationCode($input) {
        $email = $input['email'] ?? '';
        
        if (!validateEmail($email)) {
            return self::errorResponse('Invalid email address');
        }
        
        // Email rate limiting removed
        
        // Generate verification code
        $code = generateCode();
        
        // Store verification code in database
        if (!storeVerificationCode($email, $code)) {
            return self::errorResponse('Failed to generate verification code');
        }
        
        // Send email with error handling
        try {
            $emailSent = EmailService::sendVerificationCode($email, $code);
        } catch (Exception $e) {
            error_log("Email service error: " . $e->getMessage());
            $emailSent = false;
        }
        
        if ($emailSent) {
            return self::successResponse([
                'message' => 'Verification code sent successfully',
                'email' => $email
            ]);
        } else {
            // Development mode: Return success even if email fails, log the code
            error_log("Development mode: Verification code for $email is: $code");
            return self::successResponse([
                'message' => 'Email service unavailable. Development mode: Check server logs for verification code.',
                'email' => $email,
                'dev_mode' => true
            ]);
        }
    }
    
    private static function verifyCode($input) {
        $email = $input['email'] ?? '';
        $code = $input['code'] ?? '';
        
        error_log("VerifyCode method called with email: $email, code: $code");
        
        if (!validateEmail($email) || empty($code)) {
            error_log("Validation failed - email valid: " . (validateEmail($email) ? 'yes' : 'no') . ", code empty: " . (empty($code) ? 'yes' : 'no'));
            return self::errorResponse('Invalid email or verification code');
        }
        
        // Verification rate limiting removed
        
        // Verify code
        error_log("Calling global verifyCode function");
        $verificationResult = \verifyCode($email, $code);
        error_log("Verification result: " . ($verificationResult ? 'true' : 'false'));
        
        if (!$verificationResult) {
            return self::errorResponse('Invalid or expired verification code');
        }
        
        // Check if user exists
        $user = getUser($email);
        
        if ($user) {
            // Existing user - create session
            $sessionToken = createSession($user['id']);
            if ($sessionToken) {
                return self::successResponse([
                    'message' => 'Login successful',
                    'user' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email'],
                        'wallet_address' => $user['wallet_address'],
                        'balance' => $user['balance']
                    ],
                    'session_token' => $sessionToken
                ]);
            } else {
                return self::errorResponse('Failed to create session');
            }
        } else {
            // New user - needs to create account
            return self::successResponse([
                'message' => 'Email verified. Please create your account.',
                'new_user' => true,
                'email' => $email
            ]);
        }
    }
    
    private static function createAccount($input) {
        $username = $input['username'] ?? '';
        $email = $input['email'] ?? '';
        
        if (!validateEmail($email) || !validateUsername($username)) {
            return self::errorResponse('Invalid email or username');
        }
        
        // Check if user already exists
        if (getUser($email)) {
            return self::errorResponse('User already exists');
        }
        
        // Create user
        if (createUser($username, $email)) {
            $user = getUser($email);
            $sessionToken = createSession($user['id']);
            
            if ($sessionToken) {
                return self::successResponse([
                    'message' => 'Account created successfully',
                    'user' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email'],
                        'wallet_address' => $user['wallet_address'],
                        'balance' => $user['balance']
                    ],
                    'session_token' => $sessionToken
                ]);
            } else {
                return self::errorResponse('Account created but failed to create session');
            }
        } else {
            return self::errorResponse('Failed to create account');
        }
    }
    
    private static function checkSession($input) {
        $sessionToken = $input['session_token'] ?? '';
        
        if (empty($sessionToken)) {
            return self::errorResponse('No session token provided');
        }
        
        $user = validateSession($sessionToken);
        
        if ($user) {
            return self::successResponse([
                'valid' => true,
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'wallet_address' => $user['wallet_address'],
                    'balance' => $user['balance']
                ]
            ]);
        } else {
            return self::errorResponse('Invalid or expired session');
        }
    }
    
    private static function updateWalletAddress($input) {
        $sessionToken = $input['session_token'] ?? '';
        $walletAddress = $input['wallet_address'] ?? '';
        
        if (empty($sessionToken) || empty($walletAddress)) {
            return self::errorResponse('Missing session token or wallet address');
        }
        
        $user = validateSession($sessionToken);
        if (!$user) {
            return self::errorResponse('Invalid session');
        }
        
        // Validate wallet address format (basic Solana address validation)
        if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $walletAddress)) {
            return self::errorResponse('Invalid wallet address format');
        }
        
        // Update wallet address
        if (updateUser($user['id'], ['wallet_address' => $walletAddress])) {
            return self::successResponse([
                'message' => 'Wallet address updated successfully',
                'wallet_address' => $walletAddress
            ]);
        } else {
            return self::errorResponse('Failed to update wallet address');
        }
    }
    
    private static function logout($input) {
        $sessionToken = $input['session_token'] ?? '';
        
        if (empty($sessionToken)) {
            return self::errorResponse('No session token provided');
        }
        
        if (deleteSession($sessionToken)) {
            return self::successResponse(['message' => 'Logged out successfully']);
        } else {
            return self::errorResponse('Failed to logout');
        }
    }
    
    private static function successResponse($data) {
        return json_encode([
            'success' => true,
            'data' => $data
        ]);
    }
    
    private static function errorResponse($message) {
        http_response_code(400);
        return json_encode([
            'success' => false,
            'error' => $message
        ]);
    }
}

// Handle the request
try {
    echo AuthHandler::handleRequest();
} catch (Exception $e) {
    error_log('Auth Handler Error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Internal server error'
    ]);
}
?>
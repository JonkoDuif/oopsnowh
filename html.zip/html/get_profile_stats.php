<?php
// Skip access control for API endpoints
define('SKIP_ACCESS_CHECK', true);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Include database configuration
require_once __DIR__ . '/../database.php';

try {
    // Connect to MySQL database
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    if (!$pdo) {
        throw new Exception('Database connection failed');
    }
    
    $username = $_GET['username'] ?? $_GET['user'] ?? '';
    
    if (empty($username)) {
        echo json_encode(['success' => false, 'error' => 'Username parameter required']);
        exit;
    }
    
    // Get user ID first
    $stmt = $pdo->prepare("SELECT id, username, balance, created_at FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    $user_id = $user['id'];
    
    // Get game statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as games_played,
            SUM(CASE WHEN score > 0 THEN 1 ELSE 0 END) as games_won,
            SUM(kills) as total_kills,
            MAX(max_mass) as max_mass,
            SUM(survival_time) as total_survival_time,
            SUM(score) as total_earnings,
            AVG(survival_time) as avg_survival_time
        FROM game_stats 
        WHERE user_id = ?
    ");
    
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Calculate derived statistics
    $winRate = $stats['games_played'] > 0 ? ($stats['games_won'] / $stats['games_played']) * 100 : 0;
    $killsPerGame = $stats['games_played'] > 0 ? $stats['total_kills'] / $stats['games_played'] : 0;
    
    // Format response
    $response = [
        'success' => true,
        'profile' => [
            'username' => $user['username'],
            'games_played' => (int)($stats['games_played'] ?? 0),
            'games_won' => (int)($stats['games_won'] ?? 0),
            'total_kills' => (int)($stats['total_kills'] ?? 0),
            'max_mass' => (int)($stats['max_mass'] ?? 0),
            'total_survival_time' => (int)($stats['total_survival_time'] ?? 0),
            'avg_survival_time' => (int)($stats['avg_survival_time'] ?? 0),
            'total_earnings' => (float)($user['balance'] ?? 0),
            'win_rate' => round($winRate, 1),
            'kills_per_game' => round($killsPerGame, 1),
            'member_since' => $user['created_at']
        ]
    ];
    
    echo json_encode($response);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
<?php
// Simple File-Based Database for Verification Codes
// This acts like a database but uses PHP serialized files instead of JSON

class Database {
    private static $instance = null;
    private $dataDir;
    private $connected = true;
    
    private function __construct() {
        $this->dataDir = __DIR__ . '/data';
        
        // Ensure data directory exists
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0755, true);
        }
        
        // Initialize tables (create files if they don't exist)
        $this->initializeTables();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this; // Return self as we're simulating a database connection
    }
    
    public function isConnected() {
        return $this->connected;
    }
    
    public function useDatabase() {
        return true; // Always use database (file-based)
    }
    
    public function initializeTables() {
        // Create verification codes table file if it doesn't exist
        $verificationFile = $this->dataDir . '/verification_codes.db';
        if (!file_exists($verificationFile)) {
            file_put_contents($verificationFile, serialize([]));
        }
        return true;
    }
    
    // Simulate PDO prepare method for verification codes
    public function prepare($sql) {
        return new DatabaseStatement($sql, $this->dataDir);
    }
    
    public function exec($sql) {
        // For table creation, just return true since we handle it in initializeTables
        return true;
    }
}

class DatabaseStatement {
    private $sql;
    private $dataDir;
    private $result;
    
    public function __construct($sql, $dataDir) {
        $this->sql = $sql;
        $this->dataDir = $dataDir;
        $this->result = null;
    }
    
    public function execute($params = []) {
        $verificationFile = $this->dataDir . '/verification_codes.db';
        
        // Load existing data
        $data = [];
        if (file_exists($verificationFile)) {
            $data = unserialize(file_get_contents($verificationFile));
            if (!is_array($data)) {
                $data = [];
            }
        }
        
        if (strpos($this->sql, 'DELETE FROM verification_codes') !== false) {
            // Delete codes for specific email
            $email = isset($params[0]) ? $params[0] : null;
            if ($email) {
                $data = array_filter($data, function($item) use ($email) {
                    return $item['email'] !== $email;
                });
                file_put_contents($verificationFile, serialize($data));
            }
            return true;
            
        } elseif (strpos($this->sql, 'INSERT INTO verification_codes') !== false) {
            // Insert new verification code
            $newCode = [
                'id' => count($data) + 1,
                'email' => isset($params[0]) ? $params[0] : '',
                'code' => isset($params[1]) ? $params[1] : '',
                'expires_at' => isset($params[2]) ? $params[2] : date('Y-m-d H:i:s', time() + 600),
                'used' => false,
                'created_at' => date('Y-m-d H:i:s')
            ];
            $data[] = $newCode;
            file_put_contents($verificationFile, serialize($data));
            return true;
            
        } elseif (strpos($this->sql, 'SELECT * FROM verification_codes') !== false) {
            // Select verification code
            $email = isset($params[0]) ? $params[0] : '';
            $code = isset($params[1]) ? $params[1] : '';
            $currentTime = isset($params[2]) ? $params[2] : date('Y-m-d H:i:s');
            
            foreach ($data as $item) {
                if (is_array($item) && 
                    isset($item['email']) && isset($item['code']) && 
                    isset($item['expires_at']) && isset($item['used']) &&
                    $item['email'] === $email && 
                    $item['code'] === $code && 
                    $item['expires_at'] > $currentTime && 
                    !$item['used']) {
                    $this->result = $item;
                    return true;
                }
            }
            $this->result = null;
            return true;
            
        } elseif (strpos($this->sql, 'UPDATE verification_codes SET used = TRUE') !== false) {
            // Mark code as used
            $id = isset($params[0]) ? $params[0] : null;
            if ($id) {
                foreach ($data as $key => $item) {
                    if (is_array($item) && isset($item['id']) && $item['id'] == $id) {
                        $data[$key]['used'] = true;
                        break;
                    }
                }
                file_put_contents($verificationFile, serialize($data));
            }
            return true;
        }
        
        // Handle users table operations
        $usersFile = $this->dataDir . '/users.json';
        
        if (strpos($this->sql, 'SELECT * FROM users WHERE email = ?') !== false) {
            // Select user by email
            $email = isset($params[0]) ? $params[0] : '';
            
            if (file_exists($usersFile)) {
                $users = json_decode(file_get_contents($usersFile), true);
                if (is_array($users)) {
                    foreach ($users as $user) {
                        if ($user['email'] === $email) {
                            $this->result = $user;
                            return true;
                        }
                    }
                }
            }
            $this->result = null;
            return true;
            
        } elseif (strpos($this->sql, 'SELECT u.* FROM users u JOIN sessions s') !== false) {
            // Session validation query - just return null for now since we're not using sessions in file mode
            $this->result = null;
            return true;
        }
        
        return false;
    }
    
    public function fetch() {
        return isset($this->result) ? $this->result : false;
    }
}
?>
<?php
// CORS headers - no session needed
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Access-Control-Allow-Credentials: false');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once 'database_improved.php';

// Admin key verification
function verifyAdminKey($adminKey) {
    return $adminKey === 'KJ2N1Mm!-0!';
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$adminKey = $input['adminKey'] ?? '';

// Handle admin authentication - simplified without sessions
if ($action === 'admin_login') {
    if (verifyAdminKey($adminKey)) {
        echo json_encode([
            'success' => true, 
            'message' => 'Admin authenticated',
            'adminKey' => $adminKey
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid admin key']);
    }
    exit;
}

// Handle admin logout - simplified
if ($action === 'admin_logout') {
    echo json_encode(['success' => true, 'message' => 'Logged out']);
    exit;
}

// Check if admin is authenticated - only check adminKey
if (!verifyAdminKey($adminKey)) {
    echo json_encode([
        'success' => false, 
        'message' => 'Unauthorized - Invalid admin key'
    ]);
    exit;
}

try {
    $db = Database::getInstance();
    
    switch ($action) {
        case 'search_user':
            $searchTerm = $input['searchTerm'] ?? '';
            if (empty($searchTerm)) {
                echo json_encode(['success' => false, 'message' => 'Search term required']);
                break;
            }
            
            $user = $db->searchUser($searchTerm);
            if ($user) {
                echo json_encode(['success' => true, 'user' => $user]);
            } else {
                echo json_encode(['success' => false, 'message' => 'User not found']);
            }
            break;
            
        case 'get_all_users':
            $users = $db->getAllUsers();
            echo json_encode(['success' => true, 'users' => $users]);
            break;
            
        case 'ban_user':
            $userId = $input['userId'] ?? '';
            $username = $input['username'] ?? '';
            
            if (empty($userId) && empty($username)) {
                echo json_encode(['success' => false, 'message' => 'User ID or username required']);
                break;
            }
            
            $result = $db->banUser($userId, $username);
            echo json_encode(['success' => $result, 'message' => $result ? 'User banned successfully' : 'Failed to ban user']);
            break;
            
        case 'unban_user':
            $userId = $input['userId'] ?? '';
            $username = $input['username'] ?? '';
            
            if (empty($userId) && empty($username)) {
                echo json_encode(['success' => false, 'message' => 'User ID or username required']);
                break;
            }
            
            $result = $db->unbanUser($userId, $username);
            echo json_encode(['success' => $result, 'message' => $result ? 'User unbanned successfully' : 'Failed to unban user']);
            break;
            
        case 'timeout_user':
            $userId = $input['userId'] ?? '';
            $username = $input['username'] ?? '';
            $duration = $input['duration'] ?? 24 * 60 * 60 * 1000; // 24 hours default
            
            if (empty($userId) && empty($username)) {
                echo json_encode(['success' => false, 'message' => 'User ID or username required']);
                break;
            }
            
            $result = $db->timeoutUser($userId, $username, $duration);
            echo json_encode(['success' => $result, 'message' => $result ? 'User timed out successfully' : 'Failed to timeout user']);
            break;
            
        case 'get_user_wallet':
            $userId = $input['userId'] ?? '';
            $username = $input['username'] ?? '';
            
            if (empty($userId) && empty($username)) {
                echo json_encode(['success' => false, 'message' => 'User ID or username required']);
                break;
            }
            
            $wallet = $db->getUserWallet($userId, $username);
            if ($wallet) {
                echo json_encode(['success' => true, 'wallet' => $wallet]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Wallet not found']);
            }
            break;
            
        case 'update_user_balance':
            $userId = $input['userId'] ?? '';
            $username = $input['username'] ?? '';
            $solBalance = $input['solBalance'] ?? null;
            $eurBalance = $input['eurBalance'] ?? null;
            
            if (empty($userId) && empty($username)) {
                echo json_encode(['success' => false, 'message' => 'User ID or username required']);
                break;
            }
            
            $result = $db->updateUserBalance($userId, $username, $solBalance, $eurBalance);
            echo json_encode(['success' => $result, 'message' => $result ? 'Balance updated successfully' : 'Failed to update balance']);
            break;
            
        case 'get_site_settings':
            $settings = $db->getSiteSettings();
            echo json_encode(['success' => true, 'settings' => $settings]);
            break;
            
        case 'update_site_settings':
            $settings = $input['settings'] ?? [];
            $result = $db->updateSiteSettings($settings);
            echo json_encode(['success' => $result, 'message' => $result ? 'Settings updated successfully' : 'Failed to update settings']);
            break;
            
        case 'get_server_stats':
            $stats = [
                'total_users' => $db->getTotalUsers(),
                'active_users' => $db->getActiveUsers(),
                'total_games' => $db->getTotalGames(),
                'server_uptime' => $db->getServerUptime(),
                'memory_usage' => memory_get_usage(true),
                'peak_memory' => memory_get_peak_usage(true)
            ];
            echo json_encode(['success' => true, 'stats' => $stats]);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
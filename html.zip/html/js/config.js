// Game Configuration
const CONFIG = {
    // Server Configuration
    SERVER: {
        DEFAULT_HOST: '149.12.246.143',
        DEFAULT_PORT: 3000,
        RECONNECT_ATTEMPTS: 5,
        RECONNECT_DELAY: 2000,
        PING_INTERVAL: 5000
    },

    // Game Settings
    GAME: {
        // Canvas
        CANVAS_WIDTH: 1920,
        CANVAS_HEIGHT: 1080,
        VIEWPORT_SCALE: 1,
        
        // Physics
        WORLD_WIDTH: 14142,
        WORLD_HEIGHT: 14142,
        BORDER_WIDTH: 50,
        
        // Player
        PLAYER_MIN_SIZE: 10,
        PLAYER_MAX_SIZE: 1000,
        PLAYER_START_SIZE: 20,
        PLAYER_SPEED_BASE: 6.25,
        PLAYER_SPEED_SCALE: 0.02,
        
        // Splitting
        SPLIT_SPEED: 25,
        SPLIT_DECAY: 0.36,
        SPLIT_MIN_SIZE: 35,
        SPLIT_MAX_CELLS: 16,
        SPLIT_COOLDOWN: 1000,
        
        // Feeding
        FEED_SIZE: 12,
        FEED_SPEED: 25,
        FEED_DECAY: 0.99,
        FEED_MIN_SIZE: 35,
        
        // Food
        FOOD_SIZE: 10,
        FOOD_COUNT: 1000,
        FOOD_RESPAWN_TIME: 100,
        
        // Viruses
        VIRUS_SIZE: 100,
        VIRUS_COUNT: 50,
        VIRUS_SPLIT_SIZE: 120,
        
        // Mass
        MASS_LOSS_RATE: 0.002,
        MASS_LOSS_MIN: 9,
        
        // Experience and Leveling
        XP_MULTIPLIER: 1.0,
        LEVEL_XP_BASE: 100,
        LEVEL_XP_MULTIPLIER: 1.5
    },

    // Rendering
    RENDER: {
        FPS_TARGET: 60,
        INTERPOLATION: true,
        SMOOTH_CAMERA: true,
        CAMERA_SPEED: 0.05,
        
        // Visual Effects
        PARTICLE_EFFECTS: true,
        SCREEN_SHAKE: true,
        BLOOM_EFFECT: false,
        
        // UI
        SHOW_GRID: true,
        SHOW_BORDER: true,
        SHOW_NAMES: true,
        SHOW_SKINS: true,
        SHOW_MASS: true,
        
        // Colors
        BACKGROUND_COLOR: '#111111',
        GRID_COLOR: '#333333',
        BORDER_COLOR: '#ff0000',
        
        // Grid
        GRID_SIZE: 50,
        GRID_ALPHA: 0.3
    },

    // Input
    INPUT: {
        MOUSE_SENSITIVITY: 1.0,
        KEYBOARD_REPEAT_DELAY: 100,
        
        // Key Bindings
        KEYS: {
            SPLIT: 'Space',
            FEED: 'KeyW',
            AUTO_SPLIT: 'KeyZ',
            AUTO_FEED: 'KeyQ',
            CHAT: 'Enter',
            PAUSE: 'Escape',
            ZOOM_IN: 'Equal',
            ZOOM_OUT: 'Minus'
        }
    },

    // Audio
    AUDIO: {
        MASTER_VOLUME: 0.7,
        SFX_VOLUME: 0.8,
        MUSIC_VOLUME: 0.5,
        
        // Sound Effects
        SOUNDS: {
            EAT: true,
            SPLIT: true,
            FEED: true,
            DEATH: true,
            LEVEL_UP: true,
            POWERUP: true
        }
    },

    // Powerups
    POWERUPS: {
        SPEED_BOOST: {
            id: 'speed',
            name: 'Speed Boost',
            icon: '⚡',
            duration: 10000,
            multiplier: 1.5,
            cooldown: 30000
        },
        DOUBLE_SIZE: {
            id: 'double',
            name: 'Double Size',
            icon: '🔥',
            duration: 15000,
            multiplier: 2.0,
            cooldown: 60000
        },
        FREEZE: {
            id: 'freeze',
            name: 'Freeze',
            icon: '❄️',
            duration: 5000,
            radius: 200,
            cooldown: 45000
        },
        INVISIBILITY: {
            id: 'invisible',
            name: 'Invisibility',
            icon: '👻',
            duration: 8000,
            cooldown: 90000
        },
        MAGNET: {
            id: 'magnet',
            name: 'Magnet',
            icon: '🧲',
            duration: 12000,
            radius: 150,
            cooldown: 40000
        }
    },

    // Shop
    SHOP: {
        CATEGORIES: {
            POWERUPS: 'powerups',
            SKINS: 'skins',
            BOOSTS: 'boosts'
        },
        
        CURRENCY: {
            COINS: 'coins',
            GEMS: 'gems'
        },
        
        ITEMS: {
            // Powerup Packs
            SPEED_PACK: { id: 'speed_pack', price: 100, currency: 'coins', quantity: 5 },
            DOUBLE_PACK: { id: 'double_pack', price: 200, currency: 'coins', quantity: 3 },
            FREEZE_PACK: { id: 'freeze_pack', price: 150, currency: 'coins', quantity: 4 },
            
            // Skins
            RAINBOW_SKIN: { id: 'rainbow', price: 500, currency: 'coins', type: 'skin' },
            GALAXY_SKIN: { id: 'galaxy', price: 1000, currency: 'coins', type: 'skin' },
            FIRE_SKIN: { id: 'fire', price: 750, currency: 'coins', type: 'skin' },
            
            // Boosts
            XP_BOOST: { id: 'xp_boost', price: 50, currency: 'coins', duration: 3600000 },
            COIN_BOOST: { id: 'coin_boost', price: 75, currency: 'coins', duration: 3600000 }
        }
    },

    // Chat
    CHAT: {
        MAX_LENGTH: 100,
        HISTORY_SIZE: 50,
        SPAM_LIMIT: 3,
        SPAM_TIMEOUT: 5000,
        
        CHANNELS: {
            ALL: 'all',
            TEAM: 'team',
            PARTY: 'party'
        }
    },

    // Networking
    NETWORK: {
        UPDATE_RATE: 60,
        INTERPOLATION_DELAY: 100,
        PREDICTION: true,
        LAG_COMPENSATION: true,
        
        // Packet Types
        PACKETS: {
            // Client to Server
            JOIN: 'join',
            MOVE: 'move',
            SPLIT: 'split',
            FEED: 'feed',
            CHAT: 'chat',
            POWERUP: 'powerup',
            PING: 'ping',
            
            // Server to Client
            GAME_STATE: 'gameState',
            PLAYER_UPDATE: 'playerUpdate',
            LEADERBOARD: 'leaderboard',
            CHAT_MESSAGE: 'chatMessage',
            PLAYER_DEATH: 'playerDeath',
            POWERUP_SPAWN: 'powerupSpawn',
            PONG: 'pong'
        }
    },

    // Game Modes
    GAME_MODES: {
        FFA: {
            id: 'ffa',
            name: 'Free For All',
            description: 'Classic Agma.io gameplay',
            maxPlayers: 200,
            teams: false
        },
        TEAMS: {
            id: 'teams',
            name: 'Teams',
            description: 'Team-based gameplay',
            maxPlayers: 200,
            teams: true,
            teamCount: 4
        },
        EXPERIMENTAL: {
            id: 'experimental',
            name: 'Experimental',
            description: 'New features and mechanics',
            maxPlayers: 100,
            teams: false
        },
        PARTY: {
            id: 'party',
            name: 'Party',
            description: 'Private games with friends',
            maxPlayers: 50,
            teams: false,
            private: true
        },
        CRAZY: {
            id: 'crazy',
            name: 'Crazy',
            description: 'Fast-paced gameplay with powerups',
            maxPlayers: 150,
            teams: false,
            powerupsEnabled: true
        },
        SELFFEED: {
            id: 'selffeed',
            name: 'Self Feed',
            description: 'Auto-feeding enabled',
            maxPlayers: 100,
            teams: false,
            autoFeed: true
        }
    },

    // Debug
    DEBUG: {
        ENABLED: false,
        SHOW_FPS: true,
        SHOW_PING: true,
        SHOW_HITBOXES: false,
        SHOW_QUADTREE: false,
        LOG_PACKETS: false
    }
};

// Color Palettes
CONFIG.COLORS = {
    PLAYER_COLORS: [
        '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
        '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
        '#F8C471', '#82E0AA', '#F1948A', '#85C1E9', '#F4D03F'
    ],
    
    TEAM_COLORS: {
        RED: '#FF6B6B',
        BLUE: '#4ECDC4',
        GREEN: '#96CEB4',
        YELLOW: '#FFEAA7'
    },
    
    FOOD_COLORS: [
        '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
        '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'
    ]
};

// Export for Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
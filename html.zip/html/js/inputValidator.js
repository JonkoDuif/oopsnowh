// Direct access prevention
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
    throw new Error('Direct file access denied');
}

/**
 * Comprehensive Input Validation Utility
 * Provides client-side validation for all user inputs
 * Should be used in conjunction with server-side validation
 */
class InputValidator {
    
    // Email validation with comprehensive checks
    static validateEmail(email) {
        if (!email || typeof email !== 'string') {
            return { valid: false, message: 'Email is required' };
        }
        
        // Length check
        if (email.length > 254) {
            return { valid: false, message: 'Email is too long' };
        }
        
        // Basic format validation
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
            return { valid: false, message: 'Invalid email format' };
        }
        
        // Check for common disposable email domains
        const disposableDomains = [
            'tempmail.org', '10minutemail.com', 'guerrillamail.com',
            'mailinator.com', 'throwaway.email', 'temp-mail.org'
        ];
        
        const domain = email.split('@')[1]?.toLowerCase();
        if (disposableDomains.includes(domain)) {
            return { valid: false, message: 'Disposable email addresses are not allowed' };
        }
        
        return { valid: true, message: 'Valid email' };
    }
    
    // Username validation
    static validateUsername(username) {
        if (!username || typeof username !== 'string') {
            return { valid: false, message: 'Username is required' };
        }
        
        // Length check
        if (username.length < 3 || username.length > 20) {
            return { valid: false, message: 'Username must be 3-20 characters long' };
        }
        
        // Character validation - only alphanumeric and underscores
        const usernameRegex = /^[a-zA-Z0-9_]+$/;
        if (!usernameRegex.test(username)) {
            return { valid: false, message: 'Username can only contain letters, numbers, and underscores' };
        }
        
        // Check for reserved words
        const reservedWords = [
            'admin', 'administrator', 'root', 'system', 'user', 'guest',
            'null', 'undefined', 'api', 'www', 'mail', 'support'
        ];
        
        if (reservedWords.includes(username.toLowerCase())) {
            return { valid: false, message: 'This username is reserved' };
        }
        
        return { valid: true, message: 'Valid username' };
    }
    
    // Verification code validation
    static validateVerificationCode(code) {
        if (!code || typeof code !== 'string') {
            return { valid: false, message: 'Verification code is required' };
        }
        
        // Must be exactly 6 digits
        const codeRegex = /^[0-9]{6}$/;
        if (!codeRegex.test(code)) {
            return { valid: false, message: 'Verification code must be 6 digits' };
        }
        
        return { valid: true, message: 'Valid verification code' };
    }
    
    // Wallet address validation (Solana)
    static validateWalletAddress(address) {
        if (!address || typeof address !== 'string') {
            return { valid: false, message: 'Wallet address is required' };
        }
        
        // Solana address validation - base58 encoded, 32-44 characters
        const solanaRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
        if (!solanaRegex.test(address)) {
            return { valid: false, message: 'Invalid Solana wallet address format' };
        }
        
        return { valid: true, message: 'Valid wallet address' };
    }
    
    // Amount validation (for betting, transfers, etc.)
    static validateAmount(amount, min = 0.000001, max = 1000000) {
        if (amount === null || amount === undefined || amount === '') {
            return { valid: false, message: 'Amount is required' };
        }
        
        const numAmount = parseFloat(amount);
        
        if (isNaN(numAmount)) {
            return { valid: false, message: 'Amount must be a valid number' };
        }
        
        if (numAmount < min) {
            return { valid: false, message: `Amount must be at least ${min}` };
        }
        
        if (numAmount > max) {
            return { valid: false, message: `Amount cannot exceed ${max}` };
        }
        
        // Check for reasonable decimal places (max 6 for SOL)
        const decimalPlaces = (numAmount.toString().split('.')[1] || '').length;
        if (decimalPlaces > 6) {
            return { valid: false, message: 'Amount cannot have more than 6 decimal places' };
        }
        
        return { valid: true, message: 'Valid amount', value: numAmount };
    }
    
    // Search query validation
    static validateSearchQuery(query) {
        if (!query || typeof query !== 'string') {
            return { valid: false, message: 'Search query is required' };
        }
        
        // Length check
        if (query.length < 2) {
            return { valid: false, message: 'Search query must be at least 2 characters' };
        }
        
        if (query.length > 100) {
            return { valid: false, message: 'Search query is too long' };
        }
        
        // Character validation - allow alphanumeric, spaces, and basic symbols
        const queryRegex = /^[a-zA-Z0-9\s._-]+$/;
        if (!queryRegex.test(query)) {
            return { valid: false, message: 'Search query contains invalid characters' };
        }
        
        return { valid: true, message: 'Valid search query' };
    }
    
    // Generic text validation with XSS protection
    static validateText(text, minLength = 1, maxLength = 1000, allowHTML = false) {
        if (!text || typeof text !== 'string') {
            return { valid: false, message: 'Text is required' };
        }
        
        if (text.length < minLength) {
            return { valid: false, message: `Text must be at least ${minLength} characters` };
        }
        
        if (text.length > maxLength) {
            return { valid: false, message: `Text cannot exceed ${maxLength} characters` };
        }
        
        if (!allowHTML) {
            // Check for HTML/script tags
            const htmlRegex = /<[^>]*>/;
            if (htmlRegex.test(text)) {
                return { valid: false, message: 'HTML tags are not allowed' };
            }
            
            // Check for script injection attempts
            const scriptRegex = /(javascript:|data:|vbscript:|on\w+\s*=)/i;
            if (scriptRegex.test(text)) {
                return { valid: false, message: 'Script content is not allowed' };
            }
        }
        
        return { valid: true, message: 'Valid text' };
    }
    
    // Sanitize input to prevent XSS
    static sanitizeInput(input) {
        if (typeof input !== 'string') {
            return input;
        }
        
        return input
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#x27;')
            .replace(/\//g, '&#x2F;');
    }
    
    // Validate form data object
    static validateForm(formData, rules) {
        const errors = {};
        let isValid = true;
        
        for (const [field, rule] of Object.entries(rules)) {
            const value = formData[field];
            let result;
            
            switch (rule.type) {
                case 'email':
                    result = this.validateEmail(value);
                    break;
                case 'username':
                    result = this.validateUsername(value);
                    break;
                case 'verificationCode':
                    result = this.validateVerificationCode(value);
                    break;
                case 'walletAddress':
                    result = this.validateWalletAddress(value);
                    break;
                case 'amount':
                    result = this.validateAmount(value, rule.min, rule.max);
                    break;
                case 'searchQuery':
                    result = this.validateSearchQuery(value);
                    break;
                case 'text':
                    result = this.validateText(value, rule.minLength, rule.maxLength, rule.allowHTML);
                    break;
                default:
                    result = { valid: true, message: 'No validation rule' };
            }
            
            if (!result.valid) {
                errors[field] = result.message;
                isValid = false;
            }
        }
        
        return { valid: isValid, errors };
    }
    
    // Real-time validation for input fields
    static setupRealTimeValidation(inputElement, validationType, options = {}) {
        if (!inputElement) return;
        
        const validateInput = () => {
            const value = inputElement.value;
            let result;
            
            switch (validationType) {
                case 'email':
                    result = this.validateEmail(value);
                    break;
                case 'username':
                    result = this.validateUsername(value);
                    break;
                case 'verificationCode':
                    result = this.validateVerificationCode(value);
                    break;
                case 'walletAddress':
                    result = this.validateWalletAddress(value);
                    break;
                case 'amount':
                    result = this.validateAmount(value, options.min, options.max);
                    break;
                case 'searchQuery':
                    result = this.validateSearchQuery(value);
                    break;
                case 'text':
                    result = this.validateText(value, options.minLength, options.maxLength, options.allowHTML);
                    break;
                default:
                    return;
            }
            
            // Update UI based on validation result
            inputElement.classList.toggle('valid', result.valid);
            inputElement.classList.toggle('invalid', !result.valid);
            
            // Show/hide error message
            const errorElement = inputElement.parentElement.querySelector('.error-message');
            if (errorElement) {
                errorElement.textContent = result.valid ? '' : result.message;
                errorElement.style.display = result.valid ? 'none' : 'block';
            }
            
            return result;
        };
        
        // Add event listeners
        inputElement.addEventListener('input', validateInput);
        inputElement.addEventListener('blur', validateInput);
        
        return validateInput;
    }
}

// Export for use in other modules
window.InputValidator = InputValidator;
// Prevent direct loading from a /js/ path if that's how you're serving static files
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
  throw new Error('Direct file access denied');
}

/**
 * Lobby Wallet Manager
 * - Connects to Wallet WS via nginx proxy path /ws-lobby-wallet (? 127.0.0.1:8083)
 * - Provides minimal local fallback if WS unavailable
 * - Stores lightweight state in localStorage
 */

class LobbyWalletManager {
  constructor() {
    this.lobbyWallets = new Map();  // lobbyId -> { publicKey, balance, ... }
    this.ws = null;
    this.isConnected = false;
    this.playerId = this.generatePlayerId();

    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    this.reconnectDelayMs = 3000;

    this.loadLobbyWallets();
    this.connectToServer();
  }

  // --- Utility ---

  generatePlayerId() {
    let id = localStorage.getItem('player_id');
    if (!id) {
      id = 'player_' + Date.now() + '_' + Math.random().toString(36).slice(2, 11);
      localStorage.setItem('player_id', id);
    }
    return id;
  }

  saveLobbyWallets() {
    try {
      const obj = {};
      this.lobbyWallets.forEach((val, key) => obj[key] = val);
      localStorage.setItem('lobby_wallets', JSON.stringify(obj));
    } catch (e) {
      console.warn('Failed to persist lobby wallets to localStorage:', e);
    }
  }

  loadLobbyWallets() {
    try {
      const raw = localStorage.getItem('lobby_wallets');
      if (!raw) return;
      const obj = JSON.parse(raw);
      
      // Check if we have any LocalWallet addresses (cached fallback data)
      const hasLocalWallets = Object.values(obj).some(wallet => 
        wallet.publicKey && wallet.publicKey.startsWith('LocalWallet_')
      );
      
      // If we have LocalWallet addresses, clear them and force fresh connection
      if (hasLocalWallets) {
        console.log('🔄 Clearing cached LocalWallet addresses, will fetch real addresses from server');
        localStorage.removeItem('lobby_wallets');
        this.lobbyWallets.clear();
        return;
      }
      
      Object.keys(obj).forEach(k => this.lobbyWallets.set(Number(k), obj[k]));
    } catch (e) {
      console.warn('Failed to load lobby wallets from localStorage:', e);
    }
  }

  // --- WebSocket connection ---

  connectToServer() {
    try {
      let serverUrl;
      // Always use production mode - connect via nginx reverse proxy
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      serverUrl = `${proto}//${location.host}/ws-lobby-wallet`;
      console.log('🔒 Using nginx reverse proxy for lobby wallet connection');

      console.log('🔌 Connecting to lobby wallet server:', serverUrl);
      this.ws = new WebSocket(serverUrl);

      this.ws.onopen = () => {
        console.log('?? Connected to lobby wallet server');
        this.isConnected = true;
        this.reconnectAttempts = 0;
        this.requestLobbyData();
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleServerMessage(data);
        } catch (err) {
          console.error('? Error parsing wallet server message:', err);
        }
      };

      this.ws.onclose = () => {
        console.log('?? Disconnected from lobby wallet server');
        this.isConnected = false;
        this.attemptReconnect();
      };

      this.ws.onerror = (err) => {
        console.error('❌ Wallet WebSocket error:', err, 'URL:', serverUrl);
        this.isConnected = false;
        // Don't immediately fallback in production - let attemptReconnect handle it
        console.log('🔄 WebSocket error occurred, will attempt reconnection...');
      };
    } catch (err) {
      console.error('? Failed to connect wallet server:', err);
      this.fallbackToLocalMode();
    }
  }

  attemptReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      setTimeout(() => this.connectToServer(), this.reconnectDelayMs);
    } else {
      console.log('? Max wallet reconnection attempts reached. Falling back to local mode.');
      this.fallbackToLocalMode();
    }
  }

  fallbackToLocalMode() {
    console.error('❌ FALLBACK TO LOCAL MODE - WebSocket connection failed after max attempts');
    console.error('❌ This will generate LocalWallet addresses which are NOT real Solana addresses');
    
    // Minimal local in-memory wallets (mock)
    if (this.lobbyWallets.size === 0) {
      for (let i = 1; i <= 8; i++) {
        this.lobbyWallets.set(i, {
          publicKey: `LocalWallet_${i}_${Math.random().toString(36).slice(2, 10)}`,
          balance: 0,
          players: {},
        });
      }
      this.saveLobbyWallets();
      console.error('❌ Generated LocalWallet addresses - SOL transfers will fail!');
    }
  }

  // --- Server protocol helpers ---

  requestLobbyData() {
    this.send({
      type: 'request_lobby_data',
      playerId: this.playerId,
    });
  }

  handleServerMessage(msg) {
    switch (msg.type) {
      case 'lobby_data':            return this.handleLobbyData(msg);
      case 'lobby_stats_update':    return this.handleLobbyStatsUpdate(msg);
      case 'player_joined':         return this.handlePlayerJoined(msg);
      case 'player_left':           return this.handlePlayerLeft(msg);
      case 'player_update':         return this.handlePlayerUpdate(msg);
      case 'bet_success':           return this.handleBetSuccess(msg);
      case 'cashout_success':       return this.handleCashoutSuccess(msg);
      case 'error':                 return this.handleError(msg);
      default:
        console.log('?? Wallet server message:', msg);
    }
  }

  handleLobbyData({ lobbies }) {
    if (Array.isArray(lobbies)) {
      lobbies.forEach(l => {
        this.lobbyWallets.set(Number(l.lobbyId), {
          publicKey: l.publicKey,
          privateKey: l.privateKey, // Store private key for blockchain transfers
          balance: l.balance ?? 0,
          gamePool: l.gamePool ?? 0,
          totalBets: l.totalBets ?? 0,
          players: l.players ?? {},
        });
      });
      this.saveLobbyWallets();
      console.log('🔄 Wallets synced:', this.getAllLobbyInfo());
    }
  }

  handleLobbyStatsUpdate({ lobbyId, balance, publicKey, privateKey, players, gamePool, totalBets }) {
    const id = Number(lobbyId);
    const lw = this.lobbyWallets.get(id) || {};
    if (typeof balance === 'number') lw.balance = balance;
    if (typeof gamePool === 'number') lw.gamePool = gamePool;
    if (typeof totalBets === 'number') lw.totalBets = totalBets;
    if (publicKey) lw.publicKey = publicKey;
    if (privateKey) lw.privateKey = privateKey; // Store private key for blockchain transfers
    if (players) lw.players = players;
    this.lobbyWallets.set(id, lw);
    this.saveLobbyWallets();
  }

  handlePlayerJoined({ lobbyId, player }) {
    const id = Number(lobbyId);
    const lw = this.lobbyWallets.get(id) || { players: {} };
    lw.players = lw.players || {};
    lw.players[player.id] = player;
    this.lobbyWallets.set(id, lw);
    this.saveLobbyWallets();
    
    // Forward to lobby system for UI updates
    if (window.lobbySystem) {
      window.lobbySystem.handleLobbyMessage(id, {
        type: 'player_joined',
        lobbyId: id,
        playerId: player.id,
        playerData: player,
        players: Object.values(lw.players)
      });
    }
  }

  handlePlayerLeft({ lobbyId, playerId }) {
    const id = Number(lobbyId);
    const lw = this.lobbyWallets.get(id);
    if (!lw || !lw.players) return;
    delete lw.players[playerId];
    this.saveLobbyWallets();
    
    // Forward to lobby system for UI updates
    if (window.lobbySystem) {
      window.lobbySystem.handleLobbyMessage(id, {
        type: 'player_left',
        lobbyId: id,
        playerId: playerId,
        players: Object.values(lw.players)
      });
    }
  }

  handlePlayerUpdate({ lobbyId, player }) {
    const id = Number(lobbyId);
    const lw = this.lobbyWallets.get(id) || { players: {} };
    lw.players = lw.players || {};
    lw.players[player.id] = player;
    this.lobbyWallets.set(id, lw);
    this.saveLobbyWallets();
  }

  handleBetSuccess({ lobbyId, playerId, amount }) {
    console.log(`? Bet success: lobby ${lobbyId}, player ${playerId}, amount ${amount}`);
  }

  handleCashoutSuccess({ lobbyId, playerId, amount }) {
    console.log(`? Cashout success: lobby ${lobbyId}, player ${playerId}, amount ${amount}`);
  }

  handleError({ message }) {
    console.error('? Wallet server error:', message);
  }

  // --- API used by LobbySystem / UI ---

  createLobbyWallet(lobbyId) {
    const id = Number(lobbyId);
    if (this.lobbyWallets.has(id)) return this.lobbyWallets.get(id);

    const wallet = {
      publicKey: 'LocalWallet_' + Math.random().toString(36).slice(2, 10),
      balance: 0,
      gamePool: 0,
      totalBets: 0,
      players: {},
    };
    this.lobbyWallets.set(id, wallet);
    this.saveLobbyWallets();
    return wallet;
  }

  getLobbyWallet(lobbyId) {
    const id = Number(lobbyId);
    return this.lobbyWallets.get(id) || this.createLobbyWallet(id);
  }

  getLobbyStats(lobbyId) {
    const id = Number(lobbyId);
    return this.lobbyWallets.get(id) || null;
  }

  getLobbyWalletAddress(lobbyId) {
    const id = Number(lobbyId);
    const wallet = this.lobbyWallets.get(id);
    
    // Only return address if it's a valid one from the server (not a local fake one)
    if (wallet && wallet.publicKey && !wallet.publicKey.startsWith('LocalWallet_')) {
      return wallet.publicKey;
    }
    
    return null;
  }

  joinLobby(lobbyId, playerData = {}) {
    const id = Number(lobbyId);
    this.send({
      type: 'join_lobby_wallet',
      lobbyId: id,
      player: {
        id: this.playerId,
        ...playerData,
      },
    });
  }

  leaveLobby() {
    this.send({
      type: 'leave_lobby_wallet',
      playerId: this.playerId,
    });
  }

  async addPlayerBet(lobbyId, playerId, betAmount) {
    const id = Number(lobbyId);
    const amount = Number(betAmount) || 0;
    
    console.log('🔄 DEBUG: addPlayerBet called with:', { lobbyId, playerId, betAmount, id, amount });
    
    try {
      // Ensure we're connected to the server first
      console.log('🔄 DEBUG: Checking connection status:', this.isConnected);
      if (!this.isConnected) {
        throw new Error('Not connected to lobby wallet server. Please wait and try again.');
      }
      
      // Get the lobby wallet address
      console.log(`🔍 Connection status: ${this.isConnected}`);
      console.log(`🔍 Available lobbies:`, Array.from(this.lobbyWallets.keys()));
      
      const lobbyWalletAddress = this.getLobbyWalletAddress(id);
      console.log(`🔍 Retrieved wallet address for lobby ${id}: "${lobbyWalletAddress}"`);
      
      if (!lobbyWalletAddress) {
        throw new Error(`Lobby wallet address not available for lobby ${id}. Please wait for server sync.`);
      }
      
      // Check if lobby wallet exists on blockchain before attempting transfer
      const lobbyWalletExists = await this.checkLobbyWalletExists(lobbyWalletAddress);
      if (!lobbyWalletExists) {
        throw new Error(`Lobby ${id} is temporarily unavailable (wallet not found on blockchain). Please try a different lobby or wait for initialization.`);
      }
      
      // Ensure user has a wallet generated first
      let username = playerId; // Default to playerId if it's already a username
      if (window.walletSystem && window.authSystem?.isLoggedIn) {
        const currentUser = window.authSystem.getCurrentUser();
        if (currentUser && currentUser.username) {
          username = currentUser.username;
          // Generate wallet if it doesn't exist
          await window.walletSystem.generateUserWallet(currentUser.username);
        }
      }
      
      // Get user's keypair for SOL transfer
      const userKeypair = window.walletSystem?.getUserKeypair?.(username);
      if (!userKeypair) {
        throw new Error('User wallet not found or missing private key');
      }
      
      // The amount passed in is the bet amount without fee
      // We need to add the €0.10 fee for the total transfer
      const FEE_EUR = 0.10;
      
      // Get real-time SOL price for accurate conversion
      const solToEuroRate = await window.walletSystem.getRealSolPrice();
      console.log(`💱 Current SOL price: €${solToEuroRate}`);
      
      // Convert bet amount from EUR to SOL (amount is the bet without fee)
      const betAmountSOL = amount / solToEuroRate;
      const feeInSOL = FEE_EUR / solToEuroRate;
      const totalAmountSOL = betAmountSOL + feeInSOL; // Total to transfer (bet + fee)
      
      console.log(`💰 Bet conversion: €${amount} = ${betAmountSOL.toFixed(6)} SOL`);
      console.log(`💰 Fee: €${FEE_EUR} = ${feeInSOL.toFixed(6)} SOL`);
      console.log(`💰 Total transfer: €${(amount + FEE_EUR).toFixed(2)} = ${totalAmountSOL.toFixed(6)} SOL`);
      
      // Check if user has sufficient balance (bet + fee)
      const userBalance = await window.walletSystem.getUserSolBalance(username);
      
      console.log(`💰 User balance: ${userBalance.toFixed(6)} SOL`);
      console.log(`💰 Total cost: ${totalAmountSOL.toFixed(6)} SOL (${betAmountSOL.toFixed(6)} bet + ${feeInSOL.toFixed(6)} fee)`);
      
      if (userBalance < totalAmountSOL) {
        // Convert current SOL balance back to EUR for user-friendly message
        const currentBalanceEUR = userBalance * solToEuroRate;
        const requiredAmountEUR = amount + FEE_EUR;
        
        throw new Error(`You don't have enough funds. You should have €${requiredAmountEUR.toFixed(2)} (€${amount.toFixed(2)} bet + €${FEE_EUR.toFixed(2)} fee) and you only have €${currentBalanceEUR.toFixed(2)}.`);
      }
      
      console.log(`💰 Transferring ${totalAmountSOL.toFixed(6)} SOL (bet + fee) from user to lobby ${id}`);
      
      // Perform the SOL transfer (bet amount + fee)
      const transferResult = await window.walletSystem.transferSol(
        userKeypair,
        lobbyWalletAddress,
        totalAmountSOL,
        `Game bet: €${amount} + €${FEE_EUR} fee = €${(amount + FEE_EUR).toFixed(2)} total (${totalAmountSOL.toFixed(6)} SOL) for lobby ${id}`,
        true // isGameBet = true
      );
      
      if (!transferResult.success) {
        throw new Error(`SOL transfer failed: ${transferResult.error}`);
      }
      
      console.log(`✅ SOL transfer successful. Signature: ${transferResult.signature}`);
      
      // Note: No need for separate internal balance deduction since blockchain transfer already happened
      // The wallet system will automatically update the balance when queried from blockchain
      
      // Now proceed with the original bet logic
      if (!this.isConnected) {
        return this.addPlayerBetLocal(id, playerId, amount);
      }

      this.send({
        type: 'player_bet',
        lobbyId: id,
        playerId,
        amount: betAmountSOL, // This is the actual bet amount (without fee)
        amountEUR: amount, // This is the actual bet amount in EUR (without fee)
        totalTransferred: totalAmountSOL, // Total amount transferred (bet + fee)
        transferSignature: transferResult.signature
      });
      
      return {
        success: true,
        transferSignature: transferResult.signature,
        betAmount: betAmountSOL, // Actual bet amount
        betAmountEUR: amount, // Actual bet amount in EUR
        totalTransferred: totalAmountSOL, // Total transferred (bet + fee)
        totalTransferredEUR: amount + FEE_EUR, // Total in EUR
        fee: feeInSOL,
        feeEUR: FEE_EUR
      };
      
    } catch (error) {
      console.error('❌ Failed to process player bet:', error);
      throw error;
    }
  }

  async addPlayerBetLocal(lobbyId, playerId, betAmount) {
    const id = Number(lobbyId);
    const lw = this.getLobbyWallet(id);
    lw.balance = (lw.balance || 0) + (Number(betAmount) || 0);
    lw.players = lw.players || {};
    lw.players[playerId] = lw.players[playerId] || {};
    lw.players[playerId].lastBet = Number(betAmount) || 0;
    this.saveLobbyWallets();
    console.log('?? Local bet updated', { lobbyId: id, playerId, betAmount });
  }

  async handlePlayerCashout(lobbyId, playerId, cashoutAmount) {
    const id = Number(lobbyId);
    const amount = Number(cashoutAmount) || 0;
    
    try {
      // Get lobby wallet info
      const lobbyWallet = this.getLobbyWallet(id);
      if (!lobbyWallet) {
        console.error(`Lobby wallet not found for lobby ${id}`);
        // Fallback to internal balance if lobby wallet not available
        if (window.walletSystem) {
          const solPrice = await window.walletSystem.getRealSolPrice();
          const cashoutAmountSOL = amount / solPrice;
          let username = playerId;
          if (window.authSystem?.isLoggedIn) {
            const currentUser = window.authSystem.getCurrentUser();
            if (currentUser && currentUser.username) {
              username = currentUser.username;
            }
          }
          await window.walletSystem.addUserSolBalance(username, cashoutAmountSOL);
          console.log(`💰 Added ${cashoutAmountSOL.toFixed(6)} SOL to internal wallet (lobby wallet not found)`);
        }
        return {
          success: true,
          cashoutAmount: amount,
          cashoutAmountSOL: amount / (await window.walletSystem.getRealSolPrice()),
          transferredToWallet: false,
          fallbackToInternal: true
        };
      }
      
      // Get user info
      let username = playerId;
      if (window.authSystem?.isLoggedIn) {
        const currentUser = window.authSystem.getCurrentUser();
        if (currentUser && currentUser.username) {
          username = currentUser.username;
        }
      }
      
      // Convert EUR cashout amount to SOL
      const solPrice = await window.walletSystem.getRealSolPrice();
      const cashoutAmountSOL = amount / solPrice;
      
      console.log(`💸 Processing cashout: €${amount} = ${cashoutAmountSOL.toFixed(6)} SOL for user ${username}`);
      
      // Get lobby wallet keypair for transfer
      const lobbyWalletKeypair = await this.getLobbyWalletKeypair(id);
      if (!lobbyWalletKeypair) {
        console.error(`Cannot get lobby wallet keypair for lobby ${id}`);
        // Fallback to internal balance
        if (window.walletSystem) {
          await window.walletSystem.addUserSolBalance(username, cashoutAmountSOL);
          console.log(`💰 Fallback: Added ${cashoutAmountSOL.toFixed(6)} SOL to internal wallet`);
        }
        return {
          success: true,
          cashoutAmount: amount,
          cashoutAmountSOL: cashoutAmountSOL,
          transferredToWallet: false,
          fallbackToInternal: true
        };
      }
      
      // Get player's wallet address
      const playerWalletAddress = await window.walletSystem.getUserWalletAddress(username);
      if (!playerWalletAddress) {
        console.error(`Player wallet address not found for ${username}`);
        // Fallback to internal balance
        if (window.walletSystem) {
          await window.walletSystem.addUserSolBalance(username, cashoutAmountSOL);
          console.log(`💰 Fallback: Added ${cashoutAmountSOL.toFixed(6)} SOL to internal wallet`);
        }
        return {
          success: true,
          cashoutAmount: amount,
          cashoutAmountSOL: cashoutAmountSOL,
          transferredToWallet: false,
          fallbackToInternal: true
        };
      }
      
      // Perform real blockchain transfer from lobby wallet to player wallet
      console.log(`🔗 Transferring ${cashoutAmountSOL.toFixed(6)} SOL from lobby ${id} to player ${username}`);
      console.log(`   From: ${lobbyWalletKeypair.publicKey}`);
      console.log(`   To: ${playerWalletAddress}`);
      
      const transferResult = await window.walletSystem.transferSol(
        lobbyWalletKeypair.keypair,
        playerWalletAddress,
        cashoutAmountSOL,
        `Game cashout: €${amount} (${cashoutAmountSOL.toFixed(6)} SOL) from lobby ${id} to ${username}`,
        false, // Not a game bet, this is a cashout (fees covered by initial 0.10 EUR fee)
        true   // Is a cashout - lobby covers all fees from €0.10 fee
      );
      
      if (!transferResult.success) {
        console.error(`❌ Blockchain transfer failed: ${transferResult.error}`);
        // Fallback to internal balance if blockchain transfer fails
        if (window.walletSystem) {
          await window.walletSystem.addUserSolBalance(username, cashoutAmountSOL);
          console.log(`💰 Fallback: Added ${cashoutAmountSOL.toFixed(6)} SOL to internal wallet`);
        }
        return {
          success: true,
          cashoutAmount: amount,
          cashoutAmountSOL: cashoutAmountSOL,
          transferredToWallet: false,
          fallbackToInternal: true,
          error: transferResult.error
        };
      }
      
      console.log(`✅ Blockchain transfer successful! Signature: ${transferResult.signature}`);
      
      // Update lobby wallet balance and notify server
      if (!this.isConnected) {
        return this.handlePlayerCashoutLocal(id, playerId, amount);
      }
      
      console.log(`📡 Sending cashout notification to server for lobby ${id}`);
      this.send({
        type: 'player_cashout',
        lobbyId: id,
        playerId,
        amount: amount,
      });
      
      return {
        success: true,
        cashoutAmount: amount,
        cashoutAmountSOL: cashoutAmountSOL,
        transferredToWallet: true,
        transferSignature: transferResult.signature,
        fallbackToInternal: false
      };
      
    } catch (error) {
      console.error('❌ Failed to process cashout:', error);
      // Emergency fallback to internal balance
      try {
        if (window.walletSystem) {
          const solPrice = await window.walletSystem.getRealSolPrice();
          const cashoutAmountSOL = amount / solPrice;
          let username = playerId;
          if (window.authSystem?.isLoggedIn) {
            const currentUser = window.authSystem.getCurrentUser();
            if (currentUser && currentUser.username) {
              username = currentUser.username;
            }
          }
          await window.walletSystem.addUserSolBalance(username, cashoutAmountSOL);
          console.log(`💰 Emergency fallback: Added ${cashoutAmountSOL.toFixed(6)} SOL to internal wallet`);
          
          return {
            success: true,
            cashoutAmount: amount,
            cashoutAmountSOL: cashoutAmountSOL,
            transferredToWallet: false,
            fallbackToInternal: true,
            error: error.message
          };
        }
      } catch (fallbackError) {
        console.error('❌ Even fallback failed:', fallbackError);
      }
      
      // Only throw if absolutely everything failed
      throw error;
    }
  }

  // Check if lobby wallet exists on Solana blockchain
  async checkLobbyWalletExists(walletAddress) {
    try {
      if (!window.walletSystem?.connection) {
        console.warn('No Solana connection available for wallet validation');
        return false;
      }
      
      const publicKey = new window.solanaWeb3.PublicKey(walletAddress);
      const accountInfo = await window.walletSystem.connection.getAccountInfo(publicKey);
      
      const exists = accountInfo !== null;
      console.log(`🔍 Lobby wallet ${walletAddress} exists on blockchain: ${exists}`);
      
      return exists;
    } catch (error) {
      console.error(`Failed to check lobby wallet existence for ${walletAddress}:`, error);
      return false;
    }
  }

  // Get lobby wallet keypair for transfers
  async getLobbyWalletKeypair(lobbyId) {
    try {
      // Check if we have lobby wallet data from server
      const lobbyWalletData = this.lobbyWallets.get(Number(lobbyId));
      if (!lobbyWalletData || !lobbyWalletData.privateKey) {
        console.error(`No private key available for lobby ${lobbyId}`);
        console.log('Available lobby wallets:', Array.from(this.lobbyWallets.keys()));
        console.log('Lobby wallet data:', lobbyWalletData);
        return null;
      }
      
      // Create keypair from stored private key (from server)
      const privateKeyArray = Array.isArray(lobbyWalletData.privateKey) 
        ? lobbyWalletData.privateKey 
        : Object.values(lobbyWalletData.privateKey);
      
      console.log(`🔑 Creating keypair for lobby ${lobbyId} with private key length: ${privateKeyArray.length}`);
      
      const keypair = window.solanaWeb3.Keypair.fromSecretKey(
        new Uint8Array(privateKeyArray)
      );
      
      console.log(`✅ Successfully created keypair for lobby ${lobbyId}: ${keypair.publicKey.toString()}`);
      
      return {
        keypair: keypair,
        publicKey: keypair.publicKey.toString()
      };
      
    } catch (error) {
      console.error(`Failed to get lobby wallet keypair for lobby ${lobbyId}:`, error);
      return null;
    }
  }

  async handlePlayerCashoutLocal(lobbyId, playerId, cashoutAmount) {
    const id = Number(lobbyId);
    const lw = this.getLobbyWallet(id);
    lw.balance = Math.max(0, (lw.balance || 0) - (Number(cashoutAmount) || 0));
    this.saveLobbyWallets();
    console.log('💸 Local cashout updated', { lobbyId: id, playerId, cashoutAmount });
  }

  handlePlayerElimination(lobbyId, playerId, playerMoney) {
    const id = Number(lobbyId);
    console.log('?? Player eliminated', { lobbyId: id, playerId, playerMoney });
    // Could trigger payouts/refunds, depends on game rules
  }

  getAllLobbyInfo() {
    const out = [];
    this.lobbyWallets.forEach((v, k) => out.push({ id: k, ...v }));
    return out;
  }

  // --- Send helper ---

  send(payload) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    } else {
      // If no connection, just log; some calls also have local fallbacks
      console.debug('WS not connected; queued/ignored:', payload.type);
    }
  }
}

window.lobbyWalletManager = new LobbyWalletManager();
console.log('?? Lobby Wallet Manager initialized');

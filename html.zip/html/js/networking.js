// Networking Module
class NetworkManager {
    constructor() {
        this.socket = null;
        this.connected = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = CONFIG.SERVER.RECONNECT_ATTEMPTS;
        this.reconnectDelay = CONFIG.SERVER.RECONNECT_DELAY;
        this.pingInterval = null;
        this.lastPingTime = 0;
        this.ping = 0;
        this.serverList = [];
        this.currentServer = null;
        
        // Event handlers
        this.onConnect = null;
        this.onDisconnect = null;
        this.onServerInfo = null;
        this.onGameJoined = null;
        this.onPlayerSpawned = null;
        this.onGameLeft = null;
        this.onGameState = null;
        this.onPlayerUpdate = null;
        this.onLeaderboard = null;
        this.onChatMessage = null;
        this.onPlayerDeath = null;
        this.onPowerupSpawn = null;
        this.onError = null;
        
        // Message queue for when disconnected
        this.messageQueue = [];
        this.queueEnabled = true;
    }

    // Initialize network manager
    init() {
        console.log('Network manager initialized');
        // Any initialization logic can go here
    }

    // Set callback functions
    setCallbacks(callbacks) {
        if (callbacks.onConnect) this.onConnect = callbacks.onConnect;
        if (callbacks.onDisconnect) this.onDisconnect = callbacks.onDisconnect;
        if (callbacks.onServerInfo) this.onServerInfo = callbacks.onServerInfo;
        if (callbacks.onGameJoined) this.onGameJoined = callbacks.onGameJoined;
        if (callbacks.onPlayerSpawned) this.onPlayerSpawned = callbacks.onPlayerSpawned;
        if (callbacks.onGameLeft) this.onGameLeft = callbacks.onGameLeft;
        if (callbacks.onGameState) this.onGameState = callbacks.onGameState;
        if (callbacks.onPlayerUpdate) this.onPlayerUpdate = callbacks.onPlayerUpdate;
        if (callbacks.onLeaderboard) this.onLeaderboard = callbacks.onLeaderboard;
        if (callbacks.onChatMessage) this.onChatMessage = callbacks.onChatMessage;
        if (callbacks.onPlayerDeath) this.onPlayerDeath = callbacks.onPlayerDeath;
        if (callbacks.onPowerupSpawn) this.onPowerupSpawn = callbacks.onPowerupSpawn;
        if (callbacks.onError) this.onError = callbacks.onError;
    }

    // Connect to server
    connect(host = CONFIG.SERVER.DEFAULT_HOST, port = CONFIG.SERVER.DEFAULT_PORT) {
        if (this.connected) {
            console.warn('Already connected to server');
            return;
        }

        const url = `http://${host}:${port}`;
        console.log(`Connecting to server: ${url}`);

        try {
            this.socket = io(url);
            this.setupSocketHandlers();
        } catch (error) {
            console.error('Failed to create Socket.IO connection:', error);
            this.handleError(error);
        }
    }

    // Setup Socket.IO event handlers
    setupSocketHandlers() {
        this.socket.on('connect', () => {
            console.log('Connected to server');
            this.connected = true;
            this.reconnectAttempts = 0;
            
            // Process queued messages
            this.processMessageQueue();
            
            // Start ping interval
            this.startPingInterval();
            
            if (this.onConnect) {
                this.onConnect();
            }
        });

        this.socket.on('disconnect', (reason) => {
            console.log('Disconnected from server:', reason);
            this.connected = false;
            this.stopPingInterval();
            
            if (this.onDisconnect) {
                this.onDisconnect({ reason });
            }
            
            // Attempt reconnection if not intentional
            if (reason !== 'io client disconnect' && this.reconnectAttempts < this.maxReconnectAttempts) {
                this.attemptReconnect();
            }
        });

        this.socket.on('connect_error', (error) => {
            console.error('Socket.IO connection error:', error);
            this.handleError(error);
        });

        // Listen for server info and connection events
        this.socket.on('server_info', (data) => {
            this.handleMessage({ type: 'server_info', payload: data });
        });
        
        this.socket.on('game_joined', (data) => {
            this.handleMessage({ type: 'game_joined', payload: data });
        });
        
        this.socket.on('player_spawned', (data) => {
            this.handleMessage({ type: 'player_spawned', payload: data });
        });
        
        this.socket.on('game_left', (data) => {
            this.handleMessage({ type: 'game_left', payload: data });
        });
        
        // Listen for game events
        this.socket.on('game_state', (data) => {
            this.handleMessage({ type: 'game_state', payload: data });
        });
        
        this.socket.on('playerUpdate', (data) => {
            this.handleMessage({ type: 'playerUpdate', payload: data });
        });
        
        this.socket.on('leaderboard', (data) => {
            this.handleMessage({ type: 'leaderboard', payload: data });
        });
        
        this.socket.on('chat_message', (data) => {
            this.handleMessage({ type: 'chat_message', payload: data });
        });
        
        this.socket.on('playerDeath', (data) => {
            this.handleMessage({ type: 'playerDeath', payload: data });
        });
        
        this.socket.on('powerupSpawn', (data) => {
            this.handleMessage({ type: 'powerupSpawn', payload: data });
        });
        
        this.socket.on('error', (data) => {
            this.handleMessage({ type: 'error', payload: data });
        });
        
        this.socket.on('pong', (data) => {
            this.handleMessage({ type: 'pong', payload: data });
        });
    }

    // Handle incoming messages
    handleMessage(data) {
        const { type, payload } = data;

        switch (type) {
            case 'server_info':
                if (this.onServerInfo) {
                    this.onServerInfo(payload);
                }
                break;
                
            case 'game_joined':
                if (this.onGameJoined) {
                    this.onGameJoined(payload);
                }
                break;
                
            case 'player_spawned':
                if (this.onPlayerSpawned) {
                    this.onPlayerSpawned(payload);
                }
                break;
                
            case 'game_left':
                if (this.onGameLeft) {
                    this.onGameLeft(payload);
                }
                break;
                
            case 'game_state':
            case CONFIG.NETWORK.PACKETS.GAME_STATE:
                if (this.onGameState) {
                    this.onGameState(payload);
                }
                break;

            case CONFIG.NETWORK.PACKETS.PLAYER_UPDATE:
                if (this.onPlayerUpdate) {
                    this.onPlayerUpdate(payload);
                }
                break;

            case CONFIG.NETWORK.PACKETS.LEADERBOARD:
                if (this.onLeaderboard) {
                    this.onLeaderboard(payload);
                }
                break;

            case 'chat_message':
            case CONFIG.NETWORK.PACKETS.CHAT_MESSAGE:
                if (this.onChatMessage) {
                    this.onChatMessage(payload);
                }
                break;

            case CONFIG.NETWORK.PACKETS.PLAYER_DEATH:
                if (this.onPlayerDeath) {
                    this.onPlayerDeath(payload);
                }
                break;

            case CONFIG.NETWORK.PACKETS.POWERUP_SPAWN:
                if (this.onPowerupSpawn) {
                    this.onPowerupSpawn(payload);
                }
                break;

            case 'pong':
            case CONFIG.NETWORK.PACKETS.PONG:
                this.handlePong(payload);
                break;

            case 'serverList':
                this.handleServerList(payload);
                break;

            case 'error':
                console.error('Server error:', payload.message || payload);
                this.handleError(new Error(payload.message || 'Unknown server error'));
                break;

            default:
                console.warn('Unknown message type:', type);
        }
    }

    // Send message to server
    send(type, payload = {}) {
        const message = { type, payload, timestamp: Date.now() };

        if (this.connected && this.socket.connected) {
            try {
                this.socket.emit(type, payload);
                return true;
            } catch (error) {
                console.error('Failed to send message:', error);
                this.queueMessage(message);
                return false;
            }
        } else {
            this.queueMessage(message);
            return false;
        }
    }

    // Queue message for later sending
    queueMessage(message) {
        if (this.queueEnabled && this.messageQueue.length < 100) {
            this.messageQueue.push(message);
        }
    }

    // Process queued messages
    processMessageQueue() {
        while (this.messageQueue.length > 0) {
            const message = this.messageQueue.shift();
            if (this.connected) {
                this.socket.emit(message.type, message.payload);
            } else {
                break;
            }
        }
    }

    // Game-specific message methods
    joinGame(nickname, gameMode = 'ffa', serverId = null) {
        return this.send(CONFIG.NETWORK.PACKETS.JOIN, {
            nickname: Utils.sanitizeString(nickname, 15),
            gameMode,
            serverId
        });
    }

    sendMove(x, y) {
        return this.send(CONFIG.NETWORK.PACKETS.MOVE, { x, y });
    }

    sendSplit() {
        return this.send(CONFIG.NETWORK.PACKETS.SPLIT);
    }

    sendFeed() {
        return this.send(CONFIG.NETWORK.PACKETS.FEED);
    }

    sendChat(message, channel = 'all') {
        const sanitizedMessage = Utils.sanitizeString(message, CONFIG.CHAT.MAX_LENGTH);
        if (sanitizedMessage.length > 0) {
            return this.send(CONFIG.NETWORK.PACKETS.CHAT, {
                message: sanitizedMessage,
                channel
            });
        }
        return false;
    }

    // Alias for compatibility
    sendChatMessage(message, channel = 'all') {
        return this.sendChat(message, channel);
    }

    usePowerup(powerupId) {
        return this.send(CONFIG.NETWORK.PACKETS.POWERUP, { powerupId });
    }

    // Ping system
    startPingInterval() {
        this.stopPingInterval();
        this.pingInterval = setInterval(() => {
            this.sendPing();
        }, CONFIG.SERVER.PING_INTERVAL);
    }

    stopPingInterval() {
        if (this.pingInterval) {
            clearInterval(this.pingInterval);
            this.pingInterval = null;
        }
    }

    sendPing() {
        this.lastPingTime = Date.now();
        this.send(CONFIG.NETWORK.PACKETS.PING, { timestamp: this.lastPingTime });
    }

    handlePong(payload) {
        if (payload.timestamp === this.lastPingTime) {
            this.ping = Date.now() - this.lastPingTime;
        }
    }

    // Server list management
    requestServerList() {
        return this.send('getServerList');
    }

    handleServerList(servers) {
        this.serverList = servers;
        
        // Dispatch event for UI update
        const event = new CustomEvent('serverListUpdated', {
            detail: { servers: this.serverList }
        });
        window.dispatchEvent(event);
    }

    selectServer(serverId) {
        const server = this.serverList.find(s => s.id === serverId);
        if (server) {
            this.currentServer = server;
            return true;
        }
        return false;
    }

    // Reconnection logic
    attemptReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.log('Max reconnection attempts reached');
            return;
        }

        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
        
        console.log(`Attempting reconnection ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);
        
        setTimeout(() => {
            if (!this.connected) {
                if (this.currentServer) {
                    this.connect(this.currentServer.host, this.currentServer.port);
                } else {
                    this.connect();
                }
            }
        }, delay);
    }

    // Disconnect from server
    disconnect() {
        this.queueEnabled = false;
        this.messageQueue = [];
        this.stopPingInterval();
        
        if (this.socket) {
            this.socket.close(1000, 'Client disconnect');
            this.socket = null;
        }
        
        this.connected = false;
        this.reconnectAttempts = 0;
    }

    // Error handling
    handleError(error) {
        Utils.handleError(error, 'NetworkManager');
        
        if (this.onError) {
            this.onError(error);
        }
    }

    // Connection status
    isConnected() {
        return this.connected && this.socket && this.socket.readyState === WebSocket.OPEN;
    }

    getConnectionState() {
        if (!this.socket) return 'disconnected';
        
        switch (this.socket.readyState) {
            case WebSocket.CONNECTING:
                return 'connecting';
            case WebSocket.OPEN:
                return 'connected';
            case WebSocket.CLOSING:
                return 'disconnecting';
            case WebSocket.CLOSED:
                return 'disconnected';
            default:
                return 'unknown';
        }
    }

    // Statistics
    getStats() {
        return {
            connected: this.connected,
            ping: this.ping,
            reconnectAttempts: this.reconnectAttempts,
            queuedMessages: this.messageQueue.length,
            currentServer: this.currentServer,
            connectionState: this.getConnectionState()
        };
    }

    // Authentication methods
    login(username, password) {
        return this.send('login', { username, password });
    }

    register(username, email, password) {
        return this.send('register', { username, email, password });
    }

    logout() {
        return this.send('logout');
    }

    // Shop methods
    purchaseItem(itemId, currency = 'coins') {
        return this.send('purchase', { itemId, currency });
    }

    getInventory() {
        return this.send('getInventory');
    }

    // Friends and social
    addFriend(username) {
        return this.send('addFriend', { username });
    }

    removeFriend(username) {
        return this.send('removeFriend', { username });
    }

    inviteToParty(username) {
        return this.send('inviteToParty', { username });
    }

    joinParty(partyId) {
        return this.send('joinParty', { partyId });
    }

    leaveParty() {
        return this.send('leaveParty');
    }
}

// Create global network manager instance
const networkManager = new NetworkManager();

// Export for Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NetworkManager;
}
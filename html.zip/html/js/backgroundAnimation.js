// Direct access prevention
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
    throw new Error('Direct file access denied');
}

// Background Animation Controller for Agario Game
class BackgroundAnimationController {
    constructor() {
        this.players = [];
        this.init();
    }

    init() {
        // Get all moving players
        this.players = document.querySelectorAll('.moving-player');
        
        // Start the game simulation
        this.startGameSimulation();
    }

    startGameSimulation() {
        // Check for eating interactions every 2-4 seconds
        setInterval(() => {
            this.checkEatingInteractions();
        }, Math.random() * 2000 + 2000);

        // Trigger splitting every 8-15 seconds
        setInterval(() => {
            this.triggerSplitting();
        }, Math.random() * 7000 + 8000);
    }

    checkEatingInteractions() {
        const activePlayers = Array.from(this.players).filter(player => 
            !player.classList.contains('eaten') && 
            !player.classList.contains('splitting')
        );

        if (activePlayers.length < 2) return;

        // Find potential eating scenarios
        for (let i = 0; i < activePlayers.length; i++) {
            for (let j = i + 1; j < activePlayers.length; j++) {
                const player1 = activePlayers[i];
                const player2 = activePlayers[j];

                if (this.canEat(player1, player2)) {
                    this.eatPlayer(player1, player2);
                    return; // Only one eating per check
                } else if (this.canEat(player2, player1)) {
                    this.eatPlayer(player2, player1);
                    return;
                }
            }
        }
    }

    canEat(eater, prey) {
        // Check if eater is significantly larger than prey
        const eaterSize = this.getPlayerSize(eater);
        const preySize = this.getPlayerSize(prey);
        
        // Only eat if eater is at least 1.5x larger
        return eaterSize >= preySize * 1.5;
    }

    getPlayerSize(player) {
        if (player.classList.contains('tiny-player')) return 15;
        if (player.classList.contains('small-player')) return 25;
        if (player.classList.contains('medium-player')) return 40;
        if (player.classList.contains('large-player')) return 60;
        if (player.classList.contains('huge-player')) return 80;
        return 25; // default
    }

    eatPlayer(eater, prey) {
        // Animate the eating
        prey.classList.add('eaten');
        
        // Grow the eater slightly
        this.growPlayer(eater);
        
        // Remove the eaten player after animation
        setTimeout(() => {
            prey.style.display = 'none';
            
            // Respawn after some time
            setTimeout(() => {
                this.respawnPlayer(prey);
            }, Math.random() * 5000 + 3000);
        }, 500);
    }

    growPlayer(player) {
        const currentSize = this.getPlayerSize(player);
        const newSize = Math.min(currentSize + 5, 80); // Cap at huge size
        
        // Update size class
        player.classList.remove('tiny-player', 'small-player', 'medium-player', 'large-player', 'huge-player');
        
        if (newSize <= 15) player.classList.add('tiny-player');
        else if (newSize <= 25) player.classList.add('small-player');
        else if (newSize <= 40) player.classList.add('medium-player');
        else if (newSize <= 60) player.classList.add('large-player');
        else player.classList.add('huge-player');
    }

    triggerSplitting() {
        const largePlayers = Array.from(this.players).filter(player => 
            (player.classList.contains('large-player') || player.classList.contains('huge-player')) &&
            !player.classList.contains('eaten') && 
            !player.classList.contains('splitting')
        );

        if (largePlayers.length === 0) return;

        const playerToSplit = largePlayers[Math.floor(Math.random() * largePlayers.length)];
        this.splitPlayer(playerToSplit);
    }

    splitPlayer(player) {
        player.classList.add('splitting');
        
        // Create split child
        const splitChild = player.cloneNode(true);
        splitChild.classList.remove('splitting');
        splitChild.classList.add('split-child');
        
        // Make both smaller
        const currentSize = this.getPlayerSize(player);
        const newSize = Math.max(currentSize - 15, 15);
        
        [player, splitChild].forEach(p => {
            p.classList.remove('tiny-player', 'small-player', 'medium-player', 'large-player', 'huge-player');
            
            if (newSize <= 15) p.classList.add('tiny-player');
            else if (newSize <= 25) p.classList.add('small-player');
            else if (newSize <= 40) p.classList.add('medium-player');
            else if (newSize <= 60) p.classList.add('large-player');
            else p.classList.add('huge-player');
        });

        // Set random split direction
        const splitX = (Math.random() - 0.5) * 100;
        const splitY = (Math.random() - 0.5) * 100;
        splitChild.style.setProperty('--split-x', `${splitX}px`);
        splitChild.style.setProperty('--split-y', `${splitY}px`);

        // Add to DOM
        player.parentNode.appendChild(splitChild);

        // Clean up after animation
        setTimeout(() => {
            player.classList.remove('splitting');
            splitChild.remove();
        }, 800);
    }

    respawnPlayer(player) {
        player.style.display = '';
        player.classList.remove('eaten');
        
        // Reset to random small size
        player.classList.remove('tiny-player', 'small-player', 'medium-player', 'large-player', 'huge-player');
        const sizes = ['tiny-player', 'small-player'];
        player.classList.add(sizes[Math.floor(Math.random() * sizes.length)]);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new BackgroundAnimationController();
});
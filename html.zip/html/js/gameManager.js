// Game Manager - Handles UI states and game flow
class GameManager {
    constructor() {
        this.selectedBetAmount = 0.25;
        this.selectedRegion = 'US';
        this.selectedLobby = 'TRYHARD';
        this.game = null;
        this.uiManager = null;
        
        this.init();
    }

    init() {
        // Add small delay to ensure DOM is fully loaded
        setTimeout(() => {
            // Use existing global UI Manager or create new one
            this.uiManager = window.uiManager || new UIManager();
            if (!window.uiManager) {
                this.uiManager.initializeUI();
                window.uiManager = this.uiManager;
            }
            
            // Initialize game instance
            this.game = new AgarGame();
            this.game.init('gameCanvas');
            
            // Show home page initially
            this.showHomePage();
            
            // Initialize lobby system with retry mechanism
            this.initializeLobbySystemWithRetry();
            this.initializeLobbyIntegration();
            
            // Trigger initial server check now that UI is ready
            if (window.lobbySystem) {
                window.lobbySystem.triggerInitialServerCheck();
            }
            
            // Setup leaderboard button
            this.setupLeaderboardButton();
            
            // Update UI based on auth state
            setTimeout(async () => {
                await this.updateUI();
            }, 0);
        }, 50);
    }

    // Setup leaderboard button event listener
    setupLeaderboardButton() {
        const viewFullBtn = document.querySelector('.view-full-btn');
        if (viewFullBtn) {
            viewFullBtn.addEventListener('click', () => {
                // Open social system and switch to leaderboard tab
                if (window.socialSystem) {
                    window.socialSystem.showSocial();
                    window.socialSystem.switchTab('leaderboard');
                } else {
                    console.error('Social system not available');
                }
            });
            console.log('✅ View Full Leaderboard button event listener added');
        } else {
            console.error('❌ View Full Leaderboard button not found');
        }

        // Setup refresh button for social panel
        const refreshBtn = document.querySelector('.social-panel .refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                // Refresh the main page leaderboard
                this.updateMainLeaderboard();
                
                // Also refresh social system data if available
                if (window.socialSystem) {
                    window.socialSystem.loadLeaderboard();
                    window.socialSystem.loadFriends();
                }
                
                console.log('🔄 Social panel refreshed');
            });
            console.log('✅ Social panel refresh button event listener added');
        } else {
            console.error('❌ Social panel refresh button not found');
        }
    }

    // Initialize lobby system integration
    initializeLobbyIntegration() {
        // Wait for lobby system to be ready
        if (window.lobbySystem && window.lobbyWalletManager) {
            this.populateLobbyList();
            this.setupLobbyIntegrationEventListeners();
        } else {
            // Retry after a short delay
            setTimeout(() => this.initializeLobbyIntegration(), 100);
        }
    }

    // Populate lobby list UI based on selected region
    populateLobbyList() {
        console.log('🎯 GameManager: Populating lobby list for region:', this.selectedRegion);
        
        // Use UIManager's updateLobbyCards instead of replacing HTML
        if (this.uiManager) {
            this.uiManager.updateLobbyCards();
        }
        
        // Update JOIN GAME button state
        if (this.uiManager) {
            this.uiManager.updateJoinGameButtonState();
        }
    }

    // Setup lobby integration event listeners
    setupLobbyIntegrationEventListeners() {
        const lobbyList = document.getElementById('lobby-list');
        if (!lobbyList) return;

        lobbyList.addEventListener('click', (e) => {
            const lobbyCard = e.target.closest('.lobby-card');
            if (!lobbyCard || lobbyCard.classList.contains('full')) return;
            
            const lobbyId = parseInt(lobbyCard.dataset.lobbyId);
            this.joinLobbyIntegration(lobbyId);
        });
    }

    // Join a lobby through integration
    async joinLobbyIntegration(lobbyId) {
        try {
            const user = window.authSystem.getCurrentUser();
            if (!user) {
                if (this.uiManager) {
                    this.uiManager.showNotification('Please log in first!', 'warning');
                    this.uiManager.showLoginModal();
                }
                return;
            }

            const result = await window.lobbySystem.joinLobby(lobbyId, {
                id: user.id,
                username: user.username,
                balance: user.balance
            });

            if (result.success) {
                console.log(`✅ Successfully joined ${result.lobby.name}`);
                
                // Update UI
                this.updateLobbySelection(lobbyId);
                this.showPlayButton();
                
                // Refresh lobby list
                this.populateLobbyList();
                
                // Note: UI notification is handled by ui.js to avoid duplication
            } else {
                if (this.uiManager) {
                    this.uiManager.showNotification(`Failed to join lobby: ${result.error}`, 'error');
                }
            }
        } catch (error) {
            console.error('❌ Error joining lobby:', error);
            if (this.uiManager) {
                this.uiManager.showNotification('Failed to join lobby. Please try again.', 'error');
            }
        }
    }

    // Update lobby selection UI
    updateLobbySelection(selectedLobbyId) {
        const lobbyCards = document.querySelectorAll('.lobby-card');
        lobbyCards.forEach(card => {
            card.classList.remove('active');
            if (parseInt(card.dataset.lobbyId) === selectedLobbyId) {
                card.classList.add('active');
            }
        });
    }

    // Show play button after lobby selection
    showPlayButton() {
        const playButton = document.getElementById('play-button');
        if (playButton) {
            playButton.style.display = 'block';
        }
    }

    // Initialize lobby system with retry mechanism
    initializeLobbySystemWithRetry(retryCount = 0) {
        const maxRetries = 5;
        const retryDelay = 200;
        
        console.log(`🔄 Attempting to initialize lobby system (attempt ${retryCount + 1}/${maxRetries})`);
        
        const regionBtns = document.querySelectorAll('.region-btn');
        const lobbyHeaderBtn = document.getElementById('lobby-header-btn');
        const lobbyList = document.getElementById('lobby-list');
        
        if (regionBtns.length === 0 || !lobbyHeaderBtn || !lobbyList) {
            console.log('⚠️ Elements not found, retrying...', {
                regionBtns: regionBtns.length,
                lobbyHeaderBtn: !!lobbyHeaderBtn,
                lobbyList: !!lobbyList
            });
            
            if (retryCount < maxRetries) {
                setTimeout(() => {
                    this.initializeLobbySystemWithRetry(retryCount + 1);
                }, retryDelay);
                return;
            } else {
                console.error('❌ Failed to initialize lobby system after', maxRetries, 'attempts');
                return;
            }
        }
        
        console.log('✅ All elements found, initializing lobby system');
        this.initializeLobbySystem();
    }

    // Initialize lobby selection system
    initializeLobbySystem() {
        console.log('🚀 Initializing lobby system...');
        
        // Lobby dropdown toggle is handled by UIManager
        console.log('🔍 Lobby toggle will be handled by UIManager');
        
        // Region selection
        const regionBtns = document.querySelectorAll('.region-btn');
        console.log('🔍 Found region buttons:', regionBtns.length);
        console.log('🔍 Region buttons details:', Array.from(regionBtns).map(btn => ({
            text: btn.textContent,
            region: btn.dataset.region,
            classes: btn.className
        })));
        regionBtns.forEach(btn => {
            console.log('🔍 Setting up event listener for region button:', btn.dataset.region);
            btn.addEventListener('click', async (e) => {
                // Show visual feedback
                const feedback = document.createElement('div');
                feedback.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: #4CAF50;
                    color: white;
                    padding: 10px 20px;
                    border-radius: 5px;
                    z-index: 9999;
                    font-weight: bold;
                `;
                feedback.textContent = `Region switched to: ${btn.dataset.region}`;
                document.body.appendChild(feedback);
                setTimeout(() => feedback.remove(), 3000);
                
                console.log('🎯 Region button clicked:', btn.dataset.region);
                // Don't switch if already selected
                if (btn.classList.contains('active')) {
                    console.log('⚠️ Region already selected, skipping');
                    return;
                }
                
                console.log('✅ Switching to region:', btn.dataset.region);
                regionBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.selectedRegion = btn.dataset.region;
                
                // Leave current lobby when switching regions
                if (window.lobbySystem && window.lobbySystem.currentLobby) {
                    await window.lobbySystem.leaveLobby();
                }
                
                // Clear current lobby selection when switching regions
                this.selectedLobby = null;
                this.selectedLobbyId = null;
                
                // Reset header text
                this.updateLobbyHeaderText();
                
                // Repopulate lobby list for new region
                this.populateLobbyList();
                this.updateLobbyDisplay();
                this.updateGameStats();
            });
        });

        // Initial lobby list population
        this.populateLobbyList();
        
        // Update initial display
        this.updateLobbyDisplay();
    }

    // Update lobby header text
    updateLobbyHeaderText(lobbyName = null) {
        const headerText = document.getElementById('lobby-header-text');
        if (headerText) {
            headerText.textContent = lobbyName ? lobbyName : 'Select Lobby';
        }
    }

    // Close lobby dropdown
    closeLobbyDropdown() {
        const lobbyList = document.getElementById('lobby-list');
        const lobbyHeaderBtn = document.getElementById('lobby-header-btn');
        
        if (lobbyList && lobbyHeaderBtn) {
            lobbyList.style.display = 'none';
            lobbyHeaderBtn.classList.remove('expanded');
        }
    }

    // Update lobby display based on selected region
    updateLobbyDisplay() {
        const selectedRegionSpan = document.querySelector('.selected-region');
        if (selectedRegionSpan) {
            selectedRegionSpan.textContent = `${this.selectedRegion} Region`;
        }

        // Refresh lobby list with real data
        this.populateLobbyList();
    }



    // Update UI elements
    async updateUI() {
        if (this.uiManager) {
            this.uiManager.updateAuthUI();
            await this.uiManager.updateWalletUI();
        }
        this.updateJoinButton();
        this.updateGameStats();
        
        // Update lobby list if lobby system is available
        if (window.lobbySystem && window.lobbyWalletManager) {
            this.populateLobbyList();
        }
        
        // Start periodic updates for real-time data
        this.startPeriodicUpdates();
    }

    // Start periodic updates for real-time stats
    startPeriodicUpdates() {
        // Update leaderboard every 30 seconds
        if (!this.leaderboardUpdateInterval) {
            this.leaderboardUpdateInterval = setInterval(() => {
                this.updateMainLeaderboard();
            }, 30000);
        }
        
        // Update game stats every 10 seconds
        if (!this.gameStatsUpdateInterval) {
            this.gameStatsUpdateInterval = setInterval(() => {
                this.updateGameStats();
            }, 10000);
        }
        
        // Update lobby cards every 5 seconds for real-time player counts
        if (!this.lobbyUpdateInterval) {
            this.lobbyUpdateInterval = setInterval(() => {
                if (this.uiManager && window.lobbySystem) {
                    this.uiManager.updateLobbyCards();
                }
            }, 5000);
        }
    }

    // Stop periodic updates
    stopPeriodicUpdates() {
        if (this.leaderboardUpdateInterval) {
            clearInterval(this.leaderboardUpdateInterval);
            this.leaderboardUpdateInterval = null;
        }
        
        if (this.gameStatsUpdateInterval) {
            clearInterval(this.gameStatsUpdateInterval);
            this.gameStatsUpdateInterval = null;
        }
    }

    updateJoinButton() {
        const joinBtn = document.getElementById('join-game-btn');
        if (joinBtn) {
            joinBtn.innerHTML = `<span class="play-icon">▶</span> JOIN GAME`;
        }
    }

    updateGameStats() {
        // Update players online with real data - only count players actually in games, not just in lobbies
        const playersOnline = document.getElementById('players-online');
        if (playersOnline) {
            let totalPlayersInGame = 0;
            
            // Count players who are actually playing games (have active game sessions)
            if (window.game && window.game.gameRunning && window.game.multiplayer && window.game.multiplayer.isConnected) {
                // Current player is in game
                totalPlayersInGame += 1;
                
                // Add other players in the same game
                if (window.game.multiplayer.otherPlayers) {
                    totalPlayersInGame += window.game.multiplayer.otherPlayers.size || 0;
                }
            }
            
            playersOnline.textContent = totalPlayersInGame;
        }

        // Update total prize pools with real data from all lobby wallets
        const globalWinnings = document.getElementById('global-winnings');
        if (globalWinnings && window.lobbyWalletManager) {
            let totalPrizePools = 0;
            for (let lobbyId = 1; lobbyId <= 8; lobbyId++) {
                const walletInfo = window.lobbyWalletManager.getLobbyStats(lobbyId);
                if (walletInfo) {
                    totalPrizePools += walletInfo.gamePool;
                }
            }
            globalWinnings.textContent = `€${totalPrizePools.toFixed(0)}`;
        }

        // Update main page leaderboard with real data
        this.updateMainLeaderboard();
    }

    // Update the main page leaderboard with real data
    async updateMainLeaderboard() {
        try {
            const response = await fetch('php/social_api.php?action=get_leaderboard&filter=money&scope=global');
            const data = await response.json();

            if (data.success && data.leaderboard.length > 0) {
                const leaderboardList = document.querySelector('.leaderboard-list');
                if (leaderboardList) {
                    // Take only top 3 players for the main page display
                    const topPlayers = data.leaderboard.slice(0, 3);
                    
                    leaderboardList.innerHTML = topPlayers.map((player, index) => `
                        <div class="leaderboard-item">
                            <span class="rank">${index + 1}.</span>
                            <span class="player-name">${this.escapeHtml(player.username)}</span>
                            <span class="amount">€${parseFloat(player.balance).toFixed(2)}</span>
                        </div>
                    `).join('');
                }
            }
        } catch (error) {
            console.error('Error updating main leaderboard:', error);
        }
    }

    // Helper function to escape HTML
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async startGame() {
        console.log('🎮 GameManager.startGame() called');
        console.log('🔐 Auth system:', window.authSystem);
        console.log('🔐 Is logged in:', window.authSystem?.isLoggedIn);
        
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            console.log('❌ User not logged in');
            if (this.uiManager) {
                this.uiManager.showNotification('Please login to play', 'warning');
                this.uiManager.showLoginModal();
            }
            return;
        }

        const user = window.authSystem.getCurrentUser();
        console.log('👤 Current user:', user);
        
        // Check Solana wallet balance (primary balance for games)
        if (!window.walletSystem || !window.walletSystem.isInitialized) {
            console.log('❌ Wallet system not available');
            if (this.uiManager) {
                this.uiManager.showNotification('Wallet system not available. Please refresh the page.', 'error');
            }
            return;
        }
        
        try {
            const realBalance = await window.walletSystem.getUserSolBalance(user.username);
            const solPrice = await window.walletSystem.getRealSolPrice();
            const balanceInEur = realBalance * solPrice;
            
            console.log('💰 Solana wallet balance:', realBalance.toFixed(6), 'SOL', '=', balanceInEur.toFixed(2), 'EUR');
            
            if (balanceInEur < this.selectedBetAmount) {
                console.log('❌ Insufficient SOL balance');
                if (this.uiManager) {
                    const requiredAmount = this.selectedBetAmount + 0.10; // Add 0.10 fee
                    this.uiManager.showNotification(`You don't have enough funds. You should have €${requiredAmount.toFixed(2)} (€${this.selectedBetAmount.toFixed(2)} bet + €0.10 fee) and you only have €${balanceInEur.toFixed(2)}.`, 'error');
                    this.uiManager.showWalletModal();
                }
                return;
            }
        } catch (error) {
            console.warn('⚠️ Could not fetch Solana balance:', error);
            if (this.uiManager) {
                this.uiManager.showNotification('Error fetching wallet balance. Please try again.', 'error');
            }
            return;
        }
        
        console.log('🎯 Selected bet amount:', this.selectedBetAmount);

        console.log('✅ Starting game with:', {
            betAmount: this.selectedBetAmount,
            region: this.selectedRegion,
            lobby: this.selectedLobby,
            multiplayerLobbyId: this.selectedLobbyId
        });

        // Store multiplayer context
        this.multiplayerLobbyId = this.selectedLobbyId;

        // Don't automatically show lobby page - let user navigate manually
        console.log('✅ Game setup complete. User can manually navigate to lobby page if needed.');
    }

    // Show countdown before joining game
    // Actually start the game after countdown
    async actuallyStartGame() {
        console.log('Starting actual game...');
        
        // Hide lobby page and show game
        document.getElementById('lobbyPage').style.display = 'none';
        this.showGamePage();
        
        // Initialize the game if not already done
        if (!this.game) {
            console.log('🎮 Creating new AgarGame instance');
            this.game = new AgarGame();
            this.game.init('gameCanvas');
        }
        
        // Prepare game options with multiplayer context
        const gameOptions = {
            betAmount: this.selectedBetAmount,
            region: this.selectedRegion,
            lobby: this.selectedLobby,
            multiplayerLobbyId: this.multiplayerLobbyId,
            isMultiplayer: !!this.multiplayerLobbyId
        };
        
        console.log('🎮 Starting game with options:', gameOptions);
        
        // Start the game with multiplayer context
        await this.game.startGame(gameOptions.betAmount, gameOptions.region, gameOptions.lobby, gameOptions);
        
        if (this.uiManager) {
            const gameType = this.multiplayerLobbyId ? 'Multiplayer' : 'Single Player';
            this.uiManager.showNotification(`${gameType} game started! Good luck!`, 'success');
        }
    }

    // Show lobby page - DISABLED: User should stay on home page when selecting lobby
    // showLobbyPage() {
    //     console.log('🏛️ Showing lobby page');
    //     
    //     // Hide home page
    //     const homePage = document.getElementById('home-page');
    //     if (homePage) {
    //         homePage.style.display = 'none';
    //     }

    //     // Show lobby page
    //     const lobbyPage = document.getElementById('lobbyPage');
    //     if (lobbyPage) {
    //         lobbyPage.style.display = 'block';
    //     }

    //     // Update lobby information
    //     this.updateLobbyInfo();
    //     this.setupLobbyEventListeners();
    //     this.populateLobbyPlayers();
    //     
    //     if (this.uiManager) {
    //         this.uiManager.showNotification(`Joined ${this.selectedLobby} lobby in ${this.selectedRegion} region!`, 'success');
    //     }
    // }

    // Update lobby information display
    updateLobbyInfo() {
        // Update lobby title with real lobby name
        const lobbyTitle = document.getElementById('lobby-title');
        if (lobbyTitle) {
            const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
            if (currentLobby) {
                lobbyTitle.textContent = currentLobby.name;
            } else if (this.selectedLobbyId) {
                const lobbyData = window.lobbySystem.availableLobbies.get(this.selectedLobbyId);
                lobbyTitle.textContent = lobbyData ? lobbyData.name : `${this.selectedLobby} Lobby`;
            } else {
                lobbyTitle.textContent = `${this.selectedLobby} Lobby`;
            }
        }

        // Update region
        const lobbyRegion = document.getElementById('lobby-region');
        if (lobbyRegion) {
            const regionFlag = this.selectedRegion === 'US' ? '🇺🇸' : '🇪🇺';
            lobbyRegion.textContent = `${regionFlag} ${this.selectedRegion} Region`;
        }

        // Update bet amount
        const lobbyBet = document.getElementById('lobby-bet');
        if (lobbyBet) {
            lobbyBet.textContent = `€${this.selectedBetAmount.toFixed(2)} Bet`;
        }

        // Update player count with real data
        const playerCount = document.getElementById('lobby-player-count');
        if (playerCount && this.selectedLobbyId) {
            const lobbyData = window.lobbySystem.availableLobbies.get(this.selectedLobbyId);
            if (lobbyData) {
                playerCount.textContent = `${lobbyData.players.size}/${lobbyData.maxPlayers}`;
            }
        }

        // Update prize pool with real data from lobby wallet
        const prizePool = document.getElementById('lobby-prize-pool');
        if (prizePool && this.selectedLobbyId) {
            const walletInfo = window.lobbyWalletManager.getLobbyStats(this.selectedLobbyId);
            if (walletInfo) {
                prizePool.textContent = `€${walletInfo.gamePool.toFixed(0)}`;
            } else {
                prizePool.textContent = '€0';
            }
        }

        // Update total lobby worth (total bets placed)
        const lobbyWorth = document.getElementById('lobby-total-worth');
        if (lobbyWorth && this.selectedLobbyId) {
            const walletInfo = window.lobbyWalletManager.getLobbyStats(this.selectedLobbyId);
            if (walletInfo) {
                lobbyWorth.textContent = `€${walletInfo.totalBets.toFixed(0)}`;
            } else {
                lobbyWorth.textContent = '€0';
            }
        }
    }

    // Setup lobby event listeners
    setupLobbyEventListeners() {
        const readyBtn = document.getElementById('ready-btn');
        if (readyBtn) {
            console.log('🎯 Setting up Ready button event listener');
            
            // Remove any existing event listeners
            readyBtn.replaceWith(readyBtn.cloneNode(true));
            const newReadyBtn = document.getElementById('ready-btn');
            
            // Reset button to initial ready state
            newReadyBtn.disabled = false;
            newReadyBtn.classList.remove('ready-state');
            newReadyBtn.innerHTML = `
                <span class="ready-text">READY</span>
            `;
            
            newReadyBtn.addEventListener('click', (e) => {
                console.log('🎮 Ready button clicked!');
                e.preventDefault();
                e.stopPropagation();
                
                // Check if button is disabled
                if (newReadyBtn.disabled) {
                    console.log('⚠️ Ready button is disabled, ignoring click');
                    return;
                }
                
                // Check if user is logged in
                if (!window.authSystem || !window.authSystem.isLoggedIn) {
                    if (this.uiManager) {
                        this.uiManager.showNotification('Please login first to ready up!', 'warning');
                        this.uiManager.showLoginModal();
                    }
                    return;
                }
                
                // Check if user has selected a bet amount
                if (!this.selectedBetAmount || this.selectedBetAmount <= 0) {
                    if (this.uiManager) {
                        this.uiManager.showNotification('Please select a bet amount first!', 'warning');
                    }
                    return;
                }
                
                this.handleReadyClick();
            });
            
            // Also add some debugging info
            console.log('✅ Ready button event listener added successfully');
        } else {
            console.error('❌ Ready button not found!');
        }
        
        // Setup leave lobby button
        const leaveLobbyBtn = document.getElementById('leave-lobby-btn');
        if (leaveLobbyBtn) {
            console.log('🚪 Setting up Leave Lobby button event listener');
            
            // Remove any existing event listeners
            leaveLobbyBtn.replaceWith(leaveLobbyBtn.cloneNode(true));
            const newLeaveLobbyBtn = document.getElementById('leave-lobby-btn');
            
            newLeaveLobbyBtn.addEventListener('click', (e) => {
                console.log('🚪 Leave lobby button clicked!');
                e.preventDefault();
                e.stopPropagation();
                
                this.leaveLobby();
            });
            
            console.log('✅ Leave lobby button event listener added successfully');
        } else {
            console.error('❌ Leave lobby button not found!');
        }
    }

    // Populate lobby with real players from lobby system
    populateLobbyPlayers() {
        const playersGrid = document.getElementById('lobby-players-grid');
        if (!playersGrid) return;

        playersGrid.innerHTML = '';

        // Get current lobby data
        const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
        if (!currentLobby) {
            // Show message if no lobby is joined
            playersGrid.innerHTML = '<div class="no-players-message">Join a lobby to see players</div>';
            return;
        }

        // Use the players array from getCurrentLobby which has the correct format
        const players = currentLobby.players || [];
        if (players.length === 0) {
            playersGrid.innerHTML = '<div class="no-players-message">No players in lobby yet</div>';
            return;
        }

        // Display real players from the lobby
        players.forEach((player) => {
            const playerCard = document.createElement('div');
            playerCard.className = 'player-card';
            
            const isReady = player.ready || false;
            const playerLevel = player.level || Math.floor(Math.random() * 50) + 1;
            const playerName = player.username || player.name || 'Anonymous';

            playerCard.innerHTML = `
                <div class="player-avatar">
                    <div class="player-blob" style="background: hsl(${Math.random() * 360}, 70%, 60%)"></div>
                </div>
                <div class="player-info">
                    <div class="player-name">${playerName}</div>
                    <div class="player-level">Level ${playerLevel}</div>
                </div>
                <div class="player-status ${isReady ? 'ready' : 'waiting'}">
                    ${isReady ? '✅ Ready' : '⏳ Waiting'}
                </div>
            `;

            playersGrid.appendChild(playerCard);
        });
    }

    // Handle ready button click
    async handleReadyClick() {
        console.log('🚀 handleReadyClick called');
        
        // Check if user is actually in a lobby
        const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
        if (!currentLobby) {
            console.error('❌ No lobby joined');
            if (this.uiManager) {
                this.uiManager.showNotification('Please select and join a lobby first!', 'error');
            }
            return;
        }
        
        const user = window.authSystem.getCurrentUser();
        const totalCost = this.selectedBetAmount; // Already includes the €0.10 fee
        
        // Check Solana wallet balance instead of auth system balance
        if (!window.walletSystem || !window.walletSystem.isInitialized) {
            if (this.uiManager) {
                this.uiManager.showNotification('Wallet system not available. Please refresh the page.', 'error');
            }
            return;
        }
        
        try {
            const userSOLBalance = await window.walletSystem.getUserSolBalance(user.username);
            const solPrice = await window.walletSystem.getRealSolPrice();
            
            // Convert EUR amount to SOL for simplified system
            const requiredSOL = this.selectedBetAmount / solPrice; // Already includes €0.10 fee
            
            console.log('💰 Solana wallet balance for ready check:', userSOLBalance.toFixed(6), 'SOL');
            console.log('💰 Required:', requiredSOL.toFixed(6), 'SOL (€' + totalCost.toFixed(2) + ' total)');
            
            if (userSOLBalance < requiredSOL) {
                console.log('❌ Insufficient Solana wallet balance for ready');
                if (this.uiManager) {
                    const solPrice = await window.walletSystem.getRealSolPrice();
                    const currentBalanceEUR = userSOLBalance * solPrice;
                    const requiredAmountEUR = this.selectedBetAmount + 0.10; // Add 0.10 fee
                    this.uiManager.showNotification(`You don't have enough funds. You should have €${requiredAmountEUR.toFixed(2)} (€${this.selectedBetAmount.toFixed(2)} bet + €0.10 fee) and you only have €${currentBalanceEUR.toFixed(2)}.`, 'error');
                    this.uiManager.showWalletModal();
                }
                return;
            }
        } catch (error) {
            console.error('❌ Error checking Solana wallet balance:', error);
            if (this.uiManager) {
                this.uiManager.showNotification('Error checking wallet balance. Please try again.', 'error');
            }
            return;
        }
        
        console.log(`✅ Balance check passed. Payment will be processed when joining game.`);
        
        // Show success notification
        if (this.uiManager) {
            this.uiManager.showNotification(`Ready! Connecting to game server...`, 'success');
        }
        
        // Connect to game server
        try {
            await this.connectToGameServer(currentLobby);
        } catch (error) {
            console.error('❌ Failed to connect to game server:', error);
            // No refund needed since payment hasn't been processed yet
            if (this.uiManager) {
                this.uiManager.showNotification('Failed to connect to game server. Please try again.', 'error');
            }
            return;
        }
        
        console.log('✅ User is ready, starting countdown');
        this.startReadyCountdown();
    }

    // Connect to game server
    async connectToGameServer(lobby) {
        console.log('🎮 Connecting to game server for lobby:', lobby.id);
        
        // Check if lobby system is available
        if (!window.lobbySystem) {
            throw new Error('Lobby system not available');
        }
        
        // Get current user
        const user = window.authSystem.getCurrentUser();
        if (!user) {
            throw new Error('User not logged in');
        }
        
        // Prepare player data for game server
        const playerData = {
            id: user.id || user.username,
            name: user.username,
            betAmount: this.selectedBetAmount,
            lobbyId: lobby.id,
            region: this.selectedRegion || 'US'
        };
        
        // Send join game request to lobby system
        try {
            const result = await window.lobbySystem.joinGame(playerData);
            console.log('🎮 Successfully connected to game server:', result);
            return result;
        } catch (error) {
            console.error('❌ Failed to join game:', error);
            throw error;
        }
    }

    // Leave lobby and return to home
    leaveLobby() {
        // Refund the bet amount
        if (window.authSystem && window.authSystem.isLoggedIn) {
            const user = window.authSystem.getCurrentUser();
            const refundedBalance = user.balance + this.selectedBetAmount;
            window.authSystem.updateBalance(refundedBalance);
        }

        this.showHomePage();
        if (this.uiManager) {
            this.uiManager.showNotification('Left the lobby', 'info');
        }
    }

    startReadyCountdown() {
        const readyBtn = document.getElementById('ready-btn');
        
        // Show instant ready state
        readyBtn.classList.add('ready-state');
        readyBtn.disabled = true;
        readyBtn.innerHTML = `
            <span class="ready-text">STARTING...</span>
        `;
        
        // Start game immediately (no countdown delay)
        this.startActualGame();
    }

    // Start the actual game from lobby
    async startActualGame() {
        // Initialize the game if not already done
        if (!this.game) {
            console.log('🎮 Creating new AgarGame instance');
            this.game = new AgarGame();
            this.game.init('gameCanvas');
        }
        
        // Get current lobby information from lobby system
        const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
        if (!currentLobby) {
            console.error('❌ No current lobby found');
            if (this.uiManager) {
                this.uiManager.showNotification('No lobby selected. Please join a lobby first.', 'error');
            }
            return;
        }
        
        console.log('🎮 Starting game with lobby:', currentLobby);
        
        // Start the game with current lobby info
        try {
            // Show loading message while processing transaction
            if (this.uiManager) {
                this.uiManager.showNotification('Processing transaction...', 'info');
            }
            
            const gameStarted = await this.game.startGame(this.selectedBetAmount, currentLobby.region, currentLobby.type);
            if (gameStarted) {
                console.log('✅ Game started successfully from lobby');
                this.showGamePage();
                
                // Resize canvas after showing the game page
                setTimeout(() => {
                    if (this.game && this.game.resizeCanvas) {
                        console.log('🔄 Resizing canvas after showing game page');
                        this.game.resizeCanvas();
                    }
                }, 150);
                
                if (this.uiManager) {
                    this.uiManager.showNotification(`Game started! Good luck!`, 'success');
                }
            } else {
                console.error('❌ Failed to start game from lobby');
                if (this.uiManager) {
                    this.uiManager.showNotification('Failed to start game. Please try again.', 'error');
                }
                // Reset UI state on failure
                this.showHomePage();
                if (this.uiManager) {
                    this.uiManager.setJoinGameButtonLoading(false);
                    this.uiManager.isJoinGameTransactionInProgress = false;
                }
            }
        } catch (error) {
            console.error('❌ Error starting game from lobby:', error);
            if (this.uiManager) {
                this.uiManager.showNotification('Failed to start game: ' + error.message, 'error');
            }
            // Reset UI state on error
            this.showHomePage();
            if (this.uiManager) {
                this.uiManager.setJoinGameButtonLoading(false);
                this.uiManager.isJoinGameTransactionInProgress = false;
            }
        }
    }

    async startActualGameWithoutPayment() {
        // Initialize the game if not already done
        if (!this.game) {
            console.log('🎮 Creating new AgarGame instance');
            this.game = new AgarGame();
            this.game.init('gameCanvas');
        }
        
        // Get current lobby information from lobby system
        const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
        if (!currentLobby) {
            console.error('❌ No current lobby found');
            if (this.uiManager) {
                this.uiManager.showNotification('No lobby selected. Please join a lobby first.', 'error');
            }
            return;
        }
        
        console.log('🎮 Starting game with lobby (payment already processed):', currentLobby);
        
        // Start the game without payment processing since it's already done
        try {
            const gameStarted = await this.game.startGameWithoutPayment(this.selectedBetAmount, currentLobby.region, currentLobby.type);
            if (gameStarted) {
                console.log('✅ Game started successfully from lobby (no payment)');
                
                // Resize canvas after showing the game page
                setTimeout(() => {
                    if (this.game && this.game.resizeCanvas) {
                        console.log('🔄 Resizing canvas after showing game page');
                        this.game.resizeCanvas();
                    }
                }, 150);
                
                if (this.uiManager) {
                    this.uiManager.showNotification(`Game started! Good luck!`, 'success');
                }
            } else {
                console.error('❌ Failed to start game from lobby');
                if (this.uiManager) {
                    this.uiManager.showNotification('Failed to start game. Please try again.', 'error');
                }
                // Reset UI state on failure
                this.showHomePage();
                if (this.uiManager) {
                    this.uiManager.setJoinGameButtonLoading(false);
                    this.uiManager.isJoinGameTransactionInProgress = false;
                }
            }
        } catch (error) {
            console.error('❌ Error starting game from lobby:', error);
            if (this.uiManager) {
                this.uiManager.showNotification('Failed to start game: ' + error.message, 'error');
            }
            // Reset UI state on error
            this.showHomePage();
            if (this.uiManager) {
                this.uiManager.setJoinGameButtonLoading(false);
                this.uiManager.isJoinGameTransactionInProgress = false;
            }
        }
    }

    leaveGame() {
        // Players cannot manually leave games - only cash out or get eliminated
        console.log('❌ Manual game leaving is disabled - players must cash out');
        if (this.uiManager) {
            this.uiManager.showNotification('You cannot leave the game manually. Cash out with Q key or play until eliminated.', 'warning');
        }
        return false;
    }

    // Start game from lobby (called by join game button)
    async startGameFromLobby() {
        console.log('🎮 Starting game from lobby...');
        
        // Check if user is logged in
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            if (this.uiManager) {
                this.uiManager.showNotification('Please login first to join a game!', 'warning');
                this.uiManager.showLoginModal();
            }
            return;
        }
        
        // Check if user is in a lobby
        const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
        if (!currentLobby) {
            if (this.uiManager) {
                this.uiManager.showNotification('Please join a lobby first!', 'warning');
            }
            return;
        }
        
        // Check balance and fees
        const user = window.authSystem.getCurrentUser();
        const betAmount = this.selectedBetAmount;
        
        // Ensure bet amount is set
        if (!betAmount || betAmount <= 0) {
            if (this.uiManager) {
                this.uiManager.showNotification('Please select a bet amount first!', 'warning');
            }
            return;
        }
        
        if (user.balance < betAmount) {
            if (this.uiManager) {
                this.uiManager.showNotification(`Insufficient balance. You need €${betAmount.toFixed(2)} to play.`, 'error');
            }
            return;
        }
        
        try {
            // Stay on home page instead of showing lobby page
            if (this.uiManager) {
                this.uiManager.showNotification(`Joined ${currentLobby.name || 'lobby'}! Click READY when you're ready to play.`, 'success');
            }
        } catch (error) {
            console.error('❌ Error starting game from lobby:', error);
            if (this.uiManager) {
                this.uiManager.showNotification('Failed to join game. Please try again.', 'error');
            }
        }
    }

    // Join game directly with payment and immediate transition (no lobby page)
    async joinGameDirectly() {
        console.log('🎮 Joining game directly...');
        
        // Note: Transaction progress flag is managed by UI layer, not here
        
        // Reset any previous game state to ensure clean start
        if (this.game) {
            console.log('🔄 Cleaning up previous game state...');
            this.game = null;
        }
        
        // Clear any existing game UI state
        const gameContainer = document.getElementById('game-container');
        if (gameContainer) {
            gameContainer.innerHTML = '';
        }
        
        // Check if user is logged in
        if (!window.authSystem || !window.authSystem.isLoggedIn) {
            if (this.uiManager) {
                this.uiManager.showNotification('Please login first to join a game!', 'warning');
                this.uiManager.showLoginModal();
            }
            return;
        }
        
        // Check if user is in a lobby
        const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
        if (!currentLobby) {
            if (this.uiManager) {
                this.uiManager.showNotification('Please join a lobby first!', 'warning');
            }
            return;
        }
        
        const user = window.authSystem.getCurrentUser();
        const betAmount = this.selectedBetAmount; // This is just the bet amount (without fee)
        const FEE_EUR = 0.10; // €0.10 fee will be added by addPlayerBet
        
        // Ensure bet amount is set
        if (!betAmount || betAmount <= 0) {
            if (this.uiManager) {
                this.uiManager.showNotification('Please select a bet amount first!', 'warning');
            }
            return;
        }
        
        try {
            // Check Solana wallet balance using simplified SOL system
            if (!window.walletSystem || !window.walletSystem.isInitialized) {
                if (this.uiManager) {
                    this.uiManager.showNotification('Wallet system not available. Please refresh the page.', 'error');
                }
                return;
            }
            
            const userSOLBalance = await window.walletSystem.getUserSolBalance(user.username);
            
            // Convert EUR bet amount + fee to SOL for balance check
            const solPrice = await window.walletSystem.getRealSolPrice();
            const totalRequiredEUR = betAmount + FEE_EUR; // bet + €0.10 fee
            const requiredSOL = totalRequiredEUR / solPrice;
            
            console.log('💰 DEBUG - SOL balance check:');
            console.log('   User SOL balance:', userSOLBalance.toFixed(6), 'SOL');
            console.log('   Bet amount:', betAmount.toFixed(2), 'EUR');
            console.log('   Fee amount:', FEE_EUR.toFixed(2), 'EUR');
            console.log('   Total required:', totalRequiredEUR.toFixed(2), 'EUR =', requiredSOL.toFixed(6), 'SOL');
            console.log('   Sufficient funds?', userSOLBalance >= requiredSOL);
            
            if (userSOLBalance < requiredSOL) {
                if (this.uiManager) {
                    const currentBalanceEUR = userSOLBalance * solPrice;
                    this.uiManager.showNotification(`You don't have enough funds. You need €${totalRequiredEUR.toFixed(2)} (€${betAmount.toFixed(2)} bet + €${FEE_EUR.toFixed(2)} fee) but you only have €${currentBalanceEUR.toFixed(2)}.`, 'error');
                    this.uiManager.showWalletModal();
                }
                return;
            }
            
            // Transfer bet amount + fee from personal wallet to lobby wallet
            console.log('💰 Transferring bet + fee to lobby wallet...');
            
            if (!window.lobbyWalletManager) {
                if (this.uiManager) {
                    this.uiManager.showNotification('Lobby wallet system not available. Please refresh the page.', 'error');
                }
                return;
            }
            
            // Show transaction loading message
            if (this.uiManager) {
                this.uiManager.showNotification('Creating transaction, please wait...', 'info');
                this.uiManager.setJoinGameButtonLoading(true);
                this.uiManager.isJoinGameTransactionInProgress = true;
            }
            
            // Process payment transaction
            try {
                console.log('🔄 DEBUG: About to call addPlayerBet with:', {
                    lobbyId: currentLobby.id,
                    username: user.username,
                    betAmount: betAmount
                });
                
                const paymentResult = await window.lobbyWalletManager.addPlayerBet(
                    currentLobby.id,
                    user.username,
                    betAmount
                );
                
                console.log('🔄 DEBUG: addPlayerBet result:', paymentResult);
                
                if (!paymentResult || !paymentResult.success) {
                    throw new Error(`Payment failed: ${paymentResult?.error || 'Unknown error'}`);
                }
                
                console.log('✅ Payment transaction successful:', paymentResult.transferSignature);
                
                if (this.uiManager) {
                    this.uiManager.showNotification('Transaction confirmed! Joining game...', 'success');
                }
            } catch (paymentError) {
                console.error('❌ Payment transaction failed:', paymentError);
                console.error('❌ Full error details:', {
                    message: paymentError.message,
                    stack: paymentError.stack,
                    name: paymentError.name
                });
                if (this.uiManager) {
                    this.uiManager.showNotification(`Transaction failed: ${paymentError.message}`, 'error');
                    this.uiManager.setJoinGameButtonLoading(false);
                    this.uiManager.isJoinGameTransactionInProgress = false;
                }
                return;
            }
            
            if (this.uiManager) {
                this.uiManager.showNotification(`Starting game with €${betAmount.toFixed(2)} bet...`, 'success');
            }
            
            // Connect to game server
            const gameConnected = await this.connectToGameServer(currentLobby);
            
            if (!gameConnected) {
                if (this.uiManager) {
                    this.uiManager.showNotification('Failed to connect to game server. Please try again.', 'error');
                }
                return;
            }
            
            // Directly show game page (skip lobby page)
            this.showGamePage();
            
            // Start the actual game immediately after transaction completion
            await this.startActualGameWithoutPayment();
            
            // Reset transaction state after successful game start
            if (this.uiManager) {
                this.uiManager.setJoinGameButtonLoading(false);
                this.uiManager.isJoinGameTransactionInProgress = false;
            }
            
        } catch (error) {
            console.error('❌ Error joining game directly:', error);
            // Re-throw error so UI can handle button state reset
            throw error;
        }
    }

    // End game legitimately (only through cashout or elimination)
    endGameLegitimately(reason = 'cashout') {
        console.log(`🏁 Game ending legitimately: ${reason}`);
        if (this.game) {
            this.game.endGame();
        }
        this.showHomePage();
        if (this.uiManager) {
            const message = reason === 'cashout' ? 'Successfully cashed out!' : 'Game over - all balls lost!';
            this.uiManager.showNotification(message, reason === 'cashout' ? 'success' : 'info');
        }
    }

    showHomePage() {
        console.log('🎮 GameManager.js showHomePage() called');
        console.log('🎮 DEBUG: Home page visibility before GameManager showHomePage:', document.getElementById('home-page')?.style.display);
        
        // Hide game container
        const gameContainer = document.querySelector('.game-container');
        if (gameContainer) {
            gameContainer.style.display = 'none';
        }

        // Hide lobby page
        const lobbyPage = document.getElementById('lobbyPage');
        if (lobbyPage) {
            lobbyPage.style.display = 'none';
        }

        // Show home page
        const homePage = document.getElementById('home-page');
        if (homePage) {
            homePage.style.display = 'block';
            console.log('🎮 DEBUG: GameManager set home page display to block');
        } else {
            console.error('🎮 DEBUG: GameManager - Home page element not found!');
        }
        
        // Remove game-active class to show header again
        document.body.classList.remove('game-active');
        
        console.log('🎮 GameManager.js showHomePage() completed');
        console.log('🎮 DEBUG: Home page visibility after GameManager showHomePage:', document.getElementById('home-page')?.style.display);
    }

    showGamePage() {
        console.log('🎮 GameManager.js showGamePage() called - HIDING HOME PAGE!');
        console.log('🎮 DEBUG: Stack trace:', new Error().stack);
        
        // Hide home page
        const homePage = document.getElementById('home-page');
        if (homePage) {
            console.log('✅ GameManager hiding home page - setting display to none');
            homePage.style.display = 'none';
        } else {
            console.warn('⚠️ Home page element not found');
        }

        // Hide lobby page
        const lobbyPage = document.getElementById('lobbyPage');
        if (lobbyPage) {
            console.log('✅ Hiding lobby page');
            lobbyPage.style.display = 'none';
        }

        // Show game container
        const gameContainer = document.querySelector('.game-container');
        if (gameContainer) {
            console.log('✅ Showing game container');
            gameContainer.style.display = 'block';
            
            // Add game-active class to body to hide header
            document.body.classList.add('game-active');
            
            // Check canvas after showing container
            const canvas = document.getElementById('gameCanvas');
            if (canvas) {
                console.log('🎨 Canvas dimensions after showing container:', canvas.width, 'x', canvas.height);
            } else {
                console.warn('⚠️ Canvas not found');
            }
        } else {
            console.warn('⚠️ Game container not found');
        }
    }

    // Handle game join confirmation from multiplayer server
    handleGameJoinConfirmed(message) {
        console.log('🎮 Game join confirmed, transitioning to game page');
        
        // Show the game page
        this.showGamePage();
        
        // Resize canvas to ensure proper display
        if (this.game) {
            this.game.resizeCanvas();
        }
        
        console.log('✅ Successfully transitioned to game page');
    }

    // Handle game end with winnings
    handleGameEnd(winnings = 0) {
        if (winnings > 0 && window.authSystem && window.authSystem.isLoggedIn) {
            const user = window.authSystem.getCurrentUser();
            const newBalance = user.balance + winnings;
            window.authSystem.updateBalance(newBalance);
            
            if (this.uiManager) {
                this.uiManager.showNotification(`You won €${winnings.toFixed(2)}!`, 'success');
            }
        }
        
        this.showHomePage();
        setTimeout(async () => {
            await this.updateUI();
        }, 0);
    }

    // Add method to update wallet display
    async updateWalletDisplay() {
        if (this.uiManager) {
            await this.uiManager.updateWalletUI();
        }
    }

    // Update player list for multiplayer
    updatePlayerList(lobbyId, players) {
        console.log(`🔄 Updating player list for lobby ${lobbyId}:`, players);
        
        // Update the lobby system's player data
        if (window.lobbySystem && window.lobbySystem.availableLobbies.has(lobbyId)) {
            const lobby = window.lobbySystem.availableLobbies.get(lobbyId);
            
            // Clear existing players
            lobby.players.clear();
            
            // Add updated players
            players.forEach(player => {
                lobby.players.set(player.id, {
                    id: player.id,
                    username: player.name,
                    name: player.name,
                    ready: player.ready || false,
                    joinedAt: Date.now()
                });
            });
            
            console.log(`✅ Updated lobby ${lobbyId} with ${players.length} players`);
            
            // Refresh the UI if this is the current lobby
            if (window.lobbySystem.currentLobby === lobbyId) {
                this.populateLobbyPlayers();
                
                // Also update lobby stats
                this.updateLobbyInfo();
            }
        }
        
        // Update lobby card player count
        const lobbyCard = document.querySelector(`[data-lobby-id="${lobbyId}"]`);
        if (lobbyCard) {
            const playerCountElement = lobbyCard.querySelector('.lobby-players');
            if (playerCountElement) {
                const maxPlayers = window.lobbySystem?.availableLobbies.get(lobbyId)?.maxPlayers || 50;
                playerCountElement.textContent = `${players.length}/${maxPlayers} players`;
            }
        }
        
        // Refresh lobby list to show updated player counts
        this.populateLobbyList();
    }

    // Handle real-time player updates
    handlePlayerUpdate(data) {
        console.log('🔄 Player update received:', data);
        
        // Update game state if we're in the same lobby
        if (this.selectedLobbyId === data.lobbyId && this.game) {
            // Pass update to game for real-time multiplayer
            if (this.game.multiplayer && this.game.multiplayer.handlePlayerUpdate) {
                this.game.multiplayer.handlePlayerUpdate(data);
            }
        }
    }

    // Show error message to user
    showError(message) {
        console.error('❌ Error:', message);
        
        if (this.uiManager && this.uiManager.showNotification) {
            this.uiManager.showNotification(message, 'error');
        } else {
            // Fallback to alert if UI manager is not available
            alert('Error: ' + message);
        }
    }

    // Update lobby display with latest data
    updateLobbyDisplay() {
        console.log('🔄 Updating lobby display');
        
        // Refresh lobby list
        this.populateLobbyList();
        
        // Update current lobby info if we're in one
        if (this.selectedLobbyId && window.lobbyWalletManager) {
            const lobbyWallet = window.lobbyWalletManager.getLobbyWallet(this.selectedLobbyId);
            if (lobbyWallet) {
                // Update lobby stats display
                const lobbyStatsElement = document.getElementById('lobby-stats');
                if (lobbyStatsElement) {
                    lobbyStatsElement.innerHTML = `
                        <div class="stat-item">
                            <span class="stat-label">Game Pool:</span>
                            <span class="stat-value">€${lobbyWallet.gamePool?.toFixed(2) || '0.00'}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Bets:</span>
                            <span class="stat-value">€${lobbyWallet.totalBets?.toFixed(2) || '0.00'}</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Active Players:</span>
                            <span class="stat-value">${lobbyWallet.activePlayers || 0}</span>
                        </div>
                    `;
                }
            }
        }
        
        // Update lobby player list if we're in lobby page
        const lobbyPage = document.getElementById('lobbyPage');
        if (lobbyPage && lobbyPage.style.display !== 'none') {
            this.populateLobbyPlayers();
            this.updateLobbyInfo();
        }
    }

    // Get connection status for debugging
    getConnectionStatus() {
        if (window.lobbyWalletManager) {
            return window.lobbyWalletManager.getConnectionStatus();
        }
        return { isConnected: false, mode: 'unknown' };
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', async () => {
    // Initialize systems
    window.authSystem = new AuthSystem();
    
    // Initialize wallet system and wait for it to be ready
    window.walletSystem = new WalletSystem();
    
    // Wait for wallet system to be fully initialized
    console.log('⏳ Waiting for wallet system to initialize...');
    while (!window.walletSystem.isInitialized) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    console.log('✅ Wallet system fully initialized');
    
    window.gameManager = new GameManager();
    
    // Update stats periodically
    setInterval(() => {
        if (window.gameManager) {
            window.gameManager.updateGameStats();
        }
    }, 5000);
});

// Export for global access
window.GameManager = GameManager;
// Multiplayer System for Agar.io Game
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
    throw new Error('Direct file access denied');
}

// Multiplayer system for handling WebSocket connections and game state synchronization
class MultiplayerSystem {
    constructor(game) {
        this.game = game;
        this.socket = null;
        this.isConnected = false;
        this.playerId = null; // Will be set from game.player.id
        this.otherPlayers = new Map();
        this.currentLobbyId = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 3;
        this.connectionTimeout = null;
    }

    // Generate lobby ID based on region and lobby type
    getLobbyId(region, lobbyType) {
        console.log(`🔍 getLobbyId DEBUG: Input - region: ${region}, lobbyType: ${lobbyType}`);
        
        // Get lobby ID from lobby system if available
        if (window.lobbySystem) {
            const currentLobby = window.lobbySystem.getCurrentLobby();
            if (currentLobby && currentLobby.id) {
                console.log(`🔍 getLobbyId DEBUG: Using current lobby from lobbySystem: ${currentLobby.id}`);
                return currentLobby.id;
            }
        }
        
        // Fallback to hardcoded mapping if lobby system not available
        const lobbyMap = {
            'US': {
                'TRYHARD': 1,
                'CRAZY': 2,
                'OPEN': [3, 4] // Multiple OPEN lobbies for load balancing
            },
            'EU': {
                'TRYHARD': 5,
                'CRAZY': 6,
                'OPEN': [7, 8] // Multiple OPEN lobbies for load balancing
            }
        };
        
        const lobbyIds = lobbyMap[region]?.[lobbyType];
        console.log(`🔍 getLobbyId DEBUG: Found lobbyIds: ${lobbyIds}`);
        
        if (Array.isArray(lobbyIds)) {
            // Randomly select from available OPEN lobbies for load balancing
            const selectedId = lobbyIds[Math.floor(Math.random() * lobbyIds.length)];
            console.log(`🔍 getLobbyId DEBUG: Selected from array: ${selectedId}`);
            return selectedId;
        }
        
        const result = lobbyIds || 1;
        console.log(`🔍 getLobbyId DEBUG: Final result: ${result}`);
        return result;
    }

    // Connect to game multiplayer server
    async connect(region, lobby, betAmount) {
        try {
            console.log(`🔍 CONNECT DEBUG: Input params - region: ${region}, lobby: ${lobby}`);
            
            // Use player ID from game for consistency
            this.playerId = this.game.player.id;
            
            // Get current lobby ID from lobby system
            const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
            console.log(`🔍 CONNECT DEBUG: currentLobby from lobbySystem:`, currentLobby);
            
            // Use lobby ID from lobby system if available, otherwise fallback to generated ID
            let lobbyId;
            if (currentLobby && currentLobby.id) {
                lobbyId = currentLobby.id;
                console.log(`🔍 CONNECT DEBUG: Using lobby ID from lobby system: ${lobbyId}`);
                
                // Store lobby system reference for coordination
                this.region = currentLobby.region || region || 'US';
                this.lobbyType = currentLobby.type || lobby || 'OPEN';
            } else {
                // Fallback to generated lobby ID for backwards compatibility
                lobbyId = this.getLobbyId(region || 'US', lobby || 'OPEN');
                console.log(`🔍 CONNECT DEBUG: Using generated lobbyId: ${lobbyId} for region: ${region}, lobby: ${lobby}`);
                
                this.region = region || 'US';
                this.lobbyType = lobby || 'OPEN';
            }
            
            // Ensure lobbyId is never undefined
            if (!lobbyId) {
                lobbyId = 1; // Default fallback
                console.warn('⚠️ No valid lobby ID found, using default lobby 1');
            }
            
            console.log(`🎯 Using lobby ID: ${lobbyId} (region: ${this.region}, type: ${this.lobbyType})`);
            
            // Connect to the game server (not lobby server) for actual gameplay
            // Always use NGINX proxy for game server connections
            const gameServerUrl = `wss://${location.host}/ws-game`;
            console.log('🔒 Using NGINX proxy for game server connection');
            
            console.log(`[UPDATED] Connecting to Game Server at ${gameServerUrl} for Lobby ${lobbyId}`);
            
            // Create WebSocket with fallback logic
            await this.createWebSocketWithFallback(gameServerUrl, lobbyId, betAmount, this.region, this.lobbyType);
        } catch (error) {
            console.error('Failed to connect to multiplayer server:', error);
            throw error;
        }
    }

    async createWebSocketWithFallback(gameServerUrl, lobbyId, betAmount, region, lobby) {
        return new Promise((resolve, reject) => {
            this.socket = new WebSocket(gameServerUrl);
            this.currentLobbyId = lobbyId;
            
            this.connectionTimeout = setTimeout(() => {
                console.log('⏰ WebSocket connection timeout, trying fallback...');
                this.socket.close();
                this.tryFallbackConnection(gameServerUrl, lobbyId, betAmount, region, lobby, resolve, reject);
            }, 5000);
            
            this.socket.onopen = () => {
                clearTimeout(this.connectionTimeout);
                console.log(`✅ Connected to Lobby ${lobbyId} server`);
                this.isConnected = true;
                this.reconnectAttempts = 0;
                
                // Get current user information
                const user = window.authSystem ? window.authSystem.getCurrentUser() : null;
                const currentLobby = window.lobbySystem ? window.lobbySystem.getCurrentLobby() : null;
                
                // Send join game request with player data
                const joinMessage = {
                    type: 'join_game',
                    lobbyId: lobbyId,
                    player: {
                        id: this.playerId,
                        name: user ? user.username : 'Anonymous',
                        color: currentLobby && currentLobby.playerColor ? currentLobby.playerColor : this.game.player.color,
                        betAmount: betAmount
                    }
                };
                
                console.log(`🔍 CLIENT DEBUG: Sending join_game with lobbyId: ${lobbyId} (type: ${typeof lobbyId})`);
                console.log(`🔍 CLIENT DEBUG: Full message:`, JSON.stringify(joinMessage, null, 2));
                
                this.socket.send(JSON.stringify(joinMessage));
                resolve();
            };
            
            this.socket.onerror = (error) => {
                clearTimeout(this.connectionTimeout);
                console.log('❌ WebSocket connection failed, trying fallback...');
                this.tryFallbackConnection(gameServerUrl, lobbyId, betAmount, region, lobby, resolve, reject);
            };
            
            this.socket.onclose = () => {
                clearTimeout(this.connectionTimeout);
                console.log('🔒 WebSocket connection closed');
                this.isConnected = false;
            };
            
            this.socket.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data);
                    this.handleMessage(message);
                } catch (error) {
                    console.error('Error parsing message:', error);
                }
            };
        });
    }
    
    tryFallbackConnection(originalUrl, lobbyId, betAmount, region, lobby, resolve, reject) {
        // For HTTPS pages, we cannot fallback to WS - reject the connection
        if (window.location.protocol === 'https:' && originalUrl.startsWith('wss://')) {
            console.error('❌ WSS connection failed and cannot fallback to WS on HTTPS page');
            reject(new Error('WSS connection failed - server may not have valid SSL certificate'));
            return;
        }
        
        // If original was WSS, try WS (only for HTTP pages)
        if (originalUrl.startsWith('wss://')) {
            const fallbackUrl = originalUrl.replace('wss://', 'ws://');
            console.log(`🔄 Falling back to: ${fallbackUrl}`);
            
            this.socket = new WebSocket(fallbackUrl);
            
            this.socket.onopen = () => {
                console.log(`✅ Fallback connection successful to Lobby ${lobbyId}`);
                this.isConnected = true;
                this.reconnectAttempts = 0;
                
                // Send join game request
                this.socket.send(JSON.stringify({
                    type: 'join_game',
                    lobbyId: lobbyId,
                    player: {
                        id: this.game.playerId,
                        name: this.game.player.username || 'Anonymous',
                        color: this.game.player.color,
                        betAmount: betAmount,
                        x: this.game.player.x,
                        y: this.game.player.y,
                        radius: this.game.player.radius
                    }
                }));
                resolve();
            };
            
            this.socket.onerror = (error) => {
                console.error('❌ Fallback connection also failed:', error);
                reject(error);
            };
            
            this.socket.onclose = () => {
                console.log('🔒 Fallback connection closed');
                this.isConnected = false;
            };
            
            this.socket.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data);
                    this.handleMessage(message);
                } catch (error) {
                    console.error('Error parsing message:', error);
                }
            };
        } else {
            console.error('❌ No more fallback options available');
            reject(new Error('All connection attempts failed'));
        }
    }

    // Handle incoming messages from the server
    handleMessage(message) {
        switch (message.type) {
            case 'game_join_confirmed':
                this.handleGameJoinConfirmed(message);
                break;
            case 'player_joined':
                this.addPlayer(message.player);
                break;
            case 'player_left':
                this.removePlayer(message.playerId);
                break;
            case 'player_update':
                this.updatePlayer(message);
                break;
            case 'game_state':
                this.updateGameState(message.state);
                break;
            case 'player_death':
                this.handlePlayerDeath(message.playerId, message.killerId);
                break;
            case 'player_eliminated':
                console.log('🚨 Player eliminated:', message);
                this.handlePlayerDeath(message.playerId, message.eliminatedBy);
                break;
            case 'player_ball_eaten':
                console.log('🍽️ Player ball eaten:', message);
                // Handle individual ball being eaten - remove from visual display immediately
                this.handlePlayerBallEaten(message);
                break;
            case 'ballEaten':
                console.log('🍽️ Ball eaten event:', message);
                // Handle ball eating - update eater's ball and remove victim's ball
                this.handleBallEaten(message.data);
                break;
            case 'food_spawned':
                this.addFood(message.food);
                break;
            case 'food_eaten':
                this.removeFood(message.foodId);
                break;
            case 'food_update':
                this.handleFoodUpdate(message.food);
                break;
            case 'virus_update':
                this.handleVirusUpdate(message.viruses);
                break;
            case 'virus_split':
                this.handleVirusSplit(message.viruses);
                break;
            case 'lobby_full':
                this.handleLobbyFull();
                break;
            case 'cashout_response':
            case 'player_cashout_response':
                // Cashout is now handled directly in game.js, no server response needed
                console.log('💸 Cashout response received (ignored):', message);
                break;
            case 'player_cashed_out':
                // Handle when another player cashes out - remove them from the game
                console.log('💸 Player cashed out:', message);
                this.removePlayer(message.playerId);
                if (window.gameManager && window.gameManager.uiManager) {
                    window.gameManager.uiManager.showNotification(
                        `${message.playerName} cashed out €${message.amount.toFixed(2)}!`, 
                        'info'
                    );
                }
                break;
            case 'massFeed':
                console.log('🍽️ Mass feed received:', message);
                this.handleMassFeed(message.data);
                break;
            case 'massPickup':
                console.log('🔄 Mass pickup received:', message);
                this.handleMassPickup(message.data);
                break;
            case 'error':
                console.error('Server error:', message.error);
                // Handle specific errors
                if (message.error === 'Invalid lobby ID') {
                    console.error('❌ Invalid lobby ID error:', message.error);
                    // Try to rejoin through lobby system if available
                    if (window.lobbySystem) {
                        console.log('🔄 Attempting to rejoin through lobby system...');
                        const currentLobby = window.lobbySystem.getCurrentLobby();
                        if (currentLobby && currentLobby.id) {
                            // Try to rejoin the current lobby
                            console.log(`🔄 Rejoining lobby ${currentLobby.id}...`);
                            window.lobbySystem.joinLobby(currentLobby.id).catch(err => {
                                console.error('❌ Failed to rejoin lobby:', err);
                            });
                        } else {
                            console.warn('⚠️ No current lobby to rejoin, player needs to select a lobby');
                            // Could trigger UI to show lobby selection here
                        }
                    } else {
                        console.warn('⚠️ Lobby system not available for retry');
                    }
                }
                break;
            default:
                console.log('Unknown message type:', message.type);
        }
    }

    // Handle game join confirmation
    handleGameJoinConfirmed(message) {
        console.log('✅ Game join confirmed by server:', message);
        
        // Notify game manager
        if (window.gameManager) {
            window.gameManager.handleGameJoinConfirmed(message);
        }
    }

    // Removed handleCashoutResponse method - cashout is now handled directly in game.js

    // Send message to server
    sendMessage(message) {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(message));
        }
    }

    // Send player update to server
    sendPlayerUpdate(updateData = {}) {
        if (!this.isConnected) return;
        
        // Allow sending updates even with no balls (for elimination state)
        const message = {
            type: 'player_update',
            playerId: this.playerId,
            balls: this.game.player.balls || [],
            totalMoney: this.game.player.totalMoney || 0,
            name: this.game.player.name,
            color: this.game.player.color,
            timestamp: Date.now(),
            ...updateData // Allow additional data like action type
        };
        
        this.sendMessage(message);
    }
    
    // Send specific action updates
    sendActionUpdate(action, data = {}) {
        if (!this.isConnected) return;
        
        this.sendMessage({
            type: 'player_action',
            playerId: this.playerId,
            action: action,
            timestamp: Date.now(),
            ...data
        });
    }

    // Add new player
    addPlayer(player) {
        // Clean up any duplicate players before adding new one
        this.cleanupDuplicatePlayers(player.id);
        
        this.otherPlayers.set(player.id, player);
        console.log(`Player ${player.name} joined the game`);
    }

    // Remove player
    removePlayer(playerId) {
        if (this.otherPlayers.has(playerId)) {
            const player = this.otherPlayers.get(playerId);
            console.log(`Player ${player.name} left the game`);
            this.otherPlayers.delete(playerId);
        }
    }

    // Update player data
    updatePlayer(updateData) {
        // Handle both old format (complete player object) and new format (individual fields)
        if (updateData.player) {
            // Old format: complete player object
            this.otherPlayers.set(updateData.player.id, updateData.player);
        } else if (updateData.playerId) {
            // New format: individual fields
            const existingPlayer = this.otherPlayers.get(updateData.playerId);
            if (existingPlayer) {
                // Update existing player data
                if (updateData.balls) existingPlayer.balls = updateData.balls;
                if (updateData.totalMoney !== undefined) existingPlayer.totalMoney = updateData.totalMoney;
                this.otherPlayers.set(updateData.playerId, existingPlayer);
            }
        } else if (updateData.id) {
            // Direct player object (for game state updates)
            this.otherPlayers.set(updateData.id, updateData);
        }
    }

    // Update game state
    updateGameState(state) {
        // Update food
        if (state.food) {
            this.game.gameState.food = state.food;
        }
        
        // Update viruses
        if (state.viruses) {
            this.game.gameState.viruses = state.viruses;
        }
        
        // Update players
        if (state.players) {
            state.players.forEach(player => {
                if (player.id !== this.playerId) {
                    this.updatePlayer(player);
                }
            });
        }
    }

    // Handle player death
    handlePlayerDeath(playerId, killerId) {
        if (playerId === this.playerId) {
            // Current player died
            const killer = this.otherPlayers.get(killerId);
            const killerName = killer ? killer.name : 'Unknown';
            
            // Show elimination animation
            if (this.game && this.game.showEliminationAnimation) {
                this.game.showEliminationAnimation(killerName);
            } else {
                // Fallback to old method
                if (window.gameManager && window.gameManager.uiManager) {
                    window.gameManager.uiManager.showNotification(`You were eliminated by ${killerName}! Redirecting to home...`, 'error');
                }
                
                // End game and redirect to lobby after a short delay
                setTimeout(() => {
                    this.game.endGame();
                    if (window.gameManager) {
                        window.gameManager.showLobbyPage();
                    }
                }, 2000);
            }
        } else {
            // Another player died - remove them immediately
            console.log(`🚨 Removing eliminated player ${playerId}`);
            this.removePlayer(playerId);
        }
    }

    // Handle individual ball being eaten
    handlePlayerBallEaten(message) {
        const { victimId, killerId, ballId } = message;
        
        // Find the victim player
        const victim = this.otherPlayers.get(victimId);
        if (victim && victim.balls) {
            // Remove the specific ball that was eaten
            victim.balls = victim.balls.filter(ball => ball.id !== ballId);
            console.log(`🍽️ Removed ball ${ballId} from player ${victimId}. Balls remaining: ${victim.balls.length}`);
            
            // Only eliminate player if they have NO balls left (handled by separate player_eliminated message)
            // Do NOT remove player here - they can still play with remaining balls
        }
    }

    // Handle ball eating event - update eater's ball and remove victim's ball instantly
    handleBallEaten(data) {
        const { eaterPlayerId, victimPlayerId, eaterBall, victimBallId } = data;
        
        // If local player is the eater, update their ball
        if (eaterPlayerId === this.playerId) {
            const localBall = this.game.localPlayer.balls.find(ball => ball.id === eaterBall.id);
            if (localBall) {
                // Update the eater's ball with new money and size
                localBall.money = eaterBall.money;
                localBall.size = eaterBall.size;
                console.log(`🍽️ Updated local ball ${localBall.id} - new money: €${localBall.money.toFixed(2)}, size: ${localBall.size}`);
                
                // Update total money
                this.game.localPlayer.totalMoney = this.game.localPlayer.balls.reduce((sum, ball) => sum + ball.money, 0);
            }
        }
        
        // If local player is the victim, remove their ball
        if (victimPlayerId === this.playerId) {
            this.game.localPlayer.balls = this.game.localPlayer.balls.filter(ball => ball.id !== victimBallId);
            console.log(`🍽️ Removed local ball ${victimBallId}. Balls remaining: ${this.game.localPlayer.balls.length}`);
            
            // Update total money
            this.game.localPlayer.totalMoney = this.game.localPlayer.balls.reduce((sum, ball) => sum + ball.money, 0);
            
            // Check if player is eliminated (no balls left)
            if (this.game.localPlayer.balls.length === 0) {
                console.log('💀 Local player eliminated!');
                this.game.handlePlayerElimination({ eliminatedPlayerId: this.playerId, killerPlayerId: eaterPlayerId });
            }
        }
        
        // If other player is the victim, remove their ball
        if (victimPlayerId !== this.playerId) {
            const victim = this.otherPlayers.get(victimPlayerId);
            if (victim && victim.balls) {
                victim.balls = victim.balls.filter(ball => ball.id !== victimBallId);
                console.log(`🍽️ Removed ball ${victimBallId} from player ${victimPlayerId}. Balls remaining: ${victim.balls.length}`);
            }
        }
        
        // If other player is the eater, update their ball
        if (eaterPlayerId !== this.playerId) {
            const eater = this.otherPlayers.get(eaterPlayerId);
            if (eater && eater.balls) {
                const eaterBallToUpdate = eater.balls.find(ball => ball.id === eaterBall.id);
                if (eaterBallToUpdate) {
                    eaterBallToUpdate.money = eaterBall.money;
                    eaterBallToUpdate.size = eaterBall.size;
                    console.log(`🍽️ Updated other player ball ${eaterBallToUpdate.id} - new size: ${eaterBallToUpdate.size}`);
                }
            }
        }
    }

    // Add food
    addFood(food) {
        if (!this.game.gameState.food) {
            this.game.gameState.food = [];
        }
        this.game.gameState.food.push(food);
    }

    // Remove food
    removeFood(foodId) {
        if (this.game.gameState.food) {
            this.game.gameState.food = this.game.gameState.food.filter(f => f.id !== foodId);
        }
    }

    handleFoodUpdate(food) {
        // Update food from server
        if (this.game && food) {
            if (!this.game.gameState.food) {
                this.game.gameState.food = [];
            }
            this.game.gameState.food = food;
        }
    }
    
    handleVirusUpdate(viruses) {
        // Update viruses from server
        if (this.game && viruses) {
            if (!this.game.gameState.viruses) {
                this.game.gameState.viruses = [];
            }
            this.game.gameState.viruses = viruses;
        }
    }
    
    handleVirusSplit(viruses) {
        // Handle virus split event from server
        if (this.game && viruses) {
            if (!this.game.gameState.viruses) {
                this.game.gameState.viruses = [];
            }
            this.game.gameState.viruses = viruses;
            console.log('🦠 Virus split detected, updated virus count:', viruses.length);
        }
    }

    // Handle mass feed from other players
    handleMassFeed(data) {
        const { playerId, massDrop, fromBall } = data;
        
        // Add mass drop to game state
        if (!this.game.gameState.massDrops) {
            this.game.gameState.massDrops = [];
        }
        this.game.gameState.massDrops.push(massDrop);
        
        // Update the feeding player's ball if it's another player
        if (playerId !== this.playerId) {
            const otherPlayer = this.otherPlayers.get(playerId);
            if (otherPlayer && otherPlayer.balls) {
                const ball = otherPlayer.balls.find(b => b.id === fromBall.id);
                if (ball) {
                    ball.money = fromBall.money;
                    ball.size = fromBall.size;
                }
            }
        }
        
        console.log(`🍽️ Player ${playerId} fed mass: €${massDrop.money.toFixed(2)}`);
    }

    // Handle mass pickup
    handleMassPickup(data) {
        const { playerId, ballId, massDropId } = data;
        
        // Remove mass drop from game state
        if (this.game.gameState.massDrops) {
            this.game.gameState.massDrops = this.game.gameState.massDrops.filter(
                massDrop => massDrop.id !== massDropId
            );
        }
        
        console.log(`🔄 Player ${playerId} picked up mass drop ${massDropId}`);
    }

    // Handle lobby full
    handleLobbyFull() {
        if (window.gameManager && window.gameManager.uiManager) {
            window.gameManager.uiManager.showNotification('Lobby is full! Try another lobby.', 'warning');
        }
        this.disconnect();
    }

    // Attempt to reconnect
    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            console.log(`Attempting to reconnect... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);

            setTimeout(() => {
                // Try to reconnect with the same parameters
                // Note: This would need the original connection parameters
            }, 2000 * this.reconnectAttempts);
        } else {
            console.log('Max reconnection attempts reached. Switching to single player mode.');
            this.startSinglePlayerMode();
        }
    }

    // Start single player mode
    startSinglePlayerMode() {
        console.log('Starting single player mode');
        if (window.gameManager && window.gameManager.uiManager) {
            window.gameManager.uiManager.showNotification('Playing in single player mode', 'info');
        }
    }

    // Clean up duplicate players (fix for rejoin bug)
    cleanupDuplicatePlayers(currentPlayerId) {
        const playersToRemove = [];
        
        // Find any players with the same name or similar ID
        this.otherPlayers.forEach((player, playerId) => {
            if (playerId !== currentPlayerId && 
                (player.name === this.game.player.name || 
                 playerId.startsWith(currentPlayerId.substring(0, 5)))) {
                playersToRemove.push(playerId);
            }
        });
        
        // Remove duplicate players
        playersToRemove.forEach(playerId => {
            console.log(`🧹 Removing duplicate player: ${playerId}`);
            this.otherPlayers.delete(playerId);
        });
        
        if (playersToRemove.length > 0) {
            console.log(`✅ Cleaned up ${playersToRemove.length} duplicate players`);
        }
    }

    // Disconnect from server
    disconnect() {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            // Notify server that player is leaving before closing connection
            try {
                this.socket.send(JSON.stringify({
                    type: 'player_disconnect',
                    playerId: this.playerId,
                    reason: 'manual_disconnect'
                }));
                console.log('🚪 Notified server of player disconnect');
            } catch (error) {
                console.warn('⚠️ Could not notify server of disconnect:', error);
            }
            
            // Give a brief moment for the message to be sent
            setTimeout(() => {
                if (this.socket) {
                    this.socket.close();
                    this.socket = null;
                }
            }, 100);
        } else if (this.socket) {
            this.socket.close();
            this.socket = null;
        }
        
        this.isConnected = false;
        this.otherPlayers.clear();
        console.log('🔌 Disconnected from multiplayer server');
    }

    // Get all players (current + others)
    getAllPlayers() {
        const players = [];
        
        // Add current player
        if (this.game.player.balls.length > 0) {
            players.push({
                ...this.game.player,
                id: this.playerId,
                isCurrentPlayer: true
            });
        }
        
        // Add other players
        this.otherPlayers.forEach(player => {
            players.push({
                ...player,
                isCurrentPlayer: false
            });
        });

        return players;
    }

    // Send split command
    sendSplit() {
        this.sendMessage({
            type: 'player_split',
            playerId: this.playerId
        });
    }

    // Send eject mass command
    sendEjectMass() {
        this.sendMessage({
            type: 'player_eject',
            playerId: this.playerId
        });
    }

    // Send cash out command
    sendCashOut() {
        this.sendMessage({
            type: 'player_cashout',
            playerId: this.playerId
        });
    }
}

// Export for use in other modules
window.MultiplayerSystem = MultiplayerSystem;
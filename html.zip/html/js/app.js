// Main Application Entry Point
class App {
    constructor() {
        // Application state
        this.initialized = false;
        this.running = false;
        this.startTime = Date.now();
        
        // Managers
        this.gameEngine = null;
        this.renderer = null;
        this.inputHandler = null;
        this.audioManager = null;
        this.uiManager = null;
        this.networkManager = null;
        
        // Performance tracking
        this.performanceStats = {
            frameCount: 0,
            lastFPSUpdate: 0,
            fps: 0,
            averageFrameTime: 0,
            memoryUsage: 0
        };
        
        // Error handling
        this.errorCount = 0;
        this.maxErrors = 10;
        
        // Debug mode
        this.debugMode = CONFIG.DEBUG.ENABLED;
        
        // Bind methods
        this.handleError = this.handleError.bind(this);
        this.handleUnhandledRejection = this.handleUnhandledRejection.bind(this);
    }

    // Initialize application
    async init() {
        console.log('Initializing Agma.io Clone...');
        
        try {
            // Setup error handling
            this.setupErrorHandling();
            
            // Check browser compatibility
            if (!this.checkCompatibility()) {
                throw new Error('Browser not compatible');
            }
            
            // Initialize managers in order
            await this.initializeManagers();
            
            // Setup global references
            this.setupGlobalReferences();
            
            // Setup callbacks between managers
            this.setupManagerCallbacks();
            
            // Start performance monitoring
            this.startPerformanceMonitoring();
            
            // Mark as initialized
            this.initialized = true;
            
            console.log('Application initialized successfully');
            
            // Start the application
            this.start();
            
        } catch (error) {
            console.error('Failed to initialize application:', error);
            this.showFatalError('Failed to initialize application: ' + error.message);
        }
    }

    // Check browser compatibility
    checkCompatibility() {
        const requirements = {
            canvas: !!document.createElement('canvas').getContext,
            webgl: !!document.createElement('canvas').getContext('webgl'),
            websocket: typeof WebSocket !== 'undefined',
            audioContext: typeof AudioContext !== 'undefined' || typeof webkitAudioContext !== 'undefined',
            localStorage: typeof Storage !== 'undefined',
            requestAnimationFrame: typeof requestAnimationFrame !== 'undefined'
        };
        
        const missing = [];
        for (const [feature, supported] of Object.entries(requirements)) {
            if (!supported) {
                missing.push(feature);
            }
        }
        
        if (missing.length > 0) {
            console.error('Missing browser features:', missing);
            this.showCompatibilityError(missing);
            return false;
        }
        
        return true;
    }

    // Initialize all managers
    async initializeManagers() {
        console.log('Initializing managers...');
        
        // Initialize UI Manager first (for loading screen)
        this.uiManager = new UIManager();
        this.uiManager.init();
        
        // Show loading screen
        this.uiManager.showScreen('loading');
        
        // Initialize Audio Manager
        this.audioManager = new AudioManager();
        await this.audioManager.init();
        
        // Initialize Network Manager
        this.networkManager = new NetworkManager();
        this.networkManager.init();
        
        // Initialize Input Handler
        this.inputHandler = new InputHandler();
        this.inputHandler.init();
        
        // Initialize Renderer
        this.renderer = new GameRenderer();
        this.renderer.init();
        
        // Initialize Game Engine
        this.gameEngine = new GameEngine();
        this.gameEngine.init();
        
        console.log('All managers initialized');
    }

    // Setup global references
    setupGlobalReferences() {
        // Make managers globally accessible
        window.app = this;
        window.gameEngine = this.gameEngine;
        window.renderer = this.renderer;
        window.inputHandler = this.inputHandler;
        window.audioManager = this.audioManager;
        window.uiManager = this.uiManager;
        window.networkManager = this.networkManager;
    }

    // Setup callbacks between managers
    setupManagerCallbacks() {
        // Input callbacks
        this.inputHandler.setCallbacks({
            move: (x, y) => this.gameEngine.setMouseTarget(x, y),
            split: () => this.gameEngine.split(),
            feed: () => this.gameEngine.feed(),
            chat: (message) => this.networkManager.sendChatMessage(message),
            zoom: (delta) => this.gameEngine.adjustZoom(delta)
        });
        
        // Network callbacks
        this.networkManager.setCallbacks({
            onGameState: (state) => this.gameEngine.updateGameState(state),
            onPlayerJoined: (player) => this.gameEngine.addPlayer(player),
            onPlayerLeft: (playerId) => this.gameEngine.removePlayer(playerId),
            onChatMessage: (message) => this.uiManager.addChatMessage(message),
            onLeaderboard: (leaderboard) => this.uiManager.updateLeaderboard(leaderboard),
            onPowerupUpdate: (powerups) => this.uiManager.updatePowerups(powerups),
            onPlayerStats: (stats) => this.uiManager.updatePlayerStats(stats),
            onGameStart: () => this.onGameStart(),
            onGameEnd: () => this.onGameEnd(),
            onError: (error) => this.handleNetworkError(error)
        });
        
        // Game engine callbacks
        this.gameEngine.setCallbacks({
            onPlayerEat: (mass) => this.audioManager.playSound('eat', { volume: Math.min(1, mass / 100) }),
            onPlayerSplit: () => this.audioManager.playSound('split'),
            onPlayerFeed: () => this.audioManager.playSound('feed'),
            onPlayerDeath: () => this.onPlayerDeath(),
            onPowerupCollected: (powerup) => this.onPowerupCollected(powerup),
            onVirusHit: () => this.audioManager.playSound('virus_pop'),
            onScreenShake: (intensity) => this.renderer.addScreenShake(intensity)
        });
    }

    // Start the application
    start() {
        if (!this.initialized) {
            console.error('Cannot start: Application not initialized');
            return;
        }
        
        console.log('Starting application...');
        
        // Start background music
        this.audioManager.playMusic('menu_music');
        
        // Show main menu
        this.uiManager.showScreen('mainMenu');
        
        // Mark as running
        this.running = true;
        
        console.log('Application started');
    }

    // Handle game start
    onGameStart() {
        console.log('Game started');
        
        // Switch to game UI
        this.uiManager.showScreen('game');
        
        // Switch to game music
        this.audioManager.stopMusic();
        this.audioManager.playMusic('game_music');
        
        // Start game loop
        this.gameEngine.start();
    }

    // Handle game end
    onGameEnd() {
        console.log('Game ended');
        
        // Stop game loop
        this.gameEngine.stop();
        
        // Switch back to menu
        this.uiManager.showScreen('mainMenu');
        
        // Switch to menu music
        this.audioManager.stopMusic();
        this.audioManager.playMusic('menu_music');
    }

    // Handle player death
    onPlayerDeath() {
        console.log('Player died');
        
        // Play death sound
        this.audioManager.playSound('death');
        
        // Add screen shake
        this.renderer.addScreenShake(20);
        
        // Show death notification
        this.uiManager.showNotification('You died!', 'error', 2000);
    }

    // Handle powerup collection
    onPowerupCollected(powerup) {
        console.log('Powerup collected:', powerup.type);
        
        // Play powerup sound
        this.audioManager.playSound('powerup');
        
        // Show notification
        this.uiManager.showNotification(`Collected ${powerup.name}!`, 'success', 1500);
    }

    // Handle network errors
    handleNetworkError(error) {
        console.error('Network error:', error);
        
        // Show error notification
        this.uiManager.showNotification('Connection error: ' + error.message, 'error');
        
        // Try to reconnect
        if (this.networkManager) {
            setTimeout(() => {
                this.networkManager.reconnect();
            }, 2000);
        }
    }

    // Setup error handling
    setupErrorHandling() {
        window.addEventListener('error', this.handleError);
        window.addEventListener('unhandledrejection', this.handleUnhandledRejection);
    }

    // Handle JavaScript errors
    handleError(event) {
        console.error('JavaScript error:', event.error);
        
        this.errorCount++;
        
        if (this.errorCount > this.maxErrors) {
            this.showFatalError('Too many errors occurred. Please refresh the page.');
            return;
        }
        
        // Show error notification
        if (this.uiManager) {
            this.uiManager.showNotification('An error occurred', 'error');
        }
    }

    // Handle unhandled promise rejections
    handleUnhandledRejection(event) {
        console.error('Unhandled promise rejection:', event.reason);
        
        // Prevent default browser behavior
        event.preventDefault();
        
        // Handle as regular error
        this.handleError({ error: event.reason });
    }

    // Show fatal error
    showFatalError(message) {
        console.error('Fatal error:', message);
        
        // Create error overlay
        const errorOverlay = document.createElement('div');
        errorOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            font-family: Arial, sans-serif;
        `;
        
        errorOverlay.innerHTML = `
            <h1>Fatal Error</h1>
            <p>${message}</p>
            <button onclick="location.reload()" style="
                padding: 10px 20px;
                background: #ff4444;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                margin-top: 20px;
            ">Reload Page</button>
        `;
        
        document.body.appendChild(errorOverlay);
    }

    // Show compatibility error
    showCompatibilityError(missingFeatures) {
        const errorOverlay = document.createElement('div');
        errorOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            font-family: Arial, sans-serif;
            text-align: center;
        `;
        
        errorOverlay.innerHTML = `
            <h1>Browser Not Supported</h1>
            <p>Your browser is missing the following required features:</p>
            <ul style="text-align: left; margin: 20px 0;">
                ${missingFeatures.map(feature => `<li>${feature}</li>`).join('')}
            </ul>
            <p>Please update your browser or use a modern browser like Chrome, Firefox, or Edge.</p>
        `;
        
        document.body.appendChild(errorOverlay);
    }

    // Start performance monitoring
    startPerformanceMonitoring() {
        if (!this.debugMode) return;
        
        setInterval(() => {
            this.updatePerformanceStats();
        }, 1000);
    }

    // Game event handlers
    onGameStart() {
        console.log('Game started');
        this.uiManager.showScreen('game');
        this.uiManager.isGameActive = true;
        this.audioManager.playMusic('game_music');
    }

    onGameEnd() {
        console.log('Game ended');
        this.uiManager.showScreen('mainMenu');
        this.uiManager.isGameActive = false;
        this.audioManager.playMusic('menu_music');
    }

    onPlayerDeath() {
        console.log('Player died');
        this.audioManager.playSound('death');
        this.uiManager.showNotification('You died!', 'error');
    }

    onPowerupCollected(powerup) {
        console.log('Powerup collected:', powerup);
        this.audioManager.playSound('powerup_collect');
        this.uiManager.showNotification(`Collected ${powerup.name}!`, 'success');
    }

    handleNetworkError(error) {
        console.error('Network error:', error);
        this.uiManager.showNotification('Connection error: ' + error.message, 'error');
    }

    // Update performance statistics
    updatePerformanceStats() {
        const now = performance.now();
        
        // Calculate FPS
        if (this.gameEngine) {
            this.performanceStats.fps = this.gameEngine.fps;
            this.performanceStats.averageFrameTime = this.gameEngine.averageFrameTime;
        }
        
        // Get memory usage (if available)
        if (performance.memory) {
            this.performanceStats.memoryUsage = performance.memory.usedJSHeapSize / 1024 / 1024; // MB
        }
        
        // Update FPS display
        if (this.uiManager) {
            this.uiManager.updateFPS(this.performanceStats.fps);
        }
        
        // Log performance stats
        if (this.debugMode && now - this.performanceStats.lastFPSUpdate > 5000) {
            console.log('Performance Stats:', this.performanceStats);
            this.performanceStats.lastFPSUpdate = now;
        }
    }

    // Get application statistics
    getStats() {
        return {
            initialized: this.initialized,
            running: this.running,
            uptime: Date.now() - this.startTime,
            errorCount: this.errorCount,
            performance: this.performanceStats,
            managers: {
                gameEngine: this.gameEngine?.getStats(),
                renderer: this.renderer?.getStats(),
                inputHandler: this.inputHandler?.getStats(),
                audioManager: this.audioManager?.getStats(),
                uiManager: this.uiManager?.getStats(),
                networkManager: this.networkManager?.getStats()
            }
        };
    }

    // Restart application
    restart() {
        console.log('Restarting application...');
        
        // Stop all managers
        this.stop();
        
        // Reinitialize
        setTimeout(() => {
            this.init();
        }, 1000);
    }

    // Stop application
    stop() {
        console.log('Stopping application...');
        
        this.running = false;
        
        // Stop all managers
        if (this.gameEngine) this.gameEngine.destroy();
        if (this.renderer) this.renderer.destroy?.();
        if (this.inputHandler) this.inputHandler.destroy();
        if (this.audioManager) this.audioManager.destroy();
        if (this.uiManager) this.uiManager.destroy();
        if (this.networkManager) this.networkManager.destroy();
        
        // Remove global references
        delete window.app;
        delete window.gameEngine;
        delete window.renderer;
        delete window.inputHandler;
        delete window.audioManager;
        delete window.uiManager;
        delete window.networkManager;
        
        console.log('Application stopped');
    }

    // Cleanup on page unload
    cleanup() {
        this.stop();
    }
}

// Initialize application when DOM is ready
function initializeApp() {
    console.log('DOM ready, initializing application...');
    
    // Create and initialize app
    const app = new App();
    app.init();
    
    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        app.cleanup();
    });
    
    // Make app globally accessible for debugging
    window.app = app;
}

// Wait for DOM to be ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// Export for Node.js compatibility
if (typeof module !== 'undefined' && module.exports) {
    module.exports = App;
}
// Direct access prevention
if (typeof window !== 'undefined' && window.location && window.location.pathname.includes('/js/')) {
    throw new Error('Direct file access denied');
}

// Utility Functions
class Utils {
    // Generate random ID
    static generateId(length = 8) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    // Generate random color
    static generateRandomColor() {
        const hue = Math.floor(Math.random() * 360);
        return `hsl(${hue}, 70%, 60%)`;
    }

    // Calculate distance between two points
    static distance(x1, y1, x2, y2) {
        const dx = x2 - x1;
        const dy = y2 - y1;
        return Math.sqrt(dx * dx + dy * dy);
    }

    // Check if two circles collide
    static circleCollision(x1, y1, r1, x2, y2, r2) {
        const distance = this.distance(x1, y1, x2, y2);
        return distance < (r1 + r2);
    }

    // Clamp value between min and max
    static clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }

    // Linear interpolation
    static lerp(start, end, factor) {
        return start + (end - start) * factor;
    }

    // Format currency
    static formatCurrency(amount, currency = '€') {
        return `${currency}${amount.toFixed(2)}`;
    }

    // Format large numbers
    static formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    // Debounce function
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Throttle function
    static throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    // Get random element from array
    static randomElement(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    // Shuffle array
    static shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }

    // Deep clone object
    static deepClone(obj) {
        if (obj === null || typeof obj !== 'object') return obj;
        if (obj instanceof Date) return new Date(obj.getTime());
        if (obj instanceof Array) return obj.map(item => this.deepClone(item));
        if (typeof obj === 'object') {
            const clonedObj = {};
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    clonedObj[key] = this.deepClone(obj[key]);
                }
            }
            return clonedObj;
        }
    }

    // Validate email
    static isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Hash password (simple implementation)
    static hashPassword(password) {
        let hash = 0;
        if (password.length === 0) return hash;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash.toString();
    }

    // Generate random name
    static generateRandomName() {
        const adjectives = [
            'Swift', 'Mighty', 'Golden', 'Shadow', 'Blazing', 'Crystal', 'Thunder', 'Mystic',
            'Fierce', 'Noble', 'Radiant', 'Savage', 'Eternal', 'Frozen', 'Burning', 'Ancient'
        ];
        
        const nouns = [
            'Warrior', 'Hunter', 'Dragon', 'Phoenix', 'Tiger', 'Eagle', 'Wolf', 'Lion',
            'Falcon', 'Shark', 'Viper', 'Panther', 'Bear', 'Hawk', 'Fox', 'Raven'
        ];
        
        const adjective = this.randomElement(adjectives);
        const noun = this.randomElement(nouns);
        const number = Math.floor(Math.random() * 999) + 1;
        
        return `${adjective}${noun}${number}`;
    }

    // Calculate ball radius from money (Agar.io style - smaller balls)
    static calculateBallRadius(money) {
        // Validate money input
        if (!money || isNaN(money) || money <= 0) {
            return 8; // Smaller default minimum radius like Agar.io
        }
        // Much smaller radius calculation for Agar.io feel
        const radius = Math.sqrt(money * 20) + 8; // Reduced multiplier from 100 to 20
        // Ensure radius is valid and cap maximum size
        if (isNaN(radius)) {
            return 8;
        }
        return Math.min(radius, 60); // Cap maximum radius at 60 for performance
    }

    // Calculate ball speed based on radius
    static calculateBallSpeed(radius) {
        return Math.max(1, 5 - radius / 20);
    }

    // Check if point is in viewport
    static isInViewport(x, y, camera, canvasWidth, canvasHeight) {
        const margin = 100; // Extra margin for smooth rendering
        const left = camera.x - (canvasWidth / camera.zoom / 2) - margin;
        const right = camera.x + (canvasWidth / camera.zoom / 2) + margin;
        const top = camera.y - (canvasHeight / camera.zoom / 2) - margin;
        const bottom = camera.y + (canvasHeight / camera.zoom / 2) + margin;
        
        return x >= left && x <= right && y >= top && y <= bottom;
    }

    // Convert world coordinates to screen coordinates
    static worldToScreen(worldX, worldY, camera, canvasWidth, canvasHeight) {
        const screenX = (worldX - camera.x) * camera.zoom + canvasWidth / 2;
        const screenY = (worldY - camera.y) * camera.zoom + canvasHeight / 2;
        return { x: screenX, y: screenY };
    }

    // Convert screen coordinates to world coordinates
    static screenToWorld(screenX, screenY, camera, canvasWidth, canvasHeight) {
        const worldX = camera.x + (screenX - canvasWidth / 2) / camera.zoom;
        const worldY = camera.y + (screenY - canvasHeight / 2) / camera.zoom;
        return { x: worldX, y: worldY };
    }

    // Smooth camera movement
    static smoothCamera(camera, targetX, targetY, smoothing = 0.1) {
        camera.x += (targetX - camera.x) * smoothing;
        camera.y += (targetY - camera.y) * smoothing;
    }

    // Calculate optimal zoom based on player size
    static calculateOptimalZoom(totalRadius, minZoom = 0.3, maxZoom = 1) {
        const targetZoom = Math.max(minZoom, Math.min(maxZoom, 800 / totalRadius));
        return targetZoom;
    }

    // Generate food position that doesn't overlap with existing entities
    static generateSafeFoodPosition(worldWidth, worldHeight, existingEntities, minDistance = 50) {
        let attempts = 0;
        const maxAttempts = 100;
        
        while (attempts < maxAttempts) {
            const x = Math.random() * worldWidth;
            const y = Math.random() * worldHeight;
            
            let safe = true;
            for (const entity of existingEntities) {
                if (this.distance(x, y, entity.x, entity.y) < minDistance) {
                    safe = false;
                    break;
                }
            }
            
            if (safe) {
                return { x, y };
            }
            
            attempts++;
        }
        
        // If no safe position found, return random position
        return {
            x: Math.random() * worldWidth,
            y: Math.random() * worldHeight
        };
    }

    // Performance monitoring
    static createPerformanceMonitor() {
        let frameCount = 0;
        let lastTime = performance.now();
        let fps = 0;
        
        return {
            update() {
                frameCount++;
                const currentTime = performance.now();
                
                if (currentTime - lastTime >= 1000) {
                    fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
                    frameCount = 0;
                    lastTime = currentTime;
                }
                
                return fps;
            },
            
            getFPS() {
                return fps;
            }
        };
    }

    // Local storage helpers
    static saveToStorage(key, data) {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            return true;
        } catch (e) {
            console.error('Failed to save to localStorage:', e);
            return false;
        }
    }

    static loadFromStorage(key, defaultValue = null) {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : defaultValue;
        } catch (e) {
            console.error('Failed to load from localStorage:', e);
            return defaultValue;
        }
    }

    static removeFromStorage(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (e) {
            console.error('Failed to remove from localStorage:', e);
            return false;
        }
    }
}

// Export for global access
window.Utils = Utils;
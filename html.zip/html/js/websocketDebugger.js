// WebSocket Connection Debugger
// This utility helps diagnose WebSocket connection issues

class WebSocketDebugger {
    constructor() {
        this.connectionAttempts = [];
        this.isDebugging = true;
    }

    async testConnection(url, timeout = 5000) {
        return new Promise((resolve) => {
            const startTime = Date.now();
            const attempt = {
                url,
                startTime,
                status: 'attempting',
                error: null,
                duration: null
            };
            
            this.connectionAttempts.push(attempt);
            
            if (this.isDebugging) {
                console.log(`🔍 Testing WebSocket connection to: ${url}`);
            }

            const ws = new WebSocket(url);
            const timeoutId = setTimeout(() => {
                attempt.status = 'timeout';
                attempt.duration = Date.now() - startTime;
                ws.close();
                resolve(false);
            }, timeout);

            ws.onopen = () => {
                clearTimeout(timeoutId);
                attempt.status = 'success';
                attempt.duration = Date.now() - startTime;
                if (this.isDebugging) {
                    console.log(`✅ WebSocket connection successful in ${attempt.duration}ms`);
                }
                ws.close();
                resolve(true);
            };

            ws.onerror = (error) => {
                clearTimeout(timeoutId);
                attempt.status = 'error';
                attempt.error = error;
                attempt.duration = Date.now() - startTime;
                if (this.isDebugging) {
                    console.log(`❌ WebSocket connection failed:`, error);
                }
                resolve(false);
            };

            ws.onclose = (event) => {
                if (attempt.status === 'attempting') {
                    clearTimeout(timeoutId);
                    attempt.status = 'closed';
                    attempt.error = `Connection closed with code: ${event.code}, reason: ${event.reason}`;
                    attempt.duration = Date.now() - startTime;
                    if (this.isDebugging) {
                        console.log(`🔒 WebSocket connection closed: ${event.code} - ${event.reason}`);
                    }
                    resolve(false);
                }
            };
        });
    }

    async findBestConnection(baseUrl, port) {
        // Use appropriate protocol based on page protocol
        const protocols = [];
        if (window.location.protocol === 'https:') {
            // HTTPS pages can only use WSS
            protocols.push('wss');
        } else {
            // HTTP pages can use both, prefer WS for better compatibility
            protocols.push('ws', 'wss');
        }
        
        const hosts = [window.location.hostname];
        
        // Add localhost for development
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            hosts.push('localhost', '127.0.0.1');
        }

        const testUrls = [];
        
        // Generate test URLs
        for (const protocol of protocols) {
            for (const host of hosts) {
                if (port) {
                    testUrls.push(`${protocol}://${host}:${port}`);
                } else {
                    testUrls.push(`${protocol}://${host}`);
                }
            }
        }

        console.log('🔍 Testing WebSocket connections in order of preference...');
        
        for (const url of testUrls) {
            const success = await this.testConnection(url);
            if (success) {
                console.log(`✅ Best connection found: ${url}`);
                return url;
            }
        }

        console.log('❌ No working WebSocket connection found');
        return null;
    }

    getConnectionReport() {
        return {
            totalAttempts: this.connectionAttempts.length,
            successful: this.connectionAttempts.filter(a => a.status === 'success').length,
            failed: this.connectionAttempts.filter(a => a.status === 'error').length,
            timedOut: this.connectionAttempts.filter(a => a.status === 'timeout').length,
            attempts: this.connectionAttempts
        };
    }

    printReport() {
        const report = this.getConnectionReport();
        console.log('📊 WebSocket Connection Report:');
        console.log(`   Total attempts: ${report.totalAttempts}`);
        console.log(`   Successful: ${report.successful}`);
        console.log(`   Failed: ${report.failed}`);
        console.log(`   Timed out: ${report.timedOut}`);
        
        if (report.attempts.length > 0) {
            console.log('\n📋 Detailed attempts:');
            report.attempts.forEach((attempt, index) => {
                console.log(`   ${index + 1}. ${attempt.url} - ${attempt.status} (${attempt.duration}ms)`);
                if (attempt.error) {
                    console.log(`      Error: ${attempt.error}`);
                }
            });
        }
    }
}

// Export for use in other modules
if (typeof window !== 'undefined') {
    window.WebSocketDebugger = WebSocketDebugger;
}

// Auto-create global instance
if (typeof window !== 'undefined') {
    window.wsDebugger = new WebSocketDebugger();
    console.log('🔧 WebSocket Debugger initialized');
}
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

class EmailService {
    constructor() {
        this.transporter = null;
        this.verificationCodes = new Map(); // Store codes temporarily
        this.initializeTransporter();
    }

    initializeTransporter() {
        try {
            // Configure SMTP transporter using Hostinger settings
            this.transporter = nodemailer.createTransport({
                host: 'smtp.hostinger.com',
                port: 465,
                secure: true, // Use SSL
                auth: {
                    user: 'no-reply@oopsnowh.com',
                    pass: 'KJ2N10!_91n2kX'
                }
            });
            
            console.log('✅ Email service initialized');
        } catch (error) {
            console.error('❌ Failed to initialize email service:', error);
        }
    }

    generateVerificationCode() {
        return crypto.randomInt(100000, 999999).toString();
    }

    async sendAdminVerificationCode(email) {
        if (!this.transporter) {
            console.error('❌ Email transporter not initialized');
            return { success: false, error: 'Email service not available' };
        }

        const code = this.generateVerificationCode();
        const expiresAt = Date.now() + (5 * 60 * 1000); // 5 minutes

        // Store verification code
        this.verificationCodes.set(email, {
            code: code,
            expiresAt: expiresAt,
            attempts: 0
        });

        const mailOptions = {
            from: {
                name: 'OopsNowh Admin',
                address: 'no-reply@oopsnowh.com'
            },
            to: email,
            subject: 'Admin Access Verification Code - OopsNowh',
            html: this.getEmailTemplate(code)
        };

        try {
            await this.transporter.sendMail(mailOptions);
            console.log(`✅ Admin verification code sent to ${email}`);
            return { success: true, message: 'Verification code sent successfully' };
        } catch (error) {
            console.error('❌ Failed to send email:', error);
            // In development, log the code
            return { 
                success: true, 
                message: 'Email service unavailable. Check server logs for verification code.',
                devMode: true 
            };
        }
    }

    verifyCode(email, inputCode) {
        const storedData = this.verificationCodes.get(email);
        
        if (!storedData) {
            return { success: false, error: 'No verification code found for this email' };
        }

        if (Date.now() > storedData.expiresAt) {
            this.verificationCodes.delete(email);
            return { success: false, error: 'Verification code has expired' };
        }

        if (storedData.attempts >= 3) {
            this.verificationCodes.delete(email);
            return { success: false, error: 'Too many failed attempts' };
        }

        if (storedData.code !== inputCode) {
            storedData.attempts++;
            return { success: false, error: 'Invalid verification code' };
        }

        // Code is valid
        this.verificationCodes.delete(email);
        return { success: true, message: 'Email verified successfully' };
    }

    getEmailTemplate(code) {
        return `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Admin Verification Code</title>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px; }
                .container { max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
                .header { text-align: center; margin-bottom: 30px; }
                .logo { font-size: 24px; font-weight: bold; color: #8B5CF6; }
                .code-box { background-color: #8B5CF6; color: white; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0; }
                .code { font-size: 32px; font-weight: bold; letter-spacing: 5px; }
                .warning { background-color: #FEF3C7; border: 1px solid #F59E0B; padding: 15px; border-radius: 5px; margin: 20px 0; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div class="logo">🎮 OopsNowh</div>
                    <h2>Admin Access Verification</h2>
                </div>
                
                <p>Hello Admin,</p>
                <p>You have requested access to the OopsNowh admin panel. Please use the verification code below:</p>
                
                <div class="code-box">
                    <div class="code">${code}</div>
                </div>
                
                <div class="warning">
                    <strong>⚠️ Security Notice:</strong>
                    <ul>
                        <li>This code expires in 5 minutes</li>
                        <li>Only use this code if you requested admin access</li>
                        <li>Never share this code with anyone</li>
                        <li>If you didn't request this, please ignore this email</li>
                    </ul>
                </div>
                
                <p>If you have any issues, please contact the system administrator.</p>
                
                <div class="footer">
                    <p>This is an automated message from OopsNowh Admin System</p>
                    <p>© 2024 OopsNowh. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        `;
    }

    // Clean up expired codes periodically
    cleanupExpiredCodes() {
        const now = Date.now();
        for (const [email, data] of this.verificationCodes.entries()) {
            if (now > data.expiresAt) {
                this.verificationCodes.delete(email);
            }
        }
    }
}

module.exports = EmailService;
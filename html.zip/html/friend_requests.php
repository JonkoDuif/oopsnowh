<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../database_improved.php';

try {
    $db = Database::getInstance();
    
    if (!$db->isConnected()) {
        throw new Exception('Database connection failed');
    }
    
    $conn = $db->getConnection();
    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    
    switch ($action) {
        case 'send_request':
            $senderId = $_POST['sender_id'] ?? null;
            $receiverId = $_POST['receiver_id'] ?? null;
            
            if (!$senderId || !$receiverId) {
                throw new Exception('Sender and receiver IDs are required');
            }
            
            if ($senderId == $receiverId) {
                throw new Exception('Cannot send friend request to yourself');
            }
            
            // Check if users exist
            $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE id IN (?, ?)");
            $stmt->execute([$senderId, $receiverId]);
            if ($stmt->fetchColumn() != 2) {
                throw new Exception('One or both users do not exist');
            }
            
            // Check if already friends
            $stmt = $conn->prepare("SELECT COUNT(*) FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
            $stmt->execute([$senderId, $receiverId, $receiverId, $senderId]);
            if ($stmt->fetchColumn() > 0) {
                throw new Exception('Users are already friends');
            }
            
            // Check if request already exists
            $stmt = $conn->prepare("SELECT status FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
            $stmt->execute([$senderId, $receiverId, $receiverId, $senderId]);
            $existingRequest = $stmt->fetch();
            
            if ($existingRequest) {
                if ($existingRequest['status'] === 'pending') {
                    throw new Exception('Friend request already pending');
                }
                // Update existing request
                $stmt = $conn->prepare("UPDATE friend_requests SET sender_id = ?, receiver_id = ?, status = 'pending', updated_at = NOW() WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
                $stmt->execute([$senderId, $receiverId, $senderId, $receiverId, $receiverId, $senderId]);
            } else {
                // Create new request
                $stmt = $conn->prepare("INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (?, ?, 'pending')");
                $stmt->execute([$senderId, $receiverId]);
            }
            
            echo json_encode(['success' => true, 'message' => 'Friend request sent']);
            break;
            
        case 'accept_request':
            $requestId = $_POST['request_id'] ?? null;
            $userId = $_POST['user_id'] ?? null;
            
            if (!$requestId || !$userId) {
                throw new Exception('Request ID and user ID are required');
            }
            
            // Get request details
            $stmt = $conn->prepare("SELECT sender_id, receiver_id FROM friend_requests WHERE id = ? AND receiver_id = ? AND status = 'pending'");
            $stmt->execute([$requestId, $userId]);
            $request = $stmt->fetch();
            
            if (!$request) {
                throw new Exception('Friend request not found or not pending');
            }
            
            $conn->beginTransaction();
            
            try {
                // Update request status
                $stmt = $conn->prepare("UPDATE friend_requests SET status = 'accepted', updated_at = NOW() WHERE id = ?");
                $stmt->execute([$requestId]);
                
                // Add friendship (both directions)
                $stmt = $conn->prepare("INSERT INTO friendships (user_id, friend_id) VALUES (?, ?), (?, ?)");
                $stmt->execute([$request['sender_id'], $request['receiver_id'], $request['receiver_id'], $request['sender_id']]);
                
                $conn->commit();
                echo json_encode(['success' => true, 'message' => 'Friend request accepted']);
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
            break;
            
        case 'decline_request':
            $requestId = $_POST['request_id'] ?? null;
            $userId = $_POST['user_id'] ?? null;
            
            if (!$requestId || !$userId) {
                throw new Exception('Request ID and user ID are required');
            }
            
            $stmt = $conn->prepare("UPDATE friend_requests SET status = 'declined', updated_at = NOW() WHERE id = ? AND receiver_id = ? AND status = 'pending'");
            $stmt->execute([$requestId, $userId]);
            
            if ($stmt->rowCount() === 0) {
                throw new Exception('Friend request not found or not pending');
            }
            
            echo json_encode(['success' => true, 'message' => 'Friend request declined']);
            break;
            
        case 'get_requests':
            $userId = $_GET['user_id'] ?? null;
            
            if (!$userId) {
                throw new Exception('User ID is required');
            }
            
            // Get pending requests received by user
            $stmt = $conn->prepare("
                SELECT fr.id, fr.sender_id, u.username as sender_username, fr.created_at
                FROM friend_requests fr
                JOIN users u ON fr.sender_id = u.id
                WHERE fr.receiver_id = ? AND fr.status = 'pending'
                ORDER BY fr.created_at DESC
            ");
            $stmt->execute([$userId]);
            $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'requests' => $requests]);
            break;
            
        case 'remove_friend':
            $userId = $_POST['user_id'] ?? null;
            $friendId = $_POST['friend_id'] ?? null;
            
            if (!$userId || !$friendId) {
                throw new Exception('User ID and friend ID are required');
            }
            
            $conn->beginTransaction();
            
            try {
                // Remove friendship (both directions)
                $stmt = $conn->prepare("DELETE FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
                $stmt->execute([$userId, $friendId, $friendId, $userId]);
                
                // Remove any pending requests between users
                $stmt = $conn->prepare("DELETE FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
                $stmt->execute([$userId, $friendId, $friendId, $userId]);
                
                $conn->commit();
                echo json_encode(['success' => true, 'message' => 'Friend removed']);
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
            break;
            
        default:
            throw new Exception('Invalid action');
    }
    
} catch (Exception $e) {
    error_log('Friend requests error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
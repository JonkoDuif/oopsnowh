# Complete VPS Setup Guide for oopsnowh.com

This guide will help you deploy your game to a VPS with proper SSL certificates and production configuration.

## Prerequisites

- **VPS with Ubuntu 20.04+ or Debian 10+**
- **Domain name** (`oopsnowh.com`) pointing to your VPS IP
- **Root or sudo access** to the VPS
- **SSH access** to the VPS

## Step 1: Initial VPS Setup

### 1.1 Connect to your VPS
```bash
ssh root@your-vps-ip
# or
ssh your-username@your-vps-ip
```

### 1.2 Update the system
```bash
sudo apt update && sudo apt upgrade -y
```

### 1.3 Install required software
```bash
# Install Node.js (version 18.x)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PHP and SQLite
sudo apt install -y php php-cli php-sqlite3 php-json php-mbstring

# Install Git and other utilities
sudo apt install -y git curl wget unzip

# Install UFW firewall
sudo apt install -y ufw
```

### 1.4 Configure firewall
```bash
# Allow SSH (important - don't lock yourself out!)
sudo ufw allow ssh

# Allow HTTP and HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Allow game server ports
sudo ufw allow 8000/tcp
sudo ufw allow 8081/tcp
sudo ufw allow 8082/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

## Step 2: Domain and DNS Setup

### 2.1 Point your domain to VPS
In your domain registrar's control panel:
- Create an **A record** for `oopsnowh.com` pointing to your VPS IP
- Create an **A record** for `www.oopsnowh.com` pointing to your VPS IP

### 2.2 Verify DNS propagation
```bash
# Check if domain points to your VPS
nslookup oopsnowh.com
dig oopsnowh.com
```

## Step 3: SSL Certificate Setup

### 3.1 Install Certbot
```bash
sudo apt update
sudo apt install -y certbot
```

### 3.2 Generate SSL certificates
```bash
# Stop any web servers that might be using port 80
sudo systemctl stop apache2 2>/dev/null || true
sudo systemctl stop nginx 2>/dev/null || true

# Generate certificate using standalone mode
sudo certbot certonly --standalone \
    --non-interactive \
    --agree-tos \
    --email your-email@example.com \
    -d oopsnowh.com \
    -d www.oopsnowh.com
```

### 3.3 Verify certificates
```bash
# Check if certificates were created
sudo ls -la /etc/letsencrypt/live/oopsnowh.com/

# You should see:
# cert.pem -> ../../archive/oopsnowh.com/cert1.pem
# chain.pem -> ../../archive/oopsnowh.com/chain1.pem
# fullchain.pem -> ../../archive/oopsnowh.com/fullchain1.pem
# privkey.pem -> ../../archive/oopsnowh.com/privkey1.pem
```

### 3.4 Set certificate permissions
```bash
# Set proper permissions for Node.js to read certificates
sudo chmod 644 /etc/letsencrypt/live/oopsnowh.com/fullchain.pem
sudo chmod 600 /etc/letsencrypt/live/oopsnowh.com/privkey.pem

# Add current user to ssl-cert group (if exists)
sudo usermod -a -G ssl-cert $USER
```

## Step 4: Deploy Your Game

### 4.1 Create deployment directory
```bash
sudo mkdir -p /var/www/oopsnowh
sudo chown $USER:$USER /var/www/oopsnowh
cd /var/www/oopsnowh
```

### 4.2 Option A: Upload using the deployment script (Recommended)

On your local machine:
```bash
# Edit the deployment script
nano deploy-to-vps.sh

# Update these variables:
# VPS_USER="your-username"  # or "root"
# VPS_HOST="your-vps-ip"

# Make script executable
chmod +x deploy-to-vps.sh

# Run deployment
./deploy-to-vps.sh
```

### 4.2 Option B: Manual upload

```bash
# Upload files using scp
scp -r /path/to/your/local/oopsnowh/* root@your-vps-ip:/var/www/oopsnowh/

# Or clone from Git repository
git clone https://github.com/your-username/oopsnowh.git /var/www/oopsnowh
```

### 4.3 Install dependencies and setup
```bash
cd /var/www/oopsnowh

# Install Node.js dependencies
npm install

# Set file permissions
chmod +x start-production.sh
chmod +x setup-ssl.sh
sudo chown -R www-data:www-data .
```

## Step 5: Start Production Servers

### 5.1 Start servers
```bash
cd /var/www/oopsnowh

# Start all servers with SSL support
./start-production.sh
```

### 5.2 Verify servers are running
```bash
# Check running processes
ps aux | grep node
ps aux | grep php

# Check server logs
tail -f game-server.log
tail -f lobby-wallet.log
tail -f web-server.log
```

## Step 6: Test Your Deployment

### 6.1 Test website
- Visit `https://oopsnowh.com` in your browser
- Check that SSL certificate is valid (green lock icon)
- Verify the game loads without errors

### 6.2 Test WebSocket connections
- Open browser developer tools (F12)
- Go to Console tab
- Look for WebSocket connection messages
- Should see successful WSS connections to:
  - `wss://oopsnowh.com:8081` (game server)
  - `wss://oopsnowh.com:8082` (lobby wallet server)

### 6.3 Test game functionality
- Try joining a lobby
- Test multiplayer features
- Verify wallet functionality

## Step 7: Production Management

### 7.1 Process management with PM2 (Recommended)
```bash
# Install PM2 globally
sudo npm install -g pm2

# Stop current servers
pkill -f "node server.js"
pkill -f "node lobbyWalletServer.js"
pkill -f "php -S"

# Start with PM2
SSL_ENABLED=true NODE_ENV=production pm2 start server.js --name "game-server"
SSL_ENABLED=true NODE_ENV=production pm2 start lobbyWalletServer.js --name "lobby-wallet"
pm2 start "php -S 0.0.0.0:8000" --name "web-server"

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
# Follow the instructions shown

# Check PM2 status
pm2 status
pm2 logs
```

### 7.2 SSL certificate auto-renewal
```bash
# Test renewal
sudo certbot renew --dry-run

# Setup automatic renewal (already configured by certbot)
sudo systemctl status certbot.timer
```

### 7.3 Monitoring and logs
```bash
# View real-time logs
tail -f /var/www/oopsnowh/*.log

# Check system resources
htop
df -h
free -h

# Check network connections
netstat -tulpn | grep :808
```

## Troubleshooting

### SSL Certificate Issues
```bash
# Check certificate status
sudo certbot certificates

# Renew certificates manually
sudo certbot renew

# Check certificate files
sudo ls -la /etc/letsencrypt/live/oopsnowh.com/
```

### WebSocket Connection Issues
```bash
# Check if ports are open
sudo netstat -tulpn | grep :8081
sudo netstat -tulpn | grep :8082

# Test SSL connection
openssl s_client -connect oopsnowh.com:8081

# Check firewall
sudo ufw status
```

### Server Issues
```bash
# Restart servers
./start-production.sh

# Check server logs for errors
tail -f game-server.log
tail -f lobby-wallet.log

# Check system logs
sudo journalctl -f
```

### Performance Issues
```bash
# Check system resources
htop
iostat

# Check disk space
df -h

# Check memory usage
free -h
```

## Security Best Practices

1. **Keep system updated**:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

2. **Use SSH keys instead of passwords**
3. **Configure fail2ban for SSH protection**
4. **Regular backups of your database and configuration**
5. **Monitor server logs regularly**
6. **Keep SSL certificates up to date**

## Backup Strategy

```bash
# Create backup script
cat > /var/www/oopsnowh/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/oopsnowh"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup database and configuration
tar -czf $BACKUP_DIR/oopsnowh_backup_$DATE.tar.gz \
    /var/www/oopsnowh/data/ \
    /var/www/oopsnowh/*.json \
    /var/www/oopsnowh/*.js \
    /var/www/oopsnowh/*.php

# Keep only last 7 backups
find $BACKUP_DIR -name "oopsnowh_backup_*.tar.gz" -mtime +7 -delete
EOF

chmod +x /var/www/oopsnowh/backup.sh

# Add to crontab for daily backups
echo "0 2 * * * /var/www/oopsnowh/backup.sh" | sudo crontab -
```

---

🎉 **Congratulations!** Your game should now be running on your VPS with SSL support!

For support or questions, check the server logs and ensure all prerequisites are met.